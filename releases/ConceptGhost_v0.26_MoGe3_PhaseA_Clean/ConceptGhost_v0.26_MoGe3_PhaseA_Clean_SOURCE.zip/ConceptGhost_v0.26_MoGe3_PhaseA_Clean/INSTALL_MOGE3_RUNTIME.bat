@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\install_moge3_runtime.ps1"
pause

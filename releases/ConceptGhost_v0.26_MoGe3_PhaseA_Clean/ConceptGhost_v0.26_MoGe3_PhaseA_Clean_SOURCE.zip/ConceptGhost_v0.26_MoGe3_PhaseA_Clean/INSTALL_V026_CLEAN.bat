@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\install_v026_clean.ps1"
pause

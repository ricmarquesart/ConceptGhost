@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\remove_semantic_assist_runtime.ps1"
pause

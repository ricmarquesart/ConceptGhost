$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot

$PreferredComfy = "C:\Users\rmarq\AppData\Local\Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"
$Comfy = $PreferredComfy
if (-not (Test-Path $Comfy)) {
    $Candidates = @(
        (Join-Path $env:LOCALAPPDATA "Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"),
        (Join-Path $env:LOCALAPPDATA "Programs\@comfyorgcomfyui-electron\resources\ComfyUI")
    )
    $Comfy = $Candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $Comfy -or -not (Test-Path $Comfy)) {
    $Comfy = Read-Host "ComfyUI root not found. Enter full path to ComfyUI"
}
if (-not (Test-Path $Comfy)) { throw "ComfyUI root not found: $Comfy" }

$Src = Join-Path $Root "custom_nodes\ConceptGhost_Stage68"
$Dst = Join-Path $Comfy "custom_nodes\ConceptGhost_Stage68"
if (-not (Test-Path $Src)) { throw "Bundle custom node source missing: $Src" }

# Fresh replacement is intentional: it prevents retired files from surviving an overlay install.
if (Test-Path $Dst) { Remove-Item -LiteralPath $Dst -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Dst | Out-Null
Copy-Item (Join-Path $Src "*") $Dst -Recurse -Force

$WfSrc = Join-Path $Root "Workflows\Project"
$WfDst = Join-Path $Comfy "user\default\workflows\ConceptGhost"
if (Test-Path $WfDst) { Remove-Item -LiteralPath $WfDst -Recurse -Force }
New-Item -ItemType Directory -Force -Path $WfDst | Out-Null
Copy-Item (Join-Path $WfSrc "*.json") $WfDst -Force

# The retired private runtime has its own ownership marker. Delete only when ownership is proven.
$Cleanup = Join-Path $PSScriptRoot "remove_semantic_assist_runtime.ps1"
if (Test-Path $Cleanup) { & $Cleanup }

Write-Host "ConceptGhost v0.26 clean workflow installed to: $Comfy" -ForegroundColor Green
Write-Host "MoGe-2 and all non-ConceptGhost runtimes remain untouched." -ForegroundColor Green
Write-Host "MoGe-3 is still isolated. Run INSTALL_MOGE3_RUNTIME.bat to install/repair Stage A1." -ForegroundColor Cyan

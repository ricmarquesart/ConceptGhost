param([switch]$WhatIf)
$ErrorActionPreference = "Stop"
$runtime = Join-Path $env:LOCALAPPDATA "ConceptGhost-SemanticAssist-v1"
$marker = Join-Path $runtime "OWNED_BY_CONCEPTGHOST_SEMANTIC_ASSIST_V1.txt"
Write-Host "ConceptGhost - Remove Semantic Assist private runtime" -ForegroundColor Cyan
if (-not (Test-Path $runtime)) { Write-Host "[OK] Runtime not present: $runtime"; exit 0 }
if (-not (Test-Path $marker)) { throw "Safety stop: ownership marker missing. Refusing to delete $runtime" }
if ($WhatIf) { Write-Host "[WHATIF] Would remove: $runtime"; exit 0 }
Remove-Item -LiteralPath $runtime -Recurse -Force
if (Test-Path $runtime) { throw "Runtime still exists after removal: $runtime" }
Write-Host "[OK] Removed Semantic Assist private runtime only." -ForegroundColor Green
Write-Host "Shared/global Python packages and all MoGe runtimes were left untouched."

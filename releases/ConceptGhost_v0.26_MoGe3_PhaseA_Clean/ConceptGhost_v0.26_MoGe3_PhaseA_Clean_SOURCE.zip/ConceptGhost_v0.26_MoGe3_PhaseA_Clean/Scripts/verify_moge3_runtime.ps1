param([string]$RuntimeRoot = "$env:LOCALAPPDATA\ConceptGhost-MoGeRuntime-v1")
$ErrorActionPreference = "Stop"
$Python = Join-Path $RuntimeRoot "python\python.exe"
$Verify = Join-Path $RuntimeRoot "worker\verify_moge3_runtime.py"
if (-not (Test-Path $Python)) { throw "Private MoGe Python missing: $Python" }
if (-not (Test-Path $Verify)) { throw "MoGe verifier missing: $Verify" }
$env:CONCEPTGHOST_MOGE_RUNTIME = $RuntimeRoot
$env:HF_HOME = Join-Path $RuntimeRoot "cache\hf"
$env:HUGGINGFACE_HUB_CACHE = Join-Path $RuntimeRoot "cache\hf\hub"
$env:TORCH_HOME = Join-Path $RuntimeRoot "cache\torch"
& $Python $Verify
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "MoGe-3 runtime verification PASS." -ForegroundColor Green

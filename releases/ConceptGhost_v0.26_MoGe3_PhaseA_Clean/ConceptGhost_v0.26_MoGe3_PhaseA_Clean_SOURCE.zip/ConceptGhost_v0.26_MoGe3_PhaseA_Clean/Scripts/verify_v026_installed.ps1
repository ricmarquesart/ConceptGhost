$ErrorActionPreference = "Stop"
$PreferredComfy = "C:\Users\rmarq\AppData\Local\Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"
$Comfy = $PreferredComfy
if (-not (Test-Path $Comfy)) {
    $Candidate = Join-Path $env:LOCALAPPDATA "Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"
    if (Test-Path $Candidate) { $Comfy = $Candidate }
}
if (-not (Test-Path $Comfy)) { throw "Expected ComfyUI root not found: $Comfy" }

$Pkg = Join-Path $Comfy "custom_nodes\ConceptGhost_Stage68"
$Required = @("nodes.py","conceptghost_geometry.py","conceptghost_maya_worker.py","conceptghost_contracts.py","conceptghost_io.py","__init__.py")
foreach ($f in $Required) {
    if (-not (Test-Path (Join-Path $Pkg $f))) { throw "Missing installed file: $f" }
}
if (Test-Path (Join-Path $Pkg "conceptghost_semantics.py")) { throw "Retired Semantic source still exists in active custom node" }
$FeatureTokens = 'ConceptGhostSemanticAssist|CG_SEMANTIC_BUNDLE|conceptghost_semantics|SEMANTIC_GEOMETRY_GATES|semantic_assist_enabled|semantic_backend|semantic_refine_mode|semantic_profile'
$bad = Get-ChildItem $Pkg -File -Filter *.py | Select-String -Pattern $FeatureTokens
if ($bad) { throw "Retired Semantic feature references remain in active custom node" }

$Wf = Join-Path $Comfy "user\default\workflows\ConceptGhost\ConceptGhost_Master.json"
if (-not (Test-Path $Wf)) { throw "Installed master workflow missing: $Wf" }
$wfBad = Select-String -Path $Wf -Pattern $FeatureTokens
if ($wfBad) { throw "Retired Semantic feature references remain in installed workflow" }

$SemanticRuntime = Join-Path $env:LOCALAPPDATA "ConceptGhost-SemanticAssist-v1"
if (Test-Path $SemanticRuntime) { throw "Retired private Semantic runtime still exists: $SemanticRuntime" }

$txt = Get-Content (Join-Path $Pkg "nodes.py") -Raw
if ($txt -notmatch "final_topology_camera_facing_face_vertex_normals_v0.25") { throw "v0.25 normal repair policy missing" }
Write-Host "ConceptGhost v0.26 installed-file verification PASS." -ForegroundColor Green

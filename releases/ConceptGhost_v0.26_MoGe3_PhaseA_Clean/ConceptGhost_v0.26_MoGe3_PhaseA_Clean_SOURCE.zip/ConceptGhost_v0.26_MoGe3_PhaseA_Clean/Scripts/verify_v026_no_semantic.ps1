$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Required = @(
 "custom_nodes\\ConceptGhost_Stage68\\nodes.py",
 "custom_nodes\\ConceptGhost_Stage68\\conceptghost_geometry.py",
 "custom_nodes\\ConceptGhost_Stage68\\conceptghost_contracts.py",
 "custom_nodes\\ConceptGhost_Stage68\\conceptghost_io.py",
 "custom_nodes\\ConceptGhost_Stage68\\conceptghost_maya_worker.py",
 "Workflows\\Project\\ConceptGhost_Master.json",
 "Scripts\\install_moge3_runtime.ps1",
 "Scripts\\remove_semantic_assist_runtime.ps1"
)
foreach ($rel in $Required) {
    if (-not (Test-Path (Join-Path $Root $rel))) { throw "Missing required file: $rel" }
}
$Forbidden = @(
 "custom_nodes\\ConceptGhost_Stage68\\conceptghost_semantics.py",
 "SEMANTIC_ASSIST.bat",
 "Tools\\SemanticAssist",
 "requirements-semantic.lock.txt"
)
foreach ($rel in $Forbidden) {
    if (Test-Path (Join-Path $Root $rel)) { throw "Forbidden Semantic-only artifact present: $rel" }
}

# Search only active runtime/workflow files. Cleanup/migration scripts intentionally name the retired runtime.
$ActiveFiles = @(
    (Get-ChildItem (Join-Path $Root "custom_nodes\\ConceptGhost_Stage68") -File -Filter *.py),
    (Get-Item (Join-Path $Root "Workflows\\Project\\ConceptGhost_Master.json"))
) | ForEach-Object { $_ }
$FeatureTokens = 'ConceptGhostSemanticAssist|CG_SEMANTIC_BUNDLE|conceptghost_semantics|SEMANTIC_GEOMETRY_GATES|semantic_assist_enabled|semantic_backend|semantic_refine_mode|semantic_profile'
$bad = $ActiveFiles | Select-String -Pattern $FeatureTokens
if ($bad) {
    $bad | Select-Object -First 30 | ForEach-Object { Write-Host $_ }
    throw "Semantic Assist feature references remain in active runtime/workflow"
}

$Installer = Get-Content (Join-Path $Root "Scripts\\install_moge3_runtime.ps1") -Raw
if ($Installer -notmatch '\$\{LASTEXITCODE\}: \$Exe') { throw "MoGe-3 PowerShell interpolation fix is missing" }
if ($Installer -match '\$LASTEXITCODE: \$Exe') { throw "Invalid PowerShell LASTEXITCODE interpolation remains" }

Write-Host "[PASS] v0.26 no-Semantic package verified." -ForegroundColor Green

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np


def _configure_private_cache(runtime_root: Path) -> None:
    cache = runtime_root / "cache"
    hf = cache / "hf"
    torch_cache = cache / "torch"
    hf.mkdir(parents=True, exist_ok=True)
    torch_cache.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HF_HOME", str(hf))
    os.environ.setdefault("HUGGINGFACE_HUB_CACHE", str(hf / "hub"))
    os.environ.setdefault("TORCH_HOME", str(torch_cache))


def _load_rgb(path: Path):
    from PIL import Image
    img = Image.open(path).convert("RGB")
    return np.asarray(img, dtype=np.uint8)


def _to_numpy(x):
    if x is None:
        return None
    if isinstance(x, (list, tuple)):
        return [_to_numpy(v) for v in x]
    try:
        return x.detach().float().cpu().numpy()
    except AttributeError:
        return np.asarray(x)


def main() -> int:
    ap = argparse.ArgumentParser(description="ConceptGhost isolated MoGe-3 worker")
    ap.add_argument("--request", required=True, help="JSON request path")
    args = ap.parse_args()

    request_path = Path(args.request).resolve()
    req = json.loads(request_path.read_text(encoding="utf-8"))
    runtime_root = Path(req.get("runtime_root") or request_path.parents[2]).resolve()
    _configure_private_cache(runtime_root)

    import torch
    from moge.model.v3 import MoGeModel

    image_path = Path(req["image"]).resolve()
    result_npz = Path(req["result_npz"]).resolve()
    result_json = Path(req["result_json"]).resolve()
    result_npz.parent.mkdir(parents=True, exist_ok=True)
    result_json.parent.mkdir(parents=True, exist_ok=True)

    model_name = str(req.get("model") or "Ruicheng/moge-3-vitl")
    refine_steps = int(req.get("refine_steps", 3))
    resolution_level = int(req.get("resolution_level", 9))
    return_per_step = bool(req.get("return_per_step", False))
    use_fp16 = bool(req.get("use_fp16", True))
    fov_x = req.get("fov_x")
    fov_x = None if fov_x is None else float(fov_x)

    if not torch.cuda.is_available():
        raise RuntimeError("MoGe-3 ConceptGhost runtime requires CUDA for the target production path")
    device = torch.device("cuda")

    t0 = time.perf_counter()
    model = MoGeModel.from_pretrained(model_name).to(device).eval()
    t_load = time.perf_counter() - t0

    rgb = _load_rgb(image_path)
    image = torch.from_numpy(rgb).to(device=device, dtype=torch.float32).permute(2, 0, 1) / 255.0
    torch.cuda.reset_peak_memory_stats(device)
    t1 = time.perf_counter()
    output = model.infer(
        image,
        resolution_level=resolution_level,
        fov_x=fov_x,
        refine_steps=refine_steps,
        return_per_step=return_per_step,
        use_fp16=use_fp16,
    )
    torch.cuda.synchronize(device)
    infer_s = time.perf_counter() - t1
    peak_vram = int(torch.cuda.max_memory_allocated(device))

    arrays = {}
    for key in ("points", "depth", "intrinsics", "mask", "normal"):
        if key in output and output[key] is not None:
            arrays[key] = _to_numpy(output[key])
    if return_per_step:
        for key in ("points_per_step", "depth_per_step", "intrinsics_per_step"):
            if key in output and output[key] is not None:
                values = _to_numpy(output[key])
                for i, value in enumerate(values):
                    arrays[f"{key}_{i}"] = value
    np.savez_compressed(result_npz, **arrays)

    finite = {}
    for key in ("points", "depth", "intrinsics", "normal"):
        if key in arrays:
            finite[key] = bool(np.isfinite(arrays[key]).all())
    report = {
        "schema": "ConceptGhost.MoGe3WorkerResult.v1",
        "status": "PASS",
        "engine": "MoGe",
        "version": "v3",
        "model": model_name,
        "refine_steps": refine_steps,
        "resolution_level": resolution_level,
        "return_per_step": return_per_step,
        "use_fp16": use_fp16,
        "atlas_fov_used": fov_x is not None,
        "fov_x": fov_x,
        "device": str(device),
        "torch_version": torch.__version__,
        "cuda_runtime": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(device),
        "model_load_seconds": t_load,
        "inference_seconds": infer_s,
        "peak_vram_bytes": peak_vram,
        "finite": finite,
        "result_npz": str(result_npz),
    }
    result_json.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

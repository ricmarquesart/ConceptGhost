@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_v026_no_semantic.ps1"
pause

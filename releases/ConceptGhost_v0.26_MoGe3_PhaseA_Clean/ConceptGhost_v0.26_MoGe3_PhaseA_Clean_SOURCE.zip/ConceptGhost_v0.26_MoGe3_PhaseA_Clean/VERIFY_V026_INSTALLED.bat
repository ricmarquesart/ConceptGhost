@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_v026_installed.ps1"
pause

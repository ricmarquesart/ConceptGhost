from __future__ import annotations

from copy import deepcopy
from typing import Any

SCHEMA_VERSION = "0.8"
CANONICAL_COORDINATES = {
    "handedness": "right-handed",
    "up_axis": "+Y",
    "right_axis": "+X",
    "camera_forward": "-Z",
    "image_origin": "upper-left",
    "image_u": "+right",
    "image_v": "+down",
}

PRESET_PARAMETERS = {
    "Max Reference": {
        "da3_confidence_threshold": 0.10,
        "da3_downsample": 1,
        "moge_resolution_level": 9,
        "moge_force_projection": True,
        "moge_apply_mask": True,
        "canonical_downsample": 1,
        "point_width": 0.01,
        "candidate_unfrozen": True,
    },
    "Balanced": {
        "da3_confidence_threshold": 0.15,
        "da3_downsample": 2,
        "moge_resolution_level": 7,
        "moge_force_projection": True,
        "moge_apply_mask": True,
        "canonical_downsample": 2,
        "point_width": 0.012,
        "candidate_unfrozen": True,
    },
    "Fast Test": {
        "da3_confidence_threshold": 0.20,
        "da3_downsample": 4,
        "moge_resolution_level": 5,
        "moge_force_projection": True,
        "moge_apply_mask": True,
        "canonical_downsample": 4,
        "point_width": 0.015,
        "candidate_unfrozen": True,
    },
}


def build_run_config(
    source_name: str,
    preset: str = "Max Reference",
    camera_mode: str = "Auto",
    geometry_engine: str = "MoGe",
    compare_both: bool = False,
    extra_diagnostics: bool = False,
) -> dict[str, Any]:
    if preset not in PRESET_PARAMETERS:
        raise ValueError(f"Unknown preset: {preset}")
    if camera_mode not in {"Auto", "Atlas Learned", "Atlas VP"}:
        raise ValueError(f"Unknown camera mode: {camera_mode}")
    if geometry_engine not in {"DA3", "MoGe"}:
        raise ValueError(f"Unknown geometry engine: {geometry_engine}")
    return {
        "schema": f"ConceptGhost.RunConfig.v{SCHEMA_VERSION}",
        "source_name": source_name,
        "preset": preset,
        "camera_mode": camera_mode,
        "geometry_engine": geometry_engine,
        "compare_both": bool(compare_both),
        "extra_diagnostics": bool(extra_diagnostics),
        "optional_meshes": False,
        "resolved_parameters": deepcopy(PRESET_PARAMETERS[preset]),
    }



def derive_run_status(
    *,
    camera_valid: bool,
    geometry_has_points: bool,
    integration_pass: bool,
    geometry_health_pass: bool,
    maya_ok: bool,
    ply_ok: bool,
    usd_ok: bool,
    fbx_ok: bool,
) -> dict[str, Any]:
    maya_ghost_ready = bool(camera_valid and geometry_has_points and integration_pass and geometry_health_pass and usd_ok and maya_ok)
    complete = bool(maya_ghost_ready and ply_ok and fbx_ok)
    if complete:
        run_status = "PASS"
    elif geometry_has_points or camera_valid or ply_ok or usd_ok or maya_ok:
        run_status = "PARTIAL"
    else:
        run_status = "FAIL"
    authoritative = bool(camera_valid and geometry_has_points and integration_pass and geometry_health_pass)
    return {
        "run_status": run_status,
        "maya_ghost_ready": maya_ghost_ready,
        "deliverable_package_complete": complete,
        "authoritative": authoritative,
    }


def validate_scene_bundle(scene: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    if scene.get("schema") != f"ConceptGhost.SceneBundle.v{SCHEMA_VERSION}":
        errors.append("invalid SceneBundle schema")
    if not isinstance(scene.get("camera"), dict):
        errors.append("missing camera bundle")
    elif scene["camera"].get("schema") != f"ConceptGhost.CameraBundle.v{SCHEMA_VERSION}":
        errors.append("invalid camera bundle schema")
    if not isinstance(scene.get("geometry"), dict):
        errors.append("missing canonical geometry")
    elif scene["geometry"].get("schema") != f"ConceptGhost.CanonicalGeometry.v{SCHEMA_VERSION}":
        errors.append("invalid canonical geometry schema")
    if scene.get("coordinate_convention") != CANONICAL_COORDINATES:
        errors.append("canonical coordinate convention mismatch")
    status = scene.get("status", {})
    if status.get("run_status") not in {"PASS", "PARTIAL", "FAIL"}:
        errors.append("invalid run status")
    return not errors, errors


def json_safe(value: Any) -> Any:
    """Convert common numerical/container values to JSON-safe equivalents."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if hasattr(value, "tolist"):
        return value.tolist()
    return str(value)

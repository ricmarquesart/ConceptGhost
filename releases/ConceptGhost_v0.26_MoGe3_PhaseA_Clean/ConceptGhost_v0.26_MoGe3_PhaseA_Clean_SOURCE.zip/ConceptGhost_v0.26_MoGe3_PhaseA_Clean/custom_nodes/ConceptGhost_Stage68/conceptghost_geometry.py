from __future__ import annotations

import math
from typing import Any
import numpy as np




def _to_numpy(value: Any, dtype=None) -> np.ndarray:
    if value is None:
        return np.array([])
    if isinstance(value, np.ndarray):
        arr = value
    elif hasattr(value, "detach"):
        arr = value.detach().cpu().numpy()
    elif hasattr(value, "cpu") and hasattr(value, "numpy"):
        arr = value.cpu().numpy()
    else:
        arr = np.asarray(value)
    return arr.astype(dtype, copy=False) if dtype is not None else arr



def _obj_get(obj: Any, name: str, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def camera_bundle_from_atlas_solve(
    solve: Any,
    *,
    requested_mode: str,
    final_solver: str,
    fallback_attempted: bool = False,
    fallback_reason: str | None = None,
) -> dict[str, Any]:
    if solve is None:
        return {
            "schema": "ConceptGhost.CameraBundle.v0.8",
            "valid": False,
            "quality": {"pass": False, "reason": "missing_solve"},
            "provenance": {
                "requested_mode": requested_mode,
                "final_solver": final_solver,
                "fallback_attempted": bool(fallback_attempted),
                "fallback_reason": fallback_reason,
            },
        }
    camera = _obj_get(solve, "camera")
    intr = _obj_get(camera, "intrinsics")
    extr = _obj_get(camera, "extrinsics")
    w = int(_obj_get(solve, "image_width", _obj_get(intr, "image_width", 0)) or 0)
    h = int(_obj_get(solve, "image_height", _obj_get(intr, "image_height", 0)) or 0)
    fx = _obj_get(intr, "fx_px")
    fy = _obj_get(intr, "fy_px")
    cx = _obj_get(intr, "cx_px")
    cy = _obj_get(intr, "cy_px")
    if fx is None:
        focal_mm = _obj_get(intr, "focal_length_mm")
        sensor_width = _obj_get(intr, "sensor_width_mm", 36.0)
        if focal_mm and sensor_width and w:
            fx = float(focal_mm) / float(sensor_width) * float(w)
    if fy is None:
        fy = fx
    if cx is None:
        cx = (w - 1) * 0.5 if w else 0.0
    if cy is None:
        cy = (h - 1) * 0.5 if h else 0.0
    world = np.asarray(_obj_get(extr, "camera_world_matrix", np.eye(4)), dtype=np.float64)
    view = np.asarray(_obj_get(extr, "camera_view_matrix", np.eye(4)), dtype=np.float64)
    valid = bool(
        w > 0 and h > 0 and fx is not None and fy is not None
        and np.isfinite([float(fx), float(fy), float(cx), float(cy)]).all()
        and float(fx) > 0 and float(fy) > 0
        and world.shape == (4,4) and view.shape == (4,4)
        and np.isfinite(world).all() and np.isfinite(view).all()
    )
    fov_h = float(np.degrees(2.0 * np.arctan(float(w) / (2.0 * float(fx))))) if valid else 0.0
    conf_obj = _obj_get(camera, "confidence")
    conf = _obj_get(conf_obj, "global_score", _obj_get(solve, "confidence", 0.0))
    try:
        conf = float(conf)
    except Exception:
        conf = 0.0
    return {
        "schema": "ConceptGhost.CameraBundle.v0.8",
        "valid": valid,
        "image_width": w,
        "image_height": h,
        "horizontal_fov_deg": fov_h,
        "intrinsics": {
            "fx_px": float(fx or 0.0),
            "fy_px": float(fy or 0.0),
            "cx_px": float(cx or 0.0),
            "cy_px": float(cy or 0.0),
            "focal_length_mm": _obj_get(intr, "focal_length_mm"),
            "sensor_width_mm": _obj_get(intr, "sensor_width_mm", 36.0),
            "sensor_height_mm": _obj_get(intr, "sensor_height_mm"),
            "lens_model": _obj_get(intr, "lens_model", "pinhole"),
            "distortion": _obj_get(intr, "distortion", {}) or {},
        },
        "extrinsics": {
            "camera_position": list(_obj_get(extr, "camera_position", (0.0,0.0,0.0))),
            "camera_rotation_matrix": np.asarray(_obj_get(extr, "camera_rotation_matrix", np.eye(3))).tolist(),
            "camera_world_matrix": world.tolist(),
            "camera_view_matrix": view.tolist(),
            "coordinate_system": _obj_get(extr, "coordinate_system", "right_handed"),
            "up_axis": _obj_get(extr, "up_axis", "Y"),
            "projection_convention": _obj_get(extr, "projection_convention", "Atlas pinhole camera, image origin top-left."),
        },
        "quality": {
            "pass": valid,
            "policy": "vertical_slice_structural_camera_gate_candidate_unfrozen",
            "confidence": conf,
        },
        "provenance": {
            "requested_mode": requested_mode,
            "final_solver": final_solver,
            "source_method": _obj_get(solve, "source_method", "unknown"),
            "camera_authority": "Atlas",
            "learned_prior": "GeoCalib via AtlasLearnedSolveFromImage" if final_solver == "Atlas Learned" else None,
            "confidence": conf,
            "fallback_attempted": bool(fallback_attempted),
            "fallback_reason": fallback_reason,
        },
        "native": {
            "focal_length_inferred": bool(_obj_get(camera, "focal_length_inferred", False)),
            "notes": list(_obj_get(camera, "notes", []) or []),
            "debug_metadata": _obj_get(solve, "debug_metadata", {}) or {},
        },
    }

def _first_scalar_channel(arr: Any) -> np.ndarray:
    """Return one scalar HxW plane from common ComfyUI tensor layouts.

    IMAGE outputs are normally BxHxWxC, while MASK outputs are BxHxW.
    The previous helper understood the IMAGE layout but treated a BxHxW mask
    as HxWxC, which later expanded a (1,H,W) sky mask into (H,W,W) during
    resizing.  Single-image ConceptGhost runs always consume batch element 0.
    """
    x = _to_numpy(arr, np.float32)
    if x.ndim == 4:              # B,H,W,C
        x = x[0]
        if x.ndim == 3 and x.shape[-1] in (1, 3, 4):
            x = x[..., 0]
    elif x.ndim == 3:
        # A native ComfyUI MASK is B,H,W.  Check the single-image batch axis
        # before the channel-count heuristic so narrow images with W=3/4 are
        # not mistaken for H,W,C tensors.
        if x.shape[0] == 1:
            x = x[0]
        elif x.shape[-1] in (1, 3, 4):   # H,W,C
            x = x[..., 0]
    return np.asarray(x, dtype=np.float32)


def _first_rgb(arr: Any) -> np.ndarray:
    x = _to_numpy(arr, np.float32)
    if x.ndim == 4:
        x = x[0]
    if x.ndim == 2:
        x = np.repeat(x[..., None], 3, axis=-1)
    if x.shape[-1] > 3:
        x = x[..., :3]
    return np.clip(x, 0.0, 1.0)


def _resize_nearest(img: np.ndarray, h: int, w: int) -> np.ndarray:
    if img.shape[:2] == (h, w):
        return img
    ys = np.clip(np.round(np.linspace(0, img.shape[0]-1, h)).astype(np.int64), 0, img.shape[0]-1)
    xs = np.clip(np.round(np.linspace(0, img.shape[1]-1, w)).astype(np.int64), 0, img.shape[1]-1)
    return img[ys][:, xs]


def da3_depth_edge_strength(depth: np.ndarray) -> np.ndarray:
    """Return DA3-Blender-compatible normalized Sobel edge strength [0,1]."""
    dm = np.asarray(depth, dtype=np.float32)
    if dm.ndim != 2:
        raise ValueError(f"depth edge filter expects HxW, got {dm.shape}")
    if dm.size == 0:
        return np.zeros(dm.shape, dtype=np.float32)
    finite = np.isfinite(dm)
    fill = float(np.nanmedian(dm[finite])) if finite.any() else 0.0
    work = np.where(finite, dm, fill).astype(np.float32)
    p = np.pad(work, 1, mode="edge")
    gx = (
        -p[:-2, :-2] + p[:-2, 2:]
        -2.0 * p[1:-1, :-2] + 2.0 * p[1:-1, 2:]
        -p[2:, :-2] + p[2:, 2:]
    )
    gy = (
        -p[:-2, :-2] - 2.0 * p[:-2, 1:-1] - p[:-2, 2:]
        +p[2:, :-2] + 2.0 * p[2:, 1:-1] + p[2:, 2:]
    )
    mag = np.sqrt(gx * gx + gy * gy)
    finite_mag = np.isfinite(mag)
    if not finite_mag.any():
        return np.zeros(dm.shape, dtype=np.float32)
    mn = float(np.nanmin(mag[finite_mag])); mx = float(np.nanmax(mag[finite_mag]))
    if mx > mn:
        norm = (mag - mn) / (mx - mn)
    else:
        norm = np.zeros_like(mag, dtype=np.float32)
    return np.clip(norm, 0.0, 1.0).astype(np.float32)


def da3_depth_edge_mask(depth: np.ndarray, threshold: float = 12.0 / 255.0) -> np.ndarray:
    """Return pixels rejected by the DA3-Blender depth-edge strategy."""
    return np.asarray(da3_depth_edge_strength(depth) >= float(threshold), dtype=bool)




def grid_geometric_boundary_strength(points: np.ndarray, valid_mask: np.ndarray | None = None) -> np.ndarray:
    """Estimate solver-neutral depth discontinuity strength on an HxWx3 grid."""
    pts = np.asarray(points, dtype=np.float32)
    if pts.ndim != 3 or pts.shape[-1] != 3:
        raise ValueError(f"points must be HxWx3, got {pts.shape}")
    h, w, _ = pts.shape
    valid = np.isfinite(pts).all(axis=-1)
    if valid_mask is not None:
        valid &= np.asarray(valid_mask, dtype=bool)
    dist = np.linalg.norm(pts, axis=-1)
    strength = np.zeros((h, w), dtype=np.float32)
    def apply(a_slice, b_slice):
        a = dist[a_slice]; b = dist[b_slice]
        va = valid[a_slice]; vb = valid[b_slice]
        rel = np.abs(a-b) / np.maximum(np.maximum(np.abs(a), np.abs(b)), 1e-6)
        val = np.where(va & vb, np.clip(rel / 0.12, 0.0, 1.0), 0.0).astype(np.float32)
        strength[a_slice] = np.maximum(strength[a_slice], val)
        strength[b_slice] = np.maximum(strength[b_slice], val)
    if w > 1:
        apply((slice(None), slice(0,-1)), (slice(None), slice(1,None)))
    if h > 1:
        apply((slice(0,-1), slice(None)), (slice(1,None), slice(None)))
    return strength


def _scaled_intrinsics(camera: dict[str, Any], h: int, w: int) -> tuple[float,float,float,float]:
    intr = camera["intrinsics"]
    src_w = float(camera["image_width"])
    src_h = float(camera["image_height"])
    sx = w / src_w
    sy = h / src_h
    fx = float(intr["fx_px"]) * sx
    fy = float(intr["fy_px"]) * sy
    cx = float(intr["cx_px"]) * sx
    cy = float(intr["cy_px"]) * sy
    return fx, fy, cx, cy


def _transform_camera_local_to_world(local_xyz: np.ndarray, camera: dict[str, Any]) -> np.ndarray:
    world = np.asarray(camera["extrinsics"]["camera_world_matrix"], dtype=np.float64)
    homo = np.concatenate([local_xyz.astype(np.float64), np.ones((len(local_xyz),1), dtype=np.float64)], axis=1)
    # Atlas schema stores conventional 4x4 transforms. Column-vector form is used here.
    out = (world @ homo.T).T[:, :3]
    return out.astype(np.float32)




_TRUSTED_ATLAS_SCALE_SOURCES = {
    "depth_ground_plane",
    "manual_override",
    "face_reference",
    "reference_scale",
    "known_reference",
    "measured_reference",
}


def atlas_metric_scale_registration(
    camera: dict[str, Any],
    local_xyz_grid: np.ndarray,
    valid_mask: np.ndarray,
    *,
    lower_image_fraction: float = 0.60,
) -> tuple[float, dict[str, Any]]:
    """Register relative geometry to metric Atlas camera height using geometric evidence."""
    report: dict[str, Any] = {
        "applied": False,
        "scale_applied": False,
        "scale_factor": 1.0,
        "scale_sources": [],
        "source_confidences": [],
        "residual_error": None,
        "reason": "not_evaluated",
        "reason_if_not_applied": "not_evaluated",
        "units": "relative",
        "policy": "atlas_metric_multi_evidence_v0.26_geometry_only",
        "geometric_ground_candidate_count": 0,
    }
    def reject(reason: str) -> tuple[float, dict[str, Any]]:
        report["reason"] = reason; report["reason_if_not_applied"] = reason
        report["applied"] = False; report["scale_applied"] = False
        report["scale_factor"] = 1.0; report["units"] = "relative"
        return 1.0, report
    grid=np.asarray(local_xyz_grid,dtype=np.float64); valid=np.asarray(valid_mask,dtype=bool)
    if grid.ndim != 3 or grid.shape[-1] != 3 or valid.shape != grid.shape[:2]: return reject("invalid_geometry_layout")
    debug=((camera.get("native") or {}).get("debug_metadata") or {})
    scale_source=str(debug.get("scale_source") or "unknown"); report["atlas_scale_source"]=scale_source
    if scale_source not in _TRUSTED_ATLAS_SCALE_SOURCES:
        report["scale_sources"]=[f"atlas_scale_source:{scale_source}"]; report["source_confidences"]=[0.0]
        return reject("atlas_scale_not_trusted")
    try: atlas_source_confidence=float(debug.get("scale_depth_confidence",debug.get("scale_confidence",1.0)))
    except Exception: atlas_source_confidence=1.0
    atlas_source_confidence=float(np.clip(atlas_source_confidence,0.0,1.0))
    extr=camera.get("extrinsics") or {}; world=np.asarray(extr.get("camera_world_matrix",np.eye(4)),dtype=np.float64)
    if world.shape != (4,4) or not np.isfinite(world).all(): return reject("invalid_atlas_world_matrix")
    pos=np.asarray(extr.get("camera_position",world[:3,3]),dtype=np.float64).reshape(-1)
    if pos.size < 2 or not np.isfinite(pos[:3]).all(): return reject("invalid_atlas_camera_position")
    target_height=abs(float(pos[1])); report["target_camera_height_m"]=target_height
    if target_height <= 1e-4: return reject("atlas_camera_height_unavailable")
    rotation=world[:3,:3]; rel_world=np.einsum("ij,hwj->hwi",rotation,grid); rel_y=rel_world[...,1]
    h,w=valid.shape; row_gate=np.arange(h,dtype=np.float64)[:,None] >= float(h)*float(lower_image_fraction)
    candidates=valid & row_gate & np.isfinite(rel_y) & (rel_y < -1e-7)
    min_candidates=max(200,int(round(h*w*0.002))); report["geometric_ground_candidate_count"]=int(candidates.sum())
    values=rel_y[candidates]; report["candidate_count"]=int(values.size); report["min_candidate_count"]=int(min_candidates)
    if values.size < min_candidates: return reject("insufficient_ground_candidates")
    lo,hi=np.percentile(values,[1.0,99.0])
    if not np.isfinite([lo,hi]).all(): return reject("nonfinite_ground_distribution")
    if abs(float(hi-lo)) <= 1e-10:
        mode=float(np.median(values)); band_width=max(abs(mode)*0.05,1e-6)
    else:
        hist,edges=np.histogram(values,bins=192,range=(float(lo),float(hi))); peak=int(np.argmax(hist))
        mode=float((edges[peak]+edges[peak+1])*0.5); bin_width=float(edges[peak+1]-edges[peak]); band_width=max(3.0*bin_width,abs(mode)*0.05,1e-6)
    inliers=candidates & (np.abs(rel_y-mode) <= band_width); inlier_values=rel_y[inliers]
    if inlier_values.size == 0: return reject("no_ground_mode_inliers")
    ground_y=float(np.median(inlier_values)); raw_height=-ground_y; mad=float(np.median(np.abs(inlier_values-ground_y)))
    support=float(inlier_values.size/max(values.size,1)); relative_mad=float(mad/max(raw_height,1e-12)); scale=float(target_height/max(raw_height,1e-12))
    support_confidence=float(np.clip(support/0.20,0.0,1.0)); planarity_confidence=float(np.clip(1.0-relative_mad/0.15,0.0,1.0))
    sample_target=max(float(min_candidates),float(h*w)*0.01); sample_confidence=float(np.clip(float(inlier_values.size)/max(sample_target,1.0),0.0,1.0))
    evidence_score=float(0.25*atlas_source_confidence+0.20*support_confidence+0.35*planarity_confidence+0.20*sample_confidence)
    report.update({"mode_y_engine_units":mode,"band_width_engine_units":band_width,"inlier_count":int(inlier_values.size),"support_ratio":support,
        "raw_camera_height_engine_units":raw_height,"relative_mad":relative_mad,"residual_error":relative_mad,"scale_factor_candidate":scale,
        "scale_sources":["atlas_camera_height","ground_plane_support","ground_plane_planarity","ground_sample_count"],
        "source_confidences":[atlas_source_confidence,support_confidence,planarity_confidence,sample_confidence],"evidence_score":evidence_score,
        "minimum_support_ratio":0.08,"minimum_evidence_score":0.70})
    if raw_height <= 1e-6: return reject("degenerate_ground_height")
    if support < 0.08: return reject("weak_ground_support")
    if int(inlier_values.size) < 30: return reject("insufficient_ground_inliers")
    if relative_mad > 0.15: return reject("ground_not_planar_enough")
    if not (0.05 <= scale <= 200.0): return reject("scale_factor_out_of_guardrail")
    if evidence_score < 0.70: return reject("metric_evidence_score_too_low")
    report.update({"applied":True,"scale_applied":True,"scale_factor":scale,"reason":"atlas_metric_ground_registration_pass","reason_if_not_applied":None,"units":"meters"})
    return scale,report



def canonicalize_da3(camera: dict[str, Any], evidence: dict[str, Any], source_image: Any) -> dict[str, Any]:
    depth=_first_scalar_channel(evidence["depth_raw"])
    if depth.ndim != 2: raise ValueError(f"DA3 raw depth must resolve to HxW, got {depth.shape}")
    h,w=depth.shape; rgb_img=_resize_nearest(_first_rgb(source_image),h,w)
    confidence=_first_scalar_channel(evidence.get("confidence")); confidence=np.ones((h,w),dtype=np.float32) if confidence.size==0 else _resize_nearest(confidence,h,w)
    sky=_first_scalar_channel(evidence.get("sky_mask")); sky=np.zeros((h,w),dtype=np.float32) if sky.size==0 else _resize_nearest(sky,h,w)
    threshold=float(evidence.get("candidate_confidence_threshold",0.10)); edge_threshold=float(evidence.get("da3_edge_threshold",12.0/255.0))
    edge_strength=da3_depth_edge_strength(depth); edge_reject=edge_strength >= edge_threshold
    valid=np.isfinite(depth) & (depth>0) & (sky<0.5) & (~edge_reject)
    confidence_finite=np.isfinite(confidence); strong_confidence=valid & confidence_finite & (confidence>=threshold); weak_confidence=valid & (~strong_confidence)
    confidence_for_output=np.where(confidence_finite,confidence,0.0).astype(np.float32)
    v,u=np.indices((h,w),dtype=np.float32); fx,fy,cx,cy=_scaled_intrinsics(camera,h,w); z=depth
    x=(u-cx)/max(fx,1e-8)*z; y_up=-(v-cy)/max(fy,1e-8)*z; z_back=-z; local_grid=np.stack([x,y_up,z_back],axis=-1)
    metric_scale,metric_report=atlas_metric_scale_registration(camera,local_grid,valid)
    local=(local_grid*metric_scale)[valid]; world=_transform_camera_local_to_world(local,camera)
    rgb=np.clip(np.rint(rgb_img[valid]*255.0),0,255).astype(np.uint8); conf=confidence_for_output[valid].astype(np.float32)
    su=u[valid]*(float(camera["image_width"])/w); sv=v[valid]*(float(camera["image_height"])/h); source_uv=np.stack([su,sv],axis=-1).astype(np.float32)
    return {"schema":"ConceptGhost.CanonicalGeometry.v0.8","engine":"da3","xyz":world,"rgb":rgb,"confidence":conf,"source_uv":source_uv,
        "grid_xy":np.stack([u[valid],v[valid]],axis=-1).astype(np.int32),"point_count":int(len(world)),"native_resolution":[int(w),int(h)],
        "depth_semantics":evidence.get("depth_semantics","camera_z_raw"),"refinement":{"da3_blender_edge_filter":True,"edge_threshold_normalized":edge_threshold,
        "edge_rejected_pixels":int(edge_reject.sum()),"edge_rejected_ratio":float(edge_reject.mean()) if edge_reject.size else 0.0,
        "confidence_policy":"retain_low_confidence_as_weak_evidence","confidence_threshold":threshold,"strong_confidence_points":int(strong_confidence.sum()),
        "weak_confidence_points":int(weak_confidence.sum()),"weak_confidence_retained_ratio":float(weak_confidence.sum()/max(valid.sum(),1)),
        "atlas_metric_scale_registration":metric_report},"geometric_boundary_strength":edge_strength[valid].astype(np.float32)}




def canonicalize_moge(camera: dict[str, Any], evidence: dict[str, Any], source_image: Any) -> dict[str, Any]:
    geom=evidence["moge_geometry"]; points=_to_numpy(geom["points"],np.float32)
    if points.ndim==4: points=points[0]
    if points.ndim!=3 or points.shape[-1]!=3: raise ValueError(f"MoGe points must resolve to HxWx3, got {points.shape}")
    h,w,_=points.shape; image=_resize_nearest(_first_rgb(geom.get("image",source_image)),h,w); mask=_to_numpy(geom.get("mask"))
    if mask.size==0: valid=np.ones((h,w),dtype=bool)
    else:
        if mask.ndim==3: mask=mask[0]
        valid=mask.astype(bool)
    valid &= np.isfinite(points).all(axis=-1); geometric_boundary_grid=grid_geometric_boundary_strength(points,valid)
    local=points.copy(); local[...,1]*=-1.0; local[...,2]*=-1.0
    metric_scale,metric_report=atlas_metric_scale_registration(camera,local,valid)
    local_flat=(local*metric_scale)[valid]; world=_transform_camera_local_to_world(local_flat,camera)
    rgb=np.clip(np.rint(image[valid]*255.0),0,255).astype(np.uint8); v,u=np.indices((h,w),dtype=np.float32)
    su=u[valid]*(float(camera["image_width"])/w); sv=v[valid]*(float(camera["image_height"])/h); source_uv=np.stack([su,sv],axis=-1).astype(np.float32)
    return {"schema":"ConceptGhost.CanonicalGeometry.v0.8","engine":"moge","xyz":world,"rgb":rgb,"confidence":None,"source_uv":source_uv,
        "grid_xy":np.stack([u[valid],v[valid]],axis=-1).astype(np.int32),"point_count":int(len(world)),"native_resolution":[int(w),int(h)],
        "depth_semantics":"native_moge_point_map","refinement":{"atlas_metric_scale_registration":metric_report},
        "geometric_boundary_strength":geometric_boundary_grid[valid].astype(np.float32)}



def canonicalize(camera: dict[str, Any], evidence: dict[str, Any], source_image: Any) -> dict[str, Any]:
    engine=str(evidence.get("engine","")).lower()
    if engine=="da3": return canonicalize_da3(camera,evidence,source_image)
    if engine=="moge": return canonicalize_moge(camera,evidence,source_image)
    raise ValueError(f"Unsupported geometry engine: {engine}")



def reprojection_report(camera: dict[str, Any], canonical: dict[str, Any]) -> dict[str, Any]:
    xyz = np.asarray(canonical["xyz"], dtype=np.float64)
    uv_expected = np.asarray(canonical["source_uv"], dtype=np.float64)
    if len(xyz) == 0:
        return {"pass": False, "valid_projected_points": 0, "rmse_px": None, "median_px": None, "p95_px": None}
    view = np.asarray(camera["extrinsics"]["camera_view_matrix"], dtype=np.float64)
    homo = np.concatenate([xyz, np.ones((len(xyz),1), dtype=np.float64)], axis=1)
    cam = (view @ homo.T).T[:, :3]
    depth = -cam[:,2]
    intr = camera["intrinsics"]
    fx, fy = float(intr["fx_px"]), float(intr["fy_px"])
    cx, cy = float(intr["cx_px"]), float(intr["cy_px"])
    valid = np.isfinite(cam).all(axis=1) & (depth > 1e-8)
    if not valid.any():
        return {"pass": False, "valid_projected_points": 0, "rmse_px": None, "median_px": None, "p95_px": None}
    p = cam[valid]
    d = depth[valid]
    u = fx * (p[:,0] / d) + cx
    v = cy - fy * (p[:,1] / d)
    pred = np.stack([u,v], axis=1)
    err = np.linalg.norm(pred - uv_expected[valid], axis=1)
    rmse = float(np.sqrt(np.mean(err**2)))
    median = float(np.median(err))
    p95 = float(np.percentile(err, 95))
    # This gate only verifies integration consistency; a lenient 2px threshold avoids false negatives from resize conventions.
    return {
        "pass": bool(np.isfinite(rmse) and rmse <= 2.0),
        "valid_projected_points": int(valid.sum()),
        "rmse_px": rmse,
        "median_px": median,
        "p95_px": p95,
        "policy": "integration_consistency_not_depth_accuracy",
    }


def geometry_health(xyz: Any) -> dict[str, Any]:
    pts = np.asarray(xyz, dtype=np.float64).reshape((-1,3)) if np.asarray(xyz).size else np.empty((0,3), dtype=np.float64)
    n = len(pts)
    if n == 0:
        return {
            "pass": False, "catastrophic": True, "point_count": 0,
            "finite_ratio": 0.0, "extreme_outlier_ratio": 1.0,
            "bbox_min": None, "bbox_max": None, "bbox_extent": None,
        }
    finite_rows = np.isfinite(pts).all(axis=1)
    finite_ratio = float(finite_rows.mean())
    finite = pts[finite_rows]
    if len(finite) == 0:
        return {"pass": False, "catastrophic": True, "point_count": n, "finite_ratio": finite_ratio, "extreme_outlier_ratio": 1.0, "bbox_min": None, "bbox_max": None, "bbox_extent": None}
    center = np.median(finite, axis=0)
    radii = np.linalg.norm(finite-center, axis=1)
    med = float(np.median(radii))
    if med <= 1e-9:
        outlier_ratio = 0.0
    else:
        outlier_ratio = float(np.mean(radii > med * 5.0))
    lo = finite.min(axis=0)
    hi = finite.max(axis=0)
    extent = hi-lo
    catastrophic = bool(finite_ratio < 0.50 or not np.isfinite(extent).all() or float(np.max(extent)) <= 1e-9)
    # Only catastrophic geometry is blocked in the vertical slice. Smaller clouds remain inspectable.
    passes = bool(not catastrophic and finite_ratio >= 0.98 and outlier_ratio <= 0.25)
    return {
        "pass": passes,
        "catastrophic": catastrophic,
        "point_count": n,
        "finite_ratio": finite_ratio,
        "extreme_outlier_ratio": outlier_ratio,
        "bbox_min": lo.tolist(),
        "bbox_max": hi.tolist(),
        "bbox_extent": extent.tolist(),
        "policy": "vertical_slice_catastrophic_guard_candidate_unfrozen",
    }

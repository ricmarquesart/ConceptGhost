from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import struct
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np


def sanitize_scene_name(name: str) -> str:
    stem = Path(name).stem if name else "scene"
    clean = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-")
    return clean or "scene"


def make_run_folder(output_root: str | Path, scene_name: str) -> Path:
    root = Path(os.path.expanduser(os.path.expandvars(str(output_root))))
    scene = sanitize_scene_name(scene_name)
    while True:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        run_id = f"{stamp}_{uuid.uuid4().hex[:8]}"
        run = root / scene / run_id
        try:
            run.mkdir(parents=True, exist_ok=False)
            break
        except FileExistsError:
            continue
    for rel in [
        "source", "camera", "diagnostics", "geometry/native/da3", "geometry/native/moge",
        "geometry/canonical", "maya", "meshes", "compare", "logs"
    ]:
        (run / rel).mkdir(parents=True, exist_ok=True)
    return run


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: str | Path, data: dict[str, Any]) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")
    return p


def write_ply_binary(path: str | Path, xyz: np.ndarray, rgb: np.ndarray) -> Path:
    p = Path(path)
    xyz = np.asarray(xyz, dtype="<f4").reshape((-1,3))
    rgb = np.asarray(rgb, dtype=np.uint8).reshape((-1,3))
    if len(xyz) != len(rgb):
        raise ValueError("XYZ/RGB point counts differ")
    p.parent.mkdir(parents=True, exist_ok=True)
    header = (
        "ply\nformat binary_little_endian 1.0\n"
        f"element vertex {len(xyz)}\n"
        "property float x\nproperty float y\nproperty float z\n"
        "property uchar red\nproperty uchar green\nproperty uchar blue\n"
        "end_header\n"
    ).encode("ascii")
    dtype = np.dtype([("x","<f4"),("y","<f4"),("z","<f4"),("r","u1"),("g","u1"),("b","u1")])
    data = np.empty(len(xyz), dtype=dtype)
    data["x"], data["y"], data["z"] = xyz[:,0], xyz[:,1], xyz[:,2]
    data["r"], data["g"], data["b"] = rgb[:,0], rgb[:,1], rgb[:,2]
    with p.open("wb") as f:
        f.write(header)
        data.tofile(f)
    return p


def copy_preview_ply(canonical_ply: str | Path, run_id: str, output_dir: str | Path | None = None) -> Path:
    """Copy the authoritative canonical PLY into ComfyUI host output for preview only.

    The returned file is a transport/cache artifact. It must remain byte-identical
    to the canonical run-local PLY and never becomes the authoritative result.
    """
    src = Path(canonical_ply)
    if not src.is_file():
        raise FileNotFoundError(src)
    if output_dir is None:
        try:
            import folder_paths  # type: ignore
            output_dir = folder_paths.get_output_directory()
        except Exception as exc:
            raise RuntimeError(f"Could not resolve ComfyUI host output directory: {exc}") from exc
    dest = Path(output_dir) / "conceptghost" / "preview" / f"{run_id}_pointcloud.ply"
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    if sha256_file(src) != sha256_file(dest):
        raise RuntimeError("Preview PLY transport copy differs from canonical PLY")
    return dest


def create_run_download_archive(run_dir: str | Path, output_dir: str | Path | None = None) -> dict[str, Any]:
    """Create a complete, per-execution ZIP and a ComfyUI-download transport copy.

    The authoritative run folder remains untouched. The ZIP snapshots every file
    already present in that execution (including Maya, geometry, diagnostics,
    manifests, logs and later-stage outputs) except the ZIP itself.
    """
    run = Path(os.path.expanduser(os.path.expandvars(str(run_dir)))).resolve()
    if not run.is_dir():
        raise RuntimeError(f"ConceptGhost run_dir does not exist: {run}")
    scene = sanitize_scene_name(run.parent.name or "scene")
    archive_name = f"ConceptGhost_{scene}_{run.name}_COMPLETE.zip"
    package_dir = run / "package"
    package_dir.mkdir(parents=True, exist_ok=True)
    archive = package_dir / archive_name
    archive.unlink(missing_ok=True)

    # Make the final package discoverable from inside the run itself.  This is
    # written before inventory/ZIP creation so the archived output_index also
    # explains where the authoritative folder and downloadable snapshot live.
    output_index_path = run / "output_index.json"
    if output_index_path.is_file():
        try:
            output_index = json.loads(output_index_path.read_text(encoding="utf-8"))
            if not isinstance(output_index, dict):
                output_index = {}
        except Exception:
            output_index = {}
        output_index.setdefault("downloads", {})["complete_run"] = {
            "archive_name": archive_name,
            "archive_path": str(archive),
            "saved_run_folder": str(run),
            "comfyui_transport_subfolder": "conceptghost/run_packages",
            "policy": "Complete per-execution snapshot; saved run folder remains authoritative.",
        }
        write_json(output_index_path, output_index)

    files = []
    for path in sorted(x for x in run.rglob("*") if x.is_file()):
        if path.resolve() == archive.resolve():
            continue
        rel = path.relative_to(run).as_posix()
        if rel.endswith("_COMPLETE.zip"):
            continue
        files.append({"relative_path": rel, "bytes": int(path.stat().st_size), "sha256": sha256_file(path)})
    manifest_path = package_dir / "complete_run_manifest.json"
    manifest_payload = {
        "schema": "ConceptGhost.CompleteRunDownload.v0.20",
        "run_dir": str(run),
        "scene_name": scene,
        "archive_name": archive_name,
        "file_count": len(files),
        "files": files,
        "policy": "One ZIP per execution; source run folder remains authoritative.",
    }
    write_json(manifest_path, manifest_payload)

    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for path in sorted(x for x in run.rglob("*") if x.is_file()):
            if path.resolve() == archive.resolve():
                continue
            rel = path.relative_to(run).as_posix()
            if rel.endswith("_COMPLETE.zip"):
                continue
            zf.write(path, arcname=rel)

    if output_dir is None:
        try:
            import folder_paths  # type: ignore
            output_dir = folder_paths.get_output_directory()
        except Exception:
            output_dir = None
    transport = None
    download = None
    if output_dir is not None:
        transport = Path(output_dir) / "conceptghost" / "run_packages" / archive_name
        transport.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(archive, transport)
        if sha256_file(archive) != sha256_file(transport):
            raise RuntimeError("Complete-run ZIP transport copy differs from authoritative archive")
        download = {
            "filename": archive_name,
            "subfolder": "conceptghost/run_packages",
            "type": "output",
        }
    return {
        "run_dir": str(run),
        "archive_path": str(archive),
        "archive_sha256": sha256_file(archive),
        "transport_path": str(transport) if transport is not None else None,
        "download": download,
        "manifest_path": str(manifest_path),
    }


def parse_ply_header(path: str | Path) -> dict[str, Any]:
    vertex_count = None
    with open(path, "rb") as f:
        while True:
            line = f.readline().decode("ascii", errors="strict").strip()
            if line.startswith("element vertex "):
                vertex_count = int(line.split()[-1])
            if line == "end_header":
                break
            if not line:
                raise ValueError("Invalid PLY header")
    return {"vertex_count": vertex_count}


def _usd_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def write_usda_points(path: str | Path, xyz: np.ndarray, rgb: np.ndarray, *, point_width: float, metadata: dict[str, Any]) -> Path:
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    pts=np.asarray(xyz,dtype=np.float32).reshape((-1,3)); cols=np.asarray(rgb,dtype=np.uint8).reshape((-1,3))
    if len(pts)!=len(cols): raise ValueError("xyz/rgb length mismatch")
    with path.open("w", encoding="utf-8", newline="\n") as f:
        f.write("#usda 1.0\n")
        f.write("(\n    defaultPrim = \"ConceptGhostPoints\"\n    upAxis = \"Y\"\n)\n\n")
        f.write('def Points "ConceptGhostPoints" {\n')
        f.write("    point3f[] points = [\n")
        for i,(x,y,z) in enumerate(pts): f.write(f"        ({x:.9g}, {y:.9g}, {z:.9g}){',' if i+1<len(pts) else ''}\n")
        f.write("    ]\n")
        f.write("    color3f[] primvars:displayColor = [\n")
        for i,(r,g,b) in enumerate(cols): f.write(f"        ({r/255.0:.7g}, {g/255.0:.7g}, {b/255.0:.7g}){',' if i+1<len(cols) else ''}\n")
        f.write('    ] ( interpolation = "vertex" )\n')
        f.write(f"    float[] widths = [{float(point_width):.7g}] ( interpolation = \"constant\" )\n")
        f.write(f'    custom string conceptghost:metadata = "{_usd_escape(json.dumps(json_safe(metadata),sort_keys=True))}"\n')
        f.write("}\n")
    return path


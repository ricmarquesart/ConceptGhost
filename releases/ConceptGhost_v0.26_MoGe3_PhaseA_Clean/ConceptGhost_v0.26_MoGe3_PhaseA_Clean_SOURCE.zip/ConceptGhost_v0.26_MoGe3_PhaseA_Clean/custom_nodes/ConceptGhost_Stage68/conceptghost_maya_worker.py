from __future__ import annotations

import argparse
import json
import os
import re
import sys
import traceback
from pathlib import Path
from typing import Any, Iterable


def _clean_name(value: str) -> str:
    value = Path(value or "scene").stem
    value = re.sub(r"[^A-Za-z0-9_]+", "_", value).strip("_")
    return value or "scene"


def build_output_paths(run_dir: str | Path, scene_name: str) -> dict[str, Path]:
    run = Path(run_dir)
    scene = _clean_name(scene_name)
    maya_dir = run / "maya"
    return {
        "ma": maya_dir / f"ConceptGhost_{scene}_Ghost.ma",
        "fbx": maya_dir / f"ConceptGhost_{scene}_Ghost.fbx",
        "camera_fbx": maya_dir / f"ConceptGhost_{scene}_CameraOnly.fbx",
        "manifest": maya_dir / "maya_manifest.json",
    }


def maya_hierarchy_names(scene_name: str) -> dict[str, str]:
    _clean_name(scene_name)  # validate/sanitize input even though hierarchy is canonical.
    return {
        "root": "CG_ROOT",
        "cameras": "CG_CAMERA",
        "matched_camera": "CG_MATCHED_CAMERA",
        "artist_camera": "CG_ARTIST_CAMERA",
        "source": "CG_SOURCE",
        "source_plate": "CG_SOURCE_PLATE",
        "geometry": "CG_GEOMETRY",
        "hero_mesh": "CG_HERO_MESH",
        "fused_points": "CG_FUSED_POINTS",
        "diagnostics": "CG_DIAGNOSTICS",
        "atlas_relief": "CG_ATLAS_RELIEF",
        "moge_native": "CG_MOGE_NATIVE",
        "da3_native": "CG_DA3_NATIVE",
        "metadata": "CG_METADATA",
    }




def fbx_required_camera_names(matched_camera: str, artist_camera: str) -> list[str]:
    return [str(matched_camera), str(artist_camera)]


def fbx_required_export_names(matched_camera: str, artist_camera: str, hero_mesh: str | None = None) -> list[str]:
    names = fbx_required_camera_names(matched_camera, artist_camera)
    if hero_mesh:
        names.append(str(hero_mesh))
    return names


def fbx_export_mel_commands(fbx_path: str | Path) -> list[str]:
    """Robust full-scene FBX export used for the official interchange file.

    Selection export proved unreliable in the artist runtime for cameras.  The
    official scene is intentionally small/curated, so export-all is safer and
    lets the FBX plug-in walk the complete camera hierarchy.
    """
    path = str(fbx_path).replace("\\", "/")
    while "//" in path:
        path = path.replace("//", "/")
    return [
        "FBXResetExport;",
        "FBXExportCameras -v true;",
        "FBXExportLights -v false;",
        "FBXExportUpAxis y;",
        "FBXExportEmbeddedTextures -v true;",
        "FBXExportBakeComplexAnimation -v false;",
        f'FBXExport -f "{path}";',
    ]


def fbx_camera_only_export_mel_commands(fbx_path: str | Path) -> list[str]:
    path = str(fbx_path).replace("\\", "/")
    while "//" in path:
        path = path.replace("//", "/")
    return [
        "FBXResetExport;",
        "FBXExportCameras -v true;",
        "FBXExportLights -v false;",
        "FBXExportUpAxis y;",
        f'FBXExport -f "{path}" -s;',
    ]


def _verify_fbx_camera_roundtrip(
    cmds, mel, fbx_path: Path, required_cameras: list[str], expected_signatures: dict[str, dict[str, Any]] | None = None,
    required_meshes: list[str] | None = None, expected_mesh_signatures: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Round-trip verify camera presence *and* calibrated camera properties."""
    result: dict[str, Any] = {
        "status": "NOT_RUN",
        "required_cameras": list(required_cameras),
        "found_cameras": [],
        "missing_cameras": list(required_cameras),
        "signature_checks": {},
        "required_meshes": list(required_meshes or []),
        "found_meshes": [],
        "missing_meshes": list(required_meshes or []),
        "mesh_signature_checks": {},
    }
    if not fbx_path.exists():
        result["status"] = "FAIL"
        result["error"] = "FBX file was not created"
        return result
    try:
        cmds.file(new=True, force=True)
        fbx_norm = str(fbx_path).replace("\\", "/")
        mel.eval(f'FBXImport -f "{fbx_norm}";')
        found: list[str] = []
        signature_failures: list[str] = []
        for camera in required_cameras:
            if cmds.objExists(camera):
                shapes = cmds.listRelatives(camera, shapes=True, type="camera") or []
                if shapes:
                    found.append(camera)
                    if expected_signatures and camera in expected_signatures:
                        actual = _camera_signature(cmds, camera)
                        check = _compare_camera_signatures(expected_signatures[camera], actual)
                        result["signature_checks"][camera] = check
                        if not check["pass"]:
                            signature_failures.append(camera)
        missing = [name for name in required_cameras if name not in found]
        found_meshes: list[str] = []
        mesh_signature_failures: list[str] = []
        for mesh in required_meshes or []:
            if cmds.objExists(mesh):
                shapes = cmds.listRelatives(mesh, shapes=True, type="mesh") or []
                if shapes:
                    found_meshes.append(mesh)
                    if expected_mesh_signatures and mesh in expected_mesh_signatures:
                        actual_mesh = _mesh_signature(cmds, mesh)
                        mesh_check = _compare_mesh_signatures(expected_mesh_signatures[mesh], actual_mesh)
                        result["mesh_signature_checks"][mesh] = mesh_check
                        if not mesh_check["pass"]:
                            mesh_signature_failures.append(mesh)
        missing_meshes = [name for name in (required_meshes or []) if name not in found_meshes]
        passed = not missing and not signature_failures and not missing_meshes and not mesh_signature_failures
        result.update({
            "status": "PASS" if passed else "FAIL",
            "found_cameras": found,
            "missing_cameras": missing,
            "signature_failures": signature_failures,
            "found_meshes": found_meshes,
            "missing_meshes": missing_meshes,
            "mesh_signature_failures": mesh_signature_failures,
        })
    except Exception as exc:
        result["status"] = "FAIL"
        result["error"] = str(exc)
    return result



def _camera_signature(cmds, camera_transform: str) -> dict[str, Any]:
    shapes = cmds.listRelatives(camera_transform, shapes=True, type="camera") or []
    if not shapes:
        raise ValueError(f"{camera_transform} has no camera shape")
    shape = shapes[0]

    def get(name: str, default: float = 0.0) -> float:
        try:
            return float(cmds.getAttr(f"{shape}.{name}"))
        except Exception:
            return float(default)

    return {
        "focal_length_mm": get("focalLength"),
        "horizontal_film_aperture_in": get("horizontalFilmAperture"),
        "vertical_film_aperture_in": get("verticalFilmAperture"),
        "horizontal_film_offset": get("horizontalFilmOffset"),
        "vertical_film_offset": get("verticalFilmOffset"),
        "world_matrix": [float(v) for v in cmds.xform(camera_transform, query=True, worldSpace=True, matrix=True)],
    }



def _mesh_signature(cmds, mesh_transform: str, sample_vertices: int = 8) -> dict[str, Any]:
    shapes = cmds.listRelatives(mesh_transform, shapes=True, type="mesh") or []
    if not shapes:
        raise ValueError(f"{mesh_transform} has no mesh shape")
    vertex_count = int(cmds.polyEvaluate(mesh_transform, vertex=True))
    bbox = [float(v) for v in cmds.exactWorldBoundingBox(mesh_transform)]
    take = min(max(vertex_count, 0), int(sample_vertices))
    sample: list[float] = []
    if take > 0:
        values = cmds.xform(f"{mesh_transform}.vtx[0:{take-1}]", query=True, worldSpace=True, translation=True) or []
        sample = [float(v) for v in values]
    return {"vertex_count": vertex_count, "bbox": bbox, "sample_world_positions": sample}


def _compare_mesh_signatures(expected: dict[str, Any], actual: dict[str, Any]) -> dict[str, Any]:
    mismatches: dict[str, Any] = {}
    if int(expected.get("vertex_count", -1)) != int(actual.get("vertex_count", -2)):
        mismatches["vertex_count"] = {"expected": expected.get("vertex_count"), "actual": actual.get("vertex_count")}
    for key, tol in (("bbox", 1e-5), ("sample_world_positions", 1e-5)):
        ev = [float(v) for v in expected.get(key, [])]
        av = [float(v) for v in actual.get(key, [])]
        if len(ev) != len(av) or any(abs(a-b) > tol for a,b in zip(ev, av)):
            mismatches[key] = {"expected": ev, "actual": av, "tolerance": tol}
    return {"pass": not mismatches, "mismatches": mismatches}


def _compare_camera_signatures(expected: dict[str, Any], actual: dict[str, Any]) -> dict[str, Any]:
    scalar_tolerances = {
        "focal_length_mm": 1e-4,
        "horizontal_film_aperture_in": 1e-6,
        "vertical_film_aperture_in": 1e-6,
        "horizontal_film_offset": 1e-6,
        "vertical_film_offset": 1e-6,
    }
    mismatches: dict[str, Any] = {}
    for key, tol in scalar_tolerances.items():
        ev = float(expected.get(key, 0.0)); av = float(actual.get(key, 0.0))
        if abs(ev - av) > tol:
            mismatches[key] = {"expected": ev, "actual": av, "tolerance": tol}
    ew = [float(v) for v in expected.get("world_matrix", [])]
    aw = [float(v) for v in actual.get("world_matrix", [])]
    if len(ew) != 16 or len(aw) != 16 or any(abs(a-b) > 1e-5 for a,b in zip(ew, aw)):
        mismatches["world_matrix"] = {"expected": ew, "actual": aw, "tolerance": 1e-5}
    return {"pass": not mismatches, "mismatches": mismatches}


def _configure_source_image_plane(cmds, plane_shape: str) -> dict[str, Any]:
    attrs = {"fit": 1, "displayOnlyIfCurrent": 1}
    for attr, value in attrs.items():
        if cmds.attributeQuery(attr, node=plane_shape, exists=True):
            cmds.setAttr(f"{plane_shape}.{attr}", value)
    return {
        "fit": "best",
        "fit_policy": "reference aspect == film gate == resolution gate",
        "display_only_if_current": True,
    }


def _worker_exit_code(manifest: dict[str, Any]) -> int:
    ma_ok = (manifest.get("ma") or {}).get("status") == "PASS"
    fbx_ok = (manifest.get("fbx") or {}).get("status") == "PASS"
    hero = manifest.get("hero_mesh") or {}
    hero_ok = not hero.get("requested") or hero.get("status") == "PASS"
    return 0 if ma_ok and fbx_ok and hero_ok else 2

def discover_mayapy(*, explicit: str | None = None, search_roots: Iterable[str | Path] | None = None) -> Path | None:
    """Find mayapy without changing PATH or user/system environment variables."""
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))
    env_explicit = os.environ.get("CONCEPTGHOST_MAYAPY")
    if env_explicit:
        candidates.append(Path(env_explicit))

    if search_roots is None:
        search_roots = [
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Autodesk",
            Path(os.environ.get("PROGRAMW6432", r"C:\Program Files")) / "Autodesk",
        ]
    roots = [Path(r) for r in search_roots]
    # Prefer newer Mayas for MayaUSD availability; Stage 8 still records the actual version.
    for version in (2026, 2025, 2024, 2023, 2022, 2020, 2019, 2018):
        for root in roots:
            candidates.append(root / f"Maya{version}" / "bin" / "mayapy.exe")

    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file():
            return candidate
    return None


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")


def _progress(run_dir: str | Path, message: str) -> None:
    line = f"[ConceptGhost MayaWorker] {message}"
    print(line, flush=True)
    try:
        path = Path(run_dir) / "logs" / "maya_worker_progress.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def _sensor_in(sensor_mm: float) -> float:
    return float(sensor_mm) / 25.4


def atlas_matrix_to_maya_flat(matrix: Any) -> list[float]:
    """Atlas column-vector row-major affine matrix -> Maya row-vector flat matrix.

    Mirrors Atlas Camera's verified Maya exporter convention: transpose the full
    affine matrix so translation moves from the last column into Maya's last row.
    Both systems are right-handed Y-up, so no axis swap is needed.
    """
    rows = [[float(v) for v in row] for row in matrix]
    if len(rows) != 4 or any(len(row) != 4 for row in rows):
        raise ValueError("camera_world_matrix must be 4x4")
    transposed = [[rows[r][c] for r in range(4)] for c in range(4)]
    return [v for row in transposed for v in row]


def maya_camera_settings_from_bundle(camera: dict[str, Any]) -> dict[str, float | int]:
    """Convert a CameraBundle to Maya settings using the pinned Atlas exporter contract.

    Atlas 9f9ff451 authors principal-point offsets as image-space fractions
    (pixel_offset / image_size).  Do not multiply those values by the physical
    film aperture a second time: doing so changes the solved framing in Maya.
    """
    intr = camera.get("intrinsics", {})
    width = int(camera.get("image_width") or intr.get("image_width") or 0)
    height = int(camera.get("image_height") or intr.get("image_height") or 0)
    if width <= 0 or height <= 0:
        raise ValueError("CameraBundle requires positive image_width/image_height for Maya export")

    focal_raw = intr.get("focal_length_mm")
    if focal_raw is None:
        raise ValueError("CameraBundle requires focal_length_mm for Maya export")
    sensor_w_raw = intr.get("sensor_width_mm")
    if sensor_w_raw is None:
        raise ValueError("CameraBundle requires sensor_width_mm for Maya export")

    focal = float(focal_raw)
    sensor_w = float(sensor_w_raw)
    # The film-back aspect must match the reference image exactly.  Atlas may
    # carry a physical sensor-height estimate, but Maya framing becomes
    # ambiguous if that aspect disagrees with the source resolution.  Keep the
    # solved horizontal sensor width and derive height from the image ratio.
    sensor_h = float(sensor_w * height / width)
    if focal <= 0.0 or sensor_w <= 0.0 or sensor_h <= 0.0:
        raise ValueError("CameraBundle focal/sensor dimensions must be positive")

    cx = float(intr.get("cx_px", width * 0.5))
    cy = float(intr.get("cy_px", height * 0.5))
    return {
        "focal_length_mm": focal,
        "sensor_width_mm": sensor_w,
        "sensor_height_mm": sensor_h,
        "horizontal_film_aperture_in": _sensor_in(sensor_w),
        "vertical_film_aperture_in": _sensor_in(sensor_h),
        # Intentionally mirrors Atlas camera_math.pixel_offset_to_normalized_film_offset.
        "horizontal_film_offset": (cx - width * 0.5) / width,
        "vertical_film_offset": (cy - height * 0.5) / height,
        "image_width": width,
        "image_height": height,
        "device_aspect_ratio": width / height,
        "film_fit": 1,  # Maya enum: horizontal. Gates share the same aspect.
        "pixel_aspect": 1.0,
    }


def _set_camera_from_bundle(cmds, camera_transform: str, camera_shape: str, camera: dict[str, Any]) -> dict[str, float | int]:
    intr = camera.get("intrinsics", {})
    extr = camera.get("extrinsics", {})
    settings = maya_camera_settings_from_bundle(camera)
    cmds.setAttr(f"{camera_shape}.focalLength", settings["focal_length_mm"])
    cmds.setAttr(f"{camera_shape}.horizontalFilmAperture", settings["horizontal_film_aperture_in"])
    cmds.setAttr(f"{camera_shape}.verticalFilmAperture", settings["vertical_film_aperture_in"])
    cmds.setAttr(f"{camera_shape}.nearClipPlane", 0.01)
    cmds.setAttr(f"{camera_shape}.farClipPlane", 100000.0)

    if cmds.attributeQuery("horizontalFilmOffset", node=camera_shape, exists=True):
        cmds.setAttr(f"{camera_shape}.horizontalFilmOffset", settings["horizontal_film_offset"])
    if cmds.attributeQuery("verticalFilmOffset", node=camera_shape, exists=True):
        cmds.setAttr(f"{camera_shape}.verticalFilmOffset", settings["vertical_film_offset"])
    # Explicit gate/framing contract: the film back is already forced to the
    # source-image aspect, and Horizontal fit makes the resolution gate
    # deterministic instead of inheriting a user/default camera setting.
    for attr, value in (
        ("filmFit", int(settings["film_fit"])),
        ("displayResolution", 1),
        ("displayGateMask", 1),
        ("overscan", 1.0),
    ):
        if cmds.attributeQuery(attr, node=camera_shape, exists=True):
            cmds.setAttr(f"{camera_shape}.{attr}", value)

    world = extr.get("camera_world_matrix")
    if world and len(world) == 4:
        cmds.xform(camera_transform, worldSpace=True, matrix=atlas_matrix_to_maya_flat(world))
    else:
        pos = extr.get("camera_position") or (0.0, 0.0, 0.0)
        cmds.xform(camera_transform, worldSpace=True, translation=[float(x) for x in pos])
    return settings


def _prepare_maya_review_view(
    cmds,
    matched_camera: str,
    matched_shape: str,
    settings: dict[str, float | int],
) -> dict[str, Any]:
    """Make Maya open/review the solved framing without changing camera authority.

    The locked ConceptGhost camera remains authoritative.  Maya's default
    ``persp`` startup camera is only synchronized as a disposable viewing copy
    so an artist opening the .ma lands on the recovered framing immediately.
    """
    result: dict[str, Any] = {
        "matched_camera": matched_camera,
        "startup_camera": None,
        "startup_view_synced": False,
        "look_through_requested": False,
    }

    if cmds.objExists("defaultResolution"):
        cmds.setAttr("defaultResolution.width", int(settings["image_width"]))
        cmds.setAttr("defaultResolution.height", int(settings["image_height"]))
        cmds.setAttr("defaultResolution.pixelAspect", float(settings.get("pixel_aspect", 1.0)))
        try:
            cmds.setAttr("defaultResolution.deviceAspectRatio", float(settings["device_aspect_ratio"]))
        except Exception:
            pass

    try:
        cmds.setAttr(f"{matched_shape}.renderable", 1)
    except Exception:
        pass

    if cmds.objExists("persp") and cmds.objExists("perspShape"):
        try:
            world = cmds.xform(matched_camera, query=True, worldSpace=True, matrix=True)
            cmds.xform("persp", worldSpace=True, matrix=world)
            camera_attrs = {
                "focalLength": settings["focal_length_mm"],
                "horizontalFilmAperture": settings["horizontal_film_aperture_in"],
                "verticalFilmAperture": settings["vertical_film_aperture_in"],
                "horizontalFilmOffset": settings["horizontal_film_offset"],
                "verticalFilmOffset": settings["vertical_film_offset"],
                "nearClipPlane": 0.01,
                "farClipPlane": 100000.0,
                "filmFit": int(settings.get("film_fit", 1)),
                "displayResolution": 1,
                "displayGateMask": 1,
                "overscan": 1.0,
            }
            for attr, value in camera_attrs.items():
                try:
                    cmds.setAttr(f"perspShape.{attr}", value)
                except Exception:
                    pass
            result["startup_camera"] = "persp"
            result["startup_view_synced"] = True
        except Exception as exc:
            result["startup_view_error"] = str(exc)

    # Mirrors the pinned Atlas Maya exporter.  In mayapy standalone there may
    # be no modelPanel, so this is best-effort; the synced persp remains the
    # deterministic fallback for the saved scene.
    try:
        cmds.lookThru(matched_camera)
        result["look_through_requested"] = True
    except Exception as exc:
        result["look_through_error"] = str(exc)
    return result


def _create_string_attr(cmds, node: str, name: str, value: str) -> None:
    if not cmds.attributeQuery(name, node=node, exists=True):
        cmds.addAttr(node, longName=name, dataType="string")
    cmds.setAttr(f"{node}.{name}", str(value), type="string")




def _create_hero_mesh_from_payload(cmds, hero_transform: str, payload: dict[str, Any] | None) -> dict[str, Any]:
    """Author the run's Maya-ready E2 mesh directly under CG_HERO_MESH.

    The payload is already in Atlas world space and its UV V coordinate is
    already converted for Maya.  This function must not rotate/flip it again.
    """
    result: dict[str, Any] = {
        "requested": bool(payload),
        "status": "NOT_REQUESTED" if not payload else "FAIL",
        "transform": hero_transform,
        "shape": None,
        "visible_by_default": False,
    }
    if not payload:
        return result
    try:
        import numpy as np  # Maya ships NumPy; keep it worker-local.
        import maya.api.OpenMaya as om  # type: ignore

        npz_path = Path(payload["npz_path"]).resolve()
        if not npz_path.is_file():
            raise FileNotFoundError(f"Hero mesh payload missing: {npz_path}")
        data = np.load(npz_path)
        vertices = np.asarray(data["vertices"], dtype=np.float64)
        faces = np.asarray(data["faces"], dtype=np.int64)
        if vertices.ndim != 2 or vertices.shape[1] != 3 or len(vertices) == 0:
            raise ValueError(f"Invalid hero vertices: {vertices.shape}")
        if faces.ndim != 2 or faces.shape[1] < 3 or len(faces) == 0:
            raise ValueError(f"Invalid hero faces: {faces.shape}")

        sel = om.MSelectionList()
        sel.add(hero_transform)
        parent_obj = sel.getDependNode(0)
        points = om.MPointArray()
        for x, y, z in vertices:
            points.append(om.MPoint(float(x), float(y), float(z)))
        polygon_counts = [int(faces.shape[1])] * int(len(faces))
        polygon_connects = [int(v) for v in faces.reshape(-1)]
        fn = om.MFnMesh()
        fn.create(points, polygon_counts, polygon_connects, parent=parent_obj)
        shape_name = fn.setName(f"{hero_transform}Shape")

        uv_count = 0
        if "uvs" in data:
            uvs = np.asarray(data["uvs"], dtype=np.float64)
            if uvs.ndim == 2 and uvs.shape == (len(vertices), 2):
                fn.setUVs([float(v) for v in uvs[:, 0]], [float(v) for v in uvs[:, 1]])
                fn.assignUVs(polygon_counts, polygon_connects)
                uv_count = int(len(uvs))

        normal_count = 0
        normal_mode = "MAYA_COMPUTED"
        # v0.25: author per-face-vertex normals when available.  A single shared
        # vertex normal can be opposite to one incident polygon on folded 2.5D
        # geometry even when every face winding is correct.  The payload has
        # already hemisphere-clamped each corner against its final face normal.
        if "face_vertex_normals" in data:
            fvn = np.asarray(data["face_vertex_normals"], dtype=np.float64)
            if fvn.ndim == 3 and fvn.shape == (len(faces), faces.shape[1], 3):
                flat_normals = fvn.reshape((-1, 3))
                face_ids = np.repeat(np.arange(len(faces), dtype=np.int32), faces.shape[1]).tolist()
                vertex_ids = faces.reshape(-1).astype(np.int32).tolist()
                setter = getattr(fn, "setFaceVertexNormals", None)
                if setter is not None:
                    setter(
                        [om.MVector(float(x), float(y), float(z)) for x, y, z in flat_normals],
                        face_ids,
                        vertex_ids,
                    )
                    normal_count = int(len(flat_normals))
                    normal_mode = "FACE_VERTEX_PAYLOAD"
        if normal_count == 0 and "normals" in data:
            normals = np.asarray(data["normals"], dtype=np.float64)
            if normals.ndim == 2 and normals.shape == (len(vertices), 3):
                fn.setVertexNormals(
                    [om.MVector(float(x), float(y), float(z)) for x, y, z in normals],
                    list(range(len(vertices))),
                )
                normal_count = int(len(normals))
                normal_mode = "VERTEX_PAYLOAD_FALLBACK"

        shader = cmds.shadingNode("lambert", asShader=True, name="CG_HERO_MESH_MAT")
        shading_group = cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name="CG_HERO_MESH_MAT_SG")
        cmds.connectAttr(f"{shader}.outColor", f"{shading_group}.surfaceShader", force=True)
        texture_path = payload.get("texture_path")
        texture_loaded = False
        if texture_path and Path(texture_path).is_file():
            try:
                file_node = cmds.shadingNode("file", asTexture=True, isColorManaged=True, name="CG_HERO_MESH_BASECOLOR")
            except Exception:
                file_node = cmds.shadingNode("file", asTexture=True, name="CG_HERO_MESH_BASECOLOR")
            place = cmds.shadingNode("place2dTexture", asUtility=True, name="CG_HERO_MESH_UVPLACE")
            try:
                cmds.connectAttr(f"{place}.outUV", f"{file_node}.uvCoord", force=True)
                cmds.connectAttr(f"{place}.outUvFilterSize", f"{file_node}.uvFilterSize", force=True)
            except Exception:
                pass
            cmds.setAttr(f"{file_node}.fileTextureName", str(Path(texture_path).resolve()), type="string")
            cmds.connectAttr(f"{file_node}.outColor", f"{shader}.color", force=True)
            texture_loaded = True
        cmds.sets(hero_transform, edit=True, forceElement=shading_group)


        # Keep the new mesh available in the scene but non-intrusive by default.
        # The artist can enable CG_HERO_MESH with one visibility toggle.
        cmds.setAttr(f"{hero_transform}.visibility", 0)
        _create_string_attr(cmds, hero_transform, "CG_ROLE", "Solver-paired primary mesh; modeling reference")
        _create_string_attr(cmds, hero_transform, "CG_SOURCE_ENGINE", str(payload.get("source_engine", "unknown")))
        _create_string_attr(cmds, hero_transform, "CG_ALIGNMENT", str(payload.get("alignment", "unknown")))
        _create_string_attr(cmds, hero_transform, "CG_AXIS_POLICY", str(payload.get("axis_policy", "canonical world")))
        _create_string_attr(cmds, hero_transform, "CG_COORDINATE_SPACE", str(payload.get("coordinate_space", "Atlas world")))
        _create_string_attr(cmds, hero_transform, "CG_UV_POLICY", str(payload.get("uv_policy", "Maya/DCC-ready")))

        result.update({
            "status": "PASS",
            "source_engine": str(payload.get("source_engine", "unknown")),
            "alignment": str(payload.get("alignment", "unknown")),
            "axis_policy": str(payload.get("axis_policy", "canonical world")),
            "shape": str(shape_name),
            "vertex_count": int(len(vertices)),
            "face_count": int(len(faces)),
            "uv_count": uv_count,
            "normal_count": normal_count,
            "normal_mode": normal_mode,
            "texture_path": str(texture_path) if texture_path else None,
            "texture_loaded": texture_loaded,
            "topology_split": False,
        })
    except Exception as exc:
        result["status"] = "FAIL"
        result["error"] = str(exc)
    return result


def _create_maya_scene(payload: dict[str, Any]) -> dict[str, Any]:
    # Maya imports happen only in the external mayapy process.
    import maya.standalone  # type: ignore
    maya.standalone.initialize(name="python")
    import maya.cmds as cmds  # type: ignore
    import maya.mel as mel  # type: ignore

    run = Path(payload["run_dir"]).resolve()
    _progress(run, "ENTER")
    scene_name = _clean_name(payload["scene_name"])
    names = maya_hierarchy_names(scene_name)
    out = build_output_paths(run, scene_name)
    out["ma"].parent.mkdir(parents=True, exist_ok=True)

    _progress(run, "Maya standalone initialized")
    plugin_status: dict[str, bool] = {}
    for plugin in ("mayaUsdPlugin", "fbxmaya"):
        try:
            if not cmds.pluginInfo(plugin, query=True, loaded=True):
                cmds.loadPlugin(plugin, quiet=True)
            plugin_status[plugin] = bool(cmds.pluginInfo(plugin, query=True, loaded=True))
        except Exception:
            plugin_status[plugin] = False

    _progress(run, f"Plugins: {plugin_status}")
    cmds.file(new=True, force=True)
    try:
        cmds.workspace(str(run), openWorkspace=True)
    except Exception:
        pass

    root = cmds.group(empty=True, name=names["root"])
    cameras_grp = cmds.group(empty=True, name=names["cameras"], parent=root)
    source_grp = cmds.group(empty=True, name=names["source"], parent=root)
    geometry_grp = cmds.group(empty=True, name=names["geometry"], parent=root)
    hero_grp = cmds.group(empty=True, name=names["hero_mesh"], parent=geometry_grp)
    diagnostics_grp = cmds.group(empty=True, name=names["diagnostics"], parent=root)
    cmds.group(empty=True, name=names["atlas_relief"], parent=diagnostics_grp)
    cmds.group(empty=True, name=names["moge_native"], parent=diagnostics_grp)
    cmds.group(empty=True, name=names["da3_native"], parent=diagnostics_grp)
    try:
        cmds.setAttr(f"{diagnostics_grp}.visibility", 0)
    except Exception:
        pass
    metadata_grp = cmds.group(empty=True, name=names["metadata"], parent=root)

    _progress(run, "Scene hierarchy created")
    matched, matched_shape = cmds.camera(name=names["matched_camera"])
    cmds.parent(matched, cameras_grp)
    camera_settings = _set_camera_from_bundle(cmds, matched, matched_shape, payload["camera"])
    review_view = _prepare_maya_review_view(cmds, matched, matched_shape, camera_settings)
    _create_string_attr(cmds, matched, "CG_REFERENCE_RESOLUTION", f"{camera_settings['image_width']}x{camera_settings['image_height']}")
    _create_string_attr(cmds, matched, "CG_REFERENCE_ASPECT", f"{camera_settings['device_aspect_ratio']:.12g}")
    _create_string_attr(cmds, matched, "CG_CAMERA_AUTHORITY", "Atlas CameraBundle")

    artist = cmds.duplicate(matched, name=names["artist_camera"], parentOnly=False)[0]
    # Duplicate can carry locked attrs only after locking, so lock matched after duplicate.
    for attr in ("translateX", "translateY", "translateZ", "rotateX", "rotateY", "rotateZ", "scaleX", "scaleY", "scaleZ"):
        try:
            cmds.setAttr(f"{matched}.{attr}", lock=True, keyable=False, channelBox=True)
        except Exception:
            pass
    try:
        cmds.setAttr(f"{matched_shape}.focalLength", lock=True)
    except Exception:
        pass

    source_image = Path(payload["source_image"]).resolve()
    # Workspace root is run_dir, so keep the authored image path run-local.
    relative_source = source_image.relative_to(run).as_posix() if source_image.is_relative_to(run) else str(source_image)
    try:
        plane_transform, plane_shape = cmds.imagePlane(camera=matched, fileName=relative_source, name=names["source_plate"], showInAllViews=False, maintainRatio=True)
        image_plane_contract = _configure_source_image_plane(cmds, plane_shape)
        try:
            cmds.parent(plane_transform, source_grp)
        except Exception:
            pass
    except Exception as exc:
        plane_transform, plane_shape = None, None
        image_plane_contract = {"status": "FAIL", "error": str(exc)}
        _create_string_attr(cmds, metadata_grp, "sourcePlateWarning", str(exc))

    _progress(run, "Camera and source plate configured")
    if not plugin_status.get("mayaUsdPlugin"):
        raise RuntimeError("mayaUsdPlugin is not available; cannot create the dense Ghost proxy")
    proxy_transform = cmds.createNode("transform", name=names["fused_points"], parent=geometry_grp)
    proxy_shape = cmds.createNode("mayaUsdProxyShape", name=f"{names['fused_points']}Shape", parent=proxy_transform)
    ghost_usda = Path(payload["ghost_usda"]).resolve()
    relative_usd = ghost_usda.relative_to(run).as_posix() if ghost_usda.is_relative_to(run) else str(ghost_usda)
    # MayaUSD normally resolves asset paths through the workspace. Preserve run-local form first.
    if cmds.attributeQuery("filePath", node=proxy_shape, exists=True):
        cmds.setAttr(f"{proxy_shape}.filePath", relative_usd, type="string")
    else:
        raise RuntimeError("mayaUsdProxyShape has no filePath attribute")
    _create_string_attr(cmds, proxy_transform, "CG_SOURCE_ENGINE", str(payload.get("geometry_engine", "unknown")))
    _create_string_attr(cmds, proxy_transform, "CG_PAIR_MESH", names["hero_mesh"])
    _create_string_attr(cmds, proxy_transform, "CG_ALIGNMENT", str((payload.get("hero_mesh_payload") or {}).get("alignment") or "EXACT_SAME_CANONICAL_XYZ"))
    _progress(run, f"USD proxy authored: {relative_usd}")

    _progress(run, "Hero transport mesh START")
    hero_mesh_status = _create_hero_mesh_from_payload(cmds, hero_grp, payload.get("hero_mesh_payload"))
    _progress(run, f"Hero transport mesh DONE status={hero_mesh_status.get('status')} vertices={hero_mesh_status.get('vertex_count')} faces={hero_mesh_status.get('face_count')}")

    _create_string_attr(cmds, metadata_grp, "conceptGhostSchema", payload.get("schema", ""))
    _create_string_attr(cmds, metadata_grp, "geometryEngine", payload.get("geometry_engine", "unknown"))
    _create_string_attr(cmds, metadata_grp, "canonicalConvention", json.dumps(payload.get("coordinate_convention", {}), sort_keys=True))
    if not cmds.attributeQuery("pointCount", node=metadata_grp, exists=True):
        cmds.addAttr(metadata_grp, longName="pointCount", attributeType="long")
    cmds.setAttr(f"{metadata_grp}.pointCount", int(payload.get("point_count", 0)))

    _progress(run, "Maya ASCII save START")
    cmds.file(rename=str(out["ma"]))
    cmds.file(save=True, type="mayaAscii", force=True)
    _progress(run, f"Maya ASCII save DONE path={out['ma']}")

    fbx_error = None
    fbx_verification: dict[str, Any] = {
        "status": "NOT_RUN",
        "required_cameras": fbx_required_camera_names(matched, artist),
        "found_cameras": [],
        "missing_cameras": fbx_required_camera_names(matched, artist),
    }
    camera_only_verification: dict[str, Any] = {
        "status": "NOT_RUN", "path": str(out["camera_fbx"]),
        "required_cameras": fbx_required_camera_names(matched, artist),
    }
    if plugin_status.get("fbxmaya"):
        try:
            # The .ma has already been saved with the full-resolution USD proxy.
            # FBX is a DCC interchange artifact: remove only the in-memory dense
            # proxy before export so FBX never tries to traverse/convert 1M+ USD
            # points. PLY/USD remain the point-cloud authority.
            try:
                if cmds.objExists(proxy_transform):
                    cmds.delete(proxy_transform)
                _progress(run, "Dense USD proxy removed from in-memory FBX export scene")
            except Exception as exc:
                _progress(run, f"USD proxy removal warning: {exc}")

            required_fbx_cameras = fbx_required_camera_names(matched, artist)
            required_fbx_meshes = [hero_grp] if hero_mesh_status.get("status") == "PASS" else []
            expected_signatures = {name: _camera_signature(cmds, name) for name in required_fbx_cameras}
            expected_mesh_signatures = {name: _mesh_signature(cmds, name) for name in required_fbx_meshes}

            # Official FBX: export the complete curated ConceptGhost Maya scene.
            # Previous selection-only export passed synthetic checks but cameras
            # were absent in the artist runtime. Export-all lets the FBX plug-in
            # traverse camera shapes/hierarchy directly.
            _progress(run, "Official FBX export START")
            cmds.select(clear=True)
            for command in fbx_export_mel_commands(out["fbx"]):
                mel.eval(command)
            _progress(run, f"Official FBX export DONE path={out['fbx']}")

            # Independent camera-only artifact for diagnosis/interchange. Include
            # both transform and camera shapes in the selection explicitly.
            camera_nodes = []
            for cam in required_fbx_cameras:
                camera_nodes.append(cam)
                camera_nodes.extend(cmds.listRelatives(cam, shapes=True, type="camera") or [])
            cmds.select(camera_nodes, replace=True)
            for command in fbx_camera_only_export_mel_commands(out["camera_fbx"]):
                mel.eval(command)

            _progress(run, "FBX round-trip verification START")
            fbx_verification = _verify_fbx_camera_roundtrip(
                cmds, mel, out["fbx"], required_fbx_cameras, expected_signatures, required_fbx_meshes, expected_mesh_signatures
            )
            camera_only_verification = _verify_fbx_camera_roundtrip(
                cmds, mel, out["camera_fbx"], required_fbx_cameras, expected_signatures, []
            )
            _progress(run, f"FBX round-trip verification DONE status={fbx_verification.get('status')}")
            if fbx_verification.get("status") != "PASS":
                fbx_error = "Official FBX camera round-trip verification failed"
        except Exception as exc:
            fbx_error = str(exc)
    else:
        fbx_error = "fbxmaya plugin unavailable"

    maya_version = str(cmds.about(version=True))
    hero_required_ok = not hero_mesh_status.get("requested") or hero_mesh_status.get("status") == "PASS"
    manifest = {
        "schema": "ConceptGhost.MayaManifest.v0.8",
        "maya_version": maya_version,
        "plugins": plugin_status,
        "hierarchy": names,
        "ma": {"path": str(out["ma"]), "status": "PASS" if out["ma"].exists() and hero_required_ok else "FAIL"},
        "fbx": {
            "path": str(out["fbx"]),
            "status": "PASS" if out["fbx"].exists() and fbx_verification.get("status") == "PASS" else "FAIL",
            "error": fbx_error,
            "camera_roundtrip": fbx_verification,
            "export_policy": "full_scene_export_all_for_camera_reliability",
        },
        "camera_only_fbx": {
            "path": str(out["camera_fbx"]),
            "status": "PASS" if out["camera_fbx"].exists() and camera_only_verification.get("status") == "PASS" else "FAIL",
            "camera_roundtrip": camera_only_verification,
        },
        "usd_proxy": {"path": relative_usd, "shape": proxy_shape},
        "hero_mesh": hero_mesh_status,
        "source_plate": {"path": relative_source, "shape": plane_shape, "framing": image_plane_contract},
        "camera": {
            "matched_transform": matched,
            "matched_shape": matched_shape,
            "artist_transform": artist,
            "settings": camera_settings,
            "review_view": review_view,
            "authority": "Atlas CameraBundle",
        },
        "hero_mesh_in_fbx": bool(hero_mesh_status.get("status") == "PASS" and fbx_verification.get("status") == "PASS"),
        "solver_pair": {
            "source_engine": hero_mesh_status.get("source_engine") or payload.get("geometry_engine"),
            "alignment": (payload.get("hero_mesh_payload") or {}).get("alignment"),
            "points_object": names["fused_points"],
            "mesh_object": names["hero_mesh"],
        },
        "point_cloud_in_fbx": False,
        "point_cloud_authority": "USDA/PLY",
    }
    _write_json(out["manifest"], manifest)
    _progress(run, f"EXIT ma={manifest['ma']['status']} fbx={manifest['fbx']['status']}")
    return manifest


def run_worker(input_json: str | Path) -> int:
    input_path = Path(input_json).resolve()
    payload = json.loads(input_path.read_text(encoding="utf-8"))
    out = build_output_paths(payload["run_dir"], payload["scene_name"])
    try:
        manifest = _create_maya_scene(payload)
        return _worker_exit_code(manifest)
    except Exception as exc:
        failure = {
            "schema": "ConceptGhost.MayaManifest.v0.8",
            "status": "FAIL",
            "error": str(exc),
            "traceback": traceback.format_exc(),
            "ma": {"path": str(out["ma"]), "status": "PASS" if out["ma"].exists() else "FAIL"},
            "fbx": {"path": str(out["fbx"]), "status": "PASS" if out["fbx"].exists() else "FAIL"},
        }
        _write_json(out["manifest"], failure)
        return 1
    finally:
        try:
            import maya.standalone  # type: ignore
            maya.standalone.uninitialize()
        except Exception:
            pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ConceptGhost Stage 8 Maya Worker")
    parser.add_argument("input_json", help="Run-local maya_worker_input.json")
    args = parser.parse_args(argv)
    return run_worker(args.input_json)


if __name__ == "__main__":
    raise SystemExit(main())

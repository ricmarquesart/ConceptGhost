from __future__ import annotations

import json
import math
import os
import struct
import subprocess
import sys
import shutil
import copy
from pathlib import Path
from typing import Any

import numpy as np

try:
    from .conceptghost_contracts import (
        CANONICAL_COORDINATES, PRESET_PARAMETERS, build_run_config,
        derive_run_status, json_safe,
    )
    from .conceptghost_geometry import (
        _first_rgb, _to_numpy, atlas_metric_scale_registration, camera_bundle_from_atlas_solve, canonicalize,
        geometry_health, reprojection_report,
    )
    from .conceptghost_io import (
        copy_preview_ply, create_run_download_archive, make_run_folder, sanitize_scene_name, sha256_file, write_json,
        write_ply_binary, write_usda_points,
    )
except ImportError:  # direct-module test/build compatibility
    from conceptghost_contracts import (
        CANONICAL_COORDINATES, PRESET_PARAMETERS, build_run_config,
        derive_run_status, json_safe,
    )
    from conceptghost_geometry import (
        _first_rgb, _to_numpy, atlas_metric_scale_registration, camera_bundle_from_atlas_solve, canonicalize,
        geometry_health, reprojection_report,
    )
    from conceptghost_io import (
        copy_preview_ply, create_run_download_archive, make_run_folder, sanitize_scene_name, sha256_file, write_json,
        write_ply_binary, write_usda_points,
    )


try:
    import torch
except Exception:  # tests/build environment can still import the module
    torch = None

try:
    from PIL import Image, ImageDraw
except Exception:
    Image = None
    ImageDraw = None


CG_CAMERA_BUNDLE = "CG_CAMERA_BUNDLE"
CG_GEOMETRY_EVIDENCE = "CG_GEOMETRY_EVIDENCE"
CG_SCENE_BUNDLE = "CG_SCENE_BUNDLE"


def _safe_text(data: Any) -> str:
    return json.dumps(json_safe(data), indent=2, sort_keys=True, ensure_ascii=False)


def _stage0607_log(run_dir: str | Path, message: str) -> None:
    """Persistent progress breadcrumb for the long Stage 06-07 output node."""
    line = f"[ConceptGhost 06-07] {message}"
    print(line, flush=True)
    try:
        path = Path(run_dir) / "logs" / "stage06_07_progress.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def _numpy_image_to_tensor(img: np.ndarray):
    arr = np.asarray(img, dtype=np.float32)
    if arr.max(initial=0.0) > 1.0:
        arr = arr / 255.0
    if arr.ndim == 3:
        arr = arr[None, ...]
    if torch is None:
        return arr
    return torch.from_numpy(arr.copy()).float()


def _make_overlay(source_image: Any, canonical: dict[str, Any], report: dict[str, Any]):
    src = _first_rgb(source_image)
    h, w = src.shape[:2]
    base = np.clip(np.rint(src * 255.0), 0, 255).astype(np.uint8)
    if Image is None:
        return _numpy_image_to_tensor(base)
    im = Image.fromarray(base, mode="RGB")
    draw = ImageDraw.Draw(im)
    uv = np.asarray(canonical.get("source_uv", []), dtype=np.float32)
    if len(uv):
        step = max(1, len(uv) // 3000)
        for u, v in uv[::step]:
            x, y = float(u), float(v)
            if 0 <= x < w and 0 <= y < h:
                draw.point((x, y), fill=(0, 255, 0))
    label = f"CG reprojection {'PASS' if report.get('pass') else 'CHECK'} RMSE={report.get('rmse_px')}"
    draw.rectangle((0,0,min(w,560),24), fill=(0,0,0))
    draw.text((5,5), label, fill=(255,255,255))
    return _numpy_image_to_tensor(np.asarray(im).astype(np.float32) / 255.0)


class ConceptGhostMasterConfig:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "scene_name": ("STRING", {"default": "concept_scene"}),
            "preset": (["Max Reference", "Balanced", "Fast Test"], {"default": "Max Reference"}),
            "camera_mode": (["Auto", "Atlas Learned", "Atlas VP"], {"default": "Auto"}),
            "geometry_engine": (["DA3", "MoGe"], {"default": "MoGe"}),
            "compare_both": ("BOOLEAN", {"default": False}),
            "extra_diagnostics": ("BOOLEAN", {"default": False}),
            "output_root": ("STRING", {"default": r"%USERPROFILE%\ConceptGhost_Output"}),
        }}
    RETURN_TYPES=("STRING","STRING","STRING","BOOLEAN","BOOLEAN","STRING","STRING")
    RETURN_NAMES=("preset","camera_mode","geometry_engine","compare_both","extra_diagnostics","scene_name","output_root")
    FUNCTION="build"; CATEGORY="ConceptGhost/01 Master"
    def build(self,scene_name,preset,camera_mode,geometry_engine,compare_both,extra_diagnostics,output_root):
        build_run_config(source_name=scene_name,preset=preset,camera_mode=camera_mode,geometry_engine=geometry_engine,compare_both=compare_both,extra_diagnostics=extra_diagnostics)
        return (preset,camera_mode,geometry_engine,bool(compare_both),bool(extra_diagnostics),scene_name,output_root)





class ConceptGhostCameraRouter:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "camera_mode": ("STRING", {"forceInput": True}),
                "learned_solve": ("ATLAS_SOLVE", {"lazy": True}),
                "vp_solve": ("ATLAS_SOLVE", {"lazy": True}),
            }
        }

    RETURN_TYPES = (CG_CAMERA_BUNDLE, "STRING", "FLOAT")
    RETURN_NAMES = ("camera_bundle", "camera_report", "atlas_fov_x_deg")
    FUNCTION = "route"
    CATEGORY = "ConceptGhost/02 Camera"

    def check_lazy_status(self, camera_mode, learned_solve=None, vp_solve=None):
        if camera_mode == "Atlas Learned":
            return ["learned_solve"] if learned_solve is None else []
        if camera_mode == "Atlas VP":
            return ["vp_solve"] if vp_solve is None else []
        if learned_solve is None:
            return ["learned_solve"]
        learned = camera_bundle_from_atlas_solve(learned_solve, requested_mode="Auto", final_solver="Atlas Learned")
        if learned.get("valid"):
            return []
        return ["vp_solve"] if vp_solve is None else []

    def route(self, camera_mode, learned_solve=None, vp_solve=None):
        if camera_mode == "Atlas Learned":
            bundle = camera_bundle_from_atlas_solve(learned_solve, requested_mode=camera_mode, final_solver="Atlas Learned")
        elif camera_mode == "Atlas VP":
            bundle = camera_bundle_from_atlas_solve(vp_solve, requested_mode=camera_mode, final_solver="Atlas VP")
        else:
            learned = camera_bundle_from_atlas_solve(learned_solve, requested_mode="Auto", final_solver="Atlas Learned")
            if learned.get("valid"):
                bundle = learned
            else:
                bundle = camera_bundle_from_atlas_solve(
                    vp_solve,
                    requested_mode="Auto",
                    final_solver="Atlas VP",
                    fallback_attempted=True,
                    fallback_reason="Atlas Learned failed vertical-slice structural camera gate",
                )
        report = {
            "requested_mode": camera_mode,
            "final_solver": bundle.get("provenance", {}).get("final_solver"),
            "valid": bundle.get("valid", False),
            "quality": bundle.get("quality", {}),
            "policy": "Learned first; VP requested only if Learned fails structural gate",
        }
        return (bundle, _safe_text(report), float(bundle.get("horizontal_fov_deg", 0.0) or 0.0))


class ConceptGhostAtlasToDA3CameraParams:
    """Adapt the authoritative Atlas CameraBundle to DA3's CAMERA_PARAMS input.

    For the single-view V1 path, Atlas intrinsics condition DA3 directly.  DA3
    receives an identity single-view extrinsic so model conditioning does not
    double-apply or reinterpret Atlas/Maya world-axis conventions; the actual
    Atlas world transform is applied once during ConceptGhost canonicalization.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"camera_bundle": (CG_CAMERA_BUNDLE,)}}

    RETURN_TYPES = ("CAMERA_PARAMS", "STRING")
    RETURN_NAMES = ("camera_params", "report")
    FUNCTION = "build"
    CATEGORY = "ConceptGhost/02 Camera"

    def build(self, camera_bundle):
        if not camera_bundle or not camera_bundle.get("valid"):
            raise RuntimeError("Atlas CameraBundle is invalid; DA3 conditioning cannot be built")
        if torch is None:
            raise RuntimeError("PyTorch is required to build DA3 camera conditioning")
        intr = camera_bundle["intrinsics"]
        K = torch.tensor([
            [float(intr["fx_px"]), 0.0, float(intr["cx_px"])],
            [0.0, float(intr["fy_px"]), float(intr["cy_px"])],
            [0.0, 0.0, 1.0],
        ], dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        # Single-view absolute pose is arbitrary to DA3 inference; keep its local
        # frame neutral and apply the Atlas world transform exactly once later.
        E = torch.eye(4, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        params = {
            "extrinsics": E,
            "intrinsics": K,
            "image_size": (int(camera_bundle["image_height"]), int(camera_bundle["image_width"])),
        }
        report = {
            "source": "Atlas CameraBundle",
            "intrinsics_conditioned": True,
            "extrinsics_policy": "identity_single_view; Atlas world transform applied in canonicalization",
            "image_size": list(params["image_size"]),
            "horizontal_fov_deg": float(camera_bundle.get("horizontal_fov_deg", 0.0) or 0.0),
        }
        return (params, _safe_text(report))


class ConceptGhostDA3Evidence:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "depth_raw": ("IMAGE",),
                "confidence": ("IMAGE",),
                "intrinsics_json": ("STRING", {"forceInput": True}),
                "sky_mask": ("MASK",),
                "source_image": ("IMAGE",),
                "preset": ("STRING", {"forceInput": True}),
            }
        }
    RETURN_TYPES = (CG_GEOMETRY_EVIDENCE, "STRING")
    RETURN_NAMES = ("evidence", "report")
    FUNCTION = "build"
    CATEGORY = "ConceptGhost/03 Geometry"

    def build(self, depth_raw, confidence, intrinsics_json, sky_mask, source_image, preset):
        params = PRESET_PARAMETERS.get(preset, PRESET_PARAMETERS["Max Reference"])
        evidence = {
            "schema": "ConceptGhost.GeometryEvidence.v0.8",
            "engine": "da3",
            "depth_raw": depth_raw,
            "confidence": confidence,
            "sky_mask": sky_mask,
            "source_image": source_image,
            "native_intrinsics_json": intrinsics_json,
            "depth_semantics": "camera_z_raw",
            "candidate_confidence_threshold": float(params["da3_confidence_threshold"]),
            "da3_edge_threshold": 12.0 / 255.0,
            "candidate_unfrozen": True,
            "native": {
                "workflow": "public advanced_3d baseline",
                "model": "da3_large.safetensors",
                "normalization_mode": "Raw",
            },
        }
        return (evidence, _safe_text({k:v for k,v in evidence.items() if k not in {"depth_raw","confidence","sky_mask","source_image"}}))


class ConceptGhostMoGeEvidence:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "moge_geometry": ("MOGE_GEOMETRY",),
                "source_image": ("IMAGE",),
                "preset": ("STRING", {"forceInput": True}),
                "atlas_fov_x_deg": ("FLOAT", {"forceInput": True}),
            }
        }
    RETURN_TYPES = (CG_GEOMETRY_EVIDENCE, "STRING")
    RETURN_NAMES = ("evidence", "report")
    FUNCTION = "build"
    CATEGORY = "ConceptGhost/03 Geometry"

    def build(self, moge_geometry, source_image, preset, atlas_fov_x_deg):
        params = PRESET_PARAMETERS.get(preset, PRESET_PARAMETERS["Max Reference"])
        evidence = {
            "schema": "ConceptGhost.GeometryEvidence.v0.8",
            "engine": "moge",
            "moge_geometry": moge_geometry,
            "source_image": source_image,
            "atlas_fov_x_deg": float(atlas_fov_x_deg),
            "atlas_fov_conditioned": bool(float(atlas_fov_x_deg) > 0.0),
            "candidate_unfrozen": True,
            "native": {
                "model": "moge_2_vitl_normal_fp16.safetensors",
                "resolution_level": int(params["moge_resolution_level"]),
                "force_projection": bool(params["moge_force_projection"]),
                "apply_mask": bool(params["moge_apply_mask"]),
                "coordinate_system": "OpenCV camera: +X right, +Y down, +Z forward",
            },
        }
        return (evidence, _safe_text({k:v for k,v in evidence.items() if k not in {"moge_geometry","source_image"}}))


class ConceptGhostGeometryRouter:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "geometry_engine": ("STRING", {"forceInput": True}),
                "compare_both": ("BOOLEAN", {"forceInput": True}),
                "da3_evidence": (CG_GEOMETRY_EVIDENCE, {"lazy": True}),
                "moge_evidence": (CG_GEOMETRY_EVIDENCE, {"lazy": True}),
            }
        }
    RETURN_TYPES = (CG_GEOMETRY_EVIDENCE, CG_GEOMETRY_EVIDENCE, "STRING")
    RETURN_NAMES = ("primary_evidence", "secondary_evidence", "router_report")
    FUNCTION = "route"
    CATEGORY = "ConceptGhost/03 Geometry"

    def check_lazy_status(self, geometry_engine, compare_both, da3_evidence=None, moge_evidence=None):
        need = []
        if geometry_engine == "DA3":
            if da3_evidence is None:
                need.append("da3_evidence")
            if compare_both and moge_evidence is None:
                need.append("moge_evidence")
        else:
            if moge_evidence is None:
                need.append("moge_evidence")
            if compare_both and da3_evidence is None:
                need.append("da3_evidence")
        return need

    def route(self, geometry_engine, compare_both, da3_evidence=None, moge_evidence=None):
        if geometry_engine == "DA3":
            primary, secondary = da3_evidence, (moge_evidence if compare_both else None)
        else:
            primary, secondary = moge_evidence, (da3_evidence if compare_both else None)
        if primary is None:
            raise RuntimeError(f"Requested geometry engine {geometry_engine} did not produce evidence")
        report = {
            "primary_engine": primary.get("engine"),
            "secondary_engine": secondary.get("engine") if secondary else None,
            "compare_both": bool(compare_both),
            "fusion": False,
            "promotion": False,
            "selector_semantics": "DA3/MoGe route selection; Compare Both is diagnostic comparison only",
        }
        return (primary, secondary, _safe_text(report))


class ConceptGhostCanonicalize:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"camera_bundle":(CG_CAMERA_BUNDLE,),"primary_evidence":(CG_GEOMETRY_EVIDENCE,),"secondary_evidence":(CG_GEOMETRY_EVIDENCE,),"source_image":("IMAGE",),"preset":("STRING",{"forceInput":True})}}
    RETURN_TYPES=(CG_SCENE_BUNDLE,"IMAGE","STRING"); RETURN_NAMES=("scene_bundle","reprojection_overlay","scene_report"); FUNCTION="build"; CATEGORY="ConceptGhost/04 Normalizer"
    def build(self,camera_bundle,primary_evidence,secondary_evidence,source_image,preset):
        primary=canonicalize(camera_bundle,primary_evidence,source_image); health=geometry_health(primary["xyz"]); reproj=reprojection_report(camera_bundle,primary)
        stage7_status="PASS" if (camera_bundle.get("valid") and len(primary["xyz"]) and reproj.get("pass") and health.get("pass")) else ("PARTIAL" if len(primary["xyz"]) else "FAIL")
        camera_prov=camera_bundle.get("provenance",{}); metric_reg=(primary.get("refinement") or {}).get("atlas_metric_scale_registration",{}) or {}
        contributors=[{"component":"Atlas Camera","role":"camera/projection authority","detail":camera_prov.get("final_solver")},{"component":primary["engine"].upper(),"role":"selected geometry route","detail":"Atlas-conditioned where upstream supports it"},{"component":"Original Source Image","role":"RGB authority","detail":"per-point source color"},{"component":"ConceptGhost Normalizer","role":"canonical coordinate assembly","detail":"right-handed Y-up, -Z camera forward"},{"component":"Reprojection Gate","role":"integration consistency validation","detail":"Atlas camera reprojection"},{"component":"Geometry Health","role":"canonical geometry validation","detail":"point-cloud health gate"}]
        if camera_prov.get("final_solver")=="Atlas Learned": contributors.insert(1,{"component":"GeoCalib","role":"learned camera prior through Atlas","detail":camera_prov.get("learned_prior")})
        if primary["engine"]=="da3": contributors.append({"component":"DA3-Blender","role":"algorithm donor","detail":"Sobel depth-edge suppression 12/255 before point creation"})
        if metric_reg.get("applied"): contributors.append({"component":"Atlas Metric Scale Registration","role":"metric scale authority shared with selected geometry","detail":f"engine ground height × {float(metric_reg.get('scale_factor',1.0)):.6g} -> Atlas camera height {float(metric_reg.get('target_camera_height_m',0.0)):.6g} m"})
        scene={"schema":"ConceptGhost.SceneBundle.v0.8","camera":camera_bundle,"geometry":{"schema":primary["schema"],"engine":primary["engine"],"point_count":primary["point_count"],"native_resolution":primary["native_resolution"],"depth_semantics":primary["depth_semantics"]},"coordinate_convention":dict(CANONICAL_COORDINATES),"scale_convention":{"units":metric_reg.get("units","meters" if metric_reg.get("applied") else "relative"),"meters_per_unit":1.0 if metric_reg.get("applied") else None,"scale_applied":bool(metric_reg.get("scale_applied",metric_reg.get("applied",False))),"scale_factor":float(metric_reg.get("scale_factor",1.0)),"reason_if_not_applied":metric_reg.get("reason_if_not_applied",None if metric_reg.get("applied") else metric_reg.get("reason")),"scale_authority":"Atlas metric camera height registered to selected geometry ground evidence" if metric_reg.get("applied") else "relative_unregistered; engine/Atlas evidence insufficient for a metric claim","registration":json_safe(metric_reg)},"integration_consistency":reproj,"geometry_health":health,"status":{"run_status":stage7_status,"authoritative":bool(stage7_status=="PASS")},"preset":preset,"engine_metadata":json_safe(primary_evidence.get("native",{})),"synergy_contributors":contributors,"primary_authority":{"camera":"Atlas","geometry":primary["engine"],"color":"Original Source Image","final_scene":"ConceptGhost Canonical Scene"},"_runtime":{"primary_canonical":primary,"primary_evidence":primary_evidence,"source_image":source_image}}
        if secondary_evidence is not None:
            try:
                secondary=canonicalize(camera_bundle,secondary_evidence,source_image); scene["compare"]={"engine":secondary["engine"],"point_count":secondary["point_count"],"geometry_health":geometry_health(secondary["xyz"]),"integration_consistency":reprojection_report(camera_bundle,secondary)}; scene["_runtime"]["secondary_canonical"]=secondary; scene["_runtime"]["secondary_evidence"]=secondary_evidence
            except Exception as exc: scene["compare"]={"status":"FAILED","error":str(exc)}
        overlay=_make_overlay(source_image,primary,reproj); return (scene,overlay,_safe_text({k:v for k,v in scene.items() if k!="_runtime"}))



def _maya_artifact_status(run: Path, ma_path: Path, fbx_path: Path):
    """Trust the worker manifest for FBX validity, not file existence alone."""
    details = {}
    manifest_path = Path(run) / "maya" / "maya_manifest.json"
    if manifest_path.is_file():
        try:
            details = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            details = {"status": "INVALID_MANIFEST", "error": str(exc)}
    ma_entry = details.get("ma") if isinstance(details, dict) else None
    fbx_entry = details.get("fbx") if isinstance(details, dict) else None
    hero_entry = details.get("hero_mesh") if isinstance(details, dict) else None
    hero_ok = not (isinstance(hero_entry, dict) and hero_entry.get("requested")) or hero_entry.get("status") == "PASS"
    maya_ok = bool(ma_path.exists() and isinstance(ma_entry, dict) and ma_entry.get("status") == "PASS" and hero_ok)
    fbx_ok = bool(fbx_path.exists() and isinstance(fbx_entry, dict) and fbx_entry.get("status") == "PASS" and hero_ok)
    return maya_ok, fbx_ok, details


def _first_mesh_batch_item(mesh):
    """Return the first real mesh item using ComfyUI's batched MESH contract.

    Core ComfyUI stores vertices/faces/UVs/normals as BxNx* tensors and may
    attach per-item vertex/face counts for variable-size batches.  ConceptGhost
    intentionally exports a single hero mesh, matching SaveGLB's first-item
    behavior used by our workflow.
    """
    vertices = _to_numpy(getattr(mesh, "vertices", None), np.float32)
    faces = _to_numpy(getattr(mesh, "faces", None), np.int64)
    if vertices.size == 0 or faces.size == 0:
        raise ValueError("Hero MESH requires vertices and faces")

    if vertices.ndim == 3:
        vertices = vertices[0]
    if faces.ndim == 3:
        faces = faces[0]
    if vertices.ndim != 2 or vertices.shape[-1] != 3:
        raise ValueError(f"Hero MESH vertices must resolve to Nx3, got {vertices.shape}")
    if faces.ndim != 2 or faces.shape[-1] < 3:
        raise ValueError(f"Hero MESH faces must resolve to FxK, got {faces.shape}")

    vertex_counts = getattr(mesh, "vertex_counts", None)
    face_counts = getattr(mesh, "face_counts", None)
    if vertex_counts is not None:
        vc = int(_to_numpy(vertex_counts).reshape(-1)[0])
        vertices = vertices[:vc]
    if face_counts is not None:
        fc = int(_to_numpy(face_counts).reshape(-1)[0])
        faces = faces[:fc]

    def optional_vertex_attr(name: str, width: int):
        value = getattr(mesh, name, None)
        if value is None:
            return None
        arr = _to_numpy(value, np.float32)
        if arr.size == 0:
            return None
        if arr.ndim == 3:
            arr = arr[0]
        if arr.ndim != 2 or arr.shape[-1] != width:
            return None
        return arr[: len(vertices)]

    uvs = optional_vertex_attr("uvs", 2)
    normals = optional_vertex_attr("normals", 3)
    return vertices, faces, uvs, normals




def _finalize_camera_facing_mesh_normals(
    vertices: np.ndarray,
    faces: np.ndarray,
    camera: dict[str, Any],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Finalize triangle winding and normals from the *final* mesh topology.

    The old raster-derivative normal path could disagree with the actual triangle
    winding and a single shared vertex normal can become opposite to a folded
    incident face.  This routine makes the final triangle topology authoritative:

    1. orient every non-degenerate triangle toward the matched camera;
    2. build area-weighted smooth vertex normals from those final triangles;
    3. build per-face-vertex normals and hemisphere-clamp every corner to its
       geometric face normal.

    The per-face-vertex normals are what Maya should author.  Therefore no valid
    face corner can receive a stored normal pointing through the back side of its
    polygon, while smooth shading is preserved wherever it is geometrically safe.
    """
    v = np.asarray(vertices, dtype=np.float64).reshape((-1, 3))
    f = np.asarray(faces, dtype=np.int64).reshape((-1, 3)).copy()
    if len(v) == 0 or len(f) == 0:
        raise ValueError("Cannot finalize normals for an empty mesh")

    cam_pos = np.asarray(
        (camera.get("extrinsics") or {}).get("camera_position") or [0.0, 0.0, 0.0],
        dtype=np.float64,
    ).reshape(3)

    def _face_geometry(face_idx: np.ndarray):
        p0 = v[face_idx[:, 0]]
        p1 = v[face_idx[:, 1]]
        p2 = v[face_idx[:, 2]]
        raw = np.cross(p1 - p0, p2 - p0)
        length = np.linalg.norm(raw, axis=1)
        cent = (p0 + p1 + p2) / 3.0
        return raw, length, cent

    raw0, len0, cent0 = _face_geometry(f)
    valid0 = np.isfinite(len0) & (len0 > 1e-12)
    to_cam0 = cam_pos.reshape(1, 3) - cent0
    front_dot0 = np.einsum("ij,ij->i", raw0, to_cam0)
    reverse = valid0 & np.isfinite(front_dot0) & (front_dot0 < 0.0)
    if np.any(reverse):
        tmp = f[reverse, 1].copy()
        f[reverse, 1] = f[reverse, 2]
        f[reverse, 2] = tmp

    raw, length, cent = _face_geometry(f)
    valid = np.isfinite(length) & (length > 1e-12)
    face_normals = np.zeros((len(f), 3), dtype=np.float64)
    face_normals[valid] = raw[valid] / length[valid, None]

    # Area-weighted smooth normals derived from final, camera-facing faces.
    accum = np.zeros((len(v), 3), dtype=np.float64)
    raw_safe = np.where(np.isfinite(raw), raw, 0.0)
    for corner in range(3):
        np.add.at(accum, f[:, corner], raw_safe)
    accum_len = np.linalg.norm(accum, axis=1)
    vertex_normals = np.zeros((len(v), 3), dtype=np.float64)
    vok = np.isfinite(accum_len) & (accum_len > 1e-12)
    vertex_normals[vok] = accum[vok] / accum_len[vok, None]

    # A shared smooth normal cannot be valid for every face of a severe fold.
    # Author face-vertex normals and fall back to that face's own normal whenever
    # a corner normal would point into the wrong hemisphere.
    face_vertex_normals = vertex_normals[f].copy()
    corner_len = np.linalg.norm(face_vertex_normals, axis=2)
    corner_dot_before = np.einsum("fci,fi->fc", face_vertex_normals, face_normals)
    bad_corner = (~np.isfinite(corner_len)) | (corner_len <= 1e-12) | (~np.isfinite(corner_dot_before)) | (corner_dot_before <= 1e-6)
    bad_corner &= valid[:, None]
    if np.any(bad_corner):
        expanded = np.broadcast_to(face_normals[:, None, :], face_vertex_normals.shape)
        face_vertex_normals[bad_corner] = expanded[bad_corner]

    corner_dot_after = np.einsum("fci,fi->fc", face_vertex_normals, face_normals)
    opposed_after = valid[:, None] & (corner_dot_after <= 0.0)
    if np.any(opposed_after):
        # This should be mathematically unreachable after the fallback above.
        raise ValueError(
            f"Normal finalization failed: {int(np.count_nonzero(opposed_after))} face corners remain opposed"
        )

    to_cam = cam_pos.reshape(1, 3) - cent
    front_dot = np.einsum("ij,ij->i", face_normals, to_cam)
    back_facing_after = valid & np.isfinite(front_dot) & (front_dot <= 0.0)

    report = {
        "policy": "final_topology_camera_facing_face_vertex_normals_v0.25",
        "winding_reversed_faces": int(np.count_nonzero(reverse)),
        "degenerate_faces": int(np.count_nonzero(~valid)),
        "back_facing_faces_after": int(np.count_nonzero(back_facing_after)),
        "face_vertex_corners_repaired": int(np.count_nonzero(bad_corner)),
        "opposed_face_vertex_corners_after": int(np.count_nonzero(opposed_after)),
        "face_vertex_min_dot_after": float(np.min(corner_dot_after[valid])) if np.any(valid) else 0.0,
    }
    return (
        f.astype(np.int32, copy=False),
        vertex_normals.astype(np.float32, copy=False),
        face_normals.astype(np.float32, copy=False),
        face_vertex_normals.astype(np.float32, copy=False),
        report,
    )

def _build_primary_mesh_arrays_from_canonical(
    canonical: dict[str, Any],
    camera: dict[str, Any],
    image_width: int,
    image_height: int,
    *,
    max_transport_vertices: int = 250_000,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    """Build the Maya/FBX transport mesh from the selected canonical solver.

    PLY/USD keep the complete canonical point cloud. Dense image-grid geometry is
    sampled deterministically only for the native Maya/FBX transport mesh. Every
    retained vertex is an exact canonical XYZ sample. The transport mesh is
    geometry-only; the v0.25 winding and face-vertex-normal repair remains authoritative.
    """
    xyz_full = np.asarray(canonical.get("xyz", []), dtype=np.float32).reshape((-1, 3))
    grid_xy = np.asarray(canonical.get("grid_xy", []), dtype=np.int32).reshape((-1, 2))
    source_uv_full = np.asarray(canonical.get("source_uv", []), dtype=np.float32).reshape((-1, 2))
    native = canonical.get("native_resolution") or [0, 0]
    if len(native) < 2:
        raise ValueError("Canonical geometry requires native_resolution for paired mesh")
    grid_w, grid_h = int(native[0]), int(native[1])
    if len(xyz_full) < 3 or grid_w <= 1 or grid_h <= 1:
        raise ValueError("Canonical geometry cannot form a solver-paired mesh")
    if len(source_uv_full) != len(xyz_full):
        raise ValueError("Canonical source_uv count must match XYZ for paired mesh")

    grid_fallback = len(grid_xy) != len(xyz_full)
    target = max(int(max_transport_vertices), 3)

    if grid_fallback:
        stride = max(1, int(math.ceil(len(xyz_full) / float(target))))
        selected_ids = np.arange(0, len(xyz_full), stride, dtype=np.int64)
        if selected_ids.size and selected_ids[-1] != len(xyz_full) - 1:
            selected_ids = np.concatenate([selected_ids, np.asarray([len(xyz_full) - 1], dtype=np.int64)])
        xyz = xyz_full[selected_ids]
        source_uv = source_uv_full[selected_ids]
        if len(xyz) < 3:
            raise ValueError("Canonical geometry cannot form a solver-paired transport mesh")
        faces64 = np.stack([
            np.zeros(len(xyz) - 2, dtype=np.int64),
            np.arange(2, len(xyz), dtype=np.int64),
            np.arange(1, len(xyz) - 1, dtype=np.int64),
        ], axis=1)
        vertex_normals = np.zeros_like(xyz, dtype=np.float32)
    else:
        index_grid = np.full((grid_h, grid_w), -1, dtype=np.int64)
        gx = grid_xy[:, 0].astype(np.int64)
        gy = grid_xy[:, 1].astype(np.int64)
        valid_xy = (gx >= 0) & (gx < grid_w) & (gy >= 0) & (gy < grid_h)
        index_grid[gy[valid_xy], gx[valid_xy]] = np.arange(len(xyz_full), dtype=np.int64)[valid_xy]

        stride = max(1, int(math.ceil(math.sqrt(max(len(xyz_full), 1) / float(target)))))
        sampled_grid = index_grid[::stride, ::stride]
        # Deterministic geometry-only sampling for the Maya/FBX transport mesh.
        valid_ids = sampled_grid[sampled_grid >= 0]
        if valid_ids.size < 3:
            raise ValueError("Canonical grid sampling produced too few DCC vertices")
        selected_ids = np.unique(valid_ids)
        remap = np.full(len(xyz_full), -1, dtype=np.int64)
        remap[selected_ids] = np.arange(len(selected_ids), dtype=np.int64)
        compact_grid = np.full(sampled_grid.shape, -1, dtype=np.int64)
        valid = sampled_grid >= 0
        compact_grid[valid] = remap[sampled_grid[valid]]

        xyz = xyz_full[selected_ids]
        source_uv = source_uv_full[selected_ids]

        p00 = compact_grid[:-1, :-1]
        p10 = compact_grid[:-1, 1:]
        p01 = compact_grid[1:, :-1]
        p11 = compact_grid[1:, 1:]
        m1 = (p00 >= 0) & (p01 >= 0) & (p10 >= 0)
        m2 = (p10 >= 0) & (p01 >= 0) & (p11 >= 0)
        tri1 = np.stack([p00[m1], p01[m1], p10[m1]], axis=1) if np.any(m1) else np.empty((0, 3), dtype=np.int64)
        tri2 = np.stack([p10[m2], p01[m2], p11[m2]], axis=1) if np.any(m2) else np.empty((0, 3), dtype=np.int64)
        faces64 = np.concatenate([tri1, tri2], axis=0)
        if len(faces64) == 0:
            raise ValueError("Solver-paired transport mesh has no valid faces")

        # Vectorized normals on the sampled raster. Missing samples remain zero.
        pos = np.full(compact_grid.shape + (3,), np.nan, dtype=np.float32)
        pos[valid] = xyz[compact_grid[valid]]
        left = np.roll(pos, 1, axis=1); right = np.roll(pos, -1, axis=1)
        up = np.roll(pos, 1, axis=0); down = np.roll(pos, -1, axis=0)
        left[:, 0] = np.nan; right[:, -1] = np.nan; up[0, :] = np.nan; down[-1, :] = np.nan
        dx = right - left
        only_r = np.isnan(dx).any(axis=2) & (~np.isnan(right).any(axis=2)) & (~np.isnan(pos).any(axis=2))
        only_l = np.isnan(dx).any(axis=2) & (~np.isnan(left).any(axis=2)) & (~np.isnan(pos).any(axis=2))
        dx[only_r] = right[only_r] - pos[only_r]
        dx[only_l] = pos[only_l] - left[only_l]
        dy = down - up
        only_d = np.isnan(dy).any(axis=2) & (~np.isnan(down).any(axis=2)) & (~np.isnan(pos).any(axis=2))
        only_u = np.isnan(dy).any(axis=2) & (~np.isnan(up).any(axis=2)) & (~np.isnan(pos).any(axis=2))
        dy[only_d] = down[only_d] - pos[only_d]
        dy[only_u] = pos[only_u] - up[only_u]
        ng = np.cross(dy, dx)
        ln = np.linalg.norm(ng, axis=2)
        okn = valid & np.isfinite(ln) & (ln > 1e-8)
        ng[okn] = ng[okn] / ln[okn, None]
        vertex_normals = np.zeros_like(xyz, dtype=np.float32)
        vertex_normals[compact_grid[okn]] = ng[okn].astype(np.float32)

    baseline_candidate_faces = int(len(faces64))
    faces_np = faces64.astype(np.int32, copy=False)
    if len(faces_np) == 0:
        raise ValueError("Solver-paired transport mesh has no valid faces")

    # v0.25: final topology is the single source of truth for winding and normals.
    # Do this *after* every topology policy so Maya receives normals that are
    # guaranteed to agree with the faces actually exported.
    faces_np, vertex_normals, face_normals, face_vertex_normals, normal_report = _finalize_camera_facing_mesh_normals(
        xyz, faces_np, camera
    )

    iw = max(int(image_width) - 1, 1)
    ih = max(int(image_height) - 1, 1)
    uvs = np.empty((len(xyz), 2), dtype=np.float32)
    uvs[:, 0] = np.clip(source_uv[:, 0] / float(iw), 0.0, 1.0)
    uvs[:, 1] = 1.0 - np.clip(source_uv[:, 1] / float(ih), 0.0, 1.0)

    arrays: dict[str, np.ndarray] = {
        "vertices": np.asarray(xyz, dtype=np.float32),
        "faces": np.asarray(faces_np, dtype=np.int32),
        "uvs": uvs,
        "normals": np.asarray(vertex_normals, dtype=np.float32),
        "face_normals": np.asarray(face_normals, dtype=np.float32),
        "face_vertex_normals": np.asarray(face_vertex_normals, dtype=np.float32),
        "canonical_point_indices": np.asarray(selected_ids, dtype=np.int64),
    }
    sampled = int(len(xyz)) < int(len(xyz_full))
    report = {
        "source_engine": str(canonical.get("engine") or "unknown"),
        "alignment": "EXACT_CANONICAL_XYZ_SUBSET" if sampled else "EXACT_SAME_CANONICAL_XYZ",
        "point_count": int(len(xyz_full)),
        "vertex_count": int(len(xyz)),
        "face_count": int(len(faces_np)),
        "baseline_candidate_faces": int(baseline_candidate_faces),
        "coordinate_space": "Atlas world / ConceptGhost canonical axes",
        "axis_policy": "canonical_world_no_extra_yz_flip",
        "uv_policy": "Maya/DCC-ready V flip only",
        "grid_xy_fallback": bool(grid_fallback),
        "transport_stride": int(stride),
        "transport_vertex_cap": int(max_transport_vertices),
        "full_resolution_authority": "PLY/USD",
        "dcc_transport_sampled": bool(sampled),
        "normal_policy": normal_report["policy"],
        "winding_reversed_faces": normal_report["winding_reversed_faces"],
        "degenerate_faces": normal_report["degenerate_faces"],
        "back_facing_faces_after": normal_report["back_facing_faces_after"],
        "face_vertex_corners_repaired": normal_report["face_vertex_corners_repaired"],
        "opposed_face_vertex_corners_after": normal_report["opposed_face_vertex_corners_after"],
        "face_vertex_min_dot_after": normal_report["face_vertex_min_dot_after"],
    }
    return arrays, report



def _write_primary_mesh_payload(
    run_dir: str | Path,
    scene_name: str,
    canonical: dict[str, Any],
    camera: dict[str, Any],
    source_image: Any,
) -> dict[str, Any]:
    run = Path(run_dir)
    scene = sanitize_scene_name(scene_name)
    maya_dir = run / "maya"
    maya_dir.mkdir(parents=True, exist_ok=True)
    width = int(camera.get("image_width") or _first_rgb(source_image).shape[1])
    height = int(camera.get("image_height") or _first_rgb(source_image).shape[0])
    arrays, report = _build_primary_mesh_arrays_from_canonical(canonical, camera, width, height)
    npz_path = maya_dir / f"ConceptGhost_{scene}_PrimaryMesh.npz"
    np.savez_compressed(npz_path, **arrays)

    texture_path = None
    if Image is not None:
        src = np.clip(np.rint(_first_rgb(source_image) * 255.0), 0, 255).astype(np.uint8)
        texture_path = maya_dir / f"ConceptGhost_{scene}_PrimaryTexture.png"
        Image.fromarray(src, mode="RGB").save(texture_path)

    payload = {
        "schema": "ConceptGhost.PrimarySolverMeshPayload.v0.26",
        "source_engine": report["source_engine"],
        "alignment": report["alignment"],
        "coordinate_space": report["coordinate_space"],
        "axis_policy": report["axis_policy"],
        "uv_policy": report["uv_policy"],
        "npz_path": str(npz_path),
        "texture_path": str(texture_path) if texture_path else None,
        "vertex_count": report["vertex_count"],
        "point_count": report["point_count"],
        "face_count": report["face_count"],
        "full_point_count": report["point_count"],
        "transport_stride": report.get("transport_stride", 1),
        "transport_vertex_cap": report.get("transport_vertex_cap", 250000),
        "dcc_transport_sampled": report.get("dcc_transport_sampled", False),
        "full_resolution_authority": report.get("full_resolution_authority", "PLY/USD"),
    }
    write_json(maya_dir / "primary_mesh_payload.json", payload)
    return payload



def _write_maya_hero_mesh_payload(run_dir: str | Path, scene_name: str, mesh) -> dict[str, Any]:
    """Persist the Maya-ready hero mesh without changing it again.

    The input is the E2-DCC branch, already transformed to Atlas world space and
    already carrying Maya-compatible V-flipped UVs.  We serialize exact arrays
    for mayapy instead of asking Maya to reinterpret GLB/FBX conventions.
    """
    run = Path(run_dir)
    scene = sanitize_scene_name(scene_name)
    maya_dir = run / "maya"
    maya_dir.mkdir(parents=True, exist_ok=True)
    vertices, faces, uvs, normals = _first_mesh_batch_item(mesh)

    npz_path = maya_dir / f"ConceptGhost_{scene}_HeroMesh.npz"
    arrays: dict[str, np.ndarray] = {
        "vertices": np.asarray(vertices, dtype=np.float32),
        "faces": np.asarray(faces, dtype=np.int32),
    }
    if uvs is not None:
        arrays["uvs"] = np.asarray(uvs, dtype=np.float32)
    if normals is not None:
        arrays["normals"] = np.asarray(normals, dtype=np.float32)

    np.savez_compressed(npz_path, **arrays)

    texture_path = None
    texture = getattr(mesh, "texture", None)
    if texture is not None and Image is not None:
        tex = _to_numpy(texture, np.float32)
        if tex.ndim == 4:
            tex = tex[0]
        if tex.ndim == 3 and tex.shape[-1] in (3, 4):
            tex_u8 = np.clip(np.rint(tex * 255.0), 0, 255).astype(np.uint8)
            texture_path = maya_dir / f"ConceptGhost_{scene}_HeroTexture.png"
            Image.fromarray(tex_u8, mode="RGBA" if tex_u8.shape[-1] == 4 else "RGB").save(texture_path)

    payload = {
        "schema": "ConceptGhost.HeroMeshPayload.v0.26",
        "coordinate_space": "Atlas world / ConceptGhost canonical axes",
        "uv_policy": "Maya/DCC-ready; do not flip again",
        "npz_path": str(npz_path),
        "texture_path": str(texture_path) if texture_path else None,
        "vertex_count": int(len(vertices)),
        "face_count": int(len(faces)),
        "uv_count": int(len(uvs)) if uvs is not None else 0,
        "normal_count": int(len(normals)) if normals is not None else 0,
    }
    write_json(maya_dir / "hero_mesh_payload.json", payload)
    return payload











class ConceptGhostExportBundle:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "scene_bundle": (CG_SCENE_BUNDLE,),
                "source_image": ("IMAGE",),
                "scene_name": ("STRING", {"forceInput": True}),
                "output_root": ("STRING", {"forceInput": True}),
                "extra_diagnostics": ("BOOLEAN", {"forceInput": True}),
            },
            "optional": {
                "hero_mesh": ("MESH",),
            },
        }
    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("run_dir", "pointcloud_ply", "preview_ply", "ghost_usda", "ghost_ma", "ghost_fbx", "manifest_path", "status")
    FUNCTION = "export"
    CATEGORY = "ConceptGhost/07 Outputs"
    OUTPUT_NODE = True

    def export(self, scene_bundle, source_image, scene_name, output_root, extra_diagnostics, hero_mesh=None):
        runtime = scene_bundle.get("_runtime", {})
        canonical = runtime.get("primary_canonical")
        if canonical is None:
            raise RuntimeError("SceneBundle contains no canonical runtime geometry")
        run = make_run_folder(output_root, scene_name)
        scene = sanitize_scene_name(scene_name)
        _stage0607_log(run, "ENTER export bundle")
        src_path = run / "source" / "source.png"
        if Image is not None:
            src = _first_rgb(source_image)
            Image.fromarray(np.clip(np.rint(src*255.0),0,255).astype(np.uint8), mode="RGB").save(src_path)
        else:
            np.save(run / "source" / "source.npy", _first_rgb(source_image))

        camera_json = write_json(run / "camera" / "camera.json", json_safe(scene_bundle["camera"]))
        write_json(run / "diagnostics" / "reprojection_report.json", json_safe(scene_bundle["integration_consistency"]))
        write_json(run / "diagnostics" / "geometry_health.json", json_safe(scene_bundle["geometry_health"]))
        overlay = _make_overlay(source_image, canonical, scene_bundle["integration_consistency"])
        if Image is not None:
            ov = _first_rgb(overlay)
            Image.fromarray(np.clip(np.rint(ov*255.0),0,255).astype(np.uint8), mode="RGB").save(run / "diagnostics" / "reprojection_overlay.png")
            support_mask = _projection_support_mask_from_canonical(
                canonical, int(scene_bundle["camera"]["image_width"]), int(scene_bundle["camera"]["image_height"])
            )
            Image.fromarray(support_mask, mode="L").save(run / "diagnostics" / "projection_support_mask.png")

        xyz = np.asarray(canonical["xyz"], dtype=np.float32)
        rgb = np.asarray(canonical["rgb"], dtype=np.uint8)
        _stage0607_log(run, f"PLY START points={len(xyz)}")
        ply_path = write_ply_binary(run / "geometry" / "canonical" / "pointcloud.ply", xyz, rgb)
        _stage0607_log(run, f"PLY DONE bytes={ply_path.stat().st_size if ply_path.exists() else 0}")
        preview_ply_path = None
        preview_warning = None
        try:
            preview_ply_path = copy_preview_ply(ply_path, run.name)
        except Exception as exc:
            preview_warning = str(exc)
            # The canonical PLY remains authoritative even if UI transport fails.
            write_json(run / "logs" / "preview_transport_warning.json", {"warning": preview_warning})
        geom_meta = {k:json_safe(v) for k,v in canonical.items() if k not in {"xyz","rgb","confidence","source_uv"}}
        geom_meta["geometry_health"] = json_safe(scene_bundle["geometry_health"])
        write_json(run / "geometry" / "canonical" / "geometry.json", geom_meta)
        _stage0607_log(run, "USD START")
        canonical_usd_path = write_usda_points(
            run / "geometry" / "canonical" / "pointcloud.usda",
            xyz,
            rgb,
            point_width=float(PRESET_PARAMETERS.get(scene_bundle.get("preset","Max Reference"), PRESET_PARAMETERS["Max Reference"])["point_width"]),
            metadata={"engine": canonical["engine"], "point_count": len(xyz), "preset": scene_bundle.get("preset","Max Reference")},
        )
        usd_path = run / "maya" / f"ConceptGhost_{scene}_Ghost.usda"
        shutil.copy2(canonical_usd_path, usd_path)
        _stage0607_log(run, f"USD DONE bytes={canonical_usd_path.stat().st_size if canonical_usd_path.exists() else 0}")

        # Preserve engine-native evidence separately without polluting the final manifest with tensors.
        evidence = runtime.get("primary_evidence", {})
        try:
            if evidence.get("engine") == "da3":
                np.savez_compressed(
                    run / "geometry" / "native" / "da3" / "evidence.npz",
                    depth_raw=_to_numpy(evidence.get("depth_raw")),
                    confidence=_to_numpy(evidence.get("confidence")),
                    sky_mask=_to_numpy(evidence.get("sky_mask")),
                )
                write_json(run / "geometry" / "native" / "da3" / "metadata.json", json_safe({k:v for k,v in evidence.items() if k not in {"depth_raw","confidence","sky_mask","source_image"}}))
            elif evidence.get("engine") == "moge":
                g = evidence.get("moge_geometry", {})
                arrays = {k:_to_numpy(v) for k,v in g.items() if k in {"points","depth","intrinsics","mask","normal"}}
                np.savez_compressed(run / "geometry" / "native" / "moge" / "evidence.npz", **arrays)
                write_json(run / "geometry" / "native" / "moge" / "metadata.json", json_safe({k:v for k,v in evidence.items() if k not in {"moge_geometry","source_image"}}))
        except Exception as exc:
            write_json(run / "logs" / "native_evidence_warning.json", {"warning": str(exc)})

        # Comparison output is preserved independently and is never promoted/fused.
        if runtime.get("secondary_canonical") is not None:
            sec = runtime["secondary_canonical"]
            secdir = run / "compare" / sec["engine"]
            secdir.mkdir(parents=True, exist_ok=True)
            write_ply_binary(secdir / "pointcloud.ply", np.asarray(sec["xyz"], dtype=np.float32), np.asarray(sec["rgb"], dtype=np.uint8))
            write_json(secdir / "geometry.json", {k:json_safe(v) for k,v in sec.items() if k not in {"xyz","rgb","confidence","source_uv"}})

        # Solver-paired Maya geometry contract: CG_FUSED_POINTS and CG_HERO_MESH
        # always come from the same selected primary canonical solver.  The mesh
        # reuses the exact canonical XYZ as its vertices, so alignment is exact
        # for DA3 and MoGe alike.  The upstream MoGe MESH input remains an
        # intermediate/diagnostic workflow output and is no longer the authority
        # for the Maya scene.
        _stage0607_log(run, "DCC TRANSPORT MESH START")
        hero_mesh_payload = _write_primary_mesh_payload(
            run, scene, canonical, scene_bundle["camera"], source_image
        )
        _stage0607_log(run, f"DCC TRANSPORT MESH DONE vertices={hero_mesh_payload.get('vertex_count')} faces={hero_mesh_payload.get('face_count')} stride={hero_mesh_payload.get('transport_stride', 1)}")


        # Maya worker contract is written before invocation; the worker updates maya_manifest.json.
        worker_input = {
            "schema": "ConceptGhost.MayaWorkerInput.v0.8",
            "scene_name": scene,
            "run_dir": str(run),
            "source_image": str(src_path),
            "ghost_usda": str(usd_path),
            "camera": json_safe(scene_bundle["camera"]),
            "coordinate_convention": dict(CANONICAL_COORDINATES),
            "point_count": int(len(xyz)),
            "geometry_engine": str(canonical.get("engine") or "unknown"),
            "hero_mesh_payload": hero_mesh_payload,
        }
        worker_input_path = write_json(run / "maya" / "maya_worker_input.json", worker_input)
        maya_ok = False
        fbx_ok = False
        worker_message = "Maya worker not attempted on this platform"
        bat = Path(__file__).with_name("run_maya_worker.bat")
        if os.name == "nt" and bat.exists():
            worker_timeout_seconds = 420
            _stage0607_log(run, f"MAYA WORKER START timeout={worker_timeout_seconds}s")
            proc = None
            try:
                creationflags = int(getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
                proc = subprocess.Popen(
                    ["cmd", "/c", str(bat), str(worker_input_path)],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=creationflags,
                )
                stdout, stderr = proc.communicate(timeout=worker_timeout_seconds)
                (run / "logs" / "maya_worker_stdout.txt").write_text(stdout or "", encoding="utf-8")
                (run / "logs" / "maya_worker_stderr.txt").write_text(stderr or "", encoding="utf-8")
                worker_message = f"Maya worker exit={proc.returncode}"
                _stage0607_log(run, worker_message)
            except subprocess.TimeoutExpired:
                worker_message = f"Maya worker TIMEOUT after {worker_timeout_seconds}s"
                _stage0607_log(run, worker_message)
                if proc is not None:
                    try:
                        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, text=True, timeout=30)
                    except Exception:
                        try: proc.kill()
                        except Exception: pass
                    try: stdout, stderr = proc.communicate(timeout=10)
                    except Exception: stdout, stderr = "", ""
                    (run / "logs" / "maya_worker_stdout.txt").write_text(stdout or "", encoding="utf-8")
                    (run / "logs" / "maya_worker_stderr.txt").write_text(stderr or "", encoding="utf-8")
                write_json(run / "logs" / "maya_worker_timeout.json", {"timeout_seconds": worker_timeout_seconds, "message": worker_message})
            except Exception as exc:
                worker_message = f"Maya worker error: {exc}"
                _stage0607_log(run, worker_message)
        ma_path = run / "maya" / f"ConceptGhost_{scene}_Ghost.ma"
        fbx_path = run / "maya" / f"ConceptGhost_{scene}_Ghost.fbx"
        camera_fbx_path = run / "maya" / f"ConceptGhost_{scene}_CameraOnly.fbx"
        maya_ok, fbx_ok, maya_worker_manifest = _maya_artifact_status(run, ma_path, fbx_path)
        ply_ok, usd_ok = ply_path.exists(), usd_path.exists()
        status = derive_run_status(
            camera_valid=bool(scene_bundle["camera"].get("valid")),
            geometry_has_points=bool(len(xyz)),
            integration_pass=bool(scene_bundle["integration_consistency"].get("pass")),
            geometry_health_pass=bool(scene_bundle["geometry_health"].get("pass")),
            maya_ok=maya_ok,
            ply_ok=ply_ok,
            usd_ok=usd_ok,
            fbx_ok=fbx_ok,
        )
        manifest = {
            "schema": "ConceptGhost.Manifest.v0.8",
            "scene": scene,
            "run_id": run.name,
            "preset": scene_bundle.get("preset"),
            "camera": json_safe(scene_bundle["camera"].get("provenance", {})),
            "geometry": {"engine": canonical["engine"], "point_count": int(len(xyz)), "health": json_safe(scene_bundle["geometry_health"])},
            "synergy_contributors": json_safe(scene_bundle.get("synergy_contributors", [])),
            "primary_authority": json_safe(scene_bundle.get("primary_authority", {})),
            "integration_consistency": json_safe(scene_bundle["integration_consistency"]),
            "coordinate_convention": dict(CANONICAL_COORDINATES),
            "status": status,
            "worker_message": worker_message,
            "maya_worker_manifest": json_safe(maya_worker_manifest),
            "hero_mesh": {
                "requested": True,
                "source_engine": canonical.get("engine"),
                "alignment": "EXACT_SAME_CANONICAL_XYZ",
                "payload": json_safe(hero_mesh_payload),
                "maya_status": json_safe((maya_worker_manifest or {}).get("hero_mesh", {})) if isinstance(maya_worker_manifest, dict) else {},
            },
            "outputs": {
                "ply": {"status": "PASS" if ply_ok else "FAIL", "path": str(ply_path), "sha256": sha256_file(ply_path) if ply_ok else None},
                "preview_ply": {
                    "status": "PASS" if (preview_ply_path and Path(preview_ply_path).is_file()) else "WARN",
                    "path": str(preview_ply_path) if preview_ply_path else None,
                    "sha256": sha256_file(preview_ply_path) if (preview_ply_path and Path(preview_ply_path).is_file()) else None,
                    "authority": "viewer-cache-only; canonical PLY remains authoritative",
                    "warning": preview_warning,
                },
                "usd": {"status": "PASS" if usd_ok else "FAIL", "path": str(usd_path), "sha256": sha256_file(usd_path) if usd_ok else None},
                "ma": {"status": "PASS" if maya_ok else "FAIL", "path": str(ma_path)},
                "fbx": {"status": "PASS" if fbx_ok else "FAIL", "path": str(fbx_path)},
                "camera_only_fbx": {
                    "status": str(((maya_worker_manifest or {}).get("camera_only_fbx") or {}).get("status") or "PENDING_RUNTIME") if isinstance(maya_worker_manifest, dict) else "PENDING_RUNTIME",
                    "path": str(camera_fbx_path),
                },
            },
        }
        manifest_path = write_json(run / "manifest.json", manifest)
        _stage0607_log(run, f"EXIT status={status['run_status']}")
        output_index = {
            "schema": "ConceptGhost.OutputIndex.v0.17",
            "run_id": run.name,
            "policy": "Official artist outputs are separated from intermediate/diagnostic evidence.",
            "official": {
                "matched_camera": {"path": str(camera_json), "role": "OFFICIAL_CAMERA"},
                "canonical_pointcloud": {"path": str(ply_path), "role": "OFFICIAL_GEOMETRY"},
                "canonical_usd": {"path": str(usd_path), "role": "OFFICIAL_INTERCHANGE"},
                "primary_mesh": {
                    "path": str(hero_mesh_payload.get("npz_path")),
                    "role": "OFFICIAL_MODELING_REFERENCE_MESH",
                    "source_engine": canonical.get("engine"),
                    "alignment": "EXACT_SAME_CANONICAL_XYZ",
                    "visibility_in_maya": "OFF_BY_DEFAULT",
                    "axis_policy": "canonical_world_no_extra_yz_flip",
                },
                "camera_only_fbx": {
                    "path": str(camera_fbx_path),
                    "role": "OFFICIAL_CAMERA_INTERCHANGE_BACKUP",
                    "status": str(((maya_worker_manifest or {}).get("camera_only_fbx") or {}).get("status") or "PENDING_RUNTIME") if isinstance(maya_worker_manifest, dict) else "PENDING_RUNTIME",
                },
                "maya_scene": {
                    "path": str(ma_path), "role": "OFFICIAL_ARTIST_SCENE", "status": "PASS" if maya_ok else "PENDING_RUNTIME",
                    "contains": ["CG_MATCHED_CAMERA", "CG_ARTIST_CAMERA", "CG_HERO_MESH", "CG_FUSED_POINTS"],
                    "hero_mesh_visibility_default": "OFF",
                    "geometry_pair_contract": "CG_FUSED_POINTS + CG_HERO_MESH use the same primary canonical solver XYZ",
                    "source_engine": canonical.get("engine"),
                    "alignment": "EXACT_SAME_CANONICAL_XYZ",
                },
                "fbx_interchange": {
                    "path": str(fbx_path), "role": "OFFICIAL_INTERCHANGE", "status": "PASS" if fbx_ok else "PENDING_RUNTIME",
                    "contains_when_stage11_plus": ["CG_MATCHED_CAMERA", "CG_ARTIST_CAMERA", "CG_HERO_MESH"],
                    "source_engine": canonical.get("engine"),
                    "mesh_alignment": "EXACT_SAME_CANONICAL_XYZ",
                },
                "manifest": {"path": str(manifest_path), "role": "OFFICIAL_MANIFEST"},
            },
            "intermediate": {
                "E1_ATLAS_RELIEF": {
                    "role": "INTERMEDIATE_DIAGNOSTIC",
                    "label": "E1 · Atlas Relief",
                    "track_report": str(run / "meshes" / "atlas_relief" / "track.json"),
                    "status": "PENDING_STAGE10",
                },
                "E2_MOGE_NATIVE_MESH": {
                    "role": "INTERMEDIATE_DIAGNOSTIC",
                    "label": "E2 · MoGe Native Preview Mesh",
                    "workflow_output_prefix": "conceptghost/moge_stage11",
                    "coordinate_space": "native MoGe/OpenCV camera space",
                    "uv_policy": "native; intended for ComfyUI preview",
                    "status": "PROVIDER_MANAGED_OUTPUT",
                },
                "E2_MOGE_MAYA_DCC": {
                    "role": "INTERMEDIATE_DCC_EXPORT",
                    "label": "E2-DCC · MoGe Maya-ready Mesh",
                    "workflow_output_prefix": "conceptghost/moge_stage11_maya",
                    "coordinate_space": "Atlas world / ConceptGhost canonical axes",
                    "uv_policy": "V flipped for Maya/DCC",
                    "maya_payload": None,
                    "embedded_in_maya_scene": False,
                    "status": "PROVIDER_MANAGED_OUTPUT_DIAGNOSTIC_ONLY",
                },
                "E3_DA3_MESH": {
                    "role": "INTERMEDIATE_DIAGNOSTIC",
                    "label": "E3 · DA3 Mesh / Bas-Relief",
                    "track_report": str(run / "meshes" / "da3_mesh" / "track.json"),
                    "status": "PENDING_STAGE12",
                },
            },
            "diagnostics": {
                "projection_support_mask": {"path": str(run / "diagnostics" / "projection_support_mask.png")},
                "reprojection_overlay": {"path": str(run / "diagnostics" / "reprojection_overlay.png")},
                "reprojection_report": {"path": str(run / "diagnostics" / "reprojection_report.json")},
                "geometry_health": {"path": str(run / "diagnostics" / "geometry_health.json")},
            },
        }
        write_json(run / "output_index.json", output_index)
        result = (
            str(run), str(ply_path), str(preview_ply_path or ply_path), str(usd_path), str(ma_path), str(fbx_path), str(manifest_path), status["run_status"]
        )
        ui_text = [
            f"ConceptGhost {status['run_status']}",
            f"Run: {run}",
            f"Points: {len(xyz):,}",
            f"PLY: {'OK' if ply_ok else 'FAIL'}",
            f"USD: {'OK' if usd_ok else 'FAIL'}",
            f"Maya: {'OK' if maya_ok else 'PENDING/FAIL'}",
            worker_message,
        ]
        return {"ui": {"text": ui_text}, "result": result}


class ConceptGhostSelectedAtlasSolve:
    """Expose the same Atlas solve selected by CameraRouter for downstream native Atlas tracks.

    This keeps Stage 10+ on the exact same camera decision as the canonical Ghost path
    without changing CameraRouter's established output contract.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "camera_mode": ("STRING", {"forceInput": True}),
                "learned_solve": ("ATLAS_SOLVE", {"lazy": True}),
                "vp_solve": ("ATLAS_SOLVE", {"lazy": True}),
            }
        }

    RETURN_TYPES = ("ATLAS_SOLVE", "STRING")
    RETURN_NAMES = ("selected_solve", "selection_report")
    FUNCTION = "route"
    CATEGORY = "ConceptGhost/02 Camera"

    def check_lazy_status(self, camera_mode, learned_solve=None, vp_solve=None):
        if camera_mode == "Atlas Learned":
            return ["learned_solve"] if learned_solve is None else []
        if camera_mode == "Atlas VP":
            return ["vp_solve"] if vp_solve is None else []
        if learned_solve is None:
            return ["learned_solve"]
        learned = camera_bundle_from_atlas_solve(learned_solve, requested_mode="Auto", final_solver="Atlas Learned")
        if learned.get("valid"):
            return []
        return ["vp_solve"] if vp_solve is None else []

    def route(self, camera_mode, learned_solve=None, vp_solve=None):
        if camera_mode == "Atlas Learned":
            selected = learned_solve
            solver = "Atlas Learned"
        elif camera_mode == "Atlas VP":
            selected = vp_solve
            solver = "Atlas VP"
        else:
            learned = camera_bundle_from_atlas_solve(learned_solve, requested_mode="Auto", final_solver="Atlas Learned")
            if learned.get("valid"):
                selected = learned_solve
                solver = "Atlas Learned"
            else:
                selected = vp_solve
                solver = "Atlas VP"
        if selected is None:
            raise RuntimeError("No Atlas solve available for selected camera mode")
        return (selected, _safe_text({"requested_mode": camera_mode, "selected_solver": solver}))


class ConceptGhostStageAudit:
    """Stage 9 structural audit.

    It records the run configuration and output status but never blocks downstream
    stages because of quality warnings. Only missing structural inputs raise errors.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "manifest_path": ("STRING", {"forceInput": True}),
                "camera_report": ("STRING", {"forceInput": True}),
                "router_report": ("STRING", {"forceInput": True}),
                "scene_report": ("STRING", {"forceInput": True}),
                "run_status": ("STRING", {"forceInput": True}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("stage9_report_path", "stage9_status")
    FUNCTION = "write"
    CATEGORY = "ConceptGhost/09 Audit"
    OUTPUT_NODE = True

    def write(self, run_dir, manifest_path, camera_report, router_report, scene_report, run_status):
        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir))))
        if not run.is_dir():
            raise RuntimeError(f"ConceptGhost run_dir does not exist: {run}")
        manifest = Path(os.path.expandvars(os.path.expanduser(str(manifest_path))))
        if not manifest.is_file():
            raise RuntimeError(f"ConceptGhost manifest does not exist: {manifest}")
        out = run / "benchmark" / "stage09_run_summary.json"
        payload = {
            "schema": "ConceptGhost.Stage09RunSummary.v0.12",
            "structural_status": "PASS",
            "quality_status": str(run_status),
            "policy": "Quality warnings do not block downstream stages; only structural/runtime failures block.",
            "manifest_path": str(manifest),
            "camera_report": camera_report,
            "geometry_router_report": router_report,
            "scene_report": scene_report,
        }
        write_json(out, payload)
        return (str(out), "PASS")






def _refine_moge_projection_support(moge_geometry, discontinuity_threshold: float = 0.20):
    geom = dict(moge_geometry)
    points = geom.get("points")
    if points is None:
        raise ValueError("moge_geometry has no points output")
    points_np = _to_numpy(points, np.float32)
    if points_np.ndim != 4 or points_np.shape[-1] != 3:
        raise ValueError(f"MoGe points must be BxHxWx3, got {points_np.shape}")
    b, h, w, _ = points_np.shape
    depth_obj = geom.get("depth")
    depth_np = _to_numpy(depth_obj, np.float32) if depth_obj is not None else np.linalg.norm(points_np, axis=-1)
    if depth_np.ndim == 4 and depth_np.shape[-1] == 1:
        depth_np = depth_np[..., 0]
    mask_obj = geom.get("mask")
    if mask_obj is None:
        base = np.ones((b, h, w), dtype=bool)
    else:
        base = _to_numpy(mask_obj).astype(bool)
        if base.ndim == 4 and base.shape[-1] == 1:
            base = base[..., 0]
    finite = np.isfinite(points_np).all(axis=-1) & np.isfinite(depth_np) & (depth_np > 0)
    support_np = base & finite
    if discontinuity_threshold > 0:
        for i in range(b):
            d = np.where(finite[i], depth_np[i], np.nan)
            padded = np.pad(d, 1, mode="edge")
            windows = np.lib.stride_tricks.sliding_window_view(padded, (3, 3))
            local_max = np.nanmax(windows, axis=(-2, -1))
            local_min = np.nanmin(windows, axis=(-2, -1))
            span = (local_max - local_min) / np.maximum(np.abs(depth_np[i]), 1e-6)
            edge = np.nan_to_num(span, nan=np.inf, posinf=np.inf, neginf=np.inf) > float(discontinuity_threshold)
            support_np[i] &= ~edge
    if torch is not None and hasattr(points, "device"):
        support = torch.as_tensor(support_np, device=points.device, dtype=torch.bool)
        pts_out = points.clone()
        pts_out[~support] = float("inf")
        geom["points"] = pts_out
        if depth_obj is not None and hasattr(depth_obj, "clone"):
            dep_out = depth_obj.clone()
            dep_out[~support] = float("inf")
            geom["depth"] = dep_out
        geom["mask"] = support
    else:
        support = support_np
        pts_out = np.array(points_np, copy=True)
        pts_out[~support_np] = np.inf
        geom["points"] = pts_out
        if depth_obj is not None:
            dep_out = np.array(depth_np, copy=True)
            dep_out[~support_np] = np.inf
            geom["depth"] = dep_out
        geom["mask"] = support_np
    geom["conceptghost_projection_support"] = support
    return geom, support


class ConceptGhostMoGeProjectionSupport:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "moge_geometry": ("MOGE_GEOMETRY",),
            "discontinuity_threshold": ("FLOAT", {"default": 0.20, "min": 0.0, "max": 2.0, "step": 0.01}),
        }}

    RETURN_TYPES = ("MOGE_GEOMETRY",)
    RETURN_NAMES = ("moge_geometry",)
    FUNCTION = "refine"
    CATEGORY = "ConceptGhost/03 Geometry Evidence"

    def refine(self, moge_geometry, discontinuity_threshold):
        refined, _ = _refine_moge_projection_support(moge_geometry, discontinuity_threshold)
        return (refined,)


def _projection_support_mask_from_canonical(canonical, width: int, height: int) -> np.ndarray:
    mask = np.zeros((int(height), int(width)), dtype=np.uint8)
    uv = np.asarray(canonical.get("source_uv", []), dtype=np.float32).reshape((-1, 2))
    if not len(uv):
        return mask
    x = np.rint(uv[:, 0]).astype(np.int64)
    y = np.rint(uv[:, 1]).astype(np.int64)
    good = (x >= 0) & (x < width) & (y >= 0) & (y < height)
    mask[y[good], x[good]] = 255
    return mask


def _clone_array_like(value):
    if hasattr(value, "clone"):
        return value.clone()
    return np.array(value, copy=True)


def _assign_array_like(target, values_np: np.ndarray):
    if torch is not None and hasattr(target, "detach") and hasattr(target, "device"):
        return torch.as_tensor(values_np, dtype=target.dtype, device=target.device)
    return np.asarray(values_np, dtype=getattr(target, "dtype", None))







def _prepare_moge_mesh_for_dcc(mesh, moge_geometry, camera_bundle):
    """Copy native MoGe mesh into Atlas/ConceptGhost world space for DCC export.

    Native preview is intentionally untouched.  The DCC branch converts OpenCV
    camera axes (+X right, +Y down, +Z forward) to ConceptGhost camera-local
    axes, applies the same metric registration policy as canonical MoGe, then
    applies Atlas camera-to-world.  UV V is flipped only on this export copy.
    """
    fixed = copy.copy(mesh)
    vertices = getattr(mesh, "vertices", None)
    if vertices is None:
        raise ValueError("MoGe MESH has no vertices attribute; cannot prepare DCC export")
    v_np = _to_numpy(vertices, np.float32).reshape((-1, 3)).copy()
    local_vertices = v_np.copy()
    local_vertices[:, 1] *= -1.0
    local_vertices[:, 2] *= -1.0

    points = _to_numpy((moge_geometry or {}).get("points"), np.float32)
    if points.ndim == 4:
        points = points[0]
    if points.ndim != 3 or points.shape[-1] != 3:
        raise ValueError(f"MoGe geometry points must resolve to HxWx3, got {points.shape}")
    local_grid = points.copy()
    local_grid[..., 1] *= -1.0
    local_grid[..., 2] *= -1.0
    mask = _to_numpy((moge_geometry or {}).get("mask"))
    if mask.size == 0:
        valid = np.isfinite(local_grid).all(axis=-1)
    else:
        if mask.ndim == 3:
            mask = mask[0]
        valid = mask.astype(bool) & np.isfinite(local_grid).all(axis=-1)
    metric_scale, metric_report = atlas_metric_scale_registration(camera_bundle, local_grid, valid)
    local_vertices *= float(metric_scale)

    world = np.asarray(camera_bundle["extrinsics"]["camera_world_matrix"], dtype=np.float64)
    if world.shape != (4, 4) or not np.isfinite(world).all():
        raise ValueError("CameraBundle requires a finite 4x4 camera_world_matrix for DCC mesh export")
    homo = np.concatenate([local_vertices.astype(np.float64), np.ones((len(local_vertices), 1), dtype=np.float64)], axis=1)
    world_vertices = (world @ homo.T).T[:, :3].astype(np.float32)
    fixed.vertices = _assign_array_like(vertices, world_vertices.reshape(_to_numpy(vertices).shape))

    uvs = getattr(mesh, "uvs", None)
    if uvs is not None:
        uv_np = _to_numpy(uvs, np.float32).copy()
        uv_np[..., 1] = 1.0 - uv_np[..., 1]
        fixed.uvs = _assign_array_like(uvs, uv_np)

    return fixed, {
        "coordinate_space": "Atlas world / ConceptGhost canonical axes",
        "native_axes": "+X right, +Y down, +Z forward",
        "dcc_axes_conversion": "X, -Y, -Z then Atlas camera_world_matrix",
        "uv_policy": "V flipped for Maya/DCC only",
        "metric_scale": float(metric_scale),
        "metric_registration": json_safe(metric_report),
    }


class ConceptGhostMeshForDCC:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "mesh": ("MESH",),
            "moge_geometry": ("MOGE_GEOMETRY",),
            "camera_bundle": (CG_CAMERA_BUNDLE,),
        }}

    RETURN_TYPES = ("MESH", "STRING")
    RETURN_NAMES = ("mesh", "dcc_report")
    FUNCTION = "prepare"
    CATEGORY = "ConceptGhost/11 Mesh Refinement"

    def prepare(self, mesh, moge_geometry, camera_bundle):
        fixed, report = _prepare_moge_mesh_for_dcc(mesh, moge_geometry, camera_bundle)
        return (fixed, _safe_text(report))


def _flip_mesh_uv_v(mesh):
    """Return a shallow-copied mesh with V flipped for Maya/DCC compatibility."""
    fixed = copy.copy(mesh)
    uvs = getattr(mesh, "uvs", None)
    if uvs is None:
        return fixed
    if hasattr(uvs, "clone"):
        new_uvs = uvs.clone()
    else:
        new_uvs = np.array(uvs, copy=True)
    new_uvs[..., 1] = 1.0 - new_uvs[..., 1]
    fixed.uvs = new_uvs
    return fixed


class ConceptGhostMeshUVFix:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"mesh": ("MESH",)}}

    RETURN_TYPES = ("MESH",)
    RETURN_NAMES = ("mesh",)
    FUNCTION = "fix"
    CATEGORY = "ConceptGhost/11 Mesh Refinement"

    def fix(self, mesh):
        return (_flip_mesh_uv_v(mesh),)


class ConceptGhostMeshTrackRecorder:
    """Non-blocking manifest recorder that also makes upstream mesh tracks executable outputs."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "mesh_path": ("STRING", {"forceInput": True}),
                "upstream_report": ("STRING", {"forceInput": True}),
                "track_name": ("STRING", {"default": "atlas_relief"}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("track_report_path", "track_status")
    FUNCTION = "record"
    CATEGORY = "ConceptGhost/10-12 Mesh Tracks"
    OUTPUT_NODE = True

    def record(self, run_dir, mesh_path, upstream_report, track_name):
        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir))))
        if not run.is_dir():
            raise RuntimeError(f"ConceptGhost run_dir does not exist: {run}")
        safe_track = sanitize_scene_name(track_name or "mesh_track")
        mesh = Path(os.path.expandvars(os.path.expanduser(str(mesh_path)))) if mesh_path else None
        exists = bool(mesh and mesh.is_file())
        payload = {
            "schema": "ConceptGhost.MeshTrack.v0.12",
            "track": safe_track,
            "structural_status": "PASS" if exists else "WARN",
            "quality_status": "UNJUDGED",
            "mesh_path": str(mesh) if mesh else None,
            "mesh_exists": exists,
            "upstream_report": upstream_report,
            "policy": "Mesh quality does not block end-to-end skeleton progression.",
        }
        out = run / "meshes" / safe_track / "track.json"
        write_json(out, payload)

        index_path = run / "output_index.json"
        if index_path.is_file():
            try:
                index = json.loads(index_path.read_text(encoding="utf-8"))
                key_map = {"atlas_relief": "E1_ATLAS_RELIEF", "da3_mesh": "E3_DA3_MESH"}
                key = key_map.get(safe_track)
                if key and key in index.get("intermediate", {}):
                    entry = index["intermediate"][key]
                    entry["path"] = str(mesh) if mesh else None
                    entry["track_report"] = str(out)
                    entry["structural_status"] = payload["structural_status"]
                    entry["status"] = "AVAILABLE" if exists else "WARN"
                    write_json(index_path, index)
            except Exception:
                # Discoverability metadata must never block the mesh track itself.
                pass
        return (str(out), payload["structural_status"])


class ConceptGhostStage13Packager:
    """Create the Stage 13 runtime package inventory and non-blocking acceptance report.

    Stage 13 does not judge artistic quality. It proves that the current run has a
    coherent, inspectable package with provenance and checksums. Quality status is
    carried forward verbatim and never converted into a structural failure.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "manifest_path": ("STRING", {"forceInput": True}),
                "stage09_report_path": ("STRING", {"forceInput": True}),
                "atlas_track_report_path": ("STRING", {"forceInput": True}),
                "da3_track_report_path": ("STRING", {"forceInput": True}),
                "quality_status": ("STRING", {"forceInput": True}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("package_manifest_path", "acceptance_report_path", "packaging_log_path", "stage13_status")
    FUNCTION = "package"
    CATEGORY = "ConceptGhost/13 Packaging"
    OUTPUT_NODE = True

    @staticmethod
    def _required_file(path_value: str, label: str) -> Path:
        p = Path(os.path.expandvars(os.path.expanduser(str(path_value))))
        if not p.is_file():
            raise RuntimeError(f"ConceptGhost Stage 13 missing {label}: {p}")
        return p

    def package(self, run_dir, manifest_path, stage09_report_path, atlas_track_report_path, da3_track_report_path, quality_status):
        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir))))
        if not run.is_dir():
            raise RuntimeError(f"ConceptGhost Stage 13 run_dir does not exist: {run}")

        manifest = self._required_file(manifest_path, "manifest")
        stage09 = self._required_file(stage09_report_path, "Stage 9 report")
        atlas_track = self._required_file(atlas_track_report_path, "Atlas mesh track report")
        da3_track = self._required_file(da3_track_report_path, "DA3 mesh track report")

        # Inventory the run as it exists before Stage 13 writes its own package files.
        files = []
        for p in sorted(x for x in run.rglob("*") if x.is_file()):
            try:
                rel = p.relative_to(run).as_posix()
            except ValueError:
                rel = str(p)
            files.append({
                "relative_path": rel,
                "bytes": int(p.stat().st_size),
                "sha256": sha256_file(p),
            })

        package_dir = run / "package"
        acceptance_dir = run / "acceptance"
        logs_dir = run / "logs"
        package_dir.mkdir(parents=True, exist_ok=True)
        acceptance_dir.mkdir(parents=True, exist_ok=True)
        logs_dir.mkdir(parents=True, exist_ok=True)

        package_manifest = package_dir / "stage13_package_manifest.json"
        acceptance_report = acceptance_dir / "stage13_acceptance.json"
        log_path = logs_dir / "stage13_packaging.log"

        package_payload = {
            "schema": "ConceptGhost.Stage13Package.v0.15",
            "structural_status": "PASS",
            "quality_status": str(quality_status),
            "run_dir": str(run),
            "authoritative_manifest": str(manifest),
            "stage09_report": str(stage09),
            "mesh_track_reports": {
                "atlas_relief": str(atlas_track),
                "da3_mesh": str(da3_track),
                "moge_mesh": "Produced by the Stage 11 SaveGLB output node; filename is provider-managed in this skeleton build.",
            },
            "file_count": len(files),
            "files": files,
            "policy": "This package inventories the current run; it does not promote diagnostic or mesh outputs over the canonical Ghost.",
        }
        write_json(package_manifest, package_payload)

        acceptance_payload = {
            "schema": "ConceptGhost.Stage13Acceptance.v0.15",
            "structural_status": "PASS",
            "quality_status": str(quality_status),
            "policy": "Quality status does not block end-to-end skeleton progression; only missing structural/runtime outputs block.",
            "required_inputs": {
                "manifest": str(manifest),
                "stage09_report": str(stage09),
                "atlas_track_report": str(atlas_track),
                "da3_track_report": str(da3_track),
            },
            "package_manifest": str(package_manifest),
            "next_stage": 14,
        }
        write_json(acceptance_report, acceptance_payload)

        lines = [
            "ConceptGhost Stage 13 Packaging",
            "structural_status=PASS",
            f"quality_status={quality_status}",
            f"file_count={len(files)}",
            f"package_manifest={package_manifest}",
            f"acceptance_report={acceptance_report}",
        ]
        log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return (str(package_manifest), str(acceptance_report), str(log_path), "PASS")


class ConceptGhostStage14CameraValidation:
    """Optional PCS/fSpy camera-validation branch.

    Atlas remains the production camera authority.  This node writes a neutral
    camera-reference contract on every run and, when the user supplies an fSpy
    project path, parses the fSpy project header/state and compares its camera
    calibration against Atlas.  A missing or invalid optional fSpy project never
    replaces Atlas or blocks the end-to-end skeleton.

    The fSpy file reader follows the public fSpy/fSpy-Blender project format:
    little-endian file id/version/header sizes followed by JSON state and image
    bytes.  Principal-point conversion follows the public fSpy-Blender importer
    conventions so the comparison is expressed in source-image pixels.
    """

    FSPY_FILE_ID = 2037412710
    FSPY_VERSION = 1

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "camera_bundle": (CG_CAMERA_BUNDLE,),
                "stage13_acceptance_path": ("STRING", {"forceInput": True}),
                "fspy_project_path": ("STRING", {"default": ""}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("validation_report_path", "camera_reference_path", "stage14_status")
    FUNCTION = "validate"
    CATEGORY = "ConceptGhost/14 Camera Validation"
    OUTPUT_NODE = True

    @staticmethod
    def _fspy_principal_point_px(pp_x: float, pp_y: float, width: int, height: int) -> tuple[float, float]:
        # fSpy-Blender expresses the fSpy normalized principal point relative to
        # image aspect before converting it to render/camera shift.  Recreate the
        # same normalized image location and convert to pixels for comparison.
        aspect = float(width) / float(height)
        if aspect <= 1.0:
            rel_x = 0.5 * (float(pp_x) / aspect + 1.0)
            rel_y = 0.5 * (-float(pp_y) + 1.0)
        else:
            rel_x = 0.5 * (float(pp_x) + 1.0)
            rel_y = 0.5 * (-float(pp_y) * aspect + 1.0)
        return rel_x * float(width), rel_y * float(height)

    @classmethod
    def _read_fspy(cls, path: Path) -> dict[str, Any]:
        with path.open("rb") as f:
            header = f.read(16)
            if len(header) != 16:
                raise ValueError("fSpy project header is incomplete")
            file_id, version, state_size, image_size = struct.unpack("<IIII", header)
            if file_id != cls.FSPY_FILE_ID:
                raise ValueError("file is not an fSpy project")
            if version != cls.FSPY_VERSION:
                raise ValueError(f"unsupported fSpy project version: {version}")
            state_raw = f.read(state_size)
            if len(state_raw) != state_size:
                raise ValueError("fSpy project JSON state is incomplete")
            state = json.loads(state_raw.decode("utf-8"))
        cp = state.get("cameraParameters") or {}
        pp = cp.get("principalPoint") or {}
        width = int(cp.get("imageWidth") or 0)
        height = int(cp.get("imageHeight") or 0)
        if width <= 0 or height <= 0:
            raise ValueError("fSpy cameraParameters contain invalid image dimensions")
        fov_rad = float(cp.get("horizontalFieldOfView"))
        ppx, ppy = cls._fspy_principal_point_px(float(pp.get("x", 0.0)), float(pp.get("y", 0.0)), width, height)
        transform = (cp.get("cameraTransform") or {}).get("rows")
        return {
            "project_path": str(path),
            "project_version": version,
            "image_payload_bytes": int(image_size),
            "image_width": width,
            "image_height": height,
            "horizontal_fov_deg": float(math.degrees(fov_rad)),
            "principal_point_px": [float(ppx), float(ppy)],
            "camera_transform_rows": transform,
            "reference_distance_unit": (state.get("calibrationSettingsBase") or {}).get("referenceDistanceUnit"),
        }

    def validate(self, run_dir, camera_bundle, stage13_acceptance_path, fspy_project_path):
        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir))))
        if not run.is_dir():
            raise RuntimeError(f"ConceptGhost Stage 14 run_dir does not exist: {run}")
        acceptance = Path(os.path.expandvars(os.path.expanduser(str(stage13_acceptance_path))))
        if not acceptance.is_file():
            raise RuntimeError(f"ConceptGhost Stage 14 missing Stage 13 acceptance report: {acceptance}")
        if not camera_bundle or not camera_bundle.get("valid"):
            raise RuntimeError("ConceptGhost Stage 14 requires a valid Atlas CameraBundle")

        validation_dir = run / "validation"
        validation_dir.mkdir(parents=True, exist_ok=True)
        reference_path = validation_dir / "stage14_atlas_camera_reference.json"
        report_path = validation_dir / "stage14_camera_validation.json"

        intr = camera_bundle.get("intrinsics", {})
        reference = {
            "schema": "ConceptGhost.Stage14CameraReference.v0.16",
            "camera_authority": "Atlas",
            "solver": (camera_bundle.get("provenance") or {}).get("final_solver"),
            "image_width": int(camera_bundle.get("image_width", 0)),
            "image_height": int(camera_bundle.get("image_height", 0)),
            "horizontal_fov_deg": float(camera_bundle.get("horizontal_fov_deg", 0.0)),
            "intrinsics": json_safe(intr),
            "camera_world_matrix": json_safe((camera_bundle.get("extrinsics") or {}).get("camera_world_matrix")),
            "pcs_role": "Reference contract for later PCS/manual camera validation; never replaces Atlas automatically.",
        }
        write_json(reference_path, reference)

        supplied = bool(str(fspy_project_path or "").strip())
        fspy_payload = None
        comparison = None
        comparison_status = "REFERENCE_ONLY"
        optional_warning = None
        if supplied:
            project = Path(os.path.expandvars(os.path.expanduser(str(fspy_project_path))))
            try:
                fspy_payload = self._read_fspy(project)
                atlas_w = int(reference["image_width"])
                atlas_h = int(reference["image_height"])
                atlas_pp = [float(intr.get("cx_px", 0.0)), float(intr.get("cy_px", 0.0))]
                fspy_pp = fspy_payload["principal_point_px"]
                comparison = {
                    "horizontal_fov_error_deg": abs(float(reference["horizontal_fov_deg"]) - float(fspy_payload["horizontal_fov_deg"])),
                    "principal_point_error_px": float(math.hypot(atlas_pp[0] - float(fspy_pp[0]), atlas_pp[1] - float(fspy_pp[1]))),
                    "image_size_match": bool(atlas_w == int(fspy_payload["image_width"]) and atlas_h == int(fspy_payload["image_height"])),
                    "transform_comparison": "deferred_axis_normalization; raw fSpy transform preserved for refinement phase",
                }
                comparison_status = "COMPARED"
            except Exception as exc:
                optional_warning = str(exc)
                comparison_status = "FSPY_WARNING"

        report = {
            "schema": "ConceptGhost.Stage14CameraValidation.v0.16",
            "structural_status": "PASS",
            "camera_authority": "Atlas",
            "comparison_status": comparison_status,
            "stage13_acceptance_path": str(acceptance),
            "atlas_reference_path": str(reference_path),
            "fspy": {
                "project_supplied": supplied,
                "parsed": fspy_payload is not None,
                "payload": fspy_payload,
                "warning": optional_warning,
            },
            "comparison": comparison,
            "references": {
                "fspy_role": "fSpy project format / manual vanishing-point camera baseline",
                "fspy_blender_role": "fSpy-Blender importer conventions for FOV, camera transform and principal-point interpretation",
                "pcs_role": "ConceptGhost PCS remains a future/manual validation consumer of this reference contract",
            },
            "policy": "Stage 14 is validation-only. fSpy/PCS evidence cannot silently replace the Atlas production camera. Missing optional fSpy input does not block the skeleton.",
        }
        write_json(report_path, report)
        return (str(report_path), str(reference_path), "PASS")






class ConceptGhostRunPackageDownload:
    """Final per-execution packaging node with an in-workflow browser download.

    It is intentionally downstream of the last enabled stage so the ZIP snapshots
    the complete execution folder, not just the early canonical export.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "run_dir": ("STRING", {"forceInput": True}),
            "completion_token": ("STRING", {"forceInput": True}),
        }}

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("complete_run_zip", "saved_run_folder", "package_status")
    FUNCTION = "package"
    CATEGORY = "ConceptGhost/Final Output"
    OUTPUT_NODE = True

    def package(self, run_dir, completion_token, output_dir=None):
        info = create_run_download_archive(run_dir, output_dir=output_dir)
        status = "PASS"
        text = [
            "ConceptGhost complete execution package READY",
            f"Saved run folder: {info['run_dir']}",
            f"Complete run ZIP: {info['archive_path']}",
            f"Upstream completion: {completion_token}",
        ]
        ui = {"text": text}
        if info.get("download"):
            ui["conceptghost_run_download"] = [info["download"]]
        return {"ui": ui, "result": (info["archive_path"], info["run_dir"], status)}


NODE_CLASS_MAPPINGS = {
    "ConceptGhostMasterConfig": ConceptGhostMasterConfig,
    "ConceptGhostCameraRouter": ConceptGhostCameraRouter,
    "ConceptGhostSelectedAtlasSolve": ConceptGhostSelectedAtlasSolve,
    "ConceptGhostAtlasToDA3CameraParams": ConceptGhostAtlasToDA3CameraParams,
    "ConceptGhostDA3Evidence": ConceptGhostDA3Evidence,
    "ConceptGhostMoGeEvidence": ConceptGhostMoGeEvidence,
    "ConceptGhostGeometryRouter": ConceptGhostGeometryRouter,
    "ConceptGhostCanonicalize": ConceptGhostCanonicalize,
    "ConceptGhostExportBundle": ConceptGhostExportBundle,
    "ConceptGhostStageAudit": ConceptGhostStageAudit,
    "ConceptGhostMoGeProjectionSupport": ConceptGhostMoGeProjectionSupport,
    "ConceptGhostMeshForDCC": ConceptGhostMeshForDCC,
    "ConceptGhostMeshUVFix": ConceptGhostMeshUVFix,
    "ConceptGhostMeshTrackRecorder": ConceptGhostMeshTrackRecorder,
    "ConceptGhostStage13Packager": ConceptGhostStage13Packager,
    "ConceptGhostStage14CameraValidation": ConceptGhostStage14CameraValidation,
    "ConceptGhostRunPackageDownload": ConceptGhostRunPackageDownload,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ConceptGhostMasterConfig": "ConceptGhost — Master Controls",
    "ConceptGhostCameraRouter": "ConceptGhost — Atlas Camera Router",
    "ConceptGhostSelectedAtlasSolve": "ConceptGhost — Selected Atlas Solve",
    "ConceptGhostAtlasToDA3CameraParams": "ConceptGhost — Atlas → DA3 Camera Conditioning",
    "ConceptGhostDA3Evidence": "ConceptGhost — DA3 Evidence",
    "ConceptGhostMoGeEvidence": "ConceptGhost — MoGe Evidence",
    "ConceptGhostGeometryRouter": "ConceptGhost — Geometry Router",
    "ConceptGhostCanonicalize": "ConceptGhost — Canonical Point Cloud",
    "ConceptGhostExportBundle": "ConceptGhost — Export Evaluation Bundle",
    "ConceptGhostStageAudit": "ConceptGhost — Stage 9 Run Audit",
    "ConceptGhostMoGeProjectionSupport": "ConceptGhost — MoGe Projection Support",
    "ConceptGhostMeshForDCC": "ConceptGhost — MoGe Mesh → Maya/DCC",
    "ConceptGhostMeshUVFix": "ConceptGhost — Flip Mesh V for Maya (legacy)",
    "ConceptGhostMeshTrackRecorder": "ConceptGhost — Mesh Track Recorder",
    "ConceptGhostStage13Packager": "ConceptGhost — Stage 13 Package & Acceptance",
    "ConceptGhostStage14CameraValidation": "ConceptGhost — Stage 14 PCS/fSpy Camera Validation",
    "ConceptGhostRunPackageDownload": "ConceptGhost — Download Complete Run",
}

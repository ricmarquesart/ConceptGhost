from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / 'custom_nodes' / 'ConceptGhost_Stage68'
if str(PKG.parent) not in sys.path:
    sys.path.insert(0, str(PKG.parent))

from ConceptGhost_Stage68.nodes import (
    _build_primary_mesh_arrays_from_canonical,
    _finalize_camera_facing_mesh_normals,
)


def _camera():
    return {'image_width': 8, 'image_height': 8, 'extrinsics': {'camera_position': [0.0, 0.0, 0.0]}}


def test_finalizer_rewinds_back_facing_faces_and_all_final_faces_face_camera():
    # Two triangles of the same square, deliberately opposite windings.
    v = np.asarray([
        [-1.0, -1.0, 5.0],
        [ 1.0, -1.0, 5.0],
        [-1.0,  1.0, 5.0],
        [ 1.0,  1.0, 5.0],
    ], dtype=np.float32)
    f = np.asarray([[0, 1, 2], [1, 2, 3]], dtype=np.int32)
    f2, vn, fn, fvn, report = _finalize_camera_facing_mesh_normals(v, f, _camera())
    cent = v[f2].mean(axis=1)
    to_cam = -cent
    assert np.all(np.einsum('ij,ij->i', fn, to_cam) > 0.0)
    assert report['back_facing_faces_after'] == 0
    dots = np.einsum('fci,fi->fc', fvn, fn)
    assert np.all(dots > 0.0)
    assert report['opposed_face_vertex_corners_after'] == 0


def test_folded_mesh_gets_per_face_vertex_hemisphere_repair():
    # A deliberately severe fold can make one shared smooth vertex normal unsafe.
    v = np.asarray([
        [0.0, 0.0, 5.0],
        [1.0, 0.0, 5.0],
        [0.0, 1.0, 5.0],
        [0.0, 0.0, 1.0],
    ], dtype=np.float32)
    f = np.asarray([[0, 2, 1], [0, 1, 3], [0, 3, 2]], dtype=np.int32)
    f2, vn, fn, fvn, report = _finalize_camera_facing_mesh_normals(v, f, _camera())
    dots = np.einsum('fci,fi->fc', fvn, fn)
    assert np.all(dots > 0.0)
    assert report['opposed_face_vertex_corners_after'] == 0


def test_primary_mesh_payload_contains_face_vertex_normals_and_auditable_report():
    h = w = 6
    yy, xx = np.indices((h, w), dtype=np.float32)
    # Mildly warped surface to exercise smooth normals without being planar-only.
    zz = 5.0 + 0.15 * np.sin(xx * 0.7) * np.cos(yy * 0.5)
    xyz = np.stack([xx - 2.5, yy - 2.5, zz], axis=-1).reshape(-1, 3)
    uv = np.stack([xx, yy], axis=-1).reshape(-1, 2)
    grid = np.stack([xx, yy], axis=-1).reshape(-1, 2).astype(np.int32)
    canonical = {
        'engine': 'moge',
        'xyz': xyz,
        'source_uv': uv,
        'grid_xy': grid,
        'geometric_boundary_strength': np.zeros(h*w, dtype=np.float32),
        'native_resolution': [w, h],
    }
    arrays, report = _build_primary_mesh_arrays_from_canonical(
        canonical, _camera(), w, h, max_transport_vertices=h*w
    )
    assert arrays['face_vertex_normals'].shape == (len(arrays['faces']), 3, 3)
    assert arrays['face_normals'].shape == (len(arrays['faces']), 3)
    assert report['normal_policy'] == 'final_topology_camera_facing_face_vertex_normals_v0.25'
    assert report['back_facing_faces_after'] == 0
    assert report['opposed_face_vertex_corners_after'] == 0
    dots = np.einsum('fci,fi->fc', arrays['face_vertex_normals'], arrays['face_normals'])
    assert np.all(dots > 0.0)



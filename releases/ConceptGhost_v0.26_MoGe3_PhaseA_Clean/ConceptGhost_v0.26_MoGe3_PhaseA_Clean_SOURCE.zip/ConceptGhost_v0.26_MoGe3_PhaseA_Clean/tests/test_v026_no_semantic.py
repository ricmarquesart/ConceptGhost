from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / "custom_nodes" / "ConceptGhost_Stage68"
sys.path.insert(0, str(PKG))

FEATURE_TOKENS = (
    "ConceptGhostSemanticAssist",
    "CG_SEMANTIC_BUNDLE",
    "conceptghost_semantics",
    "SEMANTIC_GEOMETRY_GATES",
    "semantic_assist_enabled",
    "semantic_backend",
    "semantic_refine_mode",
    "semantic_profile",
)


def test_no_retired_feature_source_artifacts():
    assert not (PKG / "conceptghost_semantics.py").exists()
    text = "\n".join(p.read_text(encoding="utf-8") for p in PKG.glob("*.py"))
    for token in FEATURE_TOKENS:
        assert token not in text


def test_master_workflow_has_no_retired_feature_nodes_or_ports_and_links_are_valid():
    wf = json.loads((ROOT / "Workflows" / "Project" / "ConceptGhost_Master.json").read_text(encoding="utf-8"))
    payload = json.dumps(wf, ensure_ascii=False)
    for token in FEATURE_TOKENS:
        assert token.lower() not in payload.lower()
    assert len(wf["nodes"]) == 31
    assert len(wf["links"]) == 79
    node_ids = {node["id"] for node in wf["nodes"]}
    link_ids = {link[0] for link in wf["links"]}
    assert all(link[1] in node_ids and link[3] in node_ids for link in wf["links"])
    for node in wf["nodes"]:
        for output in node.get("outputs", []):
            assert all(link_id in link_ids for link_id in (output.get("links") or []))
        for input_ in node.get("inputs", []):
            assert input_.get("link") is None or input_["link"] in link_ids


def test_master_config_only_core_controls():
    import nodes

    schema = nodes.ConceptGhostMasterConfig.INPUT_TYPES()["required"]
    assert list(schema) == [
        "scene_name",
        "preset",
        "camera_mode",
        "geometry_engine",
        "compare_both",
        "extra_diagnostics",
        "output_root",
    ]


def test_moge3_powershell_parser_fix_present():
    t = (ROOT / "Scripts" / "install_moge3_runtime.ps1").read_text(encoding="utf-8")
    assert "${LASTEXITCODE}: $Exe" in t
    assert "$LASTEXITCODE: $Exe" not in t


def test_moge3_pinned_source_is_complete_and_hash_locked():
    lock = json.loads((ROOT / "Tools" / "MoGeRuntime" / "SOURCE_LOCK.json").read_text(encoding="utf-8"))
    archive = ROOT / "Tools" / "MoGeRuntime" / "vendor" / "MoGe-main.zip"
    assert archive.is_file()
    assert archive.stat().st_size == int(lock["size"])
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == lock["sha256"]
    assert (ROOT / "Tools" / "MoGeRuntime" / "worker" / "moge_worker.py").is_file()
    assert (ROOT / "Tools" / "MoGeRuntime" / "worker" / "verify_moge3_runtime.py").is_file()


def test_cleanup_is_scoped_to_owned_private_runtime():
    t = (ROOT / "Scripts" / "remove_semantic_assist_runtime.ps1").read_text(encoding="utf-8")
    assert 'ConceptGhost-SemanticAssist-v1' in t
    assert 'OWNED_BY_CONCEPTGHOST_SEMANTIC_ASSIST_V1.txt' in t
    assert 'Remove-Item -LiteralPath $runtime -Recurse -Force' in t
    assert 'pip uninstall' not in t.lower()


def test_clean_installer_fresh_replaces_active_conceptghost_only():
    t = (ROOT / "Scripts" / "install_v026_clean.ps1").read_text(encoding="utf-8")
    assert 'custom_nodes\\ConceptGhost_Stage68' in t
    assert 'user\\default\\workflows\\ConceptGhost' in t
    assert 'Remove-Item -LiteralPath $Dst -Recurse -Force' in t
    assert 'remove_semantic_assist_runtime.ps1' in t
    assert 'pip uninstall' not in t.lower()

@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  ConceptGhost v0.32 - DA3 SAFE INVENTORY / NO DELETION
echo ============================================================
echo This step only measures, searches and classifies DA3-related data.
echo It does NOT delete Python, Torch, CUDA, NumPy, Single View, Multi View/Trellis, models or workflows.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\audit_da3_safe.ps1"
if errorlevel 1 ( echo. & echo [FAIL] DA3 audit failed. & pause & exit /b 1 )
pause

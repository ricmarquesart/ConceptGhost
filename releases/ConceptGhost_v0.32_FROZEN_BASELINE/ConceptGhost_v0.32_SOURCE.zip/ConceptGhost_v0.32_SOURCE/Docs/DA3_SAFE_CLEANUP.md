# DA3 safe cleanup

DA3 is retired from the future ConceptGhost architecture. Cleanup is split into two explicit phases.

## Audit only
`AUDIT_DA3_SAFE.bat` measures known DA3 paths, scans selected local roots for DA3/DepthAnythingV3-named candidates, searches workflow/code references, hashes protected Single View / Multi View / Trellis references, and writes JSON/TXT reports under `%LOCALAPPDATA%\ConceptGhost-Audits`. It deletes nothing.

Classification policy:
- `SAFE_TO_DELETE`: exact path proven ConceptGhost/DA3-exclusive;
- `KEEP`: shared/protected;
- `UNCERTAIN`: ownership not proven, therefore KEEP.

## Removal
`REMOVE_DA3_SAFE.bat` is fail-closed. The current automatic allow-list contains only exact DA3-exclusive ConceptGhost paths. Broad Pixi caches, ComfyUI Python/Torch/CUDA/NumPy, external plugins/models, Single View and Multi View/Trellis are not authorized for automatic deletion.

The removal report records reclaimed bytes, protected hashes and a ConceptGhost post-cleanup verification result.

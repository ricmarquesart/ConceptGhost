# ConceptGhost v0.32 checklist

## Frozen baseline
- [x] v0.31.1 last proven runtime baseline preserved
- [x] duplicate inventory completed
- [x] complete-run ZIP retired
- [x] single canonical USDA policy implemented
- [x] source texture reuse implemented
- [x] hard-link-first preview transport implemented
- [x] FBX compatibility alias policy implemented
- [x] fused-points preview restored
- [x] optional Light/Medium/Strong remesh implemented and validated on frozen real PrimaryMesh
- [x] v0.32 complete self-contained bundle built with pinned MoGe vendor
- [x] legacy release/workflow/cache files removed from bundle
- [ ] final fresh v0.32 Windows/ComfyUI/Maya acceptance — intentionally deferred

## Parallel DA3 track
- [x] safe read-only inventory tool included
- [x] fail-closed exact-path remover included
- [ ] run audit on target PC and review measured space
- [ ] prove any additional DA3 plugin/model paths exclusive before authorizing deletion
- [ ] execute safe removal and compare before/after space

## Improvement track (after v0.32 freeze)
See `FUTURE_IMPROVEMENTS.md`. First approved phase is MoGe native metric evidence/measurement, followed by deterministic Atlas metrology, MoGe × Atlas agreement, Maya metric diagnostics, Depth Pro witness and robust metric consensus.

# ConceptGhost v0.32 — Frozen baseline

This release freezes the deduplicated-output and optional-remesh architecture before the next improvement program.

Key changes already incorporated:
- automatic complete-run ZIP retired; run folder is authoritative;
- canonical USDA is single physical authority;
- source texture is reused;
- FBX FullScene compatibility path avoids a second full export payload;
- ComfyUI preview transport is hard-link-first with copy fallback;
- fused-points artist preview restored without a second PLY authority;
- optional Light / Medium / Strong remesh branches default OFF and never replace PrimaryMesh;
- safe DA3 audit/removal tooling is fail-closed;
- complete bundle includes the pinned MoGe source archive for clean-machine installation.

The final fresh Maya v0.32 acceptance is intentionally deferred until the remaining improvement gates are complete.

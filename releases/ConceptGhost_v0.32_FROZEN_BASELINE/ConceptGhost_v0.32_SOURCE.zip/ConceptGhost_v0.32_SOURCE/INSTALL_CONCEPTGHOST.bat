@echo off
setlocal
cd /d "%~dp0"
echo.
echo ============================================================
echo  ConceptGhost v0.32 COMPLETE - INSTALLER
echo ============================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\install_conceptghost.ps1"
if errorlevel 1 (
  echo.
  echo [FAIL] ConceptGhost v0.32 installation failed. Review the console/runtime logs.
  pause
  exit /b 1
)
echo.
echo [PASS] ConceptGhost v0.32 installation completed.
pause

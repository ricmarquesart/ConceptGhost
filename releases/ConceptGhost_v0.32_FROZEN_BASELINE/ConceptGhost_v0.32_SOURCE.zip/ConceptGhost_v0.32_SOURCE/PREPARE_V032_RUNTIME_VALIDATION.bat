@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  ConceptGhost v0.32 - Runtime Validation Preparation
echo ============================================================
echo.
call VERIFY_CONCEPTGHOST.bat
if errorlevel 1 exit /b %errorlevel%
echo.
echo [FINAL MAYA ACCEPTANCE - DEFERRED UNTIL FEATURE GATES COMPLETE]
echo 1. Fully close and restart ComfyUI Desktop.
echo 2. CLOSE any old/restored ConceptGhost tab.
echo 3. Explicitly open: ConceptGhost_Master_v0.32.json
echo 4. Confirm geometry_profile = High Fidelity.
echo 5. Run A: Generate Remesh Variants = OFF.
echo 6. Verify: VERIFY_V032_RUNTIME_OUTPUT.bat -RemeshMode OFF
echo 7. Run B: Generate Remesh Variants = ON.
echo 8. Verify: VERIFY_V032_RUNTIME_OUTPUT.bat -RemeshMode ON
echo.
echo This Maya acceptance is intentionally deferred until the remaining improvement gates are complete.
echo.
pause

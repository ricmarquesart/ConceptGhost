# ConceptGhost v0.32 COMPLETE

Frozen pre-improvement baseline for ConceptGhost. This package consolidates the v0.31.2 dedup/remesh work into one clean, self-contained v0.32 bundle.

## What is included
- one current workflow: `Workflows/Project/ConceptGhost_Master_v0.32.json`
- ConceptGhost custom nodes and Maya worker
- installer and installed-file verifier
- final runtime/Maya acceptance verifier (intentionally deferred until remaining feature gates are complete)
- safe DA3 inventory/removal tools
- pinned MoGe source vendor archive required for clean-machine installation
- MoGe worker/runtime bootstrap files
- current regression tests and golden Maya fixture
- current checklist and future-improvements decision document

## What is deliberately not included
- v0.30/v0.31 workflows or release reports
- historical RC wrappers
- `__pycache__`, `.pytest_cache`, generated outputs or run ZIP snapshots
- DA3 runtime/plugin/model payloads
- duplicated project outputs

## Install
Run `INSTALL_CONCEPTGHOST.bat`, then `VERIFY_CONCEPTGHOST.bat`.

The installer modifies only ConceptGhost-owned payload/runtime locations. It must not replace global/ComfyUI Python, Torch, CUDA or NumPy.

## DA3 cleanup
1. Run `AUDIT_DA3_SAFE.bat`. This is read-only and creates an inventory report.
2. Review `SAFE_TO_DELETE / KEEP / UNCERTAIN`. `UNCERTAIN` always means KEEP.
3. Only after review, `REMOVE_DA3_SAFE.bat` may remove exact DA3-exclusive paths authorized by the hard safety fence.

## Maya acceptance
Maya validation is deliberately postponed until the remaining non-Maya improvement gates are complete. `PREPARE_V032_RUNTIME_VALIDATION.bat` and `VERIFY_V032_RUNTIME_OUTPUT.bat` remain in the bundle for the final acceptance phase.

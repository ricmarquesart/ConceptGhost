@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  ConceptGhost v0.32 - DA3 SAFE REMOVAL
echo ============================================================
echo Run AUDIT_DA3_SAFE.bat first and review the report.
echo This remover is fail-closed and only removes exact paths proven DA3-exclusive.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\remove_da3_safe.ps1"
if errorlevel 1 ( echo. & echo [FAIL] Safe DA3 cleanup was blocked or failed. & pause & exit /b 1 )
pause

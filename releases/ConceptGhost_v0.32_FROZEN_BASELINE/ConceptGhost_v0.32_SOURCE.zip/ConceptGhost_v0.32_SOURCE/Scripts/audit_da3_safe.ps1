param(
    [string]$ReportRoot = "$env:LOCALAPPDATA\ConceptGhost-Audits"
)
$ErrorActionPreference = "Stop"

function Get-PathStats([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) {
        return [pscustomobject]@{ Bytes=[int64]0; Files=[int64]0; Exists=$false }
    }
    $item = Get-Item -LiteralPath $Path -Force
    if (-not $item.PSIsContainer) {
        return [pscustomobject]@{ Bytes=[int64]$item.Length; Files=[int64]1; Exists=$true }
    }
    $sum=[int64]0; $count=[int64]0
    Get-ChildItem -LiteralPath $Path -Recurse -Force -File -ErrorAction SilentlyContinue | ForEach-Object {
        $sum += [int64]$_.Length; $count++
    }
    return [pscustomobject]@{ Bytes=$sum; Files=$count; Exists=$true }
}
function Human([int64]$Bytes) {
    if ($Bytes -ge 1GB) { return ("{0:N2} GB" -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ("{0:N2} MB" -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ("{0:N2} KB" -f ($Bytes / 1KB)) }
    return ("{0:N0} B" -f $Bytes)
}
function New-AuditItem([string]$Name,[string]$Path,[string]$Class,[string]$Reason,[string]$Owner) {
    $stats=Get-PathStats $Path
    return [pscustomobject]@{
        Name=$Name; Path=$Path; Bytes=$stats.Bytes; Files=$stats.Files; Exists=$stats.Exists
        Class=$Class; Reason=$Reason; Owner=$Owner
    }
}

$PreferredComfy = Join-Path $env:LOCALAPPDATA "Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"
$Comfy = $PreferredComfy
if (-not (Test-Path $Comfy)) {
    $Candidates = @(
        (Join-Path $env:LOCALAPPDATA "Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"),
        (Join-Path $env:LOCALAPPDATA "Programs\@comfyorgcomfyui-electron\resources\ComfyUI")
    )
    $Comfy = $Candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $Comfy) { throw "ComfyUI root not found" }

# Exact ConceptGhost-owned DA3 paths. Only the isolated env + host-path config are
# eligible for SAFE_TO_DELETE. Broad caches are deliberately never auto-approved.
$ProjectDa3Env = "C:\ConceptGhost\cache\da3-comfy-env"
$Da3HostPathConfig = "C:\ConceptGhost\config\da3_host_paths.json"
$ProjectPixi = "C:\ConceptGhost\cache\pixi"
$Plugin = Join-Path $Comfy "custom_nodes\ComfyUI-DepthAnythingV3"
$Models = Join-Path $Comfy "models\depthanything3"
$Tokens = @("DepthAnythingV3","DepthAnything_V3","DA3_ToMesh","DA3_PreviewPointCloud","DownloadAndLoadDepthAnythingV3Model","ComfyUI-DepthAnythingV3")
$ProtectedTokens = @("Trellis","Multi View","MultiView","Single View","SingleView")

# Search references outside the DA3 plugin. A reference makes plugin/model deletion
# explicitly unsafe. No reference still means UNCERTAIN, because workflows can live
# outside the scanned roots.
$Refs = New-Object System.Collections.Generic.List[string]
$ProtectedRefs = New-Object System.Collections.Generic.List[string]
$Roots = @((Join-Path $Comfy "user"),(Join-Path $Comfy "custom_nodes"))
foreach ($Root in $Roots) {
    if (-not (Test-Path $Root)) { continue }
    Get-ChildItem -LiteralPath $Root -Recurse -File -Include *.json,*.py,*.md,*.txt -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.FullName -notlike "$Plugin*") {
            try {
                $txt = Get-Content -LiteralPath $_.FullName -Raw -ErrorAction Stop
                foreach ($t in $Tokens) {
                    if ($txt -match [regex]::Escape($t)) { $Refs.Add($_.FullName); break }
                }
                foreach ($t in $ProtectedTokens) {
                    if ($txt -match [regex]::Escape($t)) { $ProtectedRefs.Add($_.FullName); break }
                }
            } catch {}
        }
    }
}
$Refs = @($Refs | Sort-Object -Unique)
$ProtectedRefs = @($ProtectedRefs | Sort-Object -Unique)
$ProtectedReferenceHashes = @()
foreach($P in $ProtectedRefs){
    if(Test-Path -LiteralPath $P){
        try {
            $ProtectedReferenceHashes += [pscustomobject]@{ Path=$P; Sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $P).Hash.ToLowerInvariant() }
        } catch {}
    }
}


# Broader discovery pass: names only. This inventory intentionally does not infer
# ownership from a filename and never auto-authorizes discovered paths for deletion.
$DiscoveryRoots = @(
    "C:\ConceptGhost",
    (Join-Path $env:LOCALAPPDATA "Comfy-Desktop"),
    (Join-Path $env:LOCALAPPDATA "ConceptGhost-ArchivedCustomNodes"),
    (Join-Path $env:USERPROFILE ".cache")
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
$DiscoveryPatterns = @("*DA3*","*DepthAnythingV3*","*DepthAnything3*","*depthanything3*","*Depth-Anything-V3*")
$Discovered = New-Object System.Collections.Generic.List[object]
foreach($Root in $DiscoveryRoots){
    foreach($Pattern in $DiscoveryPatterns){
        Get-ChildItem -LiteralPath $Root -Recurse -Force -ErrorAction SilentlyContinue -Filter $Pattern | ForEach-Object {
            $stats=Get-PathStats $_.FullName
            $Discovered.Add([pscustomobject]@{
                Path=$_.FullName; Bytes=$stats.Bytes; Files=$stats.Files; Exists=$true;
                Class="UNCERTAIN"; Reason="Name/token discovery only. Ownership is not proven; defaults to KEEP."
            })
        }
    }
}
$Discovered=@($Discovered | Sort-Object Path -Unique)

$Items = @(
    (New-AuditItem "ConceptGhost DA3 isolated env" $ProjectDa3Env "SAFE_TO_DELETE" "Exact retired DA3-only isolated environment under ConceptGhost-owned cache path." "ConceptGhost/DA3"),
    (New-AuditItem "ConceptGhost DA3 host-path config" $Da3HostPathConfig "SAFE_TO_DELETE" "DA3-only worker path-alignment configuration." "ConceptGhost/DA3"),
    (New-AuditItem "ConceptGhost Pixi cache" $ProjectPixi "KEEP" "Broad package/runtime cache may be shared by current or future ConceptGhost environments; exclusivity is not proven." "SHARED_OR_UNCERTAIN"),
    (New-AuditItem "ComfyUI-DepthAnythingV3 plugin" $Plugin ($(if($Refs.Count -gt 0){"KEEP"}else{"UNCERTAIN"})) ($(if($Refs.Count -gt 0){"DA3 references exist outside plugin."}else{"No scanned reference found, but external workflows may exist; do not auto-delete."})) "EXTERNAL_COMFY_PLUGIN"),
    (New-AuditItem "DepthAnythingV3 models" $Models ($(if($Refs.Count -gt 0){"KEEP"}else{"UNCERTAIN"})) ($(if($Refs.Count -gt 0){"DA3 references exist; model ownership may be shared."}else{"No scanned reference found, but model may be used outside ConceptGhost; do not auto-delete."})) "EXTERNAL_MODEL_CACHE")
)

$SafeBytes=[int64](($Items | Where-Object {$_.Class -eq "SAFE_TO_DELETE"} | Measure-Object -Property Bytes -Sum).Sum)
$KeepBytes=[int64](($Items | Where-Object {$_.Class -eq "KEEP"} | Measure-Object -Property Bytes -Sum).Sum)
$UncertainBytes=[int64](($Items | Where-Object {$_.Class -eq "UNCERTAIN"} | Measure-Object -Property Bytes -Sum).Sum)
$MeasuredBytes=[int64](($Items | Measure-Object -Property Bytes -Sum).Sum)

New-Item -ItemType Directory -Force -Path $ReportRoot | Out-Null
$Stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$JsonPath=Join-Path $ReportRoot ("DA3_SAFE_CLEANUP_AUDIT_"+$Stamp+".json")
$TxtPath=Join-Path $ReportRoot ("DA3_SAFE_CLEANUP_AUDIT_"+$Stamp+".txt")
$Report=[ordered]@{
    schema="ConceptGhost.DA3SafeCleanupAudit.v0.32"
    timestamp=(Get-Date).ToString("o")
    mode="MEASURE_AND_CLASSIFY_ONLY_NO_DELETION"
    comfy_root=$Comfy
    references=$Refs
    reference_count=$Refs.Count
    protected_workflow_references=$ProtectedRefs
    protected_reference_hashes=$ProtectedReferenceHashes
    items=$Items
    discovered_candidates=$Discovered
    discovery_roots=$DiscoveryRoots
    total_measured_bytes=$MeasuredBytes
    safe_to_delete_bytes=$SafeBytes
    keep_bytes=$KeepBytes
    uncertain_bytes=$UncertainBytes
    classification_policy=@{
        SAFE_TO_DELETE="Proven ConceptGhost DA3-exclusive exact path; eligible for separate explicit cleanup."
        KEEP="Shared/protected or known non-exclusive; never delete in DA3 cleanup."
        UNCERTAIN="Exclusivity not proven; defaults to KEEP and is never auto-deleted."
    }
    protected_invariants=@(
        "Do not modify/remove shared Python or Python environments used by other projects.",
        "Do not modify/remove Torch/PyTorch.",
        "Do not modify/remove CUDA drivers/toolkits/runtimes/GPU libraries.",
        "Do not modify/remove NumPy or other shared Python dependencies.",
        "Do not modify/remove Single View workflows/runtimes.",
        "Do not modify/remove Multi View/Trellis workflows/runtimes.",
        "Do not modify/remove unrelated ComfyUI custom nodes, models, caches or workflows.",
        "UNCERTAIN always means KEEP until ownership is proven separately."
    )
}
$Report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $JsonPath -Encoding UTF8
$lines=@()
$lines += "ConceptGhost v0.32 - SAFE DA3 cleanup audit (NO DELETION)"
$lines += "================================================================"
foreach($i in $Items){$lines += ("{0,-36} {1,12}  {2,-14} files={3}`n  {4}`n  reason: {5}" -f $i.Name,(Human $i.Bytes),$i.Class,$i.Files,$i.Path,$i.Reason)}
$lines += ""
$lines += "Discovered DA3-named candidates (UNCERTAIN/KEEP by default): $($Discovered.Count)"
$Discovered | ForEach-Object {$lines += ("  {0}  {1}" -f (Human $_.Bytes),$_.Path)}
$lines += ""
$lines += "DA3 references outside plugin: $($Refs.Count)"
$Refs | ForEach-Object {$lines += "  $_"}
$lines += ""
$lines += "Protected Single/Multi/Trellis references observed: $($ProtectedRefs.Count)"
$ProtectedRefs | Select-Object -First 30 | ForEach-Object {$lines += "  $_"}
if($ProtectedRefs.Count -gt 30){$lines += "  ... $($ProtectedRefs.Count-30) more"}
$lines += ""
$lines += "Total measured candidates: $(Human $MeasuredBytes)"
$lines += "SAFE_TO_DELETE: $(Human $SafeBytes)"
$lines += "KEEP:           $(Human $KeepBytes)"
$lines += "UNCERTAIN:      $(Human $UncertainBytes)"
$lines += ""
$lines += "No files were deleted. Run REMOVE_DA3_CONCEPTGHOST_ONLY.bat only after reviewing this audit."
$lines | Set-Content -LiteralPath $TxtPath -Encoding UTF8
$lines | ForEach-Object { Write-Host $_ }
Write-Host ""; Write-Host "JSON: $JsonPath" -ForegroundColor Cyan; Write-Host "TXT : $TxtPath" -ForegroundColor Cyan

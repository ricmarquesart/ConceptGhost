$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot

$PreferredComfy = "C:\Users\rmarq\AppData\Local\Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"
$Comfy = $PreferredComfy
if (-not (Test-Path $Comfy)) {
    $Candidates = @(
        (Join-Path $env:LOCALAPPDATA "Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"),
        (Join-Path $env:LOCALAPPDATA "Programs\@comfyorgcomfyui-electron\resources\ComfyUI")
    )
    $Comfy = $Candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $Comfy -or -not (Test-Path $Comfy)) {
    $Comfy = Read-Host "ComfyUI root not found. Enter full path to ComfyUI"
}
if (-not (Test-Path $Comfy)) { throw "ComfyUI root not found: $Comfy" }

$CustomNodesRoot = Join-Path $Comfy "custom_nodes"
$Src = Join-Path $Root "custom_nodes\ConceptGhost_Stage68"
$Dst = Join-Path $CustomNodesRoot "ConceptGhost_Stage68"
if (-not (Test-Path $Src)) { throw "Bundle custom node source missing: $Src" }
if (-not (Test-Path (Join-Path $Src "run_maya_worker.bat"))) { throw "Maya launcher missing from v0.32 package" }

# Move only stale ConceptGhost copies out of ComfyUI. Never touch unrelated custom nodes.
$ArchiveBase = Join-Path $env:LOCALAPPDATA "ConceptGhost-ArchivedCustomNodes"
$ArchiveStamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ArchiveRun = Join-Path $ArchiveBase $ArchiveStamp
$Archived = @()
if (Test-Path $CustomNodesRoot) {
    $Candidates = Get-ChildItem -LiteralPath $CustomNodesRoot -Directory -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -like "ConceptGhost_Stage68*" -and $_.FullName -ne $Dst
    }
    foreach ($Candidate in $Candidates) {
        $NodesPy = Join-Path $Candidate.FullName "nodes.py"
        $Owned = $false
        if (Test-Path $NodesPy) {
            try { $Owned = (Get-Content -LiteralPath $NodesPy -Raw -ErrorAction Stop) -match "ConceptGhostMasterConfig" } catch { $Owned = $false }
        }
        if ($Owned) {
            if (-not (Test-Path $ArchiveRun)) { New-Item -ItemType Directory -Force -Path $ArchiveRun | Out-Null }
            $Target = Join-Path $ArchiveRun $Candidate.Name
            Move-Item -LiteralPath $Candidate.FullName -Destination $Target -Force
            $Archived += $Target
            Write-Host "[ARCHIVED] stale ConceptGhost custom node: $($Candidate.Name)" -ForegroundColor Yellow
        }
    }
}

if (Test-Path $Dst) { Remove-Item -LiteralPath $Dst -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Dst | Out-Null
Copy-Item (Join-Path $Src "*") $Dst -Recurse -Force
Set-Content -LiteralPath (Join-Path $Dst "CONCEPTGHOST_VERSION.txt") -Value "ConceptGhost v0.32" -Encoding UTF8

$WfSrc = Join-Path $Root "Workflows\Project"
$WfDst = Join-Path $Comfy "user\default\workflows\ConceptGhost"
if (Test-Path $WfDst) { Remove-Item -LiteralPath $WfDst -Recurse -Force }
New-Item -ItemType Directory -Force -Path $WfDst | Out-Null
Copy-Item (Join-Path $WfSrc "*.json") $WfDst -Force

$CanonicalWorkflow = Join-Path $WfDst "ConceptGhost_Master_v0.32.json"
if (-not (Test-Path $CanonicalWorkflow)) { throw "v0.32 Dedup/Remesh workflow was not installed: $CanonicalWorkflow" }
$WorkflowHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $CanonicalWorkflow).Hash.ToLowerInvariant()
$Marker = [ordered]@{
    schema = "ConceptGhost.InstallMarker.v0.32"
    installed_at = (Get-Date).ToString("o")
    installed_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    comfy_root = $Comfy
    custom_nodes_path = $Dst
    canonical_workflow = $CanonicalWorkflow
    canonical_workflow_sha256 = $WorkflowHash
    release = "ConceptGhost_v0.32_COMPLETE"
}
$MarkerPath = Join-Path $env:LOCALAPPDATA "ConceptGhost-v0.32-install.json"
$Marker | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $MarkerPath -Encoding UTF8

Write-Host "[PASS] ConceptGhost v0.32 payload installed: $Comfy" -ForegroundColor Green
Write-Host "Default geometry: MoGe-3 / High Fidelity. Low Resolution and High Fidelity Split Clean are alternate profiles." -ForegroundColor Green
Write-Host "Single View, Multi View/Trellis, MoGe-2 and unrelated custom nodes/runtimes were not modified." -ForegroundColor Green
Write-Host "" 
Write-Host "IMPORTANT: ComfyUI can restore an OLD workflow tab from browser/UI state." -ForegroundColor Yellow
Write-Host "Close any old ConceptGhost tab and explicitly open this file:" -ForegroundColor Yellow
Write-Host "  $CanonicalWorkflow" -ForegroundColor Cyan
Write-Host "The MASTER node must show High Fidelity as default; Low Resolution and High Fidelity Split Clean are alternates" -ForegroundColor Cyan
Write-Host "The Primary + Optional Remesh node must default Generate Remesh Variants = OFF." -ForegroundColor Cyan
Write-Host "Install marker: $MarkerPath" -ForegroundColor DarkGray
if ($Archived.Count -gt 0) {
    Write-Host "Archived old ConceptGhost duplicates outside ComfyUI:" -ForegroundColor Yellow
    $Archived | ForEach-Object { Write-Host "  $_" -ForegroundColor Yellow }
}

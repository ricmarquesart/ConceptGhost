$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " ConceptGhost v0.32 - Deduplicated Outputs / Optional Remesh Installer" -ForegroundColor Cyan
Write-Host " MoGe-3 Low Resolution ViT-L + High Fidelity ViT-G" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This installer changes only ConceptGhost-owned files/runtimes." -ForegroundColor Yellow
Write-Host "It does NOT replace ComfyUI Python/Torch/CUDA or other project runtimes." -ForegroundColor Yellow
Write-Host ""

& (Join-Path $PSScriptRoot "install_comfy_payload.ps1")
& (Join-Path $PSScriptRoot "install_moge3_runtime.ps1")

Write-Host ""
Write-Host "[PASS] ConceptGhost v0.32 installation finished." -ForegroundColor Green
Write-Host "Low Resolution: MoGe-3 ViT-L, lightweight transport behavior." -ForegroundColor Green
Write-Host "High Fidelity: MoGe-3 ViT-G, resolution max, SSR=7, raw-preserving support, edge-aware full-resolution mesher." -ForegroundColor Green
Write-Host "Fully restart ComfyUI Desktop before opening the new workflow." -ForegroundColor Cyan

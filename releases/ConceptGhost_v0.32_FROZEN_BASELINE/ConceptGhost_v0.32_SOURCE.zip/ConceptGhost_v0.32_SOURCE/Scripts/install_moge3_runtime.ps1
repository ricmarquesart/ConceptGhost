param(
    [string]$RuntimeRoot = "$env:LOCALAPPDATA\ConceptGhost-MoGeRuntime-v1"
)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$BundleRoot = Split-Path -Parent $PSScriptRoot
$ToolRoot = Join-Path $BundleRoot "Tools\MoGeRuntime"
$VendorZip = Join-Path $ToolRoot "vendor\MoGe-main.zip"
$WorkerSrc = Join-Path $ToolRoot "worker"
$PythonRoot = Join-Path $RuntimeRoot "python"
$PythonExe = Join-Path $PythonRoot "python.exe"
$RepoRoot = Join-Path $RuntimeRoot "repo"
$Repo = Join-Path $RepoRoot "MoGe"
$WorkerDst = Join-Path $RuntimeRoot "worker"
$Cache = Join-Path $RuntimeRoot "cache"
$Logs = Join-Path $RuntimeRoot "logs"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Log = Join-Path $Logs ("install_" + $Stamp + ".log")
$TorchIndex = if ($env:CONCEPTGHOST_MOGE_TORCH_INDEX) { $env:CONCEPTGHOST_MOGE_TORCH_INDEX } else { "https://download.pytorch.org/whl/cu130" }

New-Item -ItemType Directory -Force -Path $RuntimeRoot,$PythonRoot,$RepoRoot,$WorkerDst,$Cache,$Logs | Out-Null
"ConceptGhost MoGe Runtime v1 - owned isolated runtime" | Set-Content (Join-Path $RuntimeRoot "OWNED_BY_CONCEPTGHOST_MOGE_RUNTIME_V1.txt") -Encoding UTF8

function Log([string]$Text) {
    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Text"
    Write-Host $line
    Add-Content -Path $Log -Value $line -Encoding UTF8
}

function Run([string]$Exe, [string[]]$CommandArgs) {
    Log ("RUN: `"$Exe`" " + ($CommandArgs -join ' '))

    # Windows PowerShell 5.1 wraps native stderr as NativeCommandError when stderr
    # is merged into the console. Capture stderr separately so harmless pip warnings
    # never look like a PowerShell failure; the native exit code remains authoritative.
    $stderrPath = Join-Path $Logs ("stderr_" + [guid]::NewGuid().ToString("N") + ".log")
    $PreviousErrorActionPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        & $Exe @CommandArgs 2> $stderrPath | Tee-Object -FilePath $Log -Append
        $ExitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $PreviousErrorActionPreference
    }

    $stderrText = ""
    if (Test-Path $stderrPath) {
        try { $stderrText = Get-Content -LiteralPath $stderrPath -Raw -ErrorAction SilentlyContinue } catch { $stderrText = "" }
        if ($stderrText) {
            Add-Content -Path $Log -Value $stderrText -Encoding UTF8
            if ($ExitCode -ne 0) { Write-Host $stderrText -ForegroundColor Red }
        }
        Remove-Item -LiteralPath $stderrPath -Force -ErrorAction SilentlyContinue
    }

    if ($ExitCode -ne 0) { throw "Command failed with exit code ${ExitCode}: $Exe" }
}

Log "ConceptGhost v0.31 MoGe-3 isolated runtime installation / repair (ViT-L + ViT-G)."
Log "Runtime root: $RuntimeRoot"
Log "Torch index: $TorchIndex"
Log "Protected ComfyUI path (read-only / never modified): C:\Users\rmarq\AppData\Local\Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"

$Ready = Join-Path $RuntimeRoot "READY.json"
$ModelsReady = Join-Path $RuntimeRoot "MODELS_READY.json"

function Set-RuntimeEnvironment {
    $env:HF_HOME = Join-Path $Cache "hf"
    $env:HUGGINGFACE_HUB_CACHE = Join-Path $Cache "hf\hub"
    $env:TORCH_HOME = Join-Path $Cache "torch"
    $env:CONCEPTGHOST_MOGE_RUNTIME = $RuntimeRoot
    New-Item -ItemType Directory -Force -Path $env:HF_HOME,$env:HUGGINGFACE_HUB_CACHE,$env:TORCH_HOME | Out-Null
}

function Assert-RequiredModelCache {
    if (-not (Test-Path $ModelsReady)) {
        Log "MODELS_READY.json missing; rebuilding model-cache evidence using the existing private runtime..."
        $null = Run -Exe $PythonExe -CommandArgs @((Join-Path $WorkerDst "precache_moge3_models.py"))
    }
    if (-not (Test-Path $ModelsReady)) { throw "MoGe model cache evidence was not created: $ModelsReady" }
    $modelsJson = Get-Content $ModelsReady -Raw | ConvertFrom-Json
    $ids = @($modelsJson.models | ForEach-Object { $_.repo_id })
    foreach ($id in @("Ruicheng/moge-3-vitl","Ruicheng/moge-3-vitg")) {
        if ($ids -notcontains $id) { throw "Existing ConceptGhost MoGe runtime is missing required cached model evidence: $id" }
    }
}

function Try-ReuseExistingRuntime {
    $requiredExisting = @(
        $PythonExe,
        (Join-Path $Repo "pyproject.toml"),
        (Join-Path $WorkerDst "moge_worker.py")
    )
    foreach ($p in $requiredExisting) {
        if (-not (Test-Path $p)) {
            Log "Existing runtime reuse unavailable; missing: $p"
            return $false
        }
    }

    Log "Bundled MoGe source ZIP is absent; validating the already-installed ConceptGhost-owned isolated runtime instead of reinstalling it."
    if (Test-Path $WorkerSrc) {
        Copy-Item (Join-Path $WorkerSrc "*") $WorkerDst -Recurse -Force
        Log "Refreshed ConceptGhost-owned worker scripts inside the existing private runtime."
    }
    Set-RuntimeEnvironment
    Assert-RequiredModelCache
    $null = Run -Exe $PythonExe -CommandArgs @((Join-Path $WorkerDst "verify_moge3_runtime.py"))
    if (-not (Test-Path $Ready)) { throw "Existing-runtime verification did not recreate READY.json" }
    $readyJson = Get-Content $Ready -Raw | ConvertFrom-Json
    if ($readyJson.status -ne "PASS") { throw "Existing ConceptGhost MoGe runtime verification did not pass" }
    Log "PASS - Existing ConceptGhost MoGe-3 isolated runtime validated and reused. Vendor source ZIP was not required."
    return $true
}

if (-not (Test-Path $VendorZip)) {
    if (Try-ReuseExistingRuntime) {
        Log "ConceptGhost v0.32 runtime reuse complete. No global Python/Torch/CUDA was changed."
        exit 0
    }
    throw "Bundled MoGe source ZIP missing and no reusable ConceptGhost isolated runtime was found: $VendorZip"
}

# A bundled source archive means an explicit full repair/install path. Only now
# clear stale readiness evidence because the runtime is about to be rebuilt.
if (Test-Path $Ready) { Remove-Item $Ready -Force }

$Git = Get-Command git.exe -ErrorAction SilentlyContinue
if (-not $Git) {
    $MinGitRoot = Join-Path $RuntimeRoot "tools\mingit-2.51.0"
    $MinGitExe = Join-Path $MinGitRoot "cmd\git.exe"
    if (-not (Test-Path $MinGitExe)) {
        $MinGitZip = Join-Path $env:TEMP "ConceptGhost-MinGit-2.51.0-64-bit.zip"
        $MinGitUrl = "https://github.com/git-for-windows/git/releases/download/v2.51.0.windows.1/MinGit-2.51.0-64-bit.zip"
        Log "System Git not found. Downloading private pinned MinGit 2.51.0..."
        Invoke-WebRequest -Uri $MinGitUrl -OutFile $MinGitZip -UseBasicParsing
        if (Test-Path $MinGitRoot) { Remove-Item $MinGitRoot -Recurse -Force }
        New-Item -ItemType Directory -Force -Path $MinGitRoot | Out-Null
        Expand-Archive -Path $MinGitZip -DestinationPath $MinGitRoot -Force
    }
    if (-not (Test-Path $MinGitExe)) { throw "Private MinGit bootstrap failed: $MinGitExe" }
    # Process-local PATH only so pip can resolve git+https dependencies. Never persisted.
    $env:PATH = (Join-Path $MinGitRoot "cmd") + ";" + $env:PATH
    $Git = Get-Command git.exe -ErrorAction Stop
}
Log ("Git: " + (& $Git.Source --version))

if (-not (Test-Path $PythonExe)) {
    $PyInstaller = Join-Path $env:TEMP "python-3.11.9-amd64.exe"
    $PyUrl = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    Log "Downloading private Python 3.11.9 from python.org..."
    Invoke-WebRequest -Uri $PyUrl -OutFile $PyInstaller -UseBasicParsing
    Log "Installing private Python under runtime root (no PATH, no launcher, no associations)..."
    $PyArgs = @(
        "/quiet", "InstallAllUsers=0", "TargetDir=$PythonRoot", "PrependPath=0",
        "Include_launcher=0", "InstallLauncherAllUsers=0", "AssociateFiles=0",
        "Shortcuts=0", "Include_doc=0", "Include_test=0", "Include_pip=1"
    )
    $proc = Start-Process -FilePath $PyInstaller -ArgumentList $PyArgs -Wait -PassThru
    if ($proc.ExitCode -ne 0) { throw "Private Python installer failed: $($proc.ExitCode)" }
}
if (-not (Test-Path $PythonExe)) { throw "Private Python not found after installation: $PythonExe" }
Run -Exe $PythonExe -CommandArgs @("-m","pip","install","--upgrade","--no-warn-script-location","pip","setuptools","wheel")

# Fresh source extraction is deterministic and never touches ComfyUI.
if (Test-Path $Repo) { Remove-Item $Repo -Recurse -Force }
$ExtractTmp = Join-Path $RepoRoot "_extract"
if (Test-Path $ExtractTmp) { Remove-Item $ExtractTmp -Recurse -Force }
New-Item -ItemType Directory -Force -Path $ExtractTmp | Out-Null
Expand-Archive -Path $VendorZip -DestinationPath $ExtractTmp -Force
$Extracted = Join-Path $ExtractTmp "MoGe-main"
if (-not (Test-Path (Join-Path $Extracted "pyproject.toml"))) { throw "Unexpected MoGe source ZIP layout" }
Move-Item $Extracted $Repo
Remove-Item $ExtractTmp -Recurse -Force
Copy-Item (Join-Path $WorkerSrc "*") $WorkerDst -Recurse -Force

Set-RuntimeEnvironment

Log "Installing/repairing isolated PyTorch/torchvision..."
Run -Exe $PythonExe -CommandArgs @("-m","pip","install","--no-warn-script-location","--index-url",$TorchIndex,"torch>=2.4","torchvision>=0.19")

Log "Installing official MoGe source and pinned dependencies into the private runtime..."
Run -Exe $PythonExe -CommandArgs @("-m","pip","install","--no-warn-script-location","-e",$Repo)

Log "Downloading/caching both production checkpoints (Low Resolution ViT-L + High Fidelity ViT-G)..."
Run -Exe $PythonExe -CommandArgs @((Join-Path $WorkerDst "precache_moge3_models.py"))
Assert-RequiredModelCache

Log "Running Low Resolution ViT-L import + checkpoint + CUDA inference gate..."
Run -Exe $PythonExe -CommandArgs @((Join-Path $WorkerDst "verify_moge3_runtime.py"))

if (-not (Test-Path $Ready)) { throw "Verification did not create READY.json" }
$readyJson = Get-Content $Ready -Raw | ConvertFrom-Json
if ($readyJson.status -ne "PASS") { throw "MoGe-3 runtime gate did not pass" }
Log "PASS - MoGe-3 isolated runtime is ready."
Log "READY: $Ready"
Log "ConceptGhost v0.31 runtime is ready. Low Resolution uses ViT-L; High Fidelity uses ViT-G. Models are cached privately. No global Python/Torch/CUDA was changed."

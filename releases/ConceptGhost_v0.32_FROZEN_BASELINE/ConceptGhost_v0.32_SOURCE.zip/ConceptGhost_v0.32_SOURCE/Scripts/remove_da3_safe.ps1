param(
    [string]$AuditJson = ""
)
$ErrorActionPreference = "Stop"
Write-Host "ConceptGhost v0.32 - SAFE removal of retired DA3-exclusive files" -ForegroundColor Cyan
Write-Host "This tool refuses broad caches, plugins, models and shared Python/Torch/CUDA/NumPy." -ForegroundColor Yellow

if (-not $AuditJson) {
    $AuditRoot = Join-Path $env:LOCALAPPDATA "ConceptGhost-Audits"
    if (Test-Path $AuditRoot) {
        $AuditJson = Get-ChildItem -LiteralPath $AuditRoot -Filter "DA3_SAFE_CLEANUP_AUDIT_*.json" -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName
    }
}
if (-not $AuditJson -or -not (Test-Path -LiteralPath $AuditJson)) {
    throw "No v0.32 DA3 safe-cleanup audit found. Run AUDIT_DA3_SAFE.bat first."
}
$Audit = Get-Content -LiteralPath $AuditJson -Raw | ConvertFrom-Json
if ($Audit.schema -ne "ConceptGhost.DA3SafeCleanupAudit.v0.32") { throw "Unsupported audit schema: $($Audit.schema)" }

# Hard-coded safety fence: even an edited audit cannot authorize anything outside
# these exact DA3-exclusive paths. Pixi, plugin, models and global/shared runtimes
# are never accepted by this remover.
$AllowedExact = @(
    "C:\ConceptGhost\cache\da3-comfy-env",
    "C:\ConceptGhost\config\da3_host_paths.json"
)
$Targets = @($Audit.items | Where-Object { $_.Class -eq "SAFE_TO_DELETE" })
foreach($T in $Targets){
    if($AllowedExact -notcontains [string]$T.Path){throw "Safety fence rejected audit-approved path: $($T.Path)"}
}
if($Targets.Count -eq 0){Write-Host "No SAFE_TO_DELETE items are present. Nothing to remove."; exit 0}

Write-Host "Audit: $AuditJson" -ForegroundColor DarkGray
Write-Host "Only these exact DA3-exclusive paths are eligible:" -ForegroundColor Yellow
foreach($T in $Targets){Write-Host ("  {0}  {1}" -f $T.Class,$T.Path) -ForegroundColor Yellow}
Write-Host ""
Write-Host "PROTECTED: C:\ConceptGhost\cache\pixi, ComfyUI-DepthAnythingV3, models, Python, Torch, CUDA, NumPy, Single View, Multi View/Trellis." -ForegroundColor Green
$Answer=Read-Host "Type REMOVE_EXCLUSIVE_DA3 to delete only the SAFE_TO_DELETE paths above"
if($Answer -ne "REMOVE_EXCLUSIVE_DA3"){Write-Host "Cancelled. No files changed."; exit 0}

$Before=[int64]0; foreach($T in $Targets){if(Test-Path -LiteralPath $T.Path){if((Get-Item -LiteralPath $T.Path).PSIsContainer){Get-ChildItem -LiteralPath $T.Path -Recurse -Force -File -ErrorAction SilentlyContinue|ForEach-Object{$Before += [int64]$_.Length}}else{$Before += [int64](Get-Item -LiteralPath $T.Path).Length}}}
foreach($T in $Targets){
    if(Test-Path -LiteralPath $T.Path){
        $resolved=(Resolve-Path -LiteralPath $T.Path).Path
        if($AllowedExact -notcontains $resolved){throw "Resolved-path safety fence rejected: $resolved"}
        Remove-Item -LiteralPath $resolved -Recurse -Force
        Write-Host "[REMOVED] $resolved" -ForegroundColor Green
    } else {Write-Host "[SKIP] Not present: $($T.Path)"}
}
foreach($P in $AllowedExact){if(Test-Path -LiteralPath $P){throw "Cleanup verification failed; path still exists: $P"}}

$ProtectedHashMismatches=@()
foreach($H in @($Audit.protected_reference_hashes)){
    if(-not(Test-Path -LiteralPath $H.Path)){
        $ProtectedHashMismatches += [pscustomobject]@{Path=$H.Path; Reason="MISSING_AFTER_CLEANUP"}
        continue
    }
    $AfterHash=(Get-FileHash -Algorithm SHA256 -LiteralPath $H.Path).Hash.ToLowerInvariant()
    if($AfterHash -ne [string]$H.Sha256){$ProtectedHashMismatches += [pscustomobject]@{Path=$H.Path; Reason="HASH_CHANGED"; Before=$H.Sha256; After=$AfterHash}}
}
if($ProtectedHashMismatches.Count -gt 0){throw "Protected Single/Multi/Trellis reference changed during DA3 cleanup: $($ProtectedHashMismatches | ConvertTo-Json -Compress)"}

$VerifyStatus="NOT_RUN"
$VerifyScript=Join-Path $PSScriptRoot "verify_conceptghost.ps1"
if(Test-Path -LiteralPath $VerifyScript){
    try { & $VerifyScript; $VerifyStatus="PASS" } catch { $VerifyStatus="FAIL: $($_.Exception.Message)" }
}
$ReportRoot=Join-Path $env:LOCALAPPDATA "ConceptGhost-Audits"
New-Item -ItemType Directory -Force -Path $ReportRoot | Out-Null
$Stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$ResultPath=Join-Path $ReportRoot ("DA3_SAFE_CLEANUP_RESULT_"+$Stamp+".json")
$Result=[ordered]@{
    schema="ConceptGhost.DA3SafeCleanupResult.v0.32"
    timestamp=(Get-Date).ToString("o")
    source_audit=$AuditJson
    removed_items=$Targets
    reclaimed_bytes=$Before
    protected_reference_hash_check="PASS"
    conceptghost_verify=$VerifyStatus
    protected_invariants=$Audit.protected_invariants
}
$Result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $ResultPath -Encoding UTF8
Write-Host "[PASS] Only audit-approved, exact DA3-exclusive paths were removed." -ForegroundColor Green
Write-Host ("Approximate reclaimed bytes from approved targets: {0}" -f $Before) -ForegroundColor Green
Write-Host "Protected Single/Multi/Trellis hash check: PASS" -ForegroundColor Green
Write-Host "ConceptGhost post-cleanup verification: $VerifyStatus" -ForegroundColor Green
Write-Host "Cleanup result: $ResultPath" -ForegroundColor Cyan

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$ManifestPath = Join-Path $Root "BUNDLE_MANIFEST.json"
if (-not (Test-Path -LiteralPath $ManifestPath)) { throw "BUNDLE_MANIFEST.json missing" }
$M = Get-Content -LiteralPath $ManifestPath -Raw | ConvertFrom-Json
if ($M.schema -ne "ConceptGhost.BundleManifest.v0.32") { throw "Unsupported bundle manifest schema: $($M.schema)" }
$Failed=$false
foreach($F in @($M.files)) {
    $P = Join-Path $Root ([string]$F.path)
    if (-not (Test-Path -LiteralPath $P)) { Write-Host "[FAIL] missing $($F.path)" -ForegroundColor Red; $Failed=$true; continue }
    $Item=Get-Item -LiteralPath $P
    if ([int64]$Item.Length -ne [int64]$F.bytes) { Write-Host "[FAIL] size $($F.path)" -ForegroundColor Red; $Failed=$true; continue }
    $H=(Get-FileHash -Algorithm SHA256 -LiteralPath $P).Hash.ToLowerInvariant()
    if ($H -ne [string]$F.sha256) { Write-Host "[FAIL] sha256 $($F.path)" -ForegroundColor Red; $Failed=$true; continue }
    Write-Host "[PASS] $($F.path)" -ForegroundColor Green
}
# Explicit cleanliness guards.
$Legacy=@(Get-ChildItem -LiteralPath $Root -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'v0\\.(30|31)|v03(0|1)|0312|0311' })
if($Legacy.Count -gt 0){ Write-Host "[FAIL] legacy-named files found:" -ForegroundColor Red; $Legacy|ForEach-Object{Write-Host $_.FullName}; $Failed=$true }
$Caches=@(Get-ChildItem -LiteralPath $Root -Recurse -Directory -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -in @('__pycache__','.pytest_cache') })
if($Caches.Count -gt 0){ Write-Host "[FAIL] generated cache directories found" -ForegroundColor Red; $Failed=$true }
$Vendor=Join-Path $Root "Tools\MoGeRuntime\vendor\MoGe-main.zip"
if(-not(Test-Path -LiteralPath $Vendor)){ Write-Host "[FAIL] pinned MoGe vendor missing" -ForegroundColor Red; $Failed=$true }
if($Failed){ Write-Host ""; Write-Host "FINAL: v0.32 BUNDLE INTEGRITY FAIL" -ForegroundColor Red; exit 1 }
Write-Host ""; Write-Host "FINAL: v0.32 BUNDLE INTEGRITY PASS" -ForegroundColor Green
Write-Host ("Files: {0} / Payload bytes: {1:N0}" -f @($M.files).Count,[int64]$M.payload_bytes) -ForegroundColor Cyan
exit 0

$ErrorActionPreference = "Stop"
$PreferredComfy = Join-Path $env:LOCALAPPDATA "Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"
$Comfy=$PreferredComfy
if (-not (Test-Path $Comfy)) {
    $Candidates=@((Join-Path $env:LOCALAPPDATA "Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"),(Join-Path $env:LOCALAPPDATA "Programs\@comfyorgcomfyui-electron\resources\ComfyUI"))
    $Comfy=$Candidates | Where-Object {Test-Path $_} | Select-Object -First 1
}
if (-not $Comfy) { throw "ComfyUI root not found" }
$NodeRoot=Join-Path $Comfy "custom_nodes\ConceptGhost_Stage68"
$Nodes=Join-Path $NodeRoot "nodes.py"; $Contracts=Join-Path $NodeRoot "conceptghost_contracts.py"; $Geometry=Join-Path $NodeRoot "conceptghost_geometry.py"; $Variants=Join-Path $NodeRoot "conceptghost_variants.py"; $IO=Join-Path $NodeRoot "conceptghost_io.py"; $Worker=Join-Path $NodeRoot "conceptghost_maya_worker.py"; $Launcher=Join-Path $NodeRoot "run_maya_worker.bat"
$Workflow=Join-Path $Comfy "user\default\workflows\ConceptGhost\ConceptGhost_Master_v0.32.json"
$MarkerPath=Join-Path $env:LOCALAPPDATA "ConceptGhost-v0.32-install.json"
foreach($P in @($Nodes,$Contracts,$Geometry,$Variants,$IO,$Worker,$Launcher,$Workflow,$MarkerPath)) { if(-not(Test-Path $P)){throw "Required v0.32 file missing: $P"} }
$All=(Get-Content $Nodes -Raw)+(Get-Content $Contracts -Raw)+(Get-Content $Geometry -Raw)+(Get-Content $Variants -Raw)+(Get-Content $IO -Raw)+(Get-Content $Worker -Raw)
$Wf=Get-Content $Workflow -Raw
foreach($T in @("ConceptGhostDA3Evidence","ConceptGhostAtlasToDA3CameraParams","DA3_ToMesh","DA3_PreviewPointCloud","ComfyUI-DepthAnythingV3","DepthAnythingV3","compare_both","ConceptGhostGeometryRouter")) { if($All -match [regex]::Escape($T) -or $Wf -match [regex]::Escape($T)){throw "Retired DA3 token remains active: $T"} }
foreach($T in @("semantic_assist_enabled","ConceptGhostSemanticAssist","CG_SEMANTIC_BUNDLE")) { if($All -match [regex]::Escape($T) -or $Wf -match [regex]::Escape($T)){throw "Retired Semantic token remains active: $T"} }
foreach($T in @("ConceptGhost.GeometryProfile.v1.2","Ruicheng/moge-3-vitg","moge_full_resolution_depth_edge_preserving","moge_full_resolution_depth_edge_split_clean","assert_profile_contract","High Fidelity","High Fidelity Split Clean","ConceptGhost.PrimarySolverMeshPayload.v0.31","ConceptGhost.MayaManifest.v0.31")) { if($All -notmatch [regex]::Escape($T)){throw "v0.32 contract token missing: $T"} }
foreach($T in @("ConceptGhostPrimaryRemeshExporter","ConceptGhostPointCloudPreview","ConceptGhost3DAssetPreview","REMESH_PRESETS_V032","PASS_NO_DUPLICATE_ARCHIVE")){if($All -notmatch [regex]::Escape($T)){throw "v0.32 dedup/remesh implementation token missing: $T"}}
$WfJson=$Wf | ConvertFrom-Json
$MasterNode=@($WfJson.nodes | Where-Object { $_.type -eq "ConceptGhostMasterConfig" })
$ProfileNode=@($WfJson.nodes | Where-Object { $_.type -eq "ConceptGhostGeometryProfile" })
$RemeshNode=@($WfJson.nodes | Where-Object { $_.type -eq "ConceptGhostPrimaryRemeshExporter" })
$PointNode=@($WfJson.nodes | Where-Object { $_.type -eq "ConceptGhostPointCloudPreview" })
$OutputPreviewNodes=@($WfJson.nodes | Where-Object { $_.type -eq "ConceptGhost3DAssetPreview" })
$LegacyZipNode=@($WfJson.nodes | Where-Object { $_.type -eq "ConceptGhostRunPackageDownload" })
if($MasterNode.Count -ne 1 -or $ProfileNode.Count -ne 1 -or $RemeshNode.Count -ne 1 -or $PointNode.Count -ne 1 -or $OutputPreviewNodes.Count -ne 4){throw "v0.32 workflow output/authority nodes missing or duplicated"}
if($LegacyZipNode.Count -ne 0){throw "v0.32 workflow still contains retired duplicate COMPLETE ZIP node"}
if(@($MasterNode[0].widgets_values).Count -lt 5){throw "v0.32 master widget contract incomplete"}
if([string]$MasterNode[0].widgets_values[3] -ne "MoGe-3"){throw "v0.32 workflow default MoGe version is not MoGe-3"}
if([string]$MasterNode[0].widgets_values[4] -ne "High Fidelity"){throw "v0.32 workflow default profile is not High Fidelity"}
foreach($T in @("Low Resolution","High Fidelity","High Fidelity Split Clean")){if($All -notmatch [regex]::Escape($T)){throw "v0.32 profile option missing from installed node code: $T"}}
if(@($RemeshNode[0].widgets_values).Count -lt 1 -or [bool]$RemeshNode[0].widgets_values[0] -ne $false){throw "v0.32 remesh switch must default OFF"}
if(@($WfJson.nodes).Count -ne 31){throw "Unexpected v0.32 Dedup/Remesh node count: $(@($WfJson.nodes).Count) (expected 31)"}
if(@($WfJson.links).Count -ne 71){throw "Unexpected v0.32 Dedup/Remesh link count: $(@($WfJson.links).Count) (expected 71)"}
$Marker=Get-Content $MarkerPath -Raw | ConvertFrom-Json
if($Marker.schema -ne "ConceptGhost.InstallMarker.v0.32"){throw "Invalid v0.32 install marker schema: $($Marker.schema)"}
$Hash=(Get-FileHash -Algorithm SHA256 -LiteralPath $Workflow).Hash.ToLowerInvariant()
if($Marker.canonical_workflow_sha256 -ne $Hash){throw "Installed canonical workflow hash differs from install marker"}
$Runtime=Join-Path $env:LOCALAPPDATA "ConceptGhost-MoGeRuntime-v1"; $Python=Join-Path $Runtime "python\python.exe"; $Ready=Join-Path $Runtime "READY.json"; $Models=Join-Path $Runtime "MODELS_READY.json"; $WorkerPy=Join-Path $Runtime "worker\moge_worker.py"
foreach($P in @($Python,$Ready,$Models,$WorkerPy)){if(-not(Test-Path $P)){throw "MoGe-3 private runtime file missing: $P"}}
$ModelsJson=Get-Content $Models -Raw | ConvertFrom-Json; $Ids=@($ModelsJson.models|ForEach-Object{$_.repo_id})
foreach($Id in @("Ruicheng/moge-3-vitl","Ruicheng/moge-3-vitg")){if($Ids -notcontains $Id){throw "Required cached model missing: $Id"}}
Write-Host "ConceptGhost v0.32 Dedup/Remesh installed-file verification PASS." -ForegroundColor Green
Write-Host "Workflow: $Workflow" -ForegroundColor Cyan
Write-Host "Nodes/links: 31 / 71" -ForegroundColor Green
Write-Host "Active workflow is MoGe-only; DA3 is not required or installed by ConceptGhost." -ForegroundColor Green
Write-Host "Low Resolution, High Fidelity, and High Fidelity Split Clean fail-closed contracts are present." -ForegroundColor Green
Write-Host "If ComfyUI is already open, close any OLD ConceptGhost tab and load the v0.32 workflow above." -ForegroundColor Yellow

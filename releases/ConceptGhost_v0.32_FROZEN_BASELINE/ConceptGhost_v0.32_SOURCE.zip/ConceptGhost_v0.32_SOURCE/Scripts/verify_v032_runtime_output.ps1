param(
    [string]$RunDir = "",
    [ValidateSet("ANY","OFF","ON")][string]$RemeshMode = "ANY"
)
$ErrorActionPreference = "Stop"

function Load-Json([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try { return (Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json) } catch { return $null }
}
function Check([string]$Name,[bool]$Ok,[string]$Detail) {
    if ($Ok) { Write-Host ("{0,-40} PASS  {1}" -f $Name,$Detail) -ForegroundColor Green }
    else { Write-Host ("{0,-40} FAIL  {1}" -f $Name,$Detail) -ForegroundColor Red; $script:Failed=$true }
}
function Is-V032Run([string]$Dir) {
    $R=Load-Json (Join-Path $Dir "meshes\remesh_variants\remesh_variant_report.json")
    $P=Load-Json (Join-Path $Dir "maya\primary_mesh_payload.json")
    $M=Load-Json (Join-Path $Dir "maya\maya_manifest.json")
    if ($null -eq $R -or $null -eq $P -or $null -eq $M) { return $false }
    if ($R.schema -ne "ConceptGhost.RemeshVariants.v0.32") { return $false }
    if ($P.schema -ne "ConceptGhost.PrimarySolverMeshPayload.v0.31") { return $false }
    if ($M.schema -ne "ConceptGhost.MayaManifest.v0.31") { return $false }
    return $true
}

$DefaultRoot=Join-Path $env:USERPROFILE "ConceptGhost_Output"
if (-not $RunDir) {
    if (-not (Test-Path $DefaultRoot)) { throw "Default ConceptGhost output root does not exist: $DefaultRoot" }
    $Candidates=@(Get-ChildItem -LiteralPath $DefaultRoot -Directory -Recurse -ErrorAction SilentlyContinue |
        Where-Object { Test-Path (Join-Path $_.FullName "meshes\remesh_variants\remesh_variant_report.json") } |
        Sort-Object LastWriteTime -Descending)
    foreach($Candidate in $Candidates) {
        if (-not (Is-V032Run $Candidate.FullName)) { continue }
        $R=Load-Json (Join-Path $Candidate.FullName "meshes\remesh_variants\remesh_variant_report.json")
        if ($RemeshMode -eq "OFF" -and [bool]$R.generate_remesh_variants) { continue }
        if ($RemeshMode -eq "ON" -and -not [bool]$R.generate_remesh_variants) { continue }
        $RunDir=$Candidate.FullName; break
    }
    if (-not $RunDir) { throw "No v0.32 run found matching RemeshMode=$RemeshMode under $DefaultRoot" }
}
$RunDir=(Resolve-Path -LiteralPath $RunDir).Path
if (-not (Is-V032Run $RunDir)) { throw "Run is not a v0.32 Dedup/Remesh run: $RunDir" }

$P=Load-Json (Join-Path $RunDir "maya\primary_mesh_payload.json")
$M=Load-Json (Join-Path $RunDir "maya\maya_manifest.json")
$F=Load-Json (Join-Path $RunDir "manifest.json")
$O=Load-Json (Join-Path $RunDir "output_index.json")
$R=Load-Json (Join-Path $RunDir "meshes\remesh_variants\remesh_variant_report.json")
$Failed=$false

Write-Host "CONCEPTGHOST v0.32 RUNTIME / DEDUP / REMESH ACCEPTANCE" -ForegroundColor Cyan
Write-Host "RunDir: $RunDir" -ForegroundColor DarkGray
Write-Host "Requested RemeshMode: $RemeshMode" -ForegroundColor DarkGray
Write-Host ""

# Core High Fidelity / Maya gates.
Check "PrimaryMesh schema" ($P.schema -eq "ConceptGhost.PrimarySolverMeshPayload.v0.31") "$($P.schema)"
Check "Maya manifest schema" ($M.schema -eq "ConceptGhost.MayaManifest.v0.31") "$($M.schema)"
Check "Final manifest schema" ($F.schema -eq "ConceptGhost.Manifest.v0.31") "$($F.schema)"
Check "High Fidelity profile" (@("High Fidelity","High Fidelity Split Clean") -contains $P.selected_profile -and $P.effective_profile -eq $P.selected_profile) "$($P.selected_profile)"
Check "Maya .ma PASS" ($M.ma.status -eq "PASS") "$($M.ma.status)"
Check "Maya input parity PASS" ($M.maya_input_parity.status -eq "PASS") "$($M.maya_input_parity.status)"
foreach($G in @("pre_maya","maya_live","maya_reopen","fbx_roundtrip")) {
    $gate=$M.normal_validation.$G
    Check ("Normal gate "+$G) ($gate.status -eq "PASS") "$($gate.status)"
}
Check "Fused points survived .ma reopen" ([bool]$M.normal_validation.maya_reopen.fused_points_present) "$($M.normal_validation.maya_reopen.fused_points_present)"
Check "Maya hierarchy fused points" ($M.hierarchy.fused_points -eq "CG_FUSED_POINTS") "$($M.hierarchy.fused_points)"
Check "Final run PASS" ($F.status.run_status -eq "PASS") "$($F.status.run_status)"

# No duplicate complete archive.
$CompleteZips=@(Get-ChildItem -LiteralPath $RunDir -File -Recurse -Filter "*_COMPLETE.zip" -ErrorAction SilentlyContinue)
Check "No COMPLETE.zip duplicate" ($CompleteZips.Count -eq 0) ("count="+$CompleteZips.Count)

# One canonical USDA only; Maya points directly to it.
$CanonicalUsd=Join-Path $RunDir "geometry\canonical\pointcloud.usda"
$LegacyMayaUsd=@(Get-ChildItem -LiteralPath (Join-Path $RunDir "maya") -File -Filter "*_Ghost.usda" -ErrorAction SilentlyContinue)
Check "Canonical USDA exists" (Test-Path -LiteralPath $CanonicalUsd) $CanonicalUsd
Check "No duplicate Maya USDA" ($LegacyMayaUsd.Count -eq 0) ("count="+$LegacyMayaUsd.Count)
$UsdPath=[string]$M.usd_proxy.path
Check "Maya USD proxy uses canonical path" ($UsdPath -replace '\\','/' -eq "geometry/canonical/pointcloud.usda") $UsdPath

# One source texture; no persistent PrimaryTexture/.fbm duplicate.
$SourceTexture=Join-Path $RunDir "source\source.png"
$PrimaryTexture=@(Get-ChildItem -LiteralPath (Join-Path $RunDir "maya") -File -Filter "*PrimaryTexture.png" -ErrorAction SilentlyContinue)
$FbmDirs=@(Get-ChildItem -LiteralPath (Join-Path $RunDir "maya") -Directory -Filter "*.fbm" -ErrorAction SilentlyContinue)
Check "Authoritative source texture exists" (Test-Path -LiteralPath $SourceTexture) $SourceTexture
Check "No duplicate PrimaryTexture PNG" ($PrimaryTexture.Count -eq 0) ("count="+$PrimaryTexture.Count)
Check "No persistent FBM sidecar" ($FbmDirs.Count -eq 0) ("count="+$FbmDirs.Count)
$PayloadTexture=[string]$P.texture_path
Check "PrimaryMesh texture reuses source.png" ((Split-Path -Leaf $PayloadTexture) -eq "source.png") $PayloadTexture

# FBX official + compatibility alias must be the same physical payload or exact bytes.
$OfficialFbx=[string]$M.fbx.path
$AliasFbx=[string]$M.full_scene_fbx.path
$OfficialOk=Test-Path -LiteralPath $OfficialFbx
$AliasOk=Test-Path -LiteralPath $AliasFbx
Check "Official FBX exists" $OfficialOk $OfficialFbx
Check "FullScene compatibility alias exists" $AliasOk $AliasFbx
if ($OfficialOk -and $AliasOk) {
    $H1=(Get-FileHash -Algorithm SHA256 -LiteralPath $OfficialFbx).Hash
    $H2=(Get-FileHash -Algorithm SHA256 -LiteralPath $AliasFbx).Hash
    Check "FBX alias exact payload" ($H1 -eq $H2) ("sha256="+$H1.ToLowerInvariant())
}
Check "FullScene policy is compatibility alias" ($M.full_scene_fbx.export_policy -eq "compatibility_alias_of_official_full_scene_fbx") "$($M.full_scene_fbx.export_policy)"

# v0.32 remesh contract.
Check "Remesh report v0.32" ($R.schema -eq "ConceptGhost.RemeshVariants.v0.32") "$($R.schema)"
$MasterPath=[string]$R.master.path
Check "PrimaryMesh Master GLB exists" (Test-Path -LiteralPath $MasterPath) $MasterPath
$ActualMode=if([bool]$R.generate_remesh_variants){"ON"}else{"OFF"}
Check "Requested remesh mode" ($RemeshMode -eq "ANY" -or $RemeshMode -eq $ActualMode) ("actual="+$ActualMode)
$DerivedFiles=@(Get-ChildItem -LiteralPath (Join-Path $RunDir "meshes\remesh_variants") -File -Filter "*Remesh_*.glb" -ErrorAction SilentlyContinue)
if ($ActualMode -eq "OFF") {
    Check "Remesh OFF status" ($R.remesh_status -eq "SKIPPED_SWITCH_OFF") "$($R.remesh_status)"
    Check "Remesh OFF writes no derived GLBs" ($DerivedFiles.Count -eq 0) ("count="+$DerivedFiles.Count)
    Check "Remesh OFF report empty" (@($R.remesh_variants.psobject.Properties).Count -eq 0) ("entries="+@($R.remesh_variants.psobject.Properties).Count)
} else {
    $Names=@($R.remesh_variants.psobject.Properties.Name)
    Check "Remesh ON status" ($R.remesh_status -eq "GENERATED") "$($R.remesh_status)"
    Check "Remesh ON has 3 report entries" ($Names.Count -eq 3 -and $Names -contains "light" -and $Names -contains "medium" -and $Names -contains "strong") ($Names -join ",")
    Check "Remesh ON has 3 derived GLBs" ($DerivedFiles.Count -eq 3) ("count="+$DerivedFiles.Count)
    $L=$R.remesh_variants.light; $Med=$R.remesh_variants.medium; $S=$R.remesh_variants.strong
    Check "Remesh density decreases" ([int64]$L.output_vertices -gt [int64]$Med.output_vertices -and [int64]$Med.output_vertices -gt [int64]$S.output_vertices) ("$($L.output_vertices) > $($Med.output_vertices) > $($S.output_vertices)")
    foreach($Entry in @($L,$Med,$S)) {
        Check ("Derived file "+$Entry.preset) (Test-Path -LiteralPath ([string]$Entry.path)) ([string]$Entry.path)
        Check ("Derived-only "+$Entry.preset) ([bool]$Entry.derived_only -and [bool]$Entry.does_not_replace_maya_primarymesh) "derived_only=true"
    }
}

# Report disk footprint so before/after can be compared without creating an archive.
$Bytes=(Get-ChildItem -LiteralPath $RunDir -File -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Write-Host ""
Write-Host ("Run physical bytes: {0:N0} ({1:N2} GiB)" -f [int64]$Bytes,([double]$Bytes/1GB)) -ForegroundColor Cyan

if ($Failed) { Write-Host ""; Write-Host "FINAL: v0.32 RUNTIME ACCEPTANCE FAIL" -ForegroundColor Red; exit 1 }
Write-Host ""; Write-Host "FINAL: v0.32 RUNTIME ACCEPTANCE PASS" -ForegroundColor Green
exit 0

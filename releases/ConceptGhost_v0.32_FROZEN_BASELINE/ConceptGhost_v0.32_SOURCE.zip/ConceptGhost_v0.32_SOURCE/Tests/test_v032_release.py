from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
NODE_ROOT = ROOT / "custom_nodes" / "ConceptGhost_Stage68"
if str(NODE_ROOT) not in sys.path:
    sys.path.insert(0, str(NODE_ROOT))

import conceptghost_contracts as contracts
import conceptghost_geometry as geometry
import nodes
import conceptghost_maya_worker as maya_worker
import conceptghost_variants as variants
import conceptghost_io as cg_io


def passing_normal_gate(stage: str, faces: int = 98, vertices: int = 64):
    return {
        "stage": stage,
        "status": "PASS",
        "vertex_count": vertices,
        "faces_total": faces,
        "valid_faces": faces,
        "degenerate_faces": 0,
        "camera_facing_faces": faces,
        "camera_away_faces": 0,
        "normal_aligned_faces": faces,
        "normal_opposed_faces": 0,
        "zero_normals": 0,
        "camera_dot": {"min": 0.1, "median": 0.5, "p05": 0.2, "p95": 0.9},
        "normal_dot": {"min": 0.8, "median": 0.99, "p05": 0.9, "p95": 1.0},
    }


def passing_maya_manifest(profile, stride=None):
    selected = profile["selected_profile"]
    runtime_stride = 1 if selected in {"High Fidelity", "High Fidelity Split Clean"} else int(stride or 3)
    gates = {
        "pre_maya": passing_normal_gate("PRE_MAYA"),
        "maya_live": passing_normal_gate("MAYA_LIVE"),
        "maya_reopen": passing_normal_gate("MAYA_REOPEN"),
        "fbx_roundtrip": passing_normal_gate("FBX_ROUNDTRIP"),
    }
    return {
        "schema": "ConceptGhost.MayaManifest.v0.31",
        "status": "PASS",
        "geometry_profile": selected,
        "selected_profile": selected,
        "effective_profile": selected,
        "profile_config": dict(profile),
        "model": profile["model"],
        "mesher_policy": profile["mesher_policy"],
        "resolution_level": profile["resolution_level"],
        "refine_steps": profile["refine_steps"],
        "transport_stride": runtime_stride,
        "depth_edge_rtol": profile["depth_edge_rtol"],
        "discontinuity_threshold": profile["mesh_profile_config"]["discontinuity_threshold"],
        "long_triangle_policy": profile["mesh_profile_config"]["long_triangle_policy"],
        "connected_components_policy": profile["mesh_profile_config"]["connected_component_policy"],
        "boundary_cleanup_policy": profile["mesh_profile_config"]["boundary_cleanup_policy"],
        "mesh_profile_config": dict(profile["mesh_profile_config"]),
        "silent_fallback": False,
        "topology_authority": profile["topology_authority"],
        "ma": {"status": "PASS", "path": "scene.ma"},
        "fbx": {"status": "PASS", "path": "scene.fbx", "camera_roundtrip": {"status": "PASS"}},
        "full_scene_fbx": {"status": "PASS", "path": "full.fbx", "camera_roundtrip": {"status": "PASS"}},
        "camera_only_fbx": {"status": "PASS", "path": "camera.fbx"},
        "maya_input_parity": {"status": "PASS", "mismatches": {}},
        "hero_mesh": {
            "requested": True,
            "status": "PASS",
            "geometry_profile": selected,
            "selected_profile": selected,
            "effective_profile": selected,
            "model": profile["model"],
            "mesher_policy": profile["mesher_policy"],
            "transport_stride": runtime_stride,
            "depth_edge_rtol": profile["depth_edge_rtol"],
            "discontinuity_threshold": profile["mesh_profile_config"]["discontinuity_threshold"],
            "long_triangle_policy": profile["mesh_profile_config"]["long_triangle_policy"],
            "connected_components_policy": profile["mesh_profile_config"]["connected_component_policy"],
            "boundary_cleanup_policy": profile["mesh_profile_config"]["boundary_cleanup_policy"],
            "vertex_count": 64,
            "face_count": 98,
        },
        "normal_validation": gates,
    }


def passing_final_manifest(profile):
    selected = profile["selected_profile"]
    maya = passing_maya_manifest(profile)
    stride = maya["transport_stride"]
    primary = {
        "geometry_profile": selected,
        "selected_profile": selected,
        "effective_profile": selected,
        "source_model": profile["model"],
        "mesher_policy": profile["mesher_policy"],
        "transport_stride": stride,
        "depth_edge_rtol": profile["depth_edge_rtol"],
        "discontinuity_threshold": profile["mesh_profile_config"]["discontinuity_threshold"],
        "long_triangle_policy": profile["mesh_profile_config"]["long_triangle_policy"],
        "connected_components_policy": profile["mesh_profile_config"]["connected_component_policy"],
        "boundary_cleanup_policy": profile["mesh_profile_config"]["boundary_cleanup_policy"],
    }
    return {
        "schema": "ConceptGhost.Manifest.v0.31",
        "geometry_profile": selected,
        "selected_profile": selected,
        "effective_profile": selected,
        "profile_config": dict(profile),
        "maya_worker_manifest": maya,
        "hero_mesh": {"payload": primary},
        "outputs": {"ma": {"status": "PASS"}, "fbx": {"status": "PASS"}, "full_scene_fbx": {"status": "PASS"}},
        "status": {"run_status": "PASS"},
    }


def camera_bundle(w=8, h=8):
    fx = fy = 8.0
    return {
        "image_width": w,
        "image_height": h,
        "intrinsics": {"fx_px": fx, "fy_px": fy, "cx_px": (w-1)/2, "cy_px": (h-1)/2},
        "extrinsics": {
            "camera_position": [0.0, 0.0, 0.0],
            "camera_world_matrix": np.eye(4).tolist(),
            "camera_view_matrix": np.eye(4).tolist(),
        },
    }


def synthetic_canonical(profile, w=8, h=8):
    yy, xx = np.indices((h, w), dtype=np.float32)
    depth = np.where(xx < w//2, 2.0, 10.0).astype(np.float32)
    xyz = np.stack([(xx-(w-1)/2)*0.1, ((h-1)/2-yy)*0.1, -depth], axis=-1).reshape(-1,3)
    uv = np.stack([xx, yy], axis=-1).reshape(-1,2).astype(np.float32)
    grid = np.stack([xx, yy], axis=-1).reshape(-1,2).astype(np.int32)
    return {
        "schema": "ConceptGhost.CanonicalGeometry.v0.30",
        "engine": "moge",
        "xyz": xyz,
        "rgb": np.zeros((w*h,3),dtype=np.uint8),
        "source_uv": uv,
        "grid_xy": grid,
        "source_pixel_id": (grid[:,1].astype(np.int64)*w+grid[:,0].astype(np.int64)),
        "camera_depth": depth.reshape(-1),
        "point_count": w*h,
        "native_resolution": [w,h],
        "depth_semantics": "native_moge_point_map",
        "geometry_profile": profile["selected_profile"],
        "selected_profile": profile["selected_profile"],
        "effective_profile": profile["selected_profile"],
        "profile_config": profile,
        "refinement": {},
        "geometric_boundary_strength": np.zeros(w*h, dtype=np.float32),
    }


def test_high_fidelity_contract_is_authoritative():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    contracts.assert_profile_contract(p, stage="TEST")
    assert p["model"] == "Ruicheng/moge-3-vitg"
    assert p["resolution_level"] == 9
    assert p["refine_steps"] == 7
    assert p["transport_stride"] == 1
    assert p["depth_edge_rtol"] == pytest.approx(0.04)
    assert p["silent_fallback"] is False


def test_exact_old_regression_missing_profile_fails_closed():
    # Reproduces the old handoff shape: RAW geometry exists but the top-level
    # evidence profile was missing, which used to silently become Standard.
    pts = np.zeros((1,2,2,3), dtype=np.float32)
    pts[...,2] = 2.0
    evidence = {
        "engine": "moge",
        "moge_geometry": {"points": pts, "mask": np.ones((1,2,2), dtype=bool), "image": np.zeros((1,2,2,3),dtype=np.float32)},
    }
    with pytest.raises(RuntimeError, match="missing authoritative profile metadata"):
        geometry.canonicalize_moge(camera_bundle(2,2), evidence, evidence["moge_geometry"]["image"])


def test_selected_effective_profile_mismatch_fails():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    p["effective_profile"] = "Standard"
    with pytest.raises(RuntimeError, match="profile mismatch"):
        contracts.assert_profile_contract(p, stage="TEST")


def test_high_fidelity_mesher_is_full_resolution_and_depth_edge_aware():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    c = synthetic_canonical(p)
    arrays, report = nodes._build_primary_mesh_arrays_from_canonical(c, camera_bundle(), 8, 8, profile_config=p)
    assert report["geometry_profile"] == "High Fidelity"
    assert report["mesher_policy"] == "moge_full_resolution_depth_edge_preserving"
    assert report["transport_stride"] == 1
    assert report["depth_edge_rtol"] == pytest.approx(0.04)
    assert report["rejected_depth_edge_faces"] > 0
    assert report["triangles_crossing_forbidden_depth_edges"] == 0
    assert report["normal_gate"] == "PASS"
    assert report["camera_away_faces"] == 0
    assert arrays["faces"].shape[0] == report["face_count"]
    assert "canonical_point_indices" in arrays and "grid_xy" in arrays and "source_uv" in arrays


def test_low_resolution_mesher_remains_lightweight_transport():
    p = contracts.build_geometry_profile("Low Resolution", "Max Reference", "MoGe-3")
    c = synthetic_canonical(p, w=8, h=8)
    arrays, report = nodes._build_primary_mesh_arrays_from_canonical(c, camera_bundle(), 8, 8, profile_config=p)
    assert report["geometry_profile"] == "Low Resolution"
    assert report["mesher_policy"] == "low_resolution_transport_stride"
    assert report["transport_stride"] == 1
    assert report["depth_edge_rtol"] is None
    assert report["transport_vertex_cap"] == 250000
    assert report["dcc_transport_sampled"] is False


def test_primary_mesh_payload_proves_hf(tmp_path):
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    c = synthetic_canonical(p)
    image = np.zeros((1,8,8,3), dtype=np.float32)
    payload = nodes._write_primary_mesh_payload(tmp_path, "test", c, camera_bundle(), image, profile_config=p)
    assert payload["geometry_profile"] == "High Fidelity"
    assert payload["selected_profile"] == payload["effective_profile"] == "High Fidelity"
    assert payload["source_model"] == "Ruicheng/moge-3-vitg"
    assert payload["transport_stride"] == 1
    assert payload["mesher_policy"] == "moge_full_resolution_depth_edge_preserving"
    assert payload["depth_edge_rtol"] == pytest.approx(0.04)
    assert Path(payload["npz_path"]).is_file()
    written = json.loads((tmp_path/"maya"/"primary_mesh_payload.json").read_text(encoding="utf-8"))
    assert written["geometry_profile"] == "High Fidelity"


def test_maya_worker_rejects_hf_standard_mesh():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    payload = {
        "profile_config": p,
        "geometry_profile": "High Fidelity",
        "selected_profile": "High Fidelity",
        "effective_profile": "High Fidelity",
        "model": "Ruicheng/moge-3-vitg",
        "mesher_policy": "moge_full_resolution_depth_edge_preserving",
        "hero_mesh_payload": {
            "geometry_profile": "Standard",
            "transport_stride": 3,
            "depth_edge_rtol": None,
        },
    }
    with pytest.raises(RuntimeError, match="PrimaryMesh profile"):
        maya_worker._assert_worker_profile(payload)


def test_gate7_maya_manifest_requires_all_four_normal_gates_and_hf_identity():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    m = passing_maya_manifest(p)
    contracts.assert_maya_manifest_contract(m, p, stage="TEST_GATE7", require_runtime_gates=True)
    assert m["normal_validation"]["pre_maya"]["status"] == "PASS"
    assert m["normal_validation"]["maya_live"]["status"] == "PASS"
    assert m["normal_validation"]["maya_reopen"]["status"] == "PASS"
    assert m["normal_validation"]["fbx_roundtrip"]["status"] == "PASS"


def test_gate7_missing_or_not_requested_runtime_gate_fails_closed():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    m = passing_maya_manifest(p)
    m["normal_validation"]["maya_reopen"] = {"stage": "MAYA_REOPEN", "status": "NOT_REQUESTED"}
    with pytest.raises(RuntimeError, match="maya_reopen"):
        contracts.assert_maya_manifest_contract(m, p, stage="TEST_GATE7", require_runtime_gates=True)


def test_gate8_maya_manifest_missing_effective_profile_fails_closed():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    m = passing_maya_manifest(p)
    del m["effective_profile"]
    with pytest.raises(RuntimeError, match="effective_profile mismatch"):
        contracts.assert_maya_manifest_contract(m, p, stage="TEST_GATE8", require_runtime_gates=True)


def test_gate8_final_manifest_proves_primarymesh_maya_fbx_same_profile():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    f = passing_final_manifest(p)
    contracts.assert_final_manifest_contract(f, p, stage="TEST_GATE8_FINAL", require_runtime_gates=True)
    assert f["hero_mesh"]["payload"]["transport_stride"] == 1
    assert f["maya_worker_manifest"]["mesher_policy"] == "moge_full_resolution_depth_edge_preserving"


def test_gate8_old_real_regression_shape_hf_selected_but_maya_standard_is_rejected():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    m = passing_maya_manifest(p)
    # Matches the real v0.29 failure shape: RAW was ViT-G HF, Maya received
    # the Standard PrimaryMesh/transport contract.
    m["geometry_profile"] = "Standard"
    m["selected_profile"] = "Standard"
    m["effective_profile"] = "Standard"
    m["mesher_policy"] = "standard_transport_stride"
    m["transport_stride"] = 3
    m["depth_edge_rtol"] = None
    m["hero_mesh"].update({
        "geometry_profile": "Standard",
        "selected_profile": "Standard",
        "effective_profile": "Standard",
        "mesher_policy": "standard_transport_stride",
        "transport_stride": 3,
        "depth_edge_rtol": None,
    })
    with pytest.raises(RuntimeError):
        contracts.assert_maya_manifest_contract(m, p, stage="REAL_OLD_REGRESSION", require_runtime_gates=True)


def test_low_resolution_gate7_manifest_accepts_runtime_stride_without_hf_assumption():
    p = contracts.build_geometry_profile("Low Resolution", "Max Reference", "MoGe-3")
    m = passing_maya_manifest(p, stride=3)
    contracts.assert_maya_manifest_contract(m, p, stage="LOWRES_GATE7", require_runtime_gates=True)


def test_low_resolution_gate8_final_manifest_remains_valid():
    p = contracts.build_geometry_profile("Low Resolution", "Max Reference", "MoGe-3")
    f = passing_final_manifest(p)
    contracts.assert_final_manifest_contract(f, p, stage="LOWRES_GATE8", require_runtime_gates=True)


def test_workflow_has_no_retired_da3_and_no_dangling_links():
    path = ROOT / "Workflows" / "Project" / "ConceptGhost_Master_v0.32.json"
    text = path.read_text(encoding="utf-8")
    for token in ("DA3", "DepthAnythingV3", "compare_both", "ConceptGhostGeometryRouter"):
        assert token.lower() not in text.lower()
    w = json.loads(text)
    nodes_by_id = {n["id"]: n for n in w["nodes"]}
    links = {l[0]: l for l in w["links"]}
    for lid, l in links.items():
        assert l[1] in nodes_by_id and l[3] in nodes_by_id
    for n in w["nodes"]:
        for idx, inp in enumerate(n.get("inputs", [])):
            lid = inp.get("link")
            if lid is not None:
                assert lid in links and links[lid][3] == n["id"] and links[lid][4] == idx
        for idx, out in enumerate(n.get("outputs", [])):
            for lid in out.get("links") or []:
                assert lid in links and links[lid][1] == n["id"] and links[lid][2] == idx


def test_active_source_has_no_da3_or_silent_profile_default():
    source_files = list(NODE_ROOT.glob("*.py"))
    joined = "\n".join(p.read_text(encoding="utf-8") for p in source_files)
    assert "DA3" not in joined and "da3" not in joined
    assert '.get("geometry_profile") or "Standard"' not in joined
    assert '.get("geometry_profile", "Standard")' not in joined


def test_master_defaults_moge3_high_fidelity_with_split_clean_profile():
    req = nodes.ConceptGhostMasterConfig.INPUT_TYPES()["required"]
    assert "geometry_engine" not in req and "compare_both" not in req
    assert req["moge_version"][1]["default"] == "MoGe-3"
    assert req["geometry_profile"][0] == ["Low Resolution", "High Fidelity", "High Fidelity Split Clean"]
    assert req["geometry_profile"][1]["default"] == "High Fidelity"

def test_v030_installer_does_not_install_da3_or_legacy_hotfix():
    root = ROOT
    install_text = "\n".join(
        p.read_text(encoding="utf-8", errors="ignore")
        for p in [root / "INSTALL_CONCEPTGHOST.bat", root / "Scripts" / "install_conceptghost.ps1", root / "Scripts" / "install_comfy_payload.ps1"]
    )
    assert "ComfyUI-DepthAnythingV3" not in install_text
    assert "install_da3" not in install_text.lower()
    assert not (root / "APPLY_V0291_HOTFIX.bat").exists()
    assert not (root / "Scripts" / "remove_semantic_assist_runtime.ps1").exists()


def test_v032_release_manifest_is_moge_only_and_hf_fail_closed():
    data = json.loads((ROOT / "RELEASE_MANIFEST.json").read_text(encoding="utf-8"))
    assert data["schema"] == "ConceptGhost.ReleaseManifest.v0.32"
    assert data["version"] == "0.32.0"
    assert data["geometry"]["default_profile"] == "High Fidelity"
    assert data["geometry"]["profiles"] == ["Low Resolution", "High Fidelity", "High Fidelity Split Clean"]
    assert data["da3"]["active_dependency"] is False
    assert data["geometry"]["high_fidelity_model"] == "Ruicheng/moge-3-vitg"
    assert data["geometry"]["depth_edge_rtol"] == 0.04
    assert data["geometry"]["silent_fallback"] is False

def test_v032_bundle_has_one_current_workflow_and_no_legacy_workflows():
    root = ROOT
    workflows = list((root / "Workflows" / "Project").glob("*.json"))
    assert [p.name for p in workflows] == ["ConceptGhost_Master_v0.32.json"]
    data = json.loads(workflows[0].read_text(encoding="utf-8"))
    assert len(data["nodes"]) == 31
    assert len(data["links"]) == 71
    master = next(n for n in data["nodes"] if n.get("type") == "ConceptGhostMasterConfig")
    assert master["widgets_values"][3] == "MoGe-3"
    assert master["widgets_values"][4] == "High Fidelity"
    installer = (root / "Scripts" / "install_comfy_payload.ps1").read_text(encoding="utf-8")
    assert "ConceptGhost-v0.32-install.json" in installer
    assert "ConceptGhost_Master_v0.32.json" in installer
    assert not any("v0.30" in p.name or "v0.31" in p.name for p in root.rglob("*"))

def test_da3_retirement_did_not_remove_moge3_runtime_helpers(monkeypatch, tmp_path):
    monkeypatch.delenv("CONCEPTGHOST_MOGE_RUNTIME", raising=False)
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    expected = (tmp_path / "ConceptGhost-MoGeRuntime-v1").resolve()
    assert nodes._conceptghost_moge3_runtime_root() == expected
    x = np.zeros((1, 2, 2, 3), dtype=np.float32)
    converted = nodes._as_worker_tensor(x)
    assert tuple(converted.shape) == tuple(x.shape)


def test_moge3_inference_reaches_runtime_readiness_gate_not_nameerror(monkeypatch, tmp_path):
    monkeypatch.delenv("CONCEPTGHOST_MOGE_RUNTIME", raising=False)
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    image = np.zeros((1, 4, 4, 3), dtype=np.float32)
    with pytest.raises(RuntimeError, match="private runtime is not ready"):
        nodes.ConceptGhostMoGe3Inference().infer(image, "Max Reference", 36.0, p)


def test_profile_contract_rejects_mutated_low_resolution_quality_fields():
    p = contracts.build_geometry_profile("Low Resolution", "Max Reference", "MoGe-3")
    p["model"] = "Ruicheng/moge-3-vitg"
    with pytest.raises(RuntimeError, match="Low Resolution contract mismatch for model"):
        contracts.assert_profile_contract(p, stage="LOWRES_MUTATION")


def test_profile_contract_rejects_mutated_high_fidelity_projection_policy():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    p["force_projection"] = False
    with pytest.raises(RuntimeError, match="High Fidelity contract mismatch for force_projection"):
        contracts.assert_profile_contract(p, stage="HF_MUTATION")


def test_gate7_rejects_topology_count_drift_and_degenerate_faces():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    m = passing_maya_manifest(p)
    m["normal_validation"]["maya_reopen"]["faces_total"] -= 1
    with pytest.raises(RuntimeError, match="face count changed"):
        contracts.assert_maya_manifest_contract(m, p, stage="COUNT_DRIFT", require_runtime_gates=True)
    m = passing_maya_manifest(p)
    m["normal_validation"]["fbx_roundtrip"]["degenerate_faces"] = 1
    with pytest.raises(RuntimeError, match="degenerate faces"):
        contracts.assert_maya_manifest_contract(m, p, stage="DEGENERATE", require_runtime_gates=True)


def test_worker_source_has_no_profile_quality_defaults():
    text = (ROOT / "Tools" / "MoGeRuntime" / "worker" / "moge_worker.py").read_text(encoding="utf-8")
    for forbidden in (
        'req.get("model") or "Ruicheng/moge-3-vitl"',
        'req.get("refine_steps", 3)',
        'req.get("resolution_level", 9)',
        'req.get("force_projection", True)',
        'req.get("apply_mask", True)',
    ):
        assert forbidden not in text
    assert "Missing fail-closed MoGe-3 request fields" in text




def test_split_clean_profile_contract_is_primarymesh_authority():
    p = contracts.build_geometry_profile("High Fidelity Split Clean", "Max Reference", "MoGe-3")
    contracts.assert_profile_contract(p, stage="SPLIT_PROFILE")
    cfg = p["mesh_profile_config"]
    assert p["model"] == "Ruicheng/moge-3-vitg"
    assert p["transport_stride"] == 1
    assert p["mesher_policy"] == "moge_full_resolution_depth_edge_split_clean"
    assert cfg["discontinuity_threshold"] == pytest.approx(0.10)
    assert cfg["long_triangle_policy"] == "relative_shape_and_depth_reject"
    assert cfg["connected_component_policy"] == "preserve_disconnected_shells"
    assert cfg["boundary_cleanup_policy"] == "edge_aware_whisker_prune"


def test_split_clean_changes_authoritative_primarymesh_topology():
    master = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    split = contracts.build_geometry_profile("High Fidelity Split Clean", "Max Reference", "MoGe-3")
    c1 = synthetic_canonical(master, w=10, h=8)
    c2 = synthetic_canonical(split, w=10, h=8)
    # Create a narrow canonical boundary so Split Clean's 0.10 control actually
    # changes the final PrimaryMesh while HF Master remains unchanged.
    boundary = np.zeros(80, dtype=np.float32)
    grid = c2["grid_xy"]
    boundary[grid[:,0] == 5] = 0.2
    c2["geometric_boundary_strength"] = boundary
    a1, r1 = nodes._build_primary_mesh_arrays_from_canonical(c1, camera_bundle(10,8), 10, 8, profile_config=master)
    a2, r2 = nodes._build_primary_mesh_arrays_from_canonical(c2, camera_bundle(10,8), 10, 8, profile_config=split)
    assert r2["discontinuity_threshold"] == pytest.approx(0.10)
    assert r2["split_clean_report"]["rejected_discontinuity_faces"] > 0
    assert len(a2["faces"]) < len(a1["faces"])
    assert r2["mesher_policy"] == "moge_full_resolution_depth_edge_split_clean"


def test_full_scene_fbx_is_required_by_gate8_contract():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    m = passing_maya_manifest(p)
    del m["full_scene_fbx"]
    with pytest.raises(RuntimeError, match="full_scene_fbx"):
        contracts.assert_maya_manifest_contract(m, p, stage="FULL_SCENE", require_runtime_gates=True)



def test_maya_input_parity_is_required_by_gate8_contract():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    m = passing_maya_manifest(p)
    m["maya_input_parity"] = {"status": "FAIL", "mismatches": {"face_count": {"expected": 98, "actual": 97}}}
    with pytest.raises(RuntimeError, match="MAYA_INPUT_PARITY"):
        contracts.assert_maya_manifest_contract(m, p, stage="INPUT_PARITY", require_runtime_gates=True)

def test_worker_output_paths_keep_legacy_and_add_full_scene(tmp_path):
    out = maya_worker.build_output_paths(tmp_path, "concept_scene")
    assert out["fbx"].name.endswith("_Ghost.fbx")
    assert out["camera_fbx"].name.endswith("_CameraOnly.fbx")
    assert out["full_scene_fbx"].name.endswith("_GhostFullScene.fbx")


def test_standard_is_backward_alias_for_low_resolution():
    old = contracts.build_geometry_profile("Standard", "Max Reference", "MoGe-3")
    assert old["selected_profile"] == "Low Resolution"
    assert old["mesher_policy"] == "low_resolution_transport_stride"


def test_split_clean_rejects_stretched_triangle_without_moving_vertices():
    master = {
        "vertices": np.array([[0,0,-2],[1,0,-2],[0,1,-2],[20,0.02,-2]], dtype=np.float32),
        "faces": np.array([[0,1,2],[1,3,2]], dtype=np.int32),
        "uvs": np.zeros((4,2), dtype=np.float32),
        "grid_xy": np.array([[0,0],[1,0],[0,1],[2,0]], dtype=np.int32),
        "source_uv": np.zeros((4,2), dtype=np.float32),
        "camera_depth": np.full(4,2.0,dtype=np.float32),
    }
    cleaned, report = variants.build_hf_split_clean(master, camera_bundle(3,2), quality_min=0.04, max_edge_ratio=10.0)
    assert report["rejected_elongated_faces"] >= 1
    assert report["vertex_motion"] == 0.0
    assert len(cleaned["faces"]) == 1


def test_simplified_proxy_reduces_hf_grid_and_keeps_depth_edges():
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    c = synthetic_canonical(p, w=10, h=10)
    arrays, _ = nodes._build_primary_mesh_arrays_from_canonical(c, camera_bundle(10,10), 10, 10, profile_config=p)
    proxy, report = variants.build_hf_simplified_proxy(arrays, camera_bundle(10,10), stride=2, depth_edge_rtol=0.04)
    assert report["output_vertices"] < len(arrays["vertices"])
    assert report["output_faces"] < len(arrays["faces"])
    assert report["depth_edge_rtol"] == pytest.approx(0.04)


def test_glb_variant_embeds_artist_camera(tmp_path):
    mesh = {
        "vertices": np.array([[0,0,-2],[1,0,-2],[0,1,-2]], dtype=np.float32),
        "faces": np.array([[0,1,2]], dtype=np.uint32),
        "uvs": np.array([[0,0],[1,0],[0,1]], dtype=np.float32),
        "normals": np.array([[0,0,1],[0,0,1],[0,0,1]], dtype=np.float32),
    }
    out = tmp_path / "camera.glb"
    variants.write_glb_with_artist_camera(out, mesh, camera_bundle(8,8), texture_path=None, mesh_name="HF_Master")
    data = variants.read_glb_json(out)
    assert data["cameras"][0]["name"] == "CG_ARTIST_CAMERA"
    assert {n["name"] for n in data["nodes"]} == {"HF_Master", "CG_ARTIST_CAMERA"}
    assert data["scenes"][0]["nodes"] == [0,1]


def test_golden_maya_fixture_freezes_known_good_high_fidelity_scene():
    fixture = json.loads((ROOT / "Tests" / "fixtures" / "golden_maya_v032_high_fidelity.json").read_text(encoding="utf-8"))
    assert fixture["source_run"] == "20260919T002220_779479Z_222fcaea"
    assert fixture["maya_version"] == "2026"
    assert fixture["camera"]["artist_transform"] == "CG_ARTIST_CAMERA"
    assert fixture["camera"]["matched_transform"] == "CG_MATCHED_CAMERA1"
    assert fixture["camera"]["horizontal_fov_deg"] == pytest.approx(36.83175195590167)
    assert len(fixture["camera"]["world_matrix"]) == 16
    hero = fixture["hero_mesh"]
    assert hero["vertex_count"] == 1426735
    assert hero["face_count"] == 2823599
    assert hero["uv_count"] == 1426735
    assert hero["material_count"] == 1
    assert hero["texture_file_name"] == "ConceptGhost_concept_scene_PrimaryTexture.png"
    assert hero["transport_stride"] == 1
    for gate in ("pre_maya", "maya_live", "maya_reopen", "fbx_roundtrip"):
        assert fixture["normal_gates"][gate] == "PASS"
    assert fixture["normal_gates"]["camera_away_faces"] == 0
    assert fixture["normal_gates"]["normal_opposed_faces"] == 0


def test_current_maya_worker_preserves_golden_scene_assembly_contract():
    text = (ROOT / "custom_nodes" / "ConceptGhost_Stage68" / "conceptghost_maya_worker.py").read_text(encoding="utf-8")
    for token in (
        '"CG_HERO_MESH_MAT"',
        '"CG_HERO_MESH_BASECOLOR"',
        '"CG_ARTIST_CAMERA"',
        '"CG_MATCHED_CAMERA"',
        'fn.create(points, polygon_counts, polygon_connects, parent=parent_obj)',
        'fn.assignUVs(polygon_counts, polygon_connects)',
        'FACE_VERTEX_PAYLOAD',
        'MAYA_INPUT_PARITY',
        'GhostFullScene.fbx',
    ):
        assert token in text


def test_split_clean_primarymesh_payload_records_authoritative_mesh_policy(tmp_path):
    p = contracts.build_geometry_profile("High Fidelity Split Clean", "Max Reference", "MoGe-3")
    c = synthetic_canonical(p, w=10, h=8)
    boundary = np.zeros(80, dtype=np.float32)
    boundary[c["grid_xy"][:, 0] == 5] = 0.2
    c["geometric_boundary_strength"] = boundary
    image = np.zeros((1, 8, 10, 3), dtype=np.float32)
    payload = nodes._write_primary_mesh_payload(tmp_path, "concept_scene", c, camera_bundle(10, 8), image, profile_config=p)
    assert payload["schema"] == "ConceptGhost.PrimarySolverMeshPayload.v0.31"
    assert payload["selected_profile"] == "High Fidelity Split Clean"
    assert payload["mesher_policy"] == "moge_full_resolution_depth_edge_split_clean"
    assert payload["discontinuity_threshold"] == pytest.approx(0.10)
    assert payload["long_triangle_policy"] == "relative_shape_and_depth_reject"
    assert payload["connected_components_policy"] == "preserve_disconnected_shells"
    assert payload["boundary_cleanup_policy"] == "edge_aware_whisker_prune"
    assert payload["split_clean_report"]["rejected_discontinuity_faces"] > 0
    on_disk = json.loads((tmp_path / "maya" / "primary_mesh_payload.json").read_text(encoding="utf-8"))
    assert on_disk["discontinuity_threshold"] == pytest.approx(0.10)


def test_hf_variant_exporter_does_not_double_clean_split_clean_primarymesh_source():
    text = (ROOT / "custom_nodes" / "ConceptGhost_Stage68" / "conceptghost_variants.py").read_text(encoding="utf-8")
    assert "PRIMARYMESH_ALREADY_SPLIT_CLEAN_NO_SECOND_PASS" in text
    assert 'if profile == "High Fidelity Split Clean"' in text


def test_v032_installed_verifier_checks_structural_profile_defaults():
    root = ROOT
    wf = json.loads((root / "Workflows" / "Project" / "ConceptGhost_Master_v0.32.json").read_text(encoding="utf-8"))
    master = next(n for n in wf["nodes"] if n.get("type") == "ConceptGhostMasterConfig")
    assert master["widgets_values"][3] == "MoGe-3"
    assert master["widgets_values"][4] == "High Fidelity"
    verifier = (root / "Scripts" / "verify_conceptghost.ps1").read_text(encoding="utf-8")
    assert '$MasterNode[0].widgets_values[4] -ne "High Fidelity"' in verifier

def test_v032_workflow_omits_duplicate_complete_run_zip_node():
    path = ROOT / "Workflows" / "Project" / "ConceptGhost_Master_v0.32.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    assert len(data["nodes"]) == 31
    assert len(data["links"]) == 71
    assert not any(n.get("type") == "ConceptGhostRunPackageDownload" for n in data["nodes"])
    text = path.read_text(encoding="utf-8")
    assert "COMPLETE RUN" not in text
    assert "DOWNLOAD ZIP" not in text


def test_v032_legacy_package_node_generates_no_duplicate_archive(tmp_path):
    run = tmp_path / "scene" / "run_001"
    run.mkdir(parents=True)
    (run / "output_index.json").write_text(json.dumps({
        "downloads": {
            "complete_run": {"archive_name": "stale_COMPLETE.zip"},
            "other": {"keep": True},
        }
    }), encoding="utf-8")
    (run / "payload.bin").write_bytes(b"authoritative")

    info = cg_io.create_run_download_archive(run, output_dir=tmp_path / "comfy")

    assert info["status"] == "PASS_NO_DUPLICATE_ARCHIVE"
    assert info["archive_path"] == ""
    assert info["transport_path"] is None
    assert not list(run.rglob("*_COMPLETE.zip"))
    assert not (run / "package").exists()
    assert not (tmp_path / "comfy" / "conceptghost" / "run_packages").exists()

    index = json.loads((run / "output_index.json").read_text(encoding="utf-8"))
    assert "complete_run" not in index.get("downloads", {})
    assert index["downloads"]["other"]["keep"] is True
    assert index["storage_policy"]["complete_run_archive"] == "DISABLED_DUPLICATE"


def test_v032_io_source_contains_no_zip_writer_or_run_package_transport():
    text = (NODE_ROOT / "conceptghost_io.py").read_text(encoding="utf-8")
    assert "import zipfile" not in text
    assert "zipfile.ZipFile" not in text
    assert "conceptghost/run_packages" not in text
    assert "_COMPLETE.zip" not in text


def test_v032_usd_authority_is_single_physical_file():
    source = (NODE_ROOT / "nodes.py").read_text(encoding="utf-8")
    assert 'usd_path = canonical_usd_path' in source
    assert 'shutil.copy2(canonical_usd_path, usd_path)' not in source
    assert 'run / "maya" / f"ConceptGhost_{scene}_Ghost.usda"' not in source


def test_v032_transport_prefers_hardlink_and_preserves_bytes(tmp_path):
    src = tmp_path / "run" / "asset.glb"
    dst = tmp_path / "comfy" / "asset.glb"
    src.parent.mkdir(parents=True)
    src.write_bytes(b"one-authoritative-payload")
    target, mode = cg_io.link_or_copy_transport(src, dst)
    assert target.read_bytes() == src.read_bytes()
    assert mode in {"hardlink", "copy_fallback"}
    if mode == "hardlink":
        assert src.stat().st_ino == target.stat().st_ino


def test_v032_hf_preview_transport_uses_dedup_helper():
    source = (NODE_ROOT / "nodes.py").read_text(encoding="utf-8")
    assert 'link_or_copy_transport(srcp, dst)' in source
    assert 'shutil.copy2(srcp, dst)' not in source


def test_v032_primary_mesh_reuses_saved_source_texture():
    source = (NODE_ROOT / "nodes.py").read_text(encoding="utf-8")
    assert 'texture_path=src_path' in source
    assert 'resolved_texture_path = candidate' in source
    # The normal v0.32 export path must not require a second PrimaryTexture PNG.
    call_region = source[source.index('hero_mesh_payload = _write_primary_mesh_payload('):source.index('_stage0607_log(run, f"DCC TRANSPORT MESH DONE', source.index('hero_mesh_payload = _write_primary_mesh_payload('))]
    assert 'texture_path=src_path' in call_region


def test_v032_full_scene_fbx_uses_compatibility_alias_not_second_export():
    source = (NODE_ROOT / "conceptghost_maya_worker.py").read_text(encoding="utf-8")
    assert '_hardlink_or_copy_alias(out["fbx"], out["full_scene_fbx"])' in source
    assert 'for command in fbx_export_mel_commands(out["full_scene_fbx"])' not in source
    assert 'compatibility_alias_of_official_full_scene_fbx' in source


def test_v032_fbx_alias_helper_avoids_duplicate_bytes_when_hardlink_available(tmp_path):
    src = tmp_path / "Ghost.fbx"
    dst = tmp_path / "GhostFullScene.fbx"
    src.write_bytes(b"fbx-full-scene")
    mode = maya_worker._hardlink_or_copy_alias(src, dst)
    assert dst.read_bytes() == src.read_bytes()
    assert mode in {"hardlink", "copy_fallback"}
    if mode == "hardlink":
        assert src.stat().st_ino == dst.stat().st_ino


def test_v032_full_scene_alias_reuses_one_roundtrip_verification():
    source = (NODE_ROOT / "conceptghost_maya_worker.py").read_text(encoding="utf-8")
    assert 'full_scene_verification = dict(fbx_verification)' in source
    assert 'verification_basis": "same_physical_payload_as_official_fbx"' in source
    assert '_verify_fbx_camera_roundtrip(\n                cmds, mel, out["full_scene_fbx"]' not in source


def test_v032_fbm_sidecars_are_transient_not_persistent():
    source = (NODE_ROOT / "conceptghost_maya_worker.py").read_text(encoding="utf-8")
    assert 'embedded_textures_no_persistent_sidecar' in source
    assert 'shutil.rmtree(candidate' in source
    assert 'media_folder = _ensure_fbx_media_folder' not in source


def _write_v032_remesh_fixture(tmp_path, *, w=16, h=16):
    p = contracts.build_geometry_profile("High Fidelity", "Max Reference", "MoGe-3")
    cam = camera_bundle(w, h)
    canonical = synthetic_canonical(p, w=w, h=h)
    arrays, _ = nodes._build_primary_mesh_arrays_from_canonical(canonical, cam, w, h, profile_config=p)
    run = tmp_path / "scene" / "run_001"
    (run / "maya").mkdir(parents=True)
    (run / "camera").mkdir(parents=True)
    npz = run / "maya" / "PrimaryMesh.npz"
    np.savez_compressed(npz, **arrays)
    (run / "camera" / "camera.json").write_text(json.dumps(cam), encoding="utf-8")
    payload = {
        "geometry_profile": "High Fidelity",
        "selected_profile": "High Fidelity",
        "effective_profile": "High Fidelity",
        "npz_path": str(npz),
        "texture_path": None,
        "scene_name": "concept_scene",
    }
    (run / "maya" / "primary_mesh_payload.json").write_text(json.dumps(payload), encoding="utf-8")
    return run, arrays


def test_v032_remesh_switch_off_skips_all_derived_computation_and_files(tmp_path):
    run, arrays = _write_v032_remesh_fixture(tmp_path)
    info = variants.export_primary_and_remesh_variants(run, generate_remesh_variants=False)
    assert info["status"] == "PASS"
    assert info["primary_mesh_unchanged"] is True
    assert info["remesh_status"] == "SKIPPED_SWITCH_OFF"
    assert info["remesh_variants"] == {}
    assert Path(info["master"]["path"]).is_file()
    assert info["master"]["vertices"] == len(arrays["vertices"])
    assert info["master"]["faces"] == len(arrays["faces"])
    assert not list((run / "meshes" / "remesh_variants").glob("*Remesh_*.glb"))


def test_v032_remesh_switch_on_generates_light_medium_strong_in_decreasing_density(tmp_path):
    run, arrays = _write_v032_remesh_fixture(tmp_path, w=20, h=20)
    info = variants.export_primary_and_remesh_variants(run, generate_remesh_variants=True)
    assert info["remesh_status"] == "GENERATED"
    r = info["remesh_variants"]
    assert set(r) == {"light", "medium", "strong"}
    assert [r[k]["stride"] for k in ("light", "medium", "strong")] == [2, 3, 4]
    for k in ("light", "medium", "strong"):
        assert Path(r[k]["path"]).is_file()
        assert r[k]["derived_only"] is True
        assert r[k]["does_not_replace_maya_primarymesh"] is True
        assert r[k]["output_vertices"] < len(arrays["vertices"])
        gltf = variants.read_glb_json(r[k]["path"])
        assert gltf["cameras"][0]["name"] == "CG_ARTIST_CAMERA"
    assert r["light"]["output_vertices"] > r["medium"]["output_vertices"] > r["strong"]["output_vertices"]
    assert r["light"]["output_faces"] > r["medium"]["output_faces"] > r["strong"]["output_faces"]


def test_v032_workflow_restores_points_and_exposes_separate_remesh_outputs():
    path = ROOT / "Workflows" / "Project" / "ConceptGhost_Master_v0.32.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    assert len(data["nodes"]) == 31
    assert len(data["links"]) == 71
    types = [n.get("type") for n in data["nodes"]]
    assert types.count("ConceptGhostPointCloudPreview") == 1
    assert types.count("ConceptGhostPrimaryRemeshExporter") == 1
    assert types.count("ConceptGhost3DAssetPreview") == 4
    exporter = next(n for n in data["nodes"] if n.get("type") == "ConceptGhostPrimaryRemeshExporter")
    assert exporter["widgets_values"] == [False]
    assert [o["name"] for o in exporter["outputs"][:4]] == [
        "primary_master_glb", "remesh_light_glb", "remesh_medium_glb", "remesh_strong_glb"
    ]
    titles = {n.get("title", "") for n in data["nodes"]}
    assert any("FUSED POINTS OUTPUT" in t for t in titles)
    assert any("REMESH LIGHT" in t for t in titles)
    assert any("REMESH MEDIUM" in t for t in titles)
    assert any("REMESH STRONG" in t for t in titles)


def test_v032_point_cloud_preview_uses_existing_preview_path_without_copy(tmp_path):
    ply = tmp_path / "pointcloud.ply"
    ply.write_bytes(b"ply\n")
    result = nodes.ConceptGhostPointCloudPreview().preview(str(ply))
    assert result["result"] == (str(ply.resolve()),)
    assert ply.read_bytes() == b"ply\n"


def test_v032_installer_and_verifier_target_only_current_workflow():
    installer = (ROOT / "Scripts" / "install_comfy_payload.ps1").read_text(encoding="utf-8")
    verifier = (ROOT / "Scripts" / "verify_conceptghost.ps1").read_text(encoding="utf-8")
    top = (ROOT / "Scripts" / "install_conceptghost.ps1").read_text(encoding="utf-8")
    assert "ConceptGhost_Master_v0.32.json" in installer
    assert "ConceptGhost.InstallMarker.v0.32" in installer
    assert "ConceptGhost-v0.32-install.json" in installer
    assert "ConceptGhost v0.32" in top
    for token in (
        "ConceptGhostPrimaryRemeshExporter",
        "ConceptGhostPointCloudPreview",
        "ConceptGhost3DAssetPreview",
        "expected 31",
        "expected 71",
        "remesh switch must default OFF",
    ):
        assert token in verifier
    assert "ConceptGhostRunPackageDownload" in verifier

def test_v032_release_manifest_records_real_remesh_validation_and_dedup_policy():
    data = json.loads((ROOT / "RELEASE_MANIFEST.json").read_text(encoding="utf-8"))
    assert data["schema"] == "ConceptGhost.ReleaseManifest.v0.32"
    assert data["version"] == "0.32.0"
    assert data["release"] == "ConceptGhost_v0.32_COMPLETE"
    assert data["storage_policy"]["complete_run_zip"] == "DISABLED_DUPLICATE"
    a = data["artist_outputs"]
    assert a["fused_points_preview"] is True
    assert a["remesh_default"] is False
    assert a["derived_remesh_replaces_primarymesh"] is False
    assert a["remesh_presets"]["Light"]["vertices"] == 354777
    assert a["remesh_presets"]["Medium"]["vertices"] == 157415
    assert a["remesh_presets"]["Strong"]["vertices"] == 88294
    assert a["camera"] == "CG_ARTIST_CAMERA"
    complete = data["complete_bundle"]
    assert complete["self_contained_clean_machine_source"] is True
    assert complete["legacy_v030_v031_files_in_bundle"] is False
    assert complete["generated_caches_in_bundle"] is False

def test_v032_da3_cleanup_audit_is_measure_only_and_defaults_uncertain_to_keep():
    audit = (ROOT / "Scripts" / "audit_da3_safe.ps1").read_text(encoding="utf-8")
    assert "ConceptGhost.DA3SafeCleanupAudit.v0.32" in audit
    assert "MEASURE_AND_CLASSIFY_ONLY_NO_DELETION" in audit
    assert '"SAFE_TO_DELETE"' in audit
    assert '"KEEP"' in audit
    assert '"UNCERTAIN"' in audit
    assert 'DiscoveryPatterns' in audit and 'DepthAnythingV3' in audit
    for protected in ("Python", "Torch/PyTorch", "CUDA", "NumPy", "Single View", "Multi View/Trellis"):
        assert protected in audit
    assert "Remove-Item" not in audit

def test_v032_da3_remover_has_exact_path_fence_and_never_deletes_pixi_plugin_models():
    remover = (ROOT / "Scripts" / "remove_da3_safe.ps1").read_text(encoding="utf-8")
    assert 'ConceptGhost.DA3SafeCleanupAudit.v0.32' in remover
    assert r'C:\ConceptGhost\cache\da3-comfy-env' in remover
    assert r'C:\ConceptGhost\config\da3_host_paths.json' in remover
    assert r'C:\ConceptGhost\cache\pixi' in remover
    assert 'REMOVE_EXCLUSIVE_DA3' in remover
    assert '$AllowedExact -notcontains' in remover
    allowed = remover[remover.index('$AllowedExact = @('):remover.index(')\n$Targets', remover.index('$AllowedExact = @('))]
    assert r'cache\pixi' not in allowed
    assert 'ComfyUI-DepthAnythingV3' not in allowed
    assert r'models\depthanything3' not in allowed

def test_v032_da3_audit_hashes_protected_workflow_references_and_cleanup_rechecks_them():
    audit = (ROOT / "Scripts" / "audit_da3_safe.ps1").read_text(encoding="utf-8")
    remover = (ROOT / "Scripts" / "remove_da3_safe.ps1").read_text(encoding="utf-8")
    assert "protected_reference_hashes" in audit
    assert "Get-FileHash -Algorithm SHA256" in audit
    assert "ProtectedHashMismatches" in remover
    assert "MISSING_AFTER_CLEANUP" in remover
    assert "HASH_CHANGED" in remover
    assert "ConceptGhost.DA3SafeCleanupResult.v0.32" in remover
    assert "conceptghost_verify" in remover
    assert 'protected_reference_hash_check="PASS"' in remover

def test_v032_maya_reopen_explicitly_requires_fused_points():
    source = (NODE_ROOT / "conceptghost_maya_worker.py").read_text(encoding="utf-8")
    assert 'reopened_fused_points_present = bool(cmds.objExists(names["fused_points"]))' in source
    assert 'Maya .ma reopen lost CG_FUSED_POINTS' in source
    assert 'fused_points_present' in source


def test_v032_runtime_acceptance_verifier_checks_dedup_and_remesh_contracts():
    verifier = (ROOT / "Scripts" / "verify_v032_runtime_output.ps1").read_text(encoding="utf-8")
    for token in (
        'ConceptGhost.RemeshVariants.v0.32',
        'No COMPLETE.zip duplicate',
        'No duplicate Maya USDA',
        'No duplicate PrimaryTexture PNG',
        'No persistent FBM sidecar',
        'FBX alias exact payload',
        'Fused points survived .ma reopen',
        'Remesh OFF writes no derived GLBs',
        'Remesh ON has 3 derived GLBs',
        'Remesh density decreases',
    ):
        assert token in verifier


def test_v032_runtime_validation_entrypoints_are_current_only():
    current = (ROOT / "PREPARE_V032_RUNTIME_VALIDATION.bat").read_text(encoding="utf-8")
    wrapper = (ROOT / "VERIFY_V032_RUNTIME_OUTPUT.bat").read_text(encoding="utf-8")
    assert 'ConceptGhost_Master_v0.32.json' in current
    assert 'VERIFY_V032_RUNTIME_OUTPUT.bat -RemeshMode OFF' in current
    assert 'VERIFY_V032_RUNTIME_OUTPUT.bat -RemeshMode ON' in current
    assert 'verify_v032_runtime_output.ps1' in wrapper
    assert not (ROOT / "PREPARE_GATE8_VALIDATION.bat").exists()
    assert not (ROOT / "VERIFY_HIGH_FIDELITY_OUTPUT.bat").exists()



def test_v032_runtime_installer_reuses_existing_runtime_when_vendor_zip_is_absent():
    script = (ROOT / "Scripts" / "install_moge3_runtime.ps1").read_text(encoding="utf-8-sig")
    assert "function Try-ReuseExistingRuntime" in script
    assert "Bundled MoGe source ZIP is absent; validating the already-installed" in script
    assert "Existing-runtime verification did not recreate READY.json" in script
    assert "Vendor source ZIP was not required" in script
    # Regression: READY must not be deleted before the vendor/reuse decision.
    vendor_gate = script.index('if (-not (Test-Path $VendorZip))')
    ready_delete = script.index('if (Test-Path $Ready) { Remove-Item $Ready -Force }')
    assert ready_delete > vendor_gate
    # A missing vendor is fatal only if no reusable private runtime exists.
    assert "no reusable ConceptGhost isolated runtime was found" in script

from __future__ import annotations

import json
import os
from pathlib import Path


def main() -> int:
    runtime_root = Path(os.environ.get("CONCEPTGHOST_MOGE_RUNTIME", Path(__file__).resolve().parents[2])).resolve()
    cache = runtime_root / "cache"
    hf = cache / "hf"
    os.environ.setdefault("HF_HOME", str(hf))
    os.environ.setdefault("HUGGINGFACE_HUB_CACHE", str(hf / "hub"))
    os.environ.setdefault("TORCH_HOME", str(cache / "torch"))

    from huggingface_hub import snapshot_download

    models = [
        {"profile": "Low Resolution", "repo_id": "Ruicheng/moge-3-vitl"},
        {"profile": "High Fidelity", "repo_id": "Ruicheng/moge-3-vitg"},
    ]
    resolved = []
    for item in models:
        path = snapshot_download(repo_id=item["repo_id"])
        resolved.append({**item, "snapshot_path": str(Path(path).resolve())})

    report = {
        "schema": "ConceptGhost.MoGe3ModelCache.v0.30",
        "status": "PASS",
        "runtime_root": str(runtime_root),
        "models": resolved,
    }
    out = runtime_root / "MODELS_READY.json"
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

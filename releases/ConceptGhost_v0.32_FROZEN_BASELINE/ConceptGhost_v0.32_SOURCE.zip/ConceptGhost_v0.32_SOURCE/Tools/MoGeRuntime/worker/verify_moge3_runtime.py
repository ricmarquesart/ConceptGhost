from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import numpy as np


def main() -> int:
    runtime_root = Path(os.environ.get("CONCEPTGHOST_MOGE_RUNTIME", Path(__file__).resolve().parents[2])).resolve()
    cache = runtime_root / "cache"
    os.environ.setdefault("HF_HOME", str(cache / "hf"))
    os.environ.setdefault("HUGGINGFACE_HUB_CACHE", str(cache / "hf" / "hub"))
    os.environ.setdefault("TORCH_HOME", str(cache / "torch"))

    import torch
    from moge.model.v3 import MoGeModel

    report = {
        "schema": "ConceptGhost.MoGeRuntimeVerification.v1",
        "runtime_root": str(runtime_root),
        "python": sys.executable,
        "torch": torch.__version__,
        "cuda_runtime": torch.version.cuda,
        "cuda_available": bool(torch.cuda.is_available()),
        "model": "Ruicheng/moge-3-vitl",
        "refine_steps_smoke": 1,
    }
    if not torch.cuda.is_available():
        report["status"] = "FAIL"
        report["reason"] = "CUDA unavailable"
        print(json.dumps(report, indent=2))
        return 2

    device = torch.device("cuda")
    report["gpu"] = torch.cuda.get_device_name(device)
    t0 = time.perf_counter()
    model = MoGeModel.from_pretrained("Ruicheng/moge-3-vitl").to(device).eval()
    report["model_load_seconds"] = time.perf_counter() - t0

    # Deterministic synthetic RGB image; no artist file is needed for installation verification.
    h, w = 192, 288
    y, x = np.indices((h, w), dtype=np.float32)
    rgb = np.stack([
        np.clip(x / max(w - 1, 1), 0, 1),
        np.clip(y / max(h - 1, 1), 0, 1),
        0.5 + 0.25 * np.sin(x / 19.0) * np.cos(y / 17.0),
    ], axis=-1)
    image = torch.from_numpy(rgb).to(device=device, dtype=torch.float32).permute(2, 0, 1)
    torch.cuda.reset_peak_memory_stats(device)
    t1 = time.perf_counter()
    out = model.infer(image, resolution_level=2, refine_steps=1, return_per_step=True, use_fp16=True)
    torch.cuda.synchronize(device)
    report["inference_seconds"] = time.perf_counter() - t1
    report["peak_vram_bytes"] = int(torch.cuda.max_memory_allocated(device))

    required = ["points", "depth", "intrinsics", "mask", "normal"]
    missing = [k for k in required if k not in out or out[k] is None]
    finite = {}
    shapes = {}
    for k in required:
        if k in out and out[k] is not None:
            arr = out[k].detach().float().cpu().numpy()
            finite[k] = bool(np.isfinite(arr).all())
            shapes[k] = list(arr.shape)
    report["missing"] = missing
    report["finite"] = finite
    report["shapes"] = shapes
    report["per_step_count"] = len(out.get("points_per_step") or [])
    ok = not missing and all(finite.values()) and report["per_step_count"] == 2
    report["status"] = "PASS" if ok else "FAIL"

    ready = runtime_root / "READY.json"
    if ok:
        ready.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if ok else 3


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import numpy as np


def main() -> int:
    runtime_root = Path(os.environ.get("CONCEPTGHOST_MOGE_RUNTIME", Path(__file__).resolve().parents[2])).resolve()
    cache = runtime_root / "cache"
    os.environ.setdefault("HF_HOME", str(cache / "hf"))
    os.environ.setdefault("HUGGINGFACE_HUB_CACHE", str(cache / "hf" / "hub"))
    os.environ.setdefault("TORCH_HOME", str(cache / "torch"))

    import torch
    from moge.model.v3 import MoGeModel

    report = {
        "schema": "ConceptGhost.MoGe3ViTGVerification.v0.30",
        "runtime_root": str(runtime_root),
        "python": sys.executable,
        "model": "Ruicheng/moge-3-vitg",
        "profile": "High Fidelity",
        "note": "Small smoke test verifies model loading and CUDA compatibility; production High Fidelity uses resolution_level=9/refine_steps=7.",
    }
    if not torch.cuda.is_available():
        report.update(status="FAIL", reason="CUDA unavailable")
        print(json.dumps(report, indent=2))
        return 2

    device = torch.device("cuda")
    report["gpu"] = torch.cuda.get_device_name(device)
    report["total_vram_bytes"] = int(torch.cuda.get_device_properties(device).total_memory)
    try:
        t0 = time.perf_counter()
        model = MoGeModel.from_pretrained(report["model"]).to(device).eval()
        report["model_load_seconds"] = time.perf_counter() - t0

        h, w = 160, 224
        y, x = np.indices((h, w), dtype=np.float32)
        rgb = np.stack([
            x / max(w - 1, 1),
            y / max(h - 1, 1),
            0.5 + 0.2 * np.sin(x / 13.0) * np.cos(y / 11.0),
        ], axis=-1)
        image = torch.from_numpy(rgb).to(device=device, dtype=torch.float32).permute(2, 0, 1)
        torch.cuda.reset_peak_memory_stats(device)
        out = model.infer(image, resolution_level=2, refine_steps=1, use_fp16=True)
        torch.cuda.synchronize(device)
        report["peak_vram_bytes"] = int(torch.cuda.max_memory_allocated(device))
        required = ["points", "depth", "intrinsics", "mask", "normal"]
        report["missing"] = [k for k in required if k not in out or out[k] is None]
        report["status"] = "PASS" if not report["missing"] else "FAIL"
        report["production_capacity_guaranteed"] = False
        report["production_capacity_note"] = "11 GB-class GPUs may still OOM at ViT-G resolution_level=9/refine_steps=7; ConceptGhost never silently downgrades High Fidelity."
    except torch.cuda.OutOfMemoryError as exc:
        report.update(status="OOM", reason=str(exc), production_capacity_guaranteed=False)
        print(json.dumps(report, indent=2))
        return 4
    except Exception as exc:
        report.update(status="FAIL", reason=repr(exc), production_capacity_guaranteed=False)
        print(json.dumps(report, indent=2))
        return 3

    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())

@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  ConceptGhost v0.32 COMPLETE - BUNDLE INTEGRITY
echo ============================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_bundle.ps1"
if errorlevel 1 ( echo. & echo [FAIL] Bundle integrity failed. & pause & exit /b 1 )
pause

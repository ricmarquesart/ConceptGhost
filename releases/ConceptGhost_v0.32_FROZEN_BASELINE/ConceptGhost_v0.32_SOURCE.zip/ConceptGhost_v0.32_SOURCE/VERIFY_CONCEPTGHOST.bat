@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_conceptghost.ps1"
if errorlevel 1 (
  echo.
  echo [FAIL] ConceptGhost v0.32 verification failed.
  pause
  exit /b 1
)
pause

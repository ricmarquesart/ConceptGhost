@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_v032_runtime_output.ps1" %*
exit /b %errorlevel%

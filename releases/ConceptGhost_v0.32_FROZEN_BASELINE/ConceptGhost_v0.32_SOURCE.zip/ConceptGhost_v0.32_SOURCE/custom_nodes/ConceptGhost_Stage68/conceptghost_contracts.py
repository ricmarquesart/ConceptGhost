from __future__ import annotations

from copy import deepcopy
from typing import Any

SCHEMA_VERSION = "0.31"
CANONICAL_COORDINATES = {
    "handedness": "right-handed",
    "up_axis": "+Y",
    "right_axis": "+X",
    "camera_forward": "-Z",
    "image_origin": "upper-left",
    "image_u": "+right",
    "image_v": "+down",
}

PRESET_PARAMETERS = {
    "Max Reference": {
        "moge_resolution_level": 9,
        "moge_force_projection": True,
        "moge_apply_mask": True,
        "canonical_downsample": 1,
        "point_width": 0.01,
        "candidate_unfrozen": True,
    },
    "Balanced": {
        "moge_resolution_level": 7,
        "moge_force_projection": True,
        "moge_apply_mask": True,
        "canonical_downsample": 2,
        "point_width": 0.012,
        "candidate_unfrozen": True,
    },
    "Fast Test": {
        "moge_resolution_level": 5,
        "moge_force_projection": True,
        "moge_apply_mask": True,
        "canonical_downsample": 4,
        "point_width": 0.015,
        "candidate_unfrozen": True,
    },
}

PROFILE_SCHEMA = "ConceptGhost.GeometryProfile.v1.2"
MAYA_NORMAL_GATES = ("pre_maya", "maya_live", "maya_reopen", "fbx_roundtrip")


def _profile_name(name: str) -> str:
    aliases = {
        "Standard": "Low Resolution",
        "High Fidelity — Split Clean": "High Fidelity Split Clean",
        "HF Split Clean": "High Fidelity Split Clean",
    }
    return aliases.get(str(name), str(name))


def _is_hf(name: str) -> bool:
    return _profile_name(name) in {"High Fidelity", "High Fidelity Split Clean"}


def _mesh_profile_config(name: str) -> dict[str, Any]:
    name = _profile_name(name)
    if name == "High Fidelity":
        return {
            "schema": "ConceptGhost.MeshProfile.v1",
            "profile_name": name,
            "discontinuity_threshold": None,
            "discontinuity_metric": "canonical_geometric_boundary_strength_0_to_1",
            "depth_edge_rtol": 0.04,
            "long_triangle_policy": "disabled",
            "long_triangle_ratio": None,
            "triangle_quality_min": None,
            "connected_component_policy": "preserve_disconnected_shells",
            "boundary_cleanup_policy": "disabled",
            "mesher_policy": "moge_full_resolution_depth_edge_preserving",
        }
    if name == "High Fidelity Split Clean":
        return {
            "schema": "ConceptGhost.MeshProfile.v1",
            "profile_name": name,
            "discontinuity_threshold": 0.10,
            "discontinuity_metric": "canonical_geometric_boundary_strength_0_to_1",
            "depth_edge_rtol": 0.04,
            "long_triangle_policy": "relative_shape_and_depth_reject",
            "long_triangle_ratio": 14.0,
            "triangle_quality_min": 0.04,
            "connected_component_policy": "preserve_disconnected_shells",
            "boundary_cleanup_policy": "edge_aware_whisker_prune",
            "mesher_policy": "moge_full_resolution_depth_edge_split_clean",
        }
    return {
        "schema": "ConceptGhost.MeshProfile.v1",
        "profile_name": "Low Resolution",
        "discontinuity_threshold": None,
        "discontinuity_metric": "not_used",
        "depth_edge_rtol": None,
        "long_triangle_policy": "disabled",
        "long_triangle_ratio": None,
        "triangle_quality_min": None,
        "connected_component_policy": "preserve_disconnected_shells",
        "boundary_cleanup_policy": "disabled",
        "mesher_policy": "low_resolution_transport_stride",
    }


def build_geometry_profile(name: str, preset: str, moge_version: str = "MoGe-3") -> dict[str, Any]:
    name = _profile_name(name)
    if name not in {"Low Resolution", "High Fidelity", "High Fidelity Split Clean"}:
        raise ValueError(f"Unknown geometry profile: {name}")
    if preset not in PRESET_PARAMETERS:
        raise ValueError(f"Unknown preset: {preset}")
    if moge_version not in {"MoGe-2", "MoGe-3"}:
        raise ValueError(f"Unknown MoGe version: {moge_version}")
    if _is_hf(name) and moge_version != "MoGe-3":
        raise ValueError("High Fidelity profiles require MoGe-3 / ViT-G; no silent downgrade to MoGe-2 is allowed")

    params = PRESET_PARAMETERS[preset]
    mesh_cfg = _mesh_profile_config(name)
    if _is_hf(name):
        mesher = mesh_cfg["mesher_policy"]
        topo = "split_clean_final_faces" if name == "High Fidelity Split Clean" else "high_fidelity_final_faces"
        return {
            "schema": PROFILE_SCHEMA, "selected_profile": name, "effective_profile": name,
            "engine": "MoGe", "preset": preset, "moge_version": "MoGe-3",
            "model": "Ruicheng/moge-3-vitg", "resolution_level": 9, "num_tokens": None,
            "refine_steps": 7, "precision_policy": "mixed", "use_fp16": True,
            "return_per_step": False, "force_projection": True, "apply_mask": True,
            "silent_fallback": False, "projection_support_policy": "raw_preserve_edges_for_mesher",
            "mesher_policy": mesher, "transport_stride": 1, "transport_vertex_cap": None,
            "depth_edge_rtol": 0.04, "mesh_profile_config": mesh_cfg,
            "simplification_policy": "disabled", "decimation_policy": "disabled",
            "smoothing_policy": "edge_aware_topology_only", "normal_policy": "derive_from_final_topology",
            "topology_authority": topo, "quality_policy": "quality_first_fail_closed",
        }

    model = "Ruicheng/moge-3-vitl" if moge_version == "MoGe-3" else "moge_2_vitl_normal_fp16.safetensors"
    return {
        "schema": PROFILE_SCHEMA, "selected_profile": name, "effective_profile": name, "engine": "MoGe",
        "preset": preset, "moge_version": moge_version, "model": model,
        "resolution_level": int(params["moge_resolution_level"]), "num_tokens": None,
        "refine_steps": ({"Max Reference": 3, "Balanced": 2, "Fast Test": 1}.get(preset, 3) if moge_version == "MoGe-3" else 0),
        "precision_policy": "mixed", "use_fp16": True, "return_per_step": False,
        "force_projection": bool(params["moge_force_projection"]), "apply_mask": bool(params["moge_apply_mask"]),
        "silent_fallback": False, "projection_support_policy": "low_resolution_mask",
        "mesher_policy": "low_resolution_transport_stride", "transport_stride": None,
        "transport_vertex_cap": 250000, "depth_edge_rtol": None, "mesh_profile_config": mesh_cfg,
        "simplification_policy": "low_resolution_transport_sampling", "decimation_policy": "disabled",
        "smoothing_policy": "topology_normals_only", "normal_policy": "derive_from_final_topology",
        "topology_authority": "low_resolution_transport_faces", "quality_policy": "v0.28_compatible_low_resolution",
    }


def assert_profile_contract(profile: dict[str, Any], *, stage: str, expected_profile: str | None = None) -> dict[str, Any]:
    if not isinstance(profile, dict):
        raise RuntimeError(f"[{stage}] missing GeometryProfile contract")
    if profile.get("schema") != PROFILE_SCHEMA:
        raise RuntimeError(f"[{stage}] invalid GeometryProfile schema: {profile.get('schema')!r}")
    selected = _profile_name(profile.get("selected_profile"))
    effective = _profile_name(profile.get("effective_profile"))
    valid_profiles = {"Low Resolution", "High Fidelity", "High Fidelity Split Clean"}
    if selected not in valid_profiles:
        raise RuntimeError(f"[{stage}] invalid selected_profile: {selected!r}")
    if effective != selected:
        raise RuntimeError(f"[{stage}] profile mismatch: selected={selected!r}, effective={effective!r}")
    if expected_profile is not None and selected != _profile_name(expected_profile):
        raise RuntimeError(f"[{stage}] expected profile {expected_profile!r}, got {selected!r}")
    if profile.get("engine") != "MoGe" or bool(profile.get("silent_fallback", True)):
        raise RuntimeError(f"[{stage}] invalid engine/fallback contract")
    preset = profile.get("preset")
    if preset not in PRESET_PARAMETERS:
        raise RuntimeError(f"[{stage}] invalid or missing profile preset: {preset!r}")

    expected = build_geometry_profile(selected, preset, str(profile.get("moge_version") or "MoGe-3"))
    # Runtime-derived stride is intentionally None only for Low Resolution.
    ignore = {"num_tokens"}
    for key, value in expected.items():
        if key in ignore:
            continue
        actual = profile.get(key)
        if isinstance(value, dict):
            if not isinstance(actual, dict):
                raise RuntimeError(f"[{stage}] missing {key}")
            for sk, sv in value.items():
                av = actual.get(sk)
                if isinstance(sv, float):
                    if av is None or abs(float(av)-sv)>1e-12:
                        raise RuntimeError(f"[{stage}] {selected} {key}.{sk} mismatch: {av!r} != {sv!r}")
                elif av != sv:
                    raise RuntimeError(f"[{stage}] {selected} {key}.{sk} mismatch: {av!r} != {sv!r}")
        elif isinstance(value, float):
            if actual is None or abs(float(actual)-value)>1e-12:
                raise RuntimeError(f"[{stage}] {selected} contract mismatch for {key}: {actual!r} != {value!r}")
        elif actual != value:
            raise RuntimeError(f"[{stage}] {selected} contract mismatch for {key}: {actual!r} != {value!r}")
    return profile


def assert_maya_manifest_contract(
    manifest: dict[str, Any],
    profile: dict[str, Any],
    *,
    stage: str = "MAYA_MANIFEST",
    require_runtime_gates: bool = True,
) -> dict[str, Any]:
    """Fail-closed validation for the Maya/FBX handoff.

    Once the user selected a profile, the Maya manifest is not allowed to
    infer missing fields, reuse low-resolution defaults, or treat absent runtime
    gates as success.
    """
    expected = assert_profile_contract(dict(profile or {}), stage=f"{stage}_PROFILE")
    if not isinstance(manifest, dict):
        raise RuntimeError(f"[{stage}] missing Maya manifest")
    if manifest.get("schema") != "ConceptGhost.MayaManifest.v0.31":
        raise RuntimeError(f"[{stage}] invalid Maya manifest schema: {manifest.get('schema')!r}")

    selected = expected["selected_profile"]
    for key in ("geometry_profile", "selected_profile", "effective_profile"):
        if manifest.get(key) != selected:
            raise RuntimeError(f"[{stage}] {key} mismatch: {manifest.get(key)!r} != {selected!r}")

    manifest_profile = manifest.get("profile_config")
    assert_profile_contract(dict(manifest_profile or {}), stage=f"{stage}_EMBEDDED_PROFILE", expected_profile=selected)

    mesh_cfg = expected.get("mesh_profile_config") or {}
    required_identity = {
        "model": expected.get("model"),
        "mesher_policy": expected.get("mesher_policy"),
        "resolution_level": expected.get("resolution_level"),
        "refine_steps": expected.get("refine_steps"),
        "depth_edge_rtol": expected.get("depth_edge_rtol"),
        "discontinuity_threshold": mesh_cfg.get("discontinuity_threshold"),
        "long_triangle_policy": mesh_cfg.get("long_triangle_policy"),
        "connected_components_policy": mesh_cfg.get("connected_component_policy"),
        "boundary_cleanup_policy": mesh_cfg.get("boundary_cleanup_policy"),
        "silent_fallback": False,
    }
    for key, value in required_identity.items():
        actual = manifest.get(key)
        if isinstance(value, float):
            if actual is None or abs(float(actual) - float(value)) > 1e-12:
                raise RuntimeError(f"[{stage}] {key} mismatch: {actual!r} != {value!r}")
        elif actual != value:
            raise RuntimeError(f"[{stage}] {key} mismatch: {actual!r} != {value!r}")

    if _is_hf(selected):
        if manifest.get("transport_stride") != 1:
            raise RuntimeError(f"[{stage}] High Fidelity profile transport_stride must be 1")
    else:
        try:
            if int(manifest.get("transport_stride")) < 1:
                raise ValueError
        except Exception as exc:
            raise RuntimeError(f"[{stage}] Low Resolution transport_stride must be a positive runtime value") from exc

    hero = manifest.get("hero_mesh") or {}
    if hero.get("requested") is not True or hero.get("status") != "PASS":
        raise RuntimeError(f"[{stage}] hero mesh was not preserved through Maya: {hero!r}")
    if hero.get("geometry_profile") != selected:
        raise RuntimeError(f"[{stage}] hero mesh profile mismatch: {hero.get('geometry_profile')!r}")
    if hero.get("mesher_policy") != expected.get("mesher_policy"):
        raise RuntimeError(f"[{stage}] hero mesh mesher policy mismatch")
    if _is_hf(selected):
        if hero.get("transport_stride") != 1:
            raise RuntimeError(f"[{stage}] hero mesh stride mismatch")
    else:
        try:
            if int(hero.get("transport_stride")) < 1:
                raise ValueError
        except Exception as exc:
            raise RuntimeError(f"[{stage}] Low Resolution hero mesh stride is invalid") from exc

    if require_runtime_gates:
        for artifact in ("ma", "fbx", "full_scene_fbx", "camera_only_fbx"):
            status = (manifest.get(artifact) or {}).get("status")
            if status != "PASS":
                raise RuntimeError(f"[{stage}] {artifact} status is {status!r}, expected PASS")
        input_parity = manifest.get("maya_input_parity") or {}
        if input_parity.get("status") != "PASS":
            raise RuntimeError(f"[{stage}] MAYA_INPUT_PARITY did not PASS: {input_parity!r}")
        gates = manifest.get("normal_validation") or {}
        expected_faces = int(hero.get("face_count", -1))
        expected_vertices = int(hero.get("vertex_count", -1))
        for gate_name in MAYA_NORMAL_GATES:
            gate = gates.get(gate_name)
            if not isinstance(gate, dict) or gate.get("status") != "PASS":
                raise RuntimeError(f"[{stage}] normal/topology gate {gate_name} did not PASS: {gate!r}")
            if int(gate.get("degenerate_faces", -1)) != 0:
                raise RuntimeError(f"[{stage}] {gate_name} contains degenerate faces: {gate.get('degenerate_faces')!r}")
            if int(gate.get("faces_total", -1)) != expected_faces:
                raise RuntimeError(f"[{stage}] {gate_name} face count changed: {gate.get('faces_total')!r} != {expected_faces!r}")
            if gate_name != "pre_maya" and int(gate.get("vertex_count", -1)) != expected_vertices:
                raise RuntimeError(f"[{stage}] {gate_name} vertex count changed: {gate.get('vertex_count')!r} != {expected_vertices!r}")

    return manifest


def assert_final_manifest_contract(
    manifest: dict[str, Any],
    profile: dict[str, Any],
    *,
    stage: str = "FINAL_MANIFEST",
    require_runtime_gates: bool = True,
) -> dict[str, Any]:
    """Validate the final run manifest and nested Maya proof end-to-end."""
    expected = assert_profile_contract(dict(profile or {}), stage=f"{stage}_PROFILE")
    if not isinstance(manifest, dict) or manifest.get("schema") != "ConceptGhost.Manifest.v0.31":
        raise RuntimeError(f"[{stage}] invalid final manifest")
    selected = expected["selected_profile"]
    for key in ("geometry_profile", "selected_profile", "effective_profile"):
        if manifest.get(key) != selected:
            raise RuntimeError(f"[{stage}] {key} mismatch: {manifest.get(key)!r} != {selected!r}")
    assert_profile_contract(dict(manifest.get("profile_config") or {}), stage=f"{stage}_EMBEDDED_PROFILE", expected_profile=selected)

    hero_payload = ((manifest.get("hero_mesh") or {}).get("payload") or {})
    required_hero = {
        "geometry_profile": selected,
        "selected_profile": selected,
        "effective_profile": selected,
        "source_model": expected.get("model"),
        "mesher_policy": expected.get("mesher_policy"),
        "depth_edge_rtol": expected.get("depth_edge_rtol"),
        "discontinuity_threshold": (expected.get("mesh_profile_config") or {}).get("discontinuity_threshold"),
        "long_triangle_policy": (expected.get("mesh_profile_config") or {}).get("long_triangle_policy"),
        "connected_components_policy": (expected.get("mesh_profile_config") or {}).get("connected_component_policy"),
        "boundary_cleanup_policy": (expected.get("mesh_profile_config") or {}).get("boundary_cleanup_policy"),
    }
    for key, value in required_hero.items():
        actual = hero_payload.get(key)
        if isinstance(value, float):
            if actual is None or abs(float(actual) - float(value)) > 1e-12:
                raise RuntimeError(f"[{stage}] PrimaryMesh {key} mismatch: {actual!r} != {value!r}")
        elif actual != value:
            raise RuntimeError(f"[{stage}] PrimaryMesh {key} mismatch: {actual!r} != {value!r}")
    if _is_hf(selected):
        if hero_payload.get("transport_stride") != 1:
            raise RuntimeError(f"[{stage}] High Fidelity profile PrimaryMesh transport_stride must be 1")
    else:
        try:
            if int(hero_payload.get("transport_stride")) < 1:
                raise ValueError
        except Exception as exc:
            raise RuntimeError(f"[{stage}] Low Resolution PrimaryMesh transport_stride is invalid") from exc

    maya_manifest = manifest.get("maya_worker_manifest")
    assert_maya_manifest_contract(
        maya_manifest,
        expected,
        stage=f"{stage}_MAYA",
        require_runtime_gates=require_runtime_gates,
    )

    if require_runtime_gates:
        outputs = manifest.get("outputs") or {}
        for key in ("ma", "fbx", "full_scene_fbx"):
            if (outputs.get(key) or {}).get("status") != "PASS":
                raise RuntimeError(f"[{stage}] final output {key} did not PASS")
        status = manifest.get("status") or {}
        if status.get("run_status") != "PASS":
            raise RuntimeError(f"[{stage}] run status is not PASS: {status!r}")

    return manifest


def build_run_config(
    source_name: str,
    preset: str = "Max Reference",
    camera_mode: str = "Auto",
    moge_version: str = "MoGe-3",
    geometry_profile: str = "High Fidelity",
    extra_diagnostics: bool = False,
) -> dict[str, Any]:
    if preset not in PRESET_PARAMETERS:
        raise ValueError(f"Unknown preset: {preset}")
    if camera_mode not in {"Auto", "Atlas Learned", "Atlas VP"}:
        raise ValueError(f"Unknown camera mode: {camera_mode}")
    profile = build_geometry_profile(geometry_profile, preset, moge_version)
    return {
        "schema": f"ConceptGhost.RunConfig.v{SCHEMA_VERSION}",
        "source_name": source_name,
        "preset": preset,
        "camera_mode": camera_mode,
        "geometry_engine": "MoGe",
        "moge_version": moge_version,
        "geometry_profile": geometry_profile,
        "profile_config": deepcopy(profile),
        "extra_diagnostics": bool(extra_diagnostics),
        "optional_meshes": False,
        "resolved_parameters": deepcopy(PRESET_PARAMETERS[preset]),
    }


def derive_run_status(
    *,
    camera_valid: bool,
    geometry_has_points: bool,
    integration_pass: bool,
    geometry_health_pass: bool,
    maya_ok: bool,
    ply_ok: bool,
    usd_ok: bool,
    fbx_ok: bool,
) -> dict[str, Any]:
    maya_ghost_ready = bool(camera_valid and geometry_has_points and integration_pass and geometry_health_pass and usd_ok and maya_ok)
    complete = bool(maya_ghost_ready and ply_ok and fbx_ok)
    if complete:
        run_status = "PASS"
    elif geometry_has_points or camera_valid or ply_ok or usd_ok or maya_ok:
        run_status = "PARTIAL"
    else:
        run_status = "FAIL"
    authoritative = bool(camera_valid and geometry_has_points and integration_pass and geometry_health_pass)
    return {
        "run_status": run_status,
        "maya_ghost_ready": maya_ghost_ready,
        "deliverable_package_complete": complete,
        "authoritative": authoritative,
    }


def validate_scene_bundle(scene: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    if scene.get("schema") != f"ConceptGhost.SceneBundle.v{SCHEMA_VERSION}":
        errors.append("invalid SceneBundle schema")
    if not isinstance(scene.get("camera"), dict):
        errors.append("missing camera bundle")
    if not isinstance(scene.get("geometry"), dict):
        errors.append("missing canonical geometry")
    if scene.get("coordinate_convention") != CANONICAL_COORDINATES:
        errors.append("canonical coordinate convention mismatch")
    try:
        assert_profile_contract(scene.get("profile_config"), stage="SceneBundle")
    except Exception as exc:
        errors.append(str(exc))
    status = scene.get("status", {})
    if status.get("run_status") not in {"PASS", "PARTIAL", "FAIL"}:
        errors.append("invalid run status")
    return not errors, errors


def json_safe(value: Any) -> Any:
    """Convert common numerical/container values to JSON-safe equivalents."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if hasattr(value, "tolist"):
        return value.tolist()
    return str(value)

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import struct
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np

try:
    from .conceptghost_contracts import json_safe
except ImportError:  # direct-module test/build compatibility
    from conceptghost_contracts import json_safe


def sanitize_scene_name(name: str) -> str:
    stem = Path(name).stem if name else "scene"
    clean = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-")
    return clean or "scene"


def make_run_folder(output_root: str | Path, scene_name: str) -> Path:
    root = Path(os.path.expanduser(os.path.expandvars(str(output_root))))
    scene = sanitize_scene_name(scene_name)
    while True:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        run_id = f"{stamp}_{uuid.uuid4().hex[:8]}"
        run = root / scene / run_id
        try:
            run.mkdir(parents=True, exist_ok=False)
            break
        except FileExistsError:
            continue
    for rel in [
        "source", "camera", "diagnostics", "geometry/native/moge",
        "geometry/canonical", "maya", "meshes", "logs"
    ]:
        (run / rel).mkdir(parents=True, exist_ok=True)
    return run


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: str | Path, data: dict[str, Any]) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")
    return p


def write_ply_binary(path: str | Path, xyz: np.ndarray, rgb: np.ndarray) -> Path:
    p = Path(path)
    xyz = np.asarray(xyz, dtype="<f4").reshape((-1,3))
    rgb = np.asarray(rgb, dtype=np.uint8).reshape((-1,3))
    if len(xyz) != len(rgb):
        raise ValueError("XYZ/RGB point counts differ")
    p.parent.mkdir(parents=True, exist_ok=True)
    header = (
        "ply\nformat binary_little_endian 1.0\n"
        f"element vertex {len(xyz)}\n"
        "property float x\nproperty float y\nproperty float z\n"
        "property uchar red\nproperty uchar green\nproperty uchar blue\n"
        "end_header\n"
    ).encode("ascii")
    dtype = np.dtype([("x","<f4"),("y","<f4"),("z","<f4"),("r","u1"),("g","u1"),("b","u1")])
    data = np.empty(len(xyz), dtype=dtype)
    data["x"], data["y"], data["z"] = xyz[:,0], xyz[:,1], xyz[:,2]
    data["r"], data["g"], data["b"] = rgb[:,0], rgb[:,1], rgb[:,2]
    with p.open("wb") as f:
        f.write(header)
        data.tofile(f)
    return p


def link_or_copy_transport(src: str | Path, dest: str | Path) -> tuple[Path, str]:
    """Expose an immutable run artifact through another directory without duplicating bytes when possible.

    A hard link is preferred when source and destination live on the same filesystem.
    Cross-volume or unsupported filesystems fall back to a verified copy so UI
    transport continues to work. The authoritative source never changes.
    """
    source = Path(src)
    target = Path(dest)
    if not source.is_file():
        raise FileNotFoundError(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.unlink(missing_ok=True)
    mode = "hardlink"
    try:
        os.link(source, target)
    except (OSError, NotImplementedError):
        mode = "copy_fallback"
        shutil.copy2(source, target)
    if sha256_file(source) != sha256_file(target):
        target.unlink(missing_ok=True)
        raise RuntimeError(f"Transport artifact differs from authoritative source: {source} -> {target}")
    return target, mode


def copy_preview_ply(canonical_ply: str | Path, run_id: str, output_dir: str | Path | None = None) -> Path:
    """Expose the authoritative canonical PLY in ComfyUI output for preview only.

    v0.32 prefers a hard link so the preview path does not consume a second
    physical copy of the point cloud. A verified copy is used only when the host
    output directory is on another filesystem or hard links are unavailable.
    """
    src = Path(canonical_ply)
    if not src.is_file():
        raise FileNotFoundError(src)
    if output_dir is None:
        try:
            import folder_paths  # type: ignore
            output_dir = folder_paths.get_output_directory()
        except Exception as exc:
            raise RuntimeError(f"Could not resolve ComfyUI host output directory: {exc}") from exc
    dest = Path(output_dir) / "conceptghost" / "preview" / f"{run_id}_pointcloud.ply"
    target, _mode = link_or_copy_transport(src, dest)
    return target


def finalize_run_without_archive(run_dir: str | Path) -> dict[str, Any]:
    """Finalize one ConceptGhost run without duplicating it into a full ZIP.

    The saved run directory is the sole authoritative execution payload. This
    function records that storage policy in ``output_index.json`` and deliberately
    creates no archive, no package manifest containing file copies, and no
    ComfyUI transport duplicate.
    """
    run = Path(os.path.expanduser(os.path.expandvars(str(run_dir)))).resolve()
    if not run.is_dir():
        raise RuntimeError(f"ConceptGhost run_dir does not exist: {run}")

    output_index_path = run / "output_index.json"
    if output_index_path.is_file():
        try:
            output_index = json.loads(output_index_path.read_text(encoding="utf-8"))
            if not isinstance(output_index, dict):
                output_index = {}
        except Exception:
            output_index = {}

        downloads = output_index.get("downloads")
        if isinstance(downloads, dict):
            downloads.pop("complete_run", None)
            if not downloads:
                output_index.pop("downloads", None)

        output_index["storage_policy"] = {
            "authoritative_run_folder": str(run),
            "complete_run_archive": "DISABLED_DUPLICATE",
            "policy": "Saved run folder is authoritative; no full-run ZIP or transport copy is generated.",
        }
        write_json(output_index_path, output_index)

    return {
        "run_dir": str(run),
        "archive_path": "",
        "archive_sha256": None,
        "transport_path": None,
        "download": None,
        "manifest_path": None,
        "status": "PASS_NO_DUPLICATE_ARCHIVE",
    }


def create_run_download_archive(run_dir: str | Path, output_dir: str | Path | None = None) -> dict[str, Any]:
    """Backward-compatible alias that no longer creates a duplicate run ZIP.

    v0.32 retires full-run archive generation. The name remains callable so an
    older serialized workflow does not fail merely because it still contains the
    legacy final packaging node. ``output_dir`` is intentionally ignored.
    """
    _ = output_dir
    return finalize_run_without_archive(run_dir)


def parse_ply_header(path: str | Path) -> dict[str, Any]:
    vertex_count = None
    with open(path, "rb") as f:
        while True:
            line = f.readline().decode("ascii", errors="strict").strip()
            if line.startswith("element vertex "):
                vertex_count = int(line.split()[-1])
            if line == "end_header":
                break
            if not line:
                raise ValueError("Invalid PLY header")
    return {"vertex_count": vertex_count}


def _usd_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def write_usda_points(path: str | Path, xyz: np.ndarray, rgb: np.ndarray, *, point_width: float, metadata: dict[str, Any]) -> Path:
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    pts=np.asarray(xyz,dtype=np.float32).reshape((-1,3)); cols=np.asarray(rgb,dtype=np.uint8).reshape((-1,3))
    if len(pts)!=len(cols): raise ValueError("xyz/rgb length mismatch")
    with path.open("w", encoding="utf-8", newline="\n") as f:
        f.write("#usda 1.0\n")
        f.write("(\n    defaultPrim = \"ConceptGhostPoints\"\n    upAxis = \"Y\"\n)\n\n")
        f.write('def Points "ConceptGhostPoints" {\n')
        f.write("    point3f[] points = [\n")
        for i,(x,y,z) in enumerate(pts): f.write(f"        ({x:.9g}, {y:.9g}, {z:.9g}){',' if i+1<len(pts) else ''}\n")
        f.write("    ]\n")
        f.write("    color3f[] primvars:displayColor = [\n")
        for i,(r,g,b) in enumerate(cols): f.write(f"        ({r/255.0:.7g}, {g/255.0:.7g}, {b/255.0:.7g}){',' if i+1<len(cols) else ''}\n")
        f.write('    ] ( interpolation = "vertex" )\n')
        f.write(f"    float[] widths = [{float(point_width):.7g}] ( interpolation = \"constant\" )\n")
        f.write(f'    custom string conceptghost:metadata = "{_usd_escape(json.dumps(json_safe(metadata),sort_keys=True))}"\n')
        f.write("}\n")
    return path


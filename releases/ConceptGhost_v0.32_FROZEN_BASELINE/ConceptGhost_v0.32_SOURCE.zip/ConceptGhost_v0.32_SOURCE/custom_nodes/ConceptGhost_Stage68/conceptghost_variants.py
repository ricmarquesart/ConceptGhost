from __future__ import annotations

import json
import math
import struct
from pathlib import Path
from typing import Any

import numpy as np

try:
    from PIL import Image
except Exception:
    Image = None


def _json_safe(v: Any):
    if isinstance(v, dict):
        return {str(k): _json_safe(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_json_safe(x) for x in v]
    if isinstance(v, np.ndarray):
        return v.tolist()
    if isinstance(v, np.generic):
        return v.item()
    return v


def _triangle_metrics(vertices: np.ndarray, faces: np.ndarray, chunk: int = 250_000):
    vertices = np.asarray(vertices, dtype=np.float32)
    faces = np.asarray(faces, dtype=np.int64)
    quality = np.empty(len(faces), dtype=np.float32)
    ratio = np.empty(len(faces), dtype=np.float32)
    for start in range(0, len(faces), chunk):
        end = min(start + chunk, len(faces))
        f = faces[start:end]
        a, b, c = vertices[f[:, 0]], vertices[f[:, 1]], vertices[f[:, 2]]
        e0 = np.linalg.norm(a - b, axis=1)
        e1 = np.linalg.norm(b - c, axis=1)
        e2 = np.linalg.norm(c - a, axis=1)
        area = 0.5 * np.linalg.norm(np.cross(b - a, c - a), axis=1)
        denom = e0 * e0 + e1 * e1 + e2 * e2
        q = (4.0 * np.sqrt(3.0) * area) / np.maximum(denom, 1e-20)
        longest = np.maximum(np.maximum(e0, e1), e2)
        shortest = np.minimum(np.minimum(e0, e1), e2)
        r = longest / np.maximum(shortest, 1e-12)
        quality[start:end] = np.where(np.isfinite(q), q, 0.0).astype(np.float32)
        ratio[start:end] = np.where(np.isfinite(r), r, np.inf).astype(np.float32)
    return quality, ratio


def _compact_mesh(vertices, faces, **attrs):
    faces = np.asarray(faces, dtype=np.int64).reshape((-1, 3))
    used = np.unique(faces.reshape(-1))
    remap = np.full(len(vertices), -1, dtype=np.int64)
    remap[used] = np.arange(len(used), dtype=np.int64)
    out = {
        "vertices": np.asarray(vertices, dtype=np.float32)[used],
        "faces": remap[faces].astype(np.uint32, copy=False),
        "source_vertex_ids": used.astype(np.int64, copy=False),
    }
    for key, value in attrs.items():
        if value is None:
            continue
        arr = np.asarray(value)
        if len(arr) == len(vertices):
            out[key] = arr[used]
    return out


def _camera_position(camera: dict[str, Any]) -> np.ndarray:
    extr = camera.get("extrinsics") or {}
    pos = np.asarray(extr.get("camera_position") or [0.0, 0.0, 0.0], dtype=np.float64).reshape(3)
    return pos


def _recompute_vertex_normals(vertices: np.ndarray, faces: np.ndarray, camera: dict[str, Any], chunk: int = 250_000):
    v = np.asarray(vertices, dtype=np.float64)
    f = np.asarray(faces, dtype=np.int64).copy()
    cam = _camera_position(camera)

    # Keep final triangles camera-facing just like the authoritative Maya path.
    for start in range(0, len(f), chunk):
        end = min(start + chunk, len(f))
        fc = f[start:end]
        a, b, c = v[fc[:, 0]], v[fc[:, 1]], v[fc[:, 2]]
        raw = np.cross(b - a, c - a)
        cent = (a + b + c) / 3.0
        dot = np.einsum("ij,ij->i", raw, cam.reshape(1, 3) - cent)
        rev = np.isfinite(dot) & (dot < 0.0)
        if np.any(rev):
            tmp = fc[rev, 1].copy()
            fc[rev, 1] = fc[rev, 2]
            fc[rev, 2] = tmp
            f[start:end] = fc

    accum = np.zeros((len(v), 3), dtype=np.float64)
    for start in range(0, len(f), chunk):
        end = min(start + chunk, len(f))
        fc = f[start:end]
        a, b, c = v[fc[:, 0]], v[fc[:, 1]], v[fc[:, 2]]
        raw = np.cross(b - a, c - a)
        raw[~np.isfinite(raw)] = 0.0
        for corner in range(3):
            np.add.at(accum, fc[:, corner], raw)
    length = np.linalg.norm(accum, axis=1)
    normals = np.zeros_like(accum, dtype=np.float32)
    good = np.isfinite(length) & (length > 1e-12)
    normals[good] = (accum[good] / length[good, None]).astype(np.float32)
    return f.astype(np.uint32, copy=False), normals


def _connected_component_count(vertex_count: int, faces: np.ndarray) -> int:
    faces = np.asarray(faces, dtype=np.int64).reshape((-1, 3))
    if vertex_count <= 0 or len(faces) == 0:
        return 0
    # Prefer SciPy's compiled sparse connected-components implementation when
    # available.  ConceptGhost does not require SciPy solely for this metric;
    # very large fallback cases return -1 and Maya records the authoritative
    # shell count via polyEvaluate(shell=True).
    try:
        from scipy.sparse import coo_matrix
        from scipy.sparse.csgraph import connected_components
        edges = np.concatenate([faces[:, [0,1]], faces[:, [1,2]], faces[:, [2,0]]], axis=0)
        used = np.unique(edges.reshape(-1))
        remap = np.full(vertex_count, -1, dtype=np.int64)
        remap[used] = np.arange(len(used), dtype=np.int64)
        e = remap[edges]
        data = np.ones(len(e), dtype=np.uint8)
        graph = coo_matrix((data, (e[:,0], e[:,1])), shape=(len(used), len(used))).tocsr()
        return int(connected_components(graph, directed=False, return_labels=False))
    except Exception:
        if vertex_count > 200_000:
            return -1
    parent = np.arange(vertex_count, dtype=np.int64)
    rank = np.zeros(vertex_count, dtype=np.uint8)
    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = int(parent[x])
        return x
    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra == rb: return
        if rank[ra] < rank[rb]: parent[ra] = rb
        elif rank[ra] > rank[rb]: parent[rb] = ra
        else: parent[rb] = ra; rank[ra] += 1
    for a,b,c in faces:
        union(int(a), int(b)); union(int(b), int(c))
    used = np.unique(faces.reshape(-1))
    return int(len({find(int(x)) for x in used}))


def build_hf_split_clean(
    master: dict[str, np.ndarray],
    camera: dict[str, Any],
    *,
    discontinuity_threshold: float = 0.10,
    quality_min: float = 0.04,
    max_edge_ratio: float = 14.0,
):
    """Conservative topology cleanup for the authoritative HF PrimaryMesh.

    ``discontinuity_threshold`` is measured on ConceptGhost canonical
    ``geometric_boundary_strength`` (0..1), not on MoGe depth-edge rtol.
    Lower values are more aggressive.  Vertices are never moved; the operation
    only removes bridge/elongated/boundary-whisker faces and preserves resulting
    disconnected shells for Maya ``Mesh > Separate``.
    """
    v = np.asarray(master["vertices"], dtype=np.float32)
    f = np.asarray(master["faces"], dtype=np.int64)
    if len(f) == 0:
        raise ValueError("HF Split Clean requires faces")

    boundary = master.get("geometric_boundary_strength")
    reject_boundary = np.zeros(len(f), dtype=bool)
    if boundary is not None and len(np.asarray(boundary).reshape(-1)) == len(v):
        b = np.asarray(boundary, dtype=np.float32).reshape(-1)
        face_strength = np.max(b[f], axis=1)
        reject_boundary = np.isfinite(face_strength) & (face_strength >= float(discontinuity_threshold))

    quality, ratio = _triangle_metrics(v, f)
    reject_shape = (quality < float(quality_min)) | (ratio > float(max_edge_ratio))
    # Long triangles are especially suspicious at a detected discontinuity, but
    # extremely poor triangles are rejected even without boundary evidence.
    severe_shape = (quality < float(quality_min) * 0.5) | (ratio > float(max_edge_ratio) * 1.25)
    reject_long = severe_shape | (reject_shape & reject_boundary)
    reject = reject_boundary | reject_long
    kept = f[~reject]
    kept_quality = quality[~reject]
    if len(kept) == 0:
        raise ValueError("HF Split Clean rejected every face")

    # Boundary cleanup without moving vertices: prune thin dangling whiskers after
    # stretched/bridge faces have been removed.
    incidence = np.bincount(kept.reshape(-1), minlength=len(v))
    dangling = ((incidence[kept] <= 2).sum(axis=1) >= 2) & (kept_quality < 0.25)
    kept2 = kept[~dangling]
    if len(kept2) == 0:
        raise ValueError("HF Split Clean boundary cleanup removed every face")

    compact = _compact_mesh(
        v, kept2,
        uvs=master.get("uvs"),
        grid_xy=master.get("grid_xy"),
        source_uv=master.get("source_uv"),
        camera_depth=master.get("camera_depth"),
        geometric_boundary_strength=master.get("geometric_boundary_strength"),
        canonical_point_indices=master.get("canonical_point_indices"),
        source_pixel_id=master.get("source_pixel_id"),
    )
    compact["faces"], compact["normals"] = _recompute_vertex_normals(compact["vertices"], compact["faces"], camera)
    components = _connected_component_count(len(compact["vertices"]), compact["faces"])
    report = {
        "variant": "HF Split Clean",
        "policy": "canonical_boundary_cut + relative_long_triangle_rejection + topology_boundary_cleanup + disconnected_shell_preservation",
        "discontinuity_threshold": float(discontinuity_threshold),
        "discontinuity_metric": "canonical_geometric_boundary_strength_0_to_1",
        "quality_min": float(quality_min),
        "max_edge_ratio": float(max_edge_ratio),
        "input_vertices": int(len(v)),
        "input_faces": int(len(f)),
        "rejected_discontinuity_faces": int(np.count_nonzero(reject_boundary)),
        "rejected_elongated_faces": int(np.count_nonzero(reject_long)),
        "rejected_boundary_whisker_faces": int(np.count_nonzero(dangling)),
        "output_vertices": int(len(compact["vertices"])),
        "output_faces": int(len(compact["faces"])),
        "component_count": components,
        "vertex_motion": 0.0,
        "separation_behavior": "disconnected shells remain disconnected; Maya Mesh > Separate can split them",
    }
    return compact, report


def _depth_edge_filter(depth: np.ndarray, faces: np.ndarray, rtol: float) -> np.ndarray:
    d = np.asarray(depth, dtype=np.float64).reshape(-1)
    td = d[np.asarray(faces, dtype=np.int64)]
    positive = np.isfinite(td).all(axis=1) & (td > 1e-8).all(axis=1)
    d01 = np.maximum(np.minimum(np.abs(td[:, 0]), np.abs(td[:, 1])), 1e-6)
    d12 = np.maximum(np.minimum(np.abs(td[:, 1]), np.abs(td[:, 2])), 1e-6)
    d20 = np.maximum(np.minimum(np.abs(td[:, 2]), np.abs(td[:, 0])), 1e-6)
    jump = np.maximum.reduce([
        np.abs(td[:, 0] - td[:, 1]) / d01,
        np.abs(td[:, 1] - td[:, 2]) / d12,
        np.abs(td[:, 2] - td[:, 0]) / d20,
    ])
    return positive & np.isfinite(jump) & (jump < float(rtol))


def build_hf_simplified_proxy(master: dict[str, np.ndarray], camera: dict[str, Any], *, stride=2, depth_edge_rtol=0.04, variant_name="HF Simplified Proxy"):
    v = np.asarray(master["vertices"], dtype=np.float32)
    grid = np.asarray(master.get("grid_xy"), dtype=np.int64).reshape((-1, 2))
    if len(grid) != len(v):
        raise ValueError("HF Simplified Proxy requires grid_xy aligned to the HF Master vertices")
    gx, gy = grid[:, 0], grid[:, 1]
    gw, gh = int(gx.max()) + 1, int(gy.max()) + 1
    index_grid = np.full((gh, gw), -1, dtype=np.int64)
    valid = (gx >= 0) & (gy >= 0) & (gx < gw) & (gy < gh)
    index_grid[gy[valid], gx[valid]] = np.arange(len(v), dtype=np.int64)[valid]
    sg = index_grid[::int(stride), ::int(stride)]
    p00, p10, p01, p11 = sg[:-1, :-1], sg[:-1, 1:], sg[1:, :-1], sg[1:, 1:]
    m1 = (p00 >= 0) & (p01 >= 0) & (p10 >= 0)
    m2 = (p10 >= 0) & (p01 >= 0) & (p11 >= 0)
    t1 = np.stack([p00[m1], p01[m1], p10[m1]], axis=1) if np.any(m1) else np.empty((0, 3), dtype=np.int64)
    t2 = np.stack([p10[m2], p01[m2], p11[m2]], axis=1) if np.any(m2) else np.empty((0, 3), dtype=np.int64)
    faces = np.concatenate([t1, t2], axis=0)
    if len(faces) == 0:
        raise ValueError("HF Simplified Proxy produced no candidate faces")

    depth = master.get("camera_depth")
    depth_rejected = 0
    if depth is not None and len(np.asarray(depth).reshape(-1)) == len(v):
        keep_depth = _depth_edge_filter(depth, faces, float(depth_edge_rtol))
        depth_rejected = int(np.count_nonzero(~keep_depth))
        faces = faces[keep_depth]

    quality, ratio = _triangle_metrics(v, faces)
    shape_reject = (quality < 0.03) | (ratio > 18.0)
    faces = faces[~shape_reject]
    compact = _compact_mesh(
        v, faces,
        uvs=master.get("uvs"),
        grid_xy=master.get("grid_xy"),
        source_uv=master.get("source_uv"),
        camera_depth=master.get("camera_depth"),
    )
    compact["faces"], compact["normals"] = _recompute_vertex_normals(compact["vertices"], compact["faces"], camera)
    report = {
        "variant": str(variant_name),
        "policy": "edge_aware_structured_remesh",
        "stride": int(stride),
        "depth_edge_rtol": float(depth_edge_rtol),
        "input_vertices": int(len(v)),
        "input_faces": int(len(master["faces"])),
        "rejected_depth_edge_faces": int(depth_rejected),
        "rejected_elongated_faces": int(np.count_nonzero(shape_reject)),
        "output_vertices": int(len(compact["vertices"])),
        "output_faces": int(len(compact["faces"])),
        "vertex_motion": 0.0,
        "note": "ZRemesher-like purpose only; this is a deterministic ConceptGhost screen-space remesh, not Pixologic ZRemesher.",
    }
    return compact, report


def _pad4(data: bytes, pad: bytes = b"\x00") -> bytes:
    return data + pad * ((4 - (len(data) % 4)) % 4)


def _camera_gltf(camera: dict[str, Any]):
    extr = camera.get("extrinsics") or {}
    world = np.asarray(extr.get("camera_world_matrix"), dtype=np.float64)
    if world.shape != (4, 4) or not np.isfinite(world).all():
        raise ValueError("camera_world_matrix is required for CG_ARTIST_CAMERA GLB export")
    width = float(camera.get("image_width") or 1.0)
    height = float(camera.get("image_height") or 1.0)
    intr = camera.get("intrinsics") or {}
    fy = float(intr.get("fy_px") or 0.0)
    if fy > 0 and height > 0:
        yfov = 2.0 * math.atan(height / (2.0 * fy))
    else:
        hfov = math.radians(float(camera.get("horizontal_fov_deg") or 35.0))
        yfov = 2.0 * math.atan(math.tan(hfov / 2.0) / max(width / height, 1e-9))
    # glTF JSON stores matrices in column-major order.
    matrix = world.flatten(order="F").astype(float).tolist()
    cam = {
        "name": "CG_ARTIST_CAMERA",
        "type": "perspective",
        "perspective": {"yfov": float(yfov), "aspectRatio": float(width / height), "znear": 0.01},
    }
    node = {"name": "CG_ARTIST_CAMERA", "camera": 0, "matrix": matrix}
    return cam, node


def write_glb_with_artist_camera(path: str | Path, mesh: dict[str, np.ndarray], camera: dict[str, Any], *, texture_path: str | Path | None, mesh_name: str, extras: dict[str, Any] | None = None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    v = np.asarray(mesh["vertices"], dtype="<f4")
    f = np.asarray(mesh["faces"], dtype="<u4").reshape((-1, 3))
    uv = np.asarray(mesh.get("uvs"), dtype="<f4") if mesh.get("uvs") is not None else None
    n = np.asarray(mesh.get("normals"), dtype="<f4") if mesh.get("normals") is not None else None

    blob = bytearray()
    views, accessors = [], []
    def add_view(data: bytes, target: int | None = None):
        offset = len(blob)
        blob.extend(data)
        while len(blob) % 4:
            blob.append(0)
        d = {"buffer": 0, "byteOffset": offset, "byteLength": len(data)}
        if target is not None:
            d["target"] = target
        views.append(d)
        return len(views) - 1
    def add_accessor(view, component, count, typ, *, mn=None, mx=None):
        a = {"bufferView": view, "componentType": component, "count": int(count), "type": typ}
        if mn is not None: a["min"] = [float(x) for x in mn]
        if mx is not None: a["max"] = [float(x) for x in mx]
        accessors.append(a)
        return len(accessors) - 1

    pos_view = add_view(v.tobytes(order="C"), 34962)
    pos_acc = add_accessor(pos_view, 5126, len(v), "VEC3", mn=np.min(v, axis=0), mx=np.max(v, axis=0))
    attrs = {"POSITION": pos_acc}
    if n is not None and len(n) == len(v):
        nv = add_view(n.tobytes(order="C"), 34962)
        attrs["NORMAL"] = add_accessor(nv, 5126, len(n), "VEC3")
    if uv is not None and len(uv) == len(v):
        uvv = add_view(uv.tobytes(order="C"), 34962)
        attrs["TEXCOORD_0"] = add_accessor(uvv, 5126, len(uv), "VEC2")
    idx = f.reshape(-1)
    iv = add_view(idx.tobytes(order="C"), 34963)
    ia = add_accessor(iv, 5125, len(idx), "SCALAR")

    gltf: dict[str, Any] = {
        "asset": {"version": "2.0", "generator": "ConceptGhost v0.31"},
        "buffers": [{"byteLength": 0}],
        "bufferViews": views,
        "accessors": accessors,
        "meshes": [{"name": mesh_name, "primitives": [{"attributes": attrs, "indices": ia, "mode": 4}]}],
        "nodes": [{"name": mesh_name, "mesh": 0}],
        "scenes": [{"nodes": [0]}],
        "scene": 0,
    }
    if extras:
        gltf["asset"]["extras"] = _json_safe(extras)

    if texture_path and Path(texture_path).is_file() and uv is not None:
        tex_bytes = Path(texture_path).read_bytes()
        tex_view = add_view(tex_bytes)
        gltf["images"] = [{"bufferView": tex_view, "mimeType": "image/png", "name": "PrimaryTexture"}]
        gltf["samplers"] = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
        gltf["textures"] = [{"sampler": 0, "source": 0}]
        gltf["materials"] = [{
            "name": "ConceptGhost_Unlit",
            "pbrMetallicRoughness": {"baseColorTexture": {"index": 0}, "metallicFactor": 0.0, "roughnessFactor": 1.0},
            "doubleSided": True,
            "extensions": {"KHR_materials_unlit": {}},
        }]
        gltf["extensionsUsed"] = ["KHR_materials_unlit"]
        gltf["meshes"][0]["primitives"][0]["material"] = 0

    cam, cam_node = _camera_gltf(camera)
    gltf["cameras"] = [cam]
    gltf["nodes"].append(cam_node)
    gltf["scenes"][0]["nodes"].append(1)

    gltf["buffers"][0]["byteLength"] = len(blob)
    json_bytes = json.dumps(gltf, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    json_padded = _pad4(json_bytes, b" ")
    bin_padded = _pad4(bytes(blob), b"\x00")
    total = 12 + 8 + len(json_padded) + 8 + len(bin_padded)
    with path.open("wb") as fh:
        fh.write(struct.pack("<4sII", b"glTF", 2, total))
        fh.write(struct.pack("<II", len(json_padded), 0x4E4F534A))
        fh.write(json_padded)
        fh.write(struct.pack("<II", len(bin_padded), 0x004E4942))
        fh.write(bin_padded)
    return path


def read_glb_json(path: str | Path) -> dict[str, Any]:
    data = Path(path).read_bytes()
    magic, version, total = struct.unpack_from("<4sII", data, 0)
    if magic != b"glTF" or version != 2 or total != len(data):
        raise ValueError("Invalid GLB 2.0 header")
    length, typ = struct.unpack_from("<II", data, 12)
    if typ != 0x4E4F534A:
        raise ValueError("GLB JSON chunk is missing")
    return json.loads(data[20:20+length].decode("utf-8").rstrip(" \x00"))


def export_hf_variants(run_dir: str | Path) -> dict[str, Any]:
    run = Path(run_dir)
    payload_path = run / "maya" / "primary_mesh_payload.json"
    camera_path = run / "camera" / "camera.json"
    if not payload_path.is_file() or not camera_path.is_file():
        raise FileNotFoundError("PrimaryMesh payload/camera is missing; run ConceptGhost ExportBundle first")
    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    camera = json.loads(camera_path.read_text(encoding="utf-8"))
    profile = str(payload.get("geometry_profile") or payload.get("selected_profile") or "")
    if profile not in {"High Fidelity", "High Fidelity Split Clean"}:
        return {"status": "SKIPPED", "reason": f"HF variants require High Fidelity; active profile={profile!r}"}
    npz_path = Path(payload["npz_path"])
    texture_path = Path(payload["texture_path"]) if payload.get("texture_path") else None
    with np.load(npz_path) as z:
        master = {k: np.array(z[k], copy=True) for k in z.files}

    # glTF texture coordinates use the native preview orientation. The Maya NPZ
    # stores DCC-ready V-flipped UVs, so restore V for GLB only.
    master_glb = dict(master)
    if "uvs" in master_glb:
        master_glb["uvs"] = np.array(master_glb["uvs"], copy=True)
        master_glb["uvs"][:, 1] = 1.0 - master_glb["uvs"][:, 1]

    if profile == "High Fidelity Split Clean":
        # The authoritative PrimaryMesh already contains the Split Clean policy.
        # Never clean it a second time: HF Master and HF Split Clean are the same
        # topology for this active profile by design.
        split = {k: np.array(v, copy=True) for k, v in master.items()}
        split_report = dict(payload.get("split_clean_report") or {})
        split_report.update({
            "schema": "ConceptGhost.HFSplitClean.v0.31",
            "status": "PASS",
            "policy": "PRIMARYMESH_ALREADY_SPLIT_CLEAN_NO_SECOND_PASS",
            "output_vertices": int(len(split.get("vertices", []))),
            "output_faces": int(len(split.get("faces", []))),
            "discontinuity_threshold": payload.get("discontinuity_threshold"),
            "source_authority": "PrimaryMesh",
        })
    else:
        split, split_report = build_hf_split_clean(master, camera)
    proxy, proxy_report = build_hf_simplified_proxy(master, camera)
    for m in (split, proxy):
        if "uvs" in m:
            m["uvs"] = np.array(m["uvs"], copy=True)
            m["uvs"][:, 1] = 1.0 - m["uvs"][:, 1]

    out = run / "meshes" / "hf_variants"
    out.mkdir(parents=True, exist_ok=True)
    scene = str(payload.get("scene_name") or "concept_scene")
    master_path = out / f"ConceptGhost_{scene}_HF_Master.glb"
    split_path = out / f"ConceptGhost_{scene}_HF_SplitClean.glb"
    proxy_path = out / f"ConceptGhost_{scene}_HF_SimplifiedProxy.glb"
    write_glb_with_artist_camera(master_path, master_glb, camera, texture_path=texture_path, mesh_name="HF_Master", extras={"variant":"HF Master", "run_id":run.name})
    write_glb_with_artist_camera(split_path, split, camera, texture_path=texture_path, mesh_name="HF_SplitClean", extras=split_report)
    write_glb_with_artist_camera(proxy_path, proxy, camera, texture_path=texture_path, mesh_name="HF_SimplifiedProxy", extras=proxy_report)
    report = {
        "schema": "ConceptGhost.HFVariants.v0.31",
        "status": "PASS",
        "run_id": run.name,
        "camera": "CG_ARTIST_CAMERA",
        "coordinate_space": "Atlas world / ConceptGhost canonical axes; identical placement to Maya PrimaryMesh",
        "master": {"path": str(master_path), "vertices": int(len(master["vertices"])), "faces": int(len(master["faces"]))},
        "split_clean": {**split_report, "path": str(split_path)},
        "simplified_proxy": {**proxy_report, "path": str(proxy_path)},
    }
    report_path = out / "variant_report.json"
    report_path.write_text(json.dumps(_json_safe(report), indent=2, ensure_ascii=False), encoding="utf-8")
    return {**report, "report_path": str(report_path)}


REMESH_PRESETS_V032 = {
    "Light": {"stride": 2, "depth_edge_rtol": 0.04},
    "Medium": {"stride": 3, "depth_edge_rtol": 0.04},
    "Strong": {"stride": 4, "depth_edge_rtol": 0.04},
}


def export_primary_and_remesh_variants(run_dir: str | Path, *, generate_remesh_variants: bool = False) -> dict[str, Any]:
    """v0.32 artist outputs: exact PrimaryMesh Master + optional deterministic remeshes.

    This intentionally does not replace or mutate the authoritative PrimaryMesh used
    by Maya. Light/Medium/Strong are derived GLBs only. When disabled, no remesh
    computation or remesh files are produced.
    """
    run = Path(run_dir)
    payload_path = run / "maya" / "primary_mesh_payload.json"
    camera_path = run / "camera" / "camera.json"
    if not payload_path.is_file() or not camera_path.is_file():
        raise FileNotFoundError("PrimaryMesh payload/camera is missing; run ConceptGhost ExportBundle first")
    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    camera = json.loads(camera_path.read_text(encoding="utf-8"))
    profile = str(payload.get("geometry_profile") or payload.get("selected_profile") or "")
    if profile not in {"High Fidelity", "High Fidelity Split Clean"}:
        return {"status": "SKIPPED", "reason": f"Primary/remesh outputs require High Fidelity; active profile={profile!r}"}

    npz_path = Path(payload["npz_path"])
    texture_path = Path(payload["texture_path"]) if payload.get("texture_path") else None
    with np.load(npz_path) as z:
        master = {k: np.array(z[k], copy=True) for k in z.files}

    master_glb = dict(master)
    if "uvs" in master_glb:
        master_glb["uvs"] = np.array(master_glb["uvs"], copy=True)
        master_glb["uvs"][:, 1] = 1.0 - master_glb["uvs"][:, 1]

    out = run / "meshes" / "remesh_variants"
    out.mkdir(parents=True, exist_ok=True)
    scene = str(payload.get("scene_name") or "concept_scene")
    master_path = out / f"ConceptGhost_{scene}_PrimaryMesh_Master.glb"
    write_glb_with_artist_camera(
        master_path, master_glb, camera, texture_path=texture_path,
        mesh_name="PrimaryMesh_Master",
        extras={
            "variant": "PrimaryMesh Master",
            "authority": "EXACT_MAYA_PRIMARYMESH",
            "run_id": run.name,
        },
    )

    report: dict[str, Any] = {
        "schema": "ConceptGhost.RemeshVariants.v0.32",
        "status": "PASS",
        "run_id": run.name,
        "camera": "CG_ARTIST_CAMERA",
        "coordinate_space": "Atlas world / ConceptGhost canonical axes; identical placement to Maya PrimaryMesh",
        "primary_mesh_unchanged": True,
        "master": {
            "path": str(master_path),
            "vertices": int(len(master["vertices"])),
            "faces": int(len(master["faces"])),
            "authority": "EXACT_MAYA_PRIMARYMESH",
        },
        "generate_remesh_variants": bool(generate_remesh_variants),
        "remesh_variants": {},
    }

    # Remove stale derived files when the switch is OFF or a preset is re-run.
    for preset_name in REMESH_PRESETS_V032:
        stale = out / f"ConceptGhost_{scene}_Remesh_{preset_name}.glb"
        if stale.exists():
            stale.unlink()

    if not generate_remesh_variants:
        report["remesh_status"] = "SKIPPED_SWITCH_OFF"
    else:
        for preset_name, preset in REMESH_PRESETS_V032.items():
            remesh, remesh_report = build_hf_simplified_proxy(
                master, camera,
                stride=int(preset["stride"]),
                depth_edge_rtol=float(preset["depth_edge_rtol"]),
                variant_name=f"ConceptGhost Remesh {preset_name}",
            )
            if "uvs" in remesh:
                remesh["uvs"] = np.array(remesh["uvs"], copy=True)
                remesh["uvs"][:, 1] = 1.0 - remesh["uvs"][:, 1]
            remesh_path = out / f"ConceptGhost_{scene}_Remesh_{preset_name}.glb"
            enriched = {
                **remesh_report,
                "preset": preset_name,
                "source_authority": "PrimaryMesh",
                "derived_only": True,
                "does_not_replace_maya_primarymesh": True,
                "path": str(remesh_path),
            }
            write_glb_with_artist_camera(
                remesh_path, remesh, camera, texture_path=texture_path,
                mesh_name=f"Remesh_{preset_name}", extras=enriched,
            )
            report["remesh_variants"][preset_name.lower()] = enriched
        report["remesh_status"] = "GENERATED"

    report_path = out / "remesh_variant_report.json"
    report_path.write_text(json.dumps(_json_safe(report), indent=2, ensure_ascii=False), encoding="utf-8")
    return {**report, "report_path": str(report_path)}

@echo off
setlocal EnableExtensions

if "%~1"=="" (
  echo Usage: run_maya_worker.bat ^<maya_worker_input.json^> 1>&2
  exit /b 64
)

set "INPUT_JSON=%~f1"
set "MAYAPY="

if defined CONCEPTGHOST_MAYAPY if exist "%CONCEPTGHOST_MAYAPY%" set "MAYAPY=%CONCEPTGHOST_MAYAPY%"

if not defined MAYAPY (
  for %%V in (2026 2025 2024 2023 2022 2020 2019 2018) do (
    if not defined MAYAPY if exist "%ProgramFiles%\Autodesk\Maya%%V\bin\mayapy.exe" set "MAYAPY=%ProgramFiles%\Autodesk\Maya%%V\bin\mayapy.exe"
  )
)

if not defined MAYAPY (
  echo [ConceptGhost] mayapy.exe was not found. Set CONCEPTGHOST_MAYAPY to an explicit mayapy.exe path. 1>&2
  exit /b 3
)

"%MAYAPY%" "%~dp0conceptghost_maya_worker.py" "%INPUT_JSON%"
exit /b %ERRORLEVEL%

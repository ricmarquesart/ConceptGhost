@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\collect_v035_validation_evidence.ps1" %*
if errorlevel 1 (echo. & echo [FAIL] Evidence collection failed. & pause & exit /b 1)
echo. & echo [PASS] v0.35 evidence ZIP created. & pause

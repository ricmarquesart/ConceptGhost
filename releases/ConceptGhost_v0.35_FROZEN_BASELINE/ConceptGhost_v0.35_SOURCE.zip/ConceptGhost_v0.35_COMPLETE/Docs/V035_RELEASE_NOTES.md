# ConceptGhost v0.35 Frozen Release Notes

- Canonical graph reorganized into nine non-overlapping visual sections.
- Seven embedded workflow guide-note nodes explain the controls artists actually change.
- P7/P8 now have a dedicated green section with explicit usage guidance.
- Official workflow is MoGe-3 only; historical MoGe-2 routing removed from the canonical graph.
- Historical Atlas Relief and provider-native MoGe preview branches removed from the canonical graph; PrimaryMesh remains the modeling authority.
- Master / Light / Medium / Strong / P8 cleanup candidate use native Save 3D Model preview/download endpoints.
- Depth Pro node/runtime path contract fixed to the private embedded Python runtime.
- `INSTALL_ALL.bat` installs the full feature set in one pass using ConceptGhost-owned private runtimes.
- DA3 is retired and not included.
- No older workflow JSON is included.

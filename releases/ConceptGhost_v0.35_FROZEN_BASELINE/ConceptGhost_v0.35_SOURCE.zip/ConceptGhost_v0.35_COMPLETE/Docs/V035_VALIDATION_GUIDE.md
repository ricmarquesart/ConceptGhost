# ConceptGhost v0.35 — Final Validation

## Suggested two-run validation

### Run A — authority/diagnostics
- High Fidelity
- Extra Diagnostics: ON if you want refinement evidence
- P2/P3: ON if you want metric comparison
- P5/P6: ON after Depth Pro is installed
- P7: ON
- P8 Enabled: ON
- P8 Approve Cleanup Candidate: OFF
- Remesh Variants: OFF

This establishes the official PrimaryMesh and all report-only evidence without producing an approved cleanup candidate.

### Run B — derived-output comparison
- Same image/camera/profile
- P7: ON
- P8 Enabled: ON
- Approve Cleanup Candidate: ON
- Remesh Variants: ON

This produces the cleanup candidate plus Light/Medium/Strong remesh variants for visual comparison. None replaces PrimaryMesh automatically.

## What to send for audit
Run `COLLECT_V035_VALIDATION_EVIDENCE.bat` after the completed Maya run and send the resulting evidence ZIP first. It contains manifests/logs/text diagnostics, small diagnostic images, and SHA-256/size inventory for heavy files. If a `.ma`, FBX or GLB is needed, the inventory tells us exactly which one to request.

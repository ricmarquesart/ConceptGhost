# ConceptGhost v0.35 — Workflow Guide

The canonical workflow is deliberately arranged left-to-right with large section boxes and seven in-workflow guide notes.

## Recommended controls

- **Master / Geometry Profile:** `High Fidelity` for final-quality evaluation. `High Fidelity Split Clean` is the stricter topology alternative. `Low Resolution` is for quick tests.
- **Extra Diagnostics:** normally OFF. Turn ON when collecting MoGe refinement evidence; it does not change PrimaryMesh.
- **P2 Atlas Metrology:** enable only when you want ground/base/top pixel measurements. Report-only.
- **P3 Agreement:** enable to compare MoGe native metric evidence against Atlas metrology. Report-only.
- **P5 Depth Pro:** enable after `INSTALL_ALL.bat` or `INSTALL_DEPTHPRO_OPTIONAL.bat`. Report-only independent witness.
- **P6 Consensus:** enable after P3, ideally with P5 enabled. Report-only robust consensus.
- **P7 Geometric Regions:** set `Enabled = ON` to create region metadata and overlay. PrimaryMesh remains unchanged.
- **P8 Local Cleanup:** `Enabled = ON` runs diagnostics. `Approve Cleanup Candidate = ON` additionally creates a derived cleanup GLB. The official PrimaryMesh is never automatically replaced.
- **Generate Remesh Variants:** OFF for the first run; ON produces Light/Medium/Strong derived GLBs. Master remains authoritative.

## Direct previews/downloads

The Master, Remesh Light, Medium, Strong and P8 cleanup candidate terminate in native ComfyUI **Save 3D Model** nodes so they can be previewed/downloaded directly.

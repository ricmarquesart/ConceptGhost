@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\install_all.ps1"
if errorlevel 1 (echo. & echo [FAIL] ConceptGhost v0.35 full installation failed. Review the console above. & pause & exit /b 1)
echo. & echo [PASS] ConceptGhost v0.35 full installation complete. & pause

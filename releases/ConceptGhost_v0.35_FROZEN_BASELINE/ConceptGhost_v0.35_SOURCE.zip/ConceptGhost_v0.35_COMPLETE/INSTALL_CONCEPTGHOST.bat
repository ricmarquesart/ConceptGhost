@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\install_conceptghost.ps1"
if errorlevel 1 (echo. & echo [FAIL] v0.35 core installation failed. & pause & exit /b 1)
echo. & echo [PASS] ConceptGhost v0.35 core installation complete. & pause

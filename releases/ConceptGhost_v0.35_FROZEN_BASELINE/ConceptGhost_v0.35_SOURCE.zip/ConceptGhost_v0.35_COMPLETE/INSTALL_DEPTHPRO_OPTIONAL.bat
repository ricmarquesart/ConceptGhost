@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\install_depthpro_runtime.ps1"
if errorlevel 1 (echo. & echo [FAIL] Depth Pro private runtime not ready. ConceptGhost core is unchanged. & pause & exit /b 1)
echo. & echo [PASS] Depth Pro private runtime ready. & pause

# ConceptGhost v0.35 COMPLETE — Frozen Build

This bundle contains one canonical workflow only: `Workflows/Project/ConceptGhost_Master_v0.35.json`.

## Recommended installation
1. Run `VERIFY_BUNDLE.bat`.
2. Run `INSTALL_ALL.bat` for the complete feature set (core + private MoGe-3 + private Depth Pro).
3. Run `VERIFY_ALL.bat`.
4. Fully restart ComfyUI.
5. Close any restored older ConceptGhost tabs and explicitly open `ConceptGhost_Master_v0.35.json`.

`INSTALL_CONCEPTGHOST.bat` is available when you intentionally want core + MoGe without Depth Pro.

## Where P7/P8 are
They are in the dedicated green **P7–P8 · REGIONS + LOCAL CLEANUP CANDIDATE** section. The guide note inside that section explains both switches.

## Final evidence
After the final full Maya run, run `COLLECT_V035_VALIDATION_EVIDENCE.bat` and send the generated evidence ZIP first.

See `Docs/V035_WORKFLOW_GUIDE.md` and `Docs/V035_VALIDATION_GUIDE.md`.

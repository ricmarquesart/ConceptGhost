param([string]$RunDir="")
$ErrorActionPreference='Stop'
if(-not $RunDir){
  $Root=Join-Path $env:USERPROFILE 'ConceptGhost_Output'
  $Cand=Get-ChildItem $Root -Directory -Recurse -ErrorAction SilentlyContinue|Where-Object{Test-Path (Join-Path $_.FullName 'manifest.json')}|Sort-Object LastWriteTime -Descending|Select-Object -First 1
  if(-not $Cand){throw "No ConceptGhost run found under $Root"}; $RunDir=$Cand.FullName
}
$RunDir=(Resolve-Path $RunDir).Path
$Out=Join-Path $RunDir 'validation\ConceptGhost_v0.35_VALIDATION_EVIDENCE.zip'
$Tmp=Join-Path $env:TEMP ('CGV035_'+[guid]::NewGuid().ToString('N')); New-Item -ItemType Directory -Force $Tmp|Out-Null
$Inventory=@()
Get-ChildItem $RunDir -File -Recurse|Where-Object{$_.FullName -ne $Out}|ForEach-Object{
  $rel=$_.FullName.Substring($RunDir.Length).TrimStart('\')
  $Inventory += [pscustomobject]@{path=$rel;bytes=$_.Length;sha256=(Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
  $copyText=$_.Extension -in @('.json','.log','.txt','.csv','.md')
  $copyImage=($_.Extension -in @('.png','.jpg','.jpeg','.webp')) -and $_.Length -lt 20MB -and ($rel -match 'diagnostic|region|reprojection|preview')
  if($copyText -or $copyImage){$dst=Join-Path $Tmp $rel; New-Item -ItemType Directory -Force (Split-Path $dst)|Out-Null; Copy-Item $_.FullName $dst -Force}
}
$Inventory|ConvertTo-Json -Depth 5|Set-Content (Join-Path $Tmp 'FILE_INVENTORY_SHA256.json') -Encoding UTF8
@{schema='ConceptGhost.ValidationEvidence.v0.35';run_dir=$RunDir;created_at=(Get-Date).ToString('o');note='Text evidence + diagnostic images + hashes; heavy MA/FBX/GLB/NPZ payloads are inventoried but not duplicated'}|ConvertTo-Json|Set-Content (Join-Path $Tmp 'EVIDENCE_INFO.json') -Encoding UTF8
New-Item -ItemType Directory -Force (Split-Path $Out)|Out-Null
if(Test-Path $Out){Remove-Item $Out -Force}
Compress-Archive (Join-Path $Tmp '*') $Out -CompressionLevel Optimal
Remove-Item $Tmp -Recurse -Force
Write-Host "[PASS] Evidence package: $Out" -ForegroundColor Green

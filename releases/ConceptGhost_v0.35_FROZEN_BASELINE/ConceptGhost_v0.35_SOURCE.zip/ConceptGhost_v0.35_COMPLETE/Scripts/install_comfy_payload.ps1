$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Candidates = @(
  (Join-Path $env:LOCALAPPDATA "Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"),
  (Join-Path $env:LOCALAPPDATA "Programs\@comfyorgcomfyui-electron\resources\ComfyUI")
)
$Comfy = $Candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Comfy) { $Comfy = Read-Host "ComfyUI root not found. Enter full path to ComfyUI" }
if (-not (Test-Path $Comfy)) { throw "ComfyUI root not found: $Comfy" }
$CustomNodesRoot=Join-Path $Comfy "custom_nodes"
$Src=Join-Path $Root "custom_nodes\ConceptGhost_Stage68"
$Dst=Join-Path $CustomNodesRoot "ConceptGhost_Stage68"
if(-not(Test-Path (Join-Path $Src "nodes.py"))){throw "ConceptGhost node payload missing"}
# Archive only stale ConceptGhost-owned siblings; never touch unrelated nodes.
$ArchiveBase=Join-Path $env:LOCALAPPDATA "ConceptGhost-ArchivedCustomNodes"
$Stamp=Get-Date -Format "yyyyMMdd_HHmmss"; $ArchiveRun=Join-Path $ArchiveBase $Stamp
if(Test-Path $CustomNodesRoot){
  $Old=Get-ChildItem $CustomNodesRoot -Directory -ErrorAction SilentlyContinue | Where-Object {$_.Name -like "ConceptGhost_Stage68*" -and $_.FullName -ne $Dst}
  foreach($C in $Old){
    $N=Join-Path $C.FullName "nodes.py"; $Owned=$false
    if(Test-Path $N){try{$Owned=(Get-Content $N -Raw)-match "ConceptGhostMasterConfig"}catch{}}
    if($Owned){New-Item -ItemType Directory -Force $ArchiveRun|Out-Null; Move-Item $C.FullName (Join-Path $ArchiveRun $C.Name) -Force}
  }
}
if(Test-Path $Dst){Remove-Item $Dst -Recurse -Force}
New-Item -ItemType Directory -Force $Dst|Out-Null
Copy-Item (Join-Path $Src "*") $Dst -Recurse -Force
Set-Content (Join-Path $Dst "CONCEPTGHOST_VERSION.txt") "ConceptGhost v0.35" -Encoding UTF8
$WfDst=Join-Path $Comfy "user\default\workflows\ConceptGhost"
if(Test-Path $WfDst){Remove-Item $WfDst -Recurse -Force}
New-Item -ItemType Directory -Force $WfDst|Out-Null
$Workflow=Join-Path $WfDst "ConceptGhost_Master_v0.35.json"
Copy-Item (Join-Path $Root "Workflows\Project\ConceptGhost_Master_v0.35.json") $Workflow -Force
$Hash=(Get-FileHash $Workflow -Algorithm SHA256).Hash.ToLowerInvariant()
$Marker=[ordered]@{schema="ConceptGhost.InstallMarker.v0.35";installed_at=(Get-Date).ToString("o");comfy_root=$Comfy;custom_nodes_path=$Dst;canonical_workflow=$Workflow;canonical_workflow_sha256=$Hash;release="ConceptGhost_v0.35_COMPLETE"}
$MarkerPath=Join-Path $env:LOCALAPPDATA "ConceptGhost-v0.35-install.json"; $Marker|ConvertTo-Json -Depth 6|Set-Content $MarkerPath -Encoding UTF8
Write-Host "[PASS] ConceptGhost v0.35 payload installed: $Comfy" -ForegroundColor Green
Write-Host "Open explicitly: $Workflow" -ForegroundColor Cyan
Write-Host "Workflow is reorganized and self-documenting. P7/P8 controls are in their own green section; remesh defaults OFF." -ForegroundColor Yellow

$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $PSScriptRoot
$M=Get-Content (Join-Path $Root 'BUNDLE_MANIFEST.json') -Raw|ConvertFrom-Json
$Fail=$false
foreach($E in $M.files){
  $P=Join-Path $Root ([string]$E.path)
  if(-not(Test-Path $P)){Write-Host "[FAIL] missing $($E.path)" -ForegroundColor Red; $Fail=$true; continue}
  $H=(Get-FileHash $P -Algorithm SHA256).Hash.ToLowerInvariant()
  if($H-ne[string]$E.sha256 -or (Get-Item $P).Length-ne[int64]$E.bytes){Write-Host "[FAIL] hash/size $($E.path)" -ForegroundColor Red; $Fail=$true}
}
if($Fail){exit 1}
Write-Host "[PASS] v0.35 bundle integrity: $(@($M.files).Count) payload files" -ForegroundColor Green

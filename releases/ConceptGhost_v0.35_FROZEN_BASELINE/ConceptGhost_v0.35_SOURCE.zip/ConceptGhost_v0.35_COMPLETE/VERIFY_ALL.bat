@echo off
setlocal
cd /d "%~dp0"
call "%~dp0VERIFY_BUNDLE.bat"
if errorlevel 1 exit /b 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_conceptghost.ps1"
if errorlevel 1 (echo. & echo [FAIL] Core verification failed. & pause & exit /b 1)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_depthpro_runtime.ps1"
if errorlevel 1 (echo. & echo [FAIL] Depth Pro verification failed. & pause & exit /b 1)
echo. & echo [PASS] ConceptGhost v0.35 bundle + core + Depth Pro verified. & pause

@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_bundle.ps1"
if errorlevel 1 (pause & exit /b 1)
pause

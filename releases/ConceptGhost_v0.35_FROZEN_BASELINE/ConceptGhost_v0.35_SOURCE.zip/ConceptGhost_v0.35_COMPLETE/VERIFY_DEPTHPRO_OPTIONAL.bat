@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scripts\verify_depthpro_runtime.ps1"
if errorlevel 1 (echo. & echo [FAIL] Depth Pro runtime verification failed. & pause & exit /b 1)
echo. & echo [PASS] Depth Pro private runtime verification complete. & pause

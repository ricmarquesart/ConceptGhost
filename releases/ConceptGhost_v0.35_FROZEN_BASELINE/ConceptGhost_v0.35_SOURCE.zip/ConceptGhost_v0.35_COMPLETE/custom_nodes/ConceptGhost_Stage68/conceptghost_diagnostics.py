from __future__ import annotations

import json
import math
import re
from typing import Any

import numpy as np


def _safe_report(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, str) and value.strip():
        try:
            obj = json.loads(value)
            return dict(obj) if isinstance(obj, dict) else {}
        except Exception:
            return {}
    return {}


def _point_on_plane_under_camera(camera_position: Any, normal: Any, offset_b: float) -> list[float] | None:
    c = np.asarray(camera_position, dtype=np.float64).reshape(3)
    n = np.asarray(normal, dtype=np.float64).reshape(3)
    norm = float(np.linalg.norm(n))
    if not math.isfinite(norm) or norm <= 1e-12:
        return None
    n = n / norm
    b = float(offset_b) / norm
    p = c - (float(np.dot(n, c) + b)) * n
    return [float(x) for x in p]


def _valid_xyz(value: Any) -> list[float] | None:
    try:
        p = np.asarray(value, dtype=np.float64).reshape(3)
    except Exception:
        return None
    if not np.isfinite(p).all():
        return None
    return [float(x) for x in p]


def _sanitize_region_name(value: str, index: int) -> str:
    raw = re.sub(r"[^A-Za-z0-9_]+", "_", str(value or "")).strip("_").upper()
    if raw:
        if not raw.startswith("CG_"):
            raw = "CG_" + raw
        return raw[:80]
    return f"CG_REGION_{index:03d}"


def normalize_region_specs(regions: Any) -> list[dict[str, Any]]:
    """Normalize optional region metadata; never implies geometry deletion."""
    if not isinstance(regions, (list, tuple)):
        return []
    out = []
    for i, item in enumerate(regions, start=1):
        if not isinstance(item, dict):
            continue
        name = _sanitize_region_name(str(item.get("name") or ""), i)
        members = item.get("maya_members") if isinstance(item.get("maya_members"), list) else []
        out.append({
            "name": name,
            "label": str(item.get("label") or name),
            "source": str(item.get("source") or "metadata"),
            "maya_members": [str(x) for x in members],
            "policy": "metadata_selection_only_no_geometry_deletion",
        })
    return out


def build_maya_metric_diagnostics_spec(
    scene_bundle: dict[str, Any],
    atlas_report: Any = None,
    agreement_report: Any = None,
    consensus_report: Any = None,
    regions: Any = None,
) -> dict[str, Any]:
    atlas = _safe_report(atlas_report)
    agreement = _safe_report(agreement_report)
    consensus = _safe_report(consensus_report)
    camera = dict(scene_bundle.get("camera") or {})
    extr = dict(camera.get("extrinsics") or {})
    camera_pos = _valid_xyz(extr.get("camera_position"))

    helpers: list[dict[str, Any]] = []
    labels: dict[str, Any] = {}
    ground_spec = None

    ground = dict(atlas.get("ground") or {})
    model = dict(ground.get("model") or {})
    if model.get("status") == "PASS":
        normal = _valid_xyz(model.get("normal_world"))
        offset = model.get("offset_b")
        if normal is not None and offset is not None:
            anchor = _point_on_plane_under_camera(camera_pos or [0, 0, 0], normal, float(offset))
            ground_spec = {
                "name": "CG_METRIC_GROUND_PLANE",
                "normal_world": normal,
                "offset_b": float(offset),
                "anchor_world": anchor,
                "confidence": float(model.get("confidence") or 0.0),
                "selected_model": ground.get("selected"),
                "policy": "diagnostic_visual_only",
            }
            if camera_pos and anchor:
                helpers += [
                    {"kind": "locator", "name": "CG_METRIC_CAMERA_HEIGHT_TOP", "position": camera_pos},
                    {"kind": "locator", "name": "CG_METRIC_CAMERA_HEIGHT_BASE", "position": anchor},
                    {"kind": "line", "name": "CG_METRIC_CAMERA_HEIGHT", "start": anchor, "end": camera_pos},
                ]
                labels["camera_height_m"] = float(np.linalg.norm(np.asarray(camera_pos) - np.asarray(anchor)))

    base = dict(atlas.get("base") or {})
    base_world = _valid_xyz(base.get("world_xyz"))
    if base_world is not None:
        helpers.append({"kind": "locator", "name": "CG_METRIC_TARGET_BASE", "position": base_world})
        if camera_pos is not None:
            helpers.append({"kind": "line", "name": "CG_METRIC_DISTANCE", "start": camera_pos, "end": base_world})
        labels["target_camera_distance_m"] = base.get("camera_distance_m")
        labels["target_ground_distance_m"] = base.get("ground_distance_m")

    height = dict(atlas.get("height") or {})
    top_world = _valid_xyz(height.get("vertical_point_world"))
    if top_world is not None and base_world is not None:
        helpers.append({"kind": "locator", "name": "CG_METRIC_TARGET_TOP", "position": top_world})
        helpers.append({"kind": "line", "name": "CG_METRIC_HEIGHT", "start": base_world, "end": top_world})
        labels["estimated_height_m"] = height.get("estimated_height_m")
        labels["height_residual_m"] = height.get("closest_approach_residual_m")

    enabled = bool(
        helpers
        or agreement.get("status") not in {None, "", "DISABLED"}
        or consensus.get("status") not in {None, "", "DISABLED"}
    )
    agreement_state = agreement.get("overall_state") or agreement.get("status")
    region_specs = normalize_region_specs(regions)
    return {
        "schema": "ConceptGhost.MayaMetricDiagnosticsSpec.v0.33",
        "status": "READY" if enabled else "DISABLED",
        "policy": "diagnostic_metadata_only_no_geometry_deletion_no_camera_or_mesh_movement",
        "group": "CG_METRIC_DIAGNOSTICS",
        "regions_group": "CG_REGIONS",
        "ground_plane": ground_spec,
        "helpers": helpers,
        "labels": labels,
        "agreement": {
            "state": agreement_state,
            "target_label": agreement.get("target_label"),
            "target_camera_distance_agreement": agreement.get("target_camera_distance_agreement"),
            "camera_height_agreement": agreement.get("camera_height_agreement"),
            "global_scale_agreement": agreement.get("global_scale_agreement"),
            "automatic_correction": False,
        },
        "consensus": {
            "status": consensus.get("status"),
            "consensus_distance_m": consensus.get("consensus_distance_m"),
            "mad_m": consensus.get("mad_m"),
            "agreement_group": consensus.get("agreement_group"),
            "source_states": consensus.get("source_states"),
            "automatic_correction": False,
        },
        "regions": region_specs,
        "region_policy": "region_is_metadata_selection_not_geometry_deletion",
    }

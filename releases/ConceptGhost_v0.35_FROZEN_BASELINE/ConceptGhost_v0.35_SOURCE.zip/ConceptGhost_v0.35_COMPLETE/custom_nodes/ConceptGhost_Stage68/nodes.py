from __future__ import annotations

import json
import math
import os
import struct
import subprocess
import sys
import shutil
import copy
import uuid
from pathlib import Path
from typing import Any

import numpy as np

try:
    from .conceptghost_contracts import (
        CANONICAL_COORDINATES, PRESET_PARAMETERS, build_run_config, build_geometry_profile,
        assert_profile_contract, assert_maya_manifest_contract, assert_final_manifest_contract,
        derive_run_status, json_safe,
    )
    from .conceptghost_geometry import (
        _first_rgb, _to_numpy, atlas_metric_scale_registration, camera_bundle_from_atlas_solve, canonicalize,
        geometry_health, reprojection_report,
    )
    from .conceptghost_io import (
        copy_preview_ply, create_run_download_archive, link_or_copy_transport, make_run_folder, sanitize_scene_name, sha256_file, write_json,
        write_ply_binary, write_usda_points,
    )
    from .conceptghost_variants import export_hf_variants, export_primary_and_remesh_variants, build_hf_split_clean
    from .conceptghost_metric import summarize_moge_native_metric, point_distance_m, regional_metric_summary
    from .conceptghost_metrology import atlas_architectural_metrology
    from .conceptghost_metric_agreement import moge_atlas_metric_agreement
    from .conceptghost_diagnostics import build_maya_metric_diagnostics_spec
    from .conceptghost_metric_consensus import build_metric_consensus
    from .conceptghost_regions import analyze_primary_mesh_regions, colorize_region_overlay
    from .conceptghost_local_cleanup import run_local_cleanup_from_run
except ImportError:  # direct-module test/build compatibility
    from conceptghost_contracts import (
        CANONICAL_COORDINATES, PRESET_PARAMETERS, build_run_config, build_geometry_profile,
        assert_profile_contract, assert_maya_manifest_contract, assert_final_manifest_contract,
        derive_run_status, json_safe,
    )
    from conceptghost_geometry import (
        _first_rgb, _to_numpy, atlas_metric_scale_registration, camera_bundle_from_atlas_solve, canonicalize,
        geometry_health, reprojection_report,
    )
    from conceptghost_io import (
        copy_preview_ply, create_run_download_archive, link_or_copy_transport, make_run_folder, sanitize_scene_name, sha256_file, write_json,
        write_ply_binary, write_usda_points,
    )
    from conceptghost_variants import export_hf_variants, export_primary_and_remesh_variants, build_hf_split_clean
    from conceptghost_metric import summarize_moge_native_metric, point_distance_m, regional_metric_summary
    from conceptghost_metrology import atlas_architectural_metrology
    from conceptghost_metric_agreement import moge_atlas_metric_agreement
    from conceptghost_diagnostics import build_maya_metric_diagnostics_spec
    from conceptghost_metric_consensus import build_metric_consensus
    from conceptghost_regions import analyze_primary_mesh_regions, colorize_region_overlay
    from conceptghost_local_cleanup import run_local_cleanup_from_run


try:
    import torch
except Exception:  # tests/build environment can still import the module
    torch = None

try:
    from PIL import Image, ImageDraw
except Exception:
    Image = None
    ImageDraw = None

try:
    import folder_paths
except Exception:
    folder_paths = None

try:
    from comfy_api.latest import Types as ComfyTypes
except Exception:
    ComfyTypes = None

try:
    from comfy_execution.graph_utils import ExecutionBlocker
except Exception:
    class ExecutionBlocker:  # lightweight test/build fallback
        def __init__(self, message=None):
            self.message = message


CG_CAMERA_BUNDLE = "CG_CAMERA_BUNDLE"
CG_GEOMETRY_EVIDENCE = "CG_GEOMETRY_EVIDENCE"
CG_SCENE_BUNDLE = "CG_SCENE_BUNDLE"
CG_DEPTHPRO_EVIDENCE = "CG_DEPTHPRO_EVIDENCE"


def _safe_text(data: Any) -> str:
    return json.dumps(json_safe(data), indent=2, sort_keys=True, ensure_ascii=False)


def _conceptghost_depthpro_runtime_root() -> Path:
    configured = os.environ.get("CONCEPTGHOST_DEPTHPRO_RUNTIME")
    if configured:
        return Path(os.path.expandvars(os.path.expanduser(configured))).resolve()
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        raise RuntimeError("LOCALAPPDATA is unavailable; cannot locate the isolated ConceptGhost Depth Pro runtime")
    return (Path(local) / "ConceptGhost-DepthProRuntime-v1").resolve()


def _conceptghost_moge3_runtime_root() -> Path:
    """Locate the ConceptGhost-owned isolated MoGe-3 runtime."""
    configured = os.environ.get("CONCEPTGHOST_MOGE_RUNTIME")
    if configured:
        return Path(os.path.expandvars(os.path.expanduser(configured))).resolve()
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        raise RuntimeError("LOCALAPPDATA is unavailable; cannot locate the isolated ConceptGhost MoGe-3 runtime")
    return (Path(local) / "ConceptGhost-MoGeRuntime-v1").resolve()


def _as_worker_tensor(array: np.ndarray, *, boolean: bool = False):
    """Convert isolated-worker NumPy output to the ComfyUI-side tensor contract."""
    arr = np.asarray(array)
    if torch is None:
        return arr.astype(bool, copy=False) if boolean else arr.astype(np.float32, copy=False)
    if boolean:
        return torch.from_numpy(arr.astype(np.bool_, copy=False))
    return torch.from_numpy(arr.astype(np.float32, copy=False))


def _stage0607_log(run_dir: str | Path, message: str) -> None:
    """Persistent progress breadcrumb for the long Stage 06-07 output node."""
    line = f"[ConceptGhost 06-07] {message}"
    print(line, flush=True)
    try:
        path = Path(run_dir) / "logs" / "stage06_07_progress.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def _numpy_image_to_tensor(img: np.ndarray):
    arr = np.asarray(img, dtype=np.float32)
    if arr.max(initial=0.0) > 1.0:
        arr = arr / 255.0
    if arr.ndim == 3:
        arr = arr[None, ...]
    if torch is None:
        return arr
    return torch.from_numpy(arr.copy()).float()


def _make_overlay(source_image: Any, canonical: dict[str, Any], report: dict[str, Any]):
    src = _first_rgb(source_image)
    h, w = src.shape[:2]
    base = np.clip(np.rint(src * 255.0), 0, 255).astype(np.uint8)
    if Image is None:
        return _numpy_image_to_tensor(base)
    im = Image.fromarray(base, mode="RGB")
    draw = ImageDraw.Draw(im)
    uv = np.asarray(canonical.get("source_uv", []), dtype=np.float32)
    if len(uv):
        step = max(1, len(uv) // 3000)
        for u, v in uv[::step]:
            x, y = float(u), float(v)
            if 0 <= x < w and 0 <= y < h:
                draw.point((x, y), fill=(0, 255, 0))
    label = f"CG reprojection {'PASS' if report.get('pass') else 'CHECK'} RMSE={report.get('rmse_px')}"
    draw.rectangle((0,0,min(w,560),24), fill=(0,0,0))
    draw.text((5,5), label, fill=(255,255,255))
    return _numpy_image_to_tensor(np.asarray(im).astype(np.float32) / 255.0)


class ConceptGhostMasterConfig:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "scene_name": ("STRING", {"default": "concept_scene"}),
            "preset": (["Max Reference", "Balanced", "Fast Test"], {"default": "Max Reference"}),
            "camera_mode": (["Auto", "Atlas Learned", "Atlas VP"], {"default": "Auto"}),
            "moge_version": (["MoGe-3"], {"default": "MoGe-3"}),
            "geometry_profile": (["Low Resolution", "High Fidelity", "High Fidelity Split Clean"], {"default": "High Fidelity"}),
            "extra_diagnostics": ("BOOLEAN", {"default": False}),
            "output_root": ("STRING", {"default": r"%USERPROFILE%\ConceptGhost_Output"}),
        }}
    RETURN_TYPES=("STRING","STRING","STRING","STRING","BOOLEAN","STRING","STRING")
    RETURN_NAMES=("preset","camera_mode","moge_version","geometry_profile","extra_diagnostics","scene_name","output_root")
    FUNCTION="build"; CATEGORY="ConceptGhost/01 Master"
    def build(self,scene_name,preset,camera_mode,moge_version,geometry_profile,extra_diagnostics,output_root):
        build_run_config(
            source_name=scene_name, preset=preset, camera_mode=camera_mode,
            moge_version=moge_version, geometry_profile=geometry_profile,
            extra_diagnostics=extra_diagnostics,
        )
        return (preset,camera_mode,moge_version,geometry_profile,bool(extra_diagnostics),scene_name,output_root)





class ConceptGhostCameraRouter:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "camera_mode": ("STRING", {"forceInput": True}),
                "learned_solve": ("ATLAS_SOLVE", {"lazy": True}),
                "vp_solve": ("ATLAS_SOLVE", {"lazy": True}),
            }
        }

    RETURN_TYPES = (CG_CAMERA_BUNDLE, "STRING", "FLOAT")
    RETURN_NAMES = ("camera_bundle", "camera_report", "atlas_fov_x_deg")
    FUNCTION = "route"
    CATEGORY = "ConceptGhost/02 Camera"

    def check_lazy_status(self, camera_mode, learned_solve=None, vp_solve=None):
        if camera_mode == "Atlas Learned":
            return ["learned_solve"] if learned_solve is None else []
        if camera_mode == "Atlas VP":
            return ["vp_solve"] if vp_solve is None else []
        if learned_solve is None:
            return ["learned_solve"]
        learned = camera_bundle_from_atlas_solve(learned_solve, requested_mode="Auto", final_solver="Atlas Learned")
        if learned.get("valid"):
            return []
        return ["vp_solve"] if vp_solve is None else []

    def route(self, camera_mode, learned_solve=None, vp_solve=None):
        if camera_mode == "Atlas Learned":
            bundle = camera_bundle_from_atlas_solve(learned_solve, requested_mode=camera_mode, final_solver="Atlas Learned")
        elif camera_mode == "Atlas VP":
            bundle = camera_bundle_from_atlas_solve(vp_solve, requested_mode=camera_mode, final_solver="Atlas VP")
        else:
            learned = camera_bundle_from_atlas_solve(learned_solve, requested_mode="Auto", final_solver="Atlas Learned")
            if learned.get("valid"):
                bundle = learned
            else:
                bundle = camera_bundle_from_atlas_solve(
                    vp_solve,
                    requested_mode="Auto",
                    final_solver="Atlas VP",
                    fallback_attempted=True,
                    fallback_reason="Atlas Learned failed vertical-slice structural camera gate",
                )
        report = {
            "requested_mode": camera_mode,
            "final_solver": bundle.get("provenance", {}).get("final_solver"),
            "valid": bundle.get("valid", False),
            "quality": bundle.get("quality", {}),
            "policy": "Learned first; VP requested only if Learned fails structural gate",
        }
        return (bundle, _safe_text(report), float(bundle.get("horizontal_fov_deg", 0.0) or 0.0))


class ConceptGhostGeometryProfile:
    """Resolve the two user-facing profiles into one authoritative contract.

    After this node, downstream stages must never infer or default the profile
    again. Missing or contradictory profile metadata is a fail-closed error.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "geometry_profile": ("STRING", {"forceInput": True}),
                "preset": ("STRING", {"forceInput": True}),
                "moge_version": ("STRING", {"forceInput": True}),
            },
            "optional": {
                "extra_diagnostics": ("BOOLEAN", {"default": False, "forceInput": True}),
            },
        }

    RETURN_TYPES = ("CG_GEOMETRY_PROFILE", "STRING")
    RETURN_NAMES = ("profile_config", "profile_report")
    FUNCTION = "resolve"
    CATEGORY = "ConceptGhost/03 Geometry"

    def resolve(self, geometry_profile, preset, moge_version, extra_diagnostics=False):
        config = build_geometry_profile(str(geometry_profile), str(preset), str(moge_version))
        # Diagnostic-only extension: does not alter the selected geometry profile,
        # model, final point map or mesher. It only asks MoGe to return intermediate
        # refinement evidence in addition to the exact same final output.
        config["diagnostic_return_per_step"] = bool(extra_diagnostics)
        assert_profile_contract(config, stage="MASTER_PROFILE_RESOLVER", expected_profile=str(geometry_profile))
        return (config, _safe_text(config))

class ConceptGhostMoGe3Inference:
    """Run MoGe-3 out-of-process in the private ConceptGhost runtime.

    The ComfyUI Python/Torch environment is never used to import MoGe-3 itself.
    Only the resulting arrays cross the process boundary and are wrapped as the
    same MOGE_GEOMETRY contract consumed by the existing ConceptGhost pipeline.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "image": ("IMAGE",),
            "preset": ("STRING", {"forceInput": True}),
            "atlas_fov_x_deg": ("FLOAT", {"forceInput": True}),
            "profile_config": ("CG_GEOMETRY_PROFILE",),
        }}

    RETURN_TYPES = ("MOGE_GEOMETRY", "STRING")
    RETURN_NAMES = ("moge_geometry", "report")
    FUNCTION = "infer"
    CATEGORY = "ConceptGhost/03 Geometry"

    def infer(self, image, preset, atlas_fov_x_deg, profile_config):
        runtime = _conceptghost_moge3_runtime_root()
        python_exe = runtime / "python" / "python.exe"
        worker = runtime / "worker" / "moge_worker.py"
        ready = runtime / "READY.json"
        missing = [str(p) for p in (python_exe, worker, ready) if not p.is_file()]
        if missing:
            raise RuntimeError(
                "MoGe-3 private runtime is not ready. Run INSTALL_MOGE3_RUNTIME.bat and "
                "VERIFY_MOGE3_RUNTIME.bat first. Missing: " + "; ".join(missing)
            )

        profile = assert_profile_contract(dict(profile_config or {}), stage="MOGE3_INFERENCE")
        if profile.get("moge_version") != "MoGe-3":
            raise RuntimeError("[MOGE3_INFERENCE] received a non-MoGe-3 profile contract")
        profile_name = str(profile["selected_profile"])
        model_name = str(profile["model"])
        refine_steps = int(profile["refine_steps"])
        resolution_level = int(profile["resolution_level"])
        num_tokens = profile.get("num_tokens")
        use_fp16 = bool(profile["use_fp16"])
        return_per_step = bool(profile["return_per_step"] or profile.get("diagnostic_return_per_step", False))
        fov = float(atlas_fov_x_deg or 0.0)
        fov_request = fov if fov > 0.0 else None

        jobs_root = runtime / "jobs"
        jobs_root.mkdir(parents=True, exist_ok=True)
        job_dir = jobs_root / ("comfy_" + uuid.uuid4().hex)
        job_dir.mkdir(parents=True, exist_ok=False)
        image_path = job_dir / "input.png"
        request_path = job_dir / "request.json"
        result_npz = job_dir / "result.npz"
        result_json = job_dir / "result.json"
        process_log = job_dir / "worker.log"

        src = _first_rgb(image)
        rgb8 = np.clip(np.rint(src * 255.0), 0, 255).astype(np.uint8)
        if Image is None:
            raise RuntimeError("Pillow is required by ConceptGhost to hand an image to the isolated MoGe-3 worker")
        Image.fromarray(rgb8, mode="RGB").save(image_path)

        request = {
            "schema": "ConceptGhost.MoGe3WorkerRequest.v1",
            "runtime_root": str(runtime),
            "image": str(image_path),
            "result_npz": str(result_npz),
            "result_json": str(result_json),
            "model": model_name,
            "resolution_level": resolution_level,
            "num_tokens": num_tokens,
            "refine_steps": refine_steps,
            "return_per_step": return_per_step,
            "use_fp16": use_fp16,
            "precision_policy": profile["precision_policy"],
            "fov_x": fov_request,
            "profile": profile_name,
            "selected_profile": profile_name,
            "effective_profile": profile_name,
            "force_projection": bool(profile["force_projection"]),
            "apply_mask": bool(profile["apply_mask"]),
        }
        request_path.write_text(json.dumps(request, indent=2), encoding="utf-8")

        cmd = [str(python_exe), str(worker), "--request", str(request_path)]
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        success = False
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(runtime),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=60 * 60,
                creationflags=creationflags,
                check=False,
            )
            process_log.write_text(proc.stdout or "", encoding="utf-8")
            if proc.returncode != 0:
                tail = (proc.stdout or "")[-6000:]
                raise RuntimeError(f"MoGe-3 worker failed with exit code {proc.returncode}.\n{tail}")
            if not result_npz.is_file() or not result_json.is_file():
                raise RuntimeError("MoGe-3 worker returned success but did not produce its result files")

            worker_report = json.loads(result_json.read_text(encoding="utf-8"))
            expected_worker = {
                "schema": "ConceptGhost.MoGe3WorkerResult.v1",
                "status": "PASS",
                "model_requested": model_name,
                "model_loaded": model_name,
                "selected_profile": profile_name,
                "effective_profile": profile_name,
                "refine_steps": refine_steps,
                "resolution_level": resolution_level,
                "force_projection": bool(profile["force_projection"]),
                "apply_mask": bool(profile["apply_mask"]),
                "use_fp16": use_fp16,
                "precision_policy": profile["precision_policy"],
            }
            for key, expected in expected_worker.items():
                if worker_report.get(key) != expected:
                    raise RuntimeError(
                        f"[MOGE3_INFERENCE] worker result {key} mismatch: "
                        f"{worker_report.get(key)!r} != {expected!r}"
                    )
            with np.load(result_npz, allow_pickle=False) as data:
                arrays = {name: np.asarray(data[name]) for name in data.files}
            if "points" not in arrays or "mask" not in arrays:
                raise RuntimeError(f"MoGe-3 result is missing required arrays: {sorted(arrays)}")

            points = arrays["points"]
            if points.ndim == 3:
                points = points[None, ...]
            if points.ndim != 4 or points.shape[-1] != 3:
                raise RuntimeError(f"MoGe-3 points must resolve to BxHxWx3, got {points.shape}")

            points_tensor = _as_worker_tensor(points)
            geometry = {
                "points": points_tensor,
                # A1: semantic immutable alias. This is the exact MoGe-native metric
                # point map before ConceptGhost/Atlas registration. It intentionally
                # references the same tensor instead of duplicating a multi-million
                # point payload in RAM. Downstream code must treat it as read-only.
                "points_metric_native": points_tensor,
                "image": image.cpu() if hasattr(image, "cpu") else image,
                "conceptghost_moge_version": "MoGe-3",
                "conceptghost_model": str(worker_report["model_loaded"]),
                "conceptghost_geometry_profile": profile_name,
                "conceptghost_profile_config": dict(profile),
                "conceptghost_worker_report": worker_report,
            }
            if "depth" in arrays:
                depth = arrays["depth"]
                if depth.ndim == 2:
                    depth = depth[None, ...]
                depth_tensor = _as_worker_tensor(depth)
                geometry["depth"] = depth_tensor
                geometry["depth_metric_native"] = depth_tensor
            mask = arrays["mask"]
            if mask.ndim == 2:
                mask = mask[None, ...]
            mask_tensor = _as_worker_tensor(mask, boolean=True)
            geometry["mask"] = mask_tensor
            geometry["mask_native"] = mask_tensor
            if "normal" in arrays:
                normal = arrays["normal"]
                if normal.ndim == 3:
                    normal = normal[None, ...]
                normal_tensor = _as_worker_tensor(normal)
                geometry["normal"] = normal_tensor
                geometry["normal_native"] = normal_tensor
            if "intrinsics" in arrays:
                intr = arrays["intrinsics"]
                if intr.ndim == 2:
                    intr = intr[None, ...]
                intr_tensor = _as_worker_tensor(intr)
                geometry["intrinsics"] = intr_tensor
                geometry["intrinsics_native"] = intr_tensor

            # Optional A1.7 refinement evidence. These arrays exist only when the
            # authoritative profile explicitly requests return_per_step. Keep the
            # worker key names so export can persist them once in evidence.npz.
            refinement_array_names = []
            for name, value in arrays.items():
                if name.startswith(("points_per_step_", "depth_per_step_", "intrinsics_per_step_")):
                    geometry[name] = _as_worker_tensor(value)
                    refinement_array_names.append(name)

            report = {
                "engine": "MoGe",
                "version": "MoGe-3",
                "model": geometry["conceptghost_model"],
                "runtime": str(runtime),
                "resolution_level": resolution_level,
                "refine_steps": refine_steps,
                "num_tokens": num_tokens,
                "geometry_profile": profile_name,
                "atlas_fov_x_deg": fov_request,
                "points_shape": list(points.shape),
                "native_metric_aliases": ["points_metric_native", "depth_metric_native", "normal_native", "intrinsics_native", "mask_native"],
                "refinement_array_names": sorted(refinement_array_names),
                "worker": worker_report,
            }
            success = True
            return (geometry, _safe_text(report))
        except Exception:
            # Keep the complete failed job for diagnosis.
            raise
        finally:
            # Successful runs only need their compact report; large transfer files are transient.
            if success and result_json.is_file():
                try:
                    last_report = runtime / "LAST_COMFY_RUN.json"
                    shutil.copy2(result_json, last_report)
                    if os.environ.get("CONCEPTGHOST_KEEP_MOGE3_JOBS", "0") != "1":
                        shutil.rmtree(job_dir, ignore_errors=True)
                except Exception:
                    pass


class ConceptGhostDepthProEvidence:
    """Optional independent metric witness in a private Depth Pro runtime."""

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "image": ("IMAGE",),
            "camera_bundle": (CG_CAMERA_BUNDLE,),
            "enabled": ("BOOLEAN", {"default": False}),
        }}

    RETURN_TYPES = (CG_DEPTHPRO_EVIDENCE, "STRING")
    RETURN_NAMES = ("depthpro_evidence", "depthpro_report")
    FUNCTION = "infer"
    CATEGORY = "ConceptGhost/04 Metrology"
    OUTPUT_NODE = True

    def infer(self, image, camera_bundle, enabled):
        if not bool(enabled):
            evidence = {
                "schema": "ConceptGhost.DepthProEvidence.v0.33",
                "status": "DISABLED",
                "role": "independent_metric_witness_report_only",
                "geometry_authority": False,
                "camera_authority": False,
                "automatic_correction": False,
            }
            return {
                "ui": {"text": ["Depth Pro witness: DISABLED", "REPORT ONLY · core ConceptGhost unaffected"]},
                "result": (evidence, _safe_text(evidence)),
            }

        runtime = _conceptghost_depthpro_runtime_root()
        python_exe = runtime / "python" / "python.exe"
        worker = runtime / "worker" / "depthpro_worker.py"
        ready = runtime / "READY.json"
        missing = [str(p) for p in (python_exe, worker, ready) if not p.is_file()]
        if missing:
            raise RuntimeError(
                "Depth Pro private runtime is not ready. Run INSTALL_ALL.bat or INSTALL_DEPTHPRO_OPTIONAL.bat first. Missing: "
                + "; ".join(missing)
            )

        jobs_root = runtime / "jobs"
        jobs_root.mkdir(parents=True, exist_ok=True)
        job_dir = jobs_root / ("comfy_" + uuid.uuid4().hex)
        job_dir.mkdir(parents=True, exist_ok=False)
        image_path = job_dir / "input.png"
        request_path = job_dir / "request.json"
        result_npz = job_dir / "result.npz"
        result_json = job_dir / "result.json"
        process_log = job_dir / "worker.log"

        if Image is None:
            raise RuntimeError("Pillow is required to hand an image to the isolated Depth Pro worker")
        src = _first_rgb(image)
        Image.fromarray(np.clip(np.rint(src * 255.0), 0, 255).astype(np.uint8), mode="RGB").save(image_path)
        intr = dict(camera_bundle.get("intrinsics") or {})
        atlas_focal = float(intr.get("fx_px") or 0.0)
        request = {
            "schema": "ConceptGhost.DepthProWorkerRequest.v0.33",
            "runtime_root": str(runtime),
            "image": str(image_path),
            "result_npz": str(result_npz),
            "result_json": str(result_json),
            "atlas_focal_px": atlas_focal if atlas_focal > 0 else None,
            "source_width": int(camera_bundle.get("image_width") or 0),
            "source_height": int(camera_bundle.get("image_height") or 0),
            "role": "independent_metric_witness_report_only",
        }
        request_path.write_text(json.dumps(request, indent=2), encoding="utf-8")
        cmd = [str(python_exe), str(worker), "--request", str(request_path)]
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        success = False
        try:
            proc = subprocess.run(
                cmd, cwd=str(runtime), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", timeout=60 * 60,
                creationflags=creationflags, check=False,
            )
            process_log.write_text(proc.stdout or "", encoding="utf-8")
            if proc.returncode != 0:
                raise RuntimeError(f"Depth Pro worker failed with exit code {proc.returncode}.\n{(proc.stdout or '')[-6000:]}")
            if not result_npz.is_file() or not result_json.is_file():
                raise RuntimeError("Depth Pro worker returned success without result files")
            report = json.loads(result_json.read_text(encoding="utf-8"))
            if report.get("schema") != "ConceptGhost.DepthProWorkerResult.v0.33" or report.get("status") != "PASS":
                raise RuntimeError(f"Depth Pro worker result contract failed: {report}")
            with np.load(result_npz, allow_pickle=False) as data:
                arrays = {name: np.asarray(data[name]) for name in data.files}
            depth_ind = arrays.get("depth_independent_m")
            if depth_ind is None or depth_ind.ndim != 2:
                raise RuntimeError(f"Depth Pro missing independent metric depth: {None if depth_ind is None else depth_ind.shape}")
            evidence = {
                "schema": "ConceptGhost.DepthProEvidence.v0.33",
                "status": "PASS",
                "role": "independent_metric_witness_report_only",
                "depth_independent_m": _as_worker_tensor(depth_ind[None, ...]),
                "depth_atlas_focal_m": _as_worker_tensor(arrays["depth_atlas_focal_m"][None, ...]) if arrays.get("depth_atlas_focal_m") is not None and arrays["depth_atlas_focal_m"].size else None,
                "valid_mask": _as_worker_tensor(arrays.get("valid_mask", np.isfinite(depth_ind) & (depth_ind > 0))[None, ...], boolean=True),
                "predicted_focal_px": float(report.get("predicted_focal_px") or 0.0),
                "atlas_focal_px": report.get("atlas_focal_px"),
                "source_width": int(camera_bundle.get("image_width") or src.shape[1]),
                "source_height": int(camera_bundle.get("image_height") or src.shape[0]),
                "primary_independence": str(report.get("primary_independence") or "Depth Pro independent focal"),
                "upstream_commit": str(report.get("upstream_commit") or ""),
                "worker_report": report,
                "geometry_authority": False,
                "camera_authority": False,
                "automatic_correction": False,
            }
            success = True
            ui = {"text": [
                "Depth Pro witness: PASS",
                f"Predicted focal: {evidence['predicted_focal_px']:.2f}px",
                "Primary witness uses Depth Pro inferred focal (independent from Atlas focal)",
                "REPORT ONLY · no mesh/camera movement",
            ]}
            return {"ui": ui, "result": (evidence, _safe_text({k:v for k,v in evidence.items() if k not in {'depth_independent_m','depth_atlas_focal_m','valid_mask'}}))}
        finally:
            if success and os.environ.get("CONCEPTGHOST_KEEP_DEPTHPRO_JOBS", "0") != "1":
                shutil.rmtree(job_dir, ignore_errors=True)


class ConceptGhostMoGeVersionRouter:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "moge_version": ("STRING", {"forceInput": True}),
            "moge2_geometry": ("MOGE_GEOMETRY", {"lazy": True}),
            "moge3_geometry": ("MOGE_GEOMETRY", {"lazy": True}),
        }}

    RETURN_TYPES = ("MOGE_GEOMETRY", "STRING")
    RETURN_NAMES = ("moge_geometry", "router_report")
    FUNCTION = "route"
    CATEGORY = "ConceptGhost/03 Geometry"

    def check_lazy_status(self, moge_version, moge2_geometry=None, moge3_geometry=None):
        if moge_version == "MoGe-3":
            return ["moge3_geometry"] if moge3_geometry is None else []
        return ["moge2_geometry"] if moge2_geometry is None else []

    def route(self, moge_version, moge2_geometry=None, moge3_geometry=None):
        if moge_version == "MoGe-3":
            selected = moge3_geometry
        elif moge_version == "MoGe-2":
            selected = moge2_geometry
        else:
            raise RuntimeError(f"Unknown MoGe version requested: {moge_version}")
        if selected is None:
            raise RuntimeError(f"Requested {moge_version} did not produce MOGE_GEOMETRY")
        selected = dict(selected)
        if moge_version == "MoGe-3":
            if selected.get("conceptghost_moge_version") != "MoGe-3":
                raise RuntimeError("[MOGE_VERSION_ROUTER] MoGe-3 output is missing explicit version identity")
            if not selected.get("conceptghost_model"):
                raise RuntimeError("[MOGE_VERSION_ROUTER] MoGe-3 output is missing explicit model identity")
        else:
            selected.setdefault("conceptghost_moge_version", "MoGe-2")
            selected.setdefault("conceptghost_model", "moge_2_vitl_normal_fp16.safetensors")
        report = {
            "selected": moge_version,
            "model": selected.get("conceptghost_model"),
            "lazy_selection": True,
            "fallback": False,
        }
        return (selected, _safe_text(report))


class ConceptGhostMoGeEvidence:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "moge_geometry": ("MOGE_GEOMETRY",),
                "source_image": ("IMAGE",),
                "preset": ("STRING", {"forceInput": True}),
                "atlas_fov_x_deg": ("FLOAT", {"forceInput": True}),
                "profile_config": ("CG_GEOMETRY_PROFILE",),
            }
        }
    RETURN_TYPES = (CG_GEOMETRY_EVIDENCE, "STRING")
    RETURN_NAMES = ("evidence", "report")
    FUNCTION = "build"
    CATEGORY = "ConceptGhost/03 Geometry"

    def build(self, moge_geometry, source_image, preset, atlas_fov_x_deg, profile_config):
        profile = assert_profile_contract(dict(profile_config or {}), stage="MOGE_EVIDENCE")
        geometry = dict(moge_geometry or {})
        if "conceptghost_moge_version" not in geometry or "conceptghost_model" not in geometry:
            raise RuntimeError("[MOGE_EVIDENCE] selected MoGe output is missing explicit version/model identity")
        moge_version = str(geometry["conceptghost_moge_version"])
        actual_model = str(geometry["conceptghost_model"])
        selected = str(profile["selected_profile"])
        if moge_version != profile["moge_version"]:
            raise RuntimeError(f"[MOGE_EVIDENCE] version mismatch: {moge_version!r} != {profile['moge_version']!r}")
        if actual_model != profile["model"]:
            raise RuntimeError(f"[MOGE_EVIDENCE] model mismatch: {actual_model!r} != {profile['model']!r}")

        if moge_version == "MoGe-3":
            if "conceptghost_profile_config" not in geometry or "conceptghost_worker_report" not in geometry:
                raise RuntimeError("[MOGE_EVIDENCE] MoGe-3 output is missing worker profile/report provenance")
            worker_profile = dict(geometry["conceptghost_profile_config"] or {})
            worker_report = dict(geometry["conceptghost_worker_report"] or {})
            if worker_profile != profile:
                raise RuntimeError("[MOGE_EVIDENCE] worker profile_config differs from authoritative profile_config")
            required_worker = {
                "schema": "ConceptGhost.MoGe3WorkerResult.v1",
                "status": "PASS",
                "model_loaded": profile["model"],
                "selected_profile": selected,
                "effective_profile": selected,
                "resolution_level": int(profile["resolution_level"]),
                "refine_steps": int(profile["refine_steps"]),
                "force_projection": bool(profile["force_projection"]),
                "apply_mask": bool(profile["apply_mask"]),
                "use_fp16": bool(profile["use_fp16"]),
                "precision_policy": profile["precision_policy"],
            }
            for key, expected in required_worker.items():
                if worker_report.get(key) != expected:
                    raise RuntimeError(
                        f"[MOGE_EVIDENCE] worker {key} mismatch: "
                        f"{worker_report.get(key)!r} != {expected!r}"
                    )

        evidence = {
            "schema": "ConceptGhost.GeometryEvidence.v0.30",
            "engine": "moge",
            "geometry_profile": selected,
            "selected_profile": selected,
            "effective_profile": selected,
            "profile_config": dict(profile),
            "moge_geometry": moge_geometry,
            "source_image": source_image,
            "atlas_fov_x_deg": float(atlas_fov_x_deg),
            "atlas_fov_conditioned": bool(float(atlas_fov_x_deg) > 0.0),
            "candidate_unfrozen": True,
            "native": {
                "version": moge_version,
                "model": actual_model,
                "runtime": "isolated ConceptGhost MoGe-3 subprocess" if moge_version == "MoGe-3" else "ComfyUI MoGe-2 node",
                "resolution_level": int(profile["resolution_level"]),
                "refine_steps": int(profile["refine_steps"]),
                "force_projection": bool(profile["force_projection"]),
                "apply_mask": bool(profile["apply_mask"]),
                "coordinate_system": "OpenCV camera: +X right, +Y down, +Z forward",
                "geometry_profile": selected,
                "selected_profile": selected,
                "effective_profile": selected,
                "mesher_policy": profile["mesher_policy"],
                "transport_stride": profile.get("transport_stride"),
                "depth_edge_rtol": profile.get("depth_edge_rtol"),
                "metric_native_policy": "preserve_moge_output_before_atlas_registration",
                "metric_native_units": "meters",
                "metric_native_aliases_are_zero_copy": True,
            },
        }
        return (evidence, _safe_text({k:v for k,v in evidence.items() if k not in {"moge_geometry","source_image"}}))


class ConceptGhostMoGeMetricMeasure:
    """Artist-facing, report-only measurements from immutable MoGe-native metric points.

    This node never touches canonical/world geometry. Pixel -1 selects image center.
    Region x1/y1 <= 0 means the full native image extent.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "primary_evidence": (CG_GEOMETRY_EVIDENCE,),
            "point_a_x": ("INT", {"default": -1, "min": -1, "max": 100000}),
            "point_a_y": ("INT", {"default": -1, "min": -1, "max": 100000}),
            "use_point_b": ("BOOLEAN", {"default": False}),
            "point_b_x": ("INT", {"default": -1, "min": -1, "max": 100000}),
            "point_b_y": ("INT", {"default": -1, "min": -1, "max": 100000}),
            "region_x0": ("INT", {"default": 0, "min": 0, "max": 100000}),
            "region_y0": ("INT", {"default": 0, "min": 0, "max": 100000}),
            "region_x1": ("INT", {"default": 0, "min": 0, "max": 100000}),
            "region_y1": ("INT", {"default": 0, "min": 0, "max": 100000}),
        }}

    RETURN_TYPES = ("STRING", "FLOAT", "FLOAT")
    RETURN_NAMES = ("metric_report", "camera_to_point_a_m", "point_a_to_b_m")
    FUNCTION = "measure"
    CATEGORY = "ConceptGhost/03 Geometry/Metric"
    OUTPUT_NODE = True

    def measure(self, primary_evidence, point_a_x, point_a_y, use_point_b, point_b_x, point_b_y, region_x0, region_y0, region_x1, region_y1):
        evidence = dict(primary_evidence or {})
        geometry = dict(evidence.get("moge_geometry") or {})
        points = _to_numpy(geometry.get("points_metric_native", geometry.get("points")), np.float32)
        if points.ndim == 4:
            points = points[0]
        if points.ndim != 3 or points.shape[-1] != 3:
            raise RuntimeError(f"[MOGE_METRIC_MEASURE] missing native metric point map: {points.shape}")
        h, w = points.shape[:2]
        mask = geometry.get("mask_native", geometry.get("mask"))

        ax = w // 2 if int(point_a_x) < 0 else int(point_a_x)
        ay = h // 2 if int(point_a_y) < 0 else int(point_a_y)
        camera_distance = point_distance_m(points, (ax, ay), mask=mask)

        pair_distance = 0.0
        b_payload = None
        if bool(use_point_b):
            bx = w // 2 if int(point_b_x) < 0 else int(point_b_x)
            by = h // 2 if int(point_b_y) < 0 else int(point_b_y)
            pair_distance = point_distance_m(points, (ax, ay), (bx, by), mask=mask)
            b_payload = [bx, by]

        x1 = None if int(region_x1) <= 0 else int(region_x1)
        y1 = None if int(region_y1) <= 0 else int(region_y1)
        region = regional_metric_summary(
            points, mask, x0=int(region_x0), y0=int(region_y0), x1=x1, y1=y1
        )
        report = {
            "schema": "ConceptGhost.MoGeMetricMeasurement.v0.33",
            "status": "PASS",
            "policy": "report_only_native_moge_metric_no_geometry_movement",
            "units": "meters",
            "point_a_px": [ax, ay],
            "camera_to_point_a_m": float(camera_distance),
            "point_b_px": b_payload,
            "point_a_to_b_m": float(pair_distance) if bool(use_point_b) else None,
            "region": region,
        }
        ui = {"text": [
            f"MoGe native metric · camera→A: {camera_distance:.3f} m",
            (f"A→B: {pair_distance:.3f} m" if bool(use_point_b) else "A→B: disabled"),
            f"Region support: {float(region.get('support_ratio', 0.0))*100.0:.2f}%",
            "REPORT ONLY · official geometry unchanged",
        ]}
        return {"ui": ui, "result": (_safe_text(report), float(camera_distance), float(pair_distance))}

class ConceptGhostAtlasMetrologyMeasure:
    """Deterministic Atlas ray/ground/height metrology. Report-only by design."""

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "scene_bundle": (CG_SCENE_BUNDLE,),
            "enabled": ("BOOLEAN", {"default": False}),
            "base_x_px": ("INT", {"default": 0, "min": 0, "max": 32768}),
            "base_y_px": ("INT", {"default": 0, "min": 0, "max": 32768}),
            "use_top_pixel": ("BOOLEAN", {"default": False}),
            "top_x_px": ("INT", {"default": 0, "min": 0, "max": 32768}),
            "top_y_px": ("INT", {"default": 0, "min": 0, "max": 32768}),
            "reference_height_m": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 100000.0, "step": 0.01}),
        }}

    RETURN_TYPES = ("STRING", "FLOAT", "FLOAT", "FLOAT")
    RETURN_NAMES = ("atlas_metrology_report", "base_distance_m", "estimated_height_m", "height_ratio_to_reference")
    FUNCTION = "measure"
    CATEGORY = "ConceptGhost/04 Metrology"
    OUTPUT_NODE = True

    def measure(self, scene_bundle, enabled, base_x_px, base_y_px, use_top_pixel, top_x_px, top_y_px, reference_height_m):
        if not bool(enabled):
            report = {
                "schema": "ConceptGhost.AtlasMetrology.v0.33",
                "status": "DISABLED",
                "policy": "report_only_no_camera_or_geometry_movement",
                "reason": "artist_measurement_disabled",
            }
            return {
                "ui": {"text": ["Atlas metrology: DISABLED", "REPORT ONLY · camera and PrimaryMesh unchanged"]},
                "result": (_safe_text(report), 0.0, 0.0, 0.0),
            }
        top = (float(top_x_px), float(top_y_px)) if bool(use_top_pixel) else None
        report = atlas_architectural_metrology(
            scene_bundle,
            (float(base_x_px), float(base_y_px)),
            top,
        )
        base = report.get("base") or {}
        height = report.get("height") or {}
        base_distance = float(base.get("camera_distance_m") or 0.0)
        estimated_height = float(height.get("estimated_height_m") or 0.0)
        ref = float(reference_height_m or 0.0)
        ratio = float(estimated_height / ref) if estimated_height > 0.0 and ref > 0.0 else 0.0
        report["physical_size_consistency"] = {
            "available": bool(estimated_height > 0.0 and ref > 0.0),
            "reference_height_m": ref if ref > 0.0 else None,
            "estimated_to_reference_ratio": ratio if ratio > 0.0 else None,
            "role": "plausibility_evidence_not_absolute_authority",
        }
        ground = report.get("ground") or {}
        selected = ground.get("selected") or "NONE"
        ui = {"text": [
            f"Atlas metrology: {report.get('status')} · ground={selected}",
            (f"Base camera distance: {base_distance:.3f} m" if base_distance > 0 else "Base distance unavailable"),
            (f"Estimated height: {estimated_height:.3f} m" if estimated_height > 0 else "Height disabled/unavailable"),
            "REPORT ONLY · camera and PrimaryMesh unchanged",
        ]}
        return {"ui": ui, "result": (_safe_text(report), base_distance, estimated_height, ratio)}


class ConceptGhostMoGeAtlasAgreement:
    """Compare MoGe native metric evidence with deterministic Atlas metrology."""

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "scene_bundle": (CG_SCENE_BUNDLE,),
            "enabled": ("BOOLEAN", {"default": False}),
            "target_label": ("STRING", {"default": "Target"}),
            "base_x_px": ("INT", {"default": 0, "min": 0, "max": 32768}),
            "base_y_px": ("INT", {"default": 0, "min": 0, "max": 32768}),
        }}

    RETURN_TYPES = ("STRING", "STRING", "FLOAT")
    RETURN_NAMES = ("agreement_report", "agreement_state", "distance_difference_percent")
    FUNCTION = "compare"
    CATEGORY = "ConceptGhost/04 Metrology"
    OUTPUT_NODE = True

    def compare(self, scene_bundle, enabled, target_label, base_x_px, base_y_px):
        if not bool(enabled):
            report = {
                "schema": "ConceptGhost.MoGeAtlasMetricAgreement.v0.33",
                "status": "DISABLED",
                "policy": "report_only_no_camera_or_geometry_movement",
                "automatic_correction": False,
            }
            return {
                "ui": {"text": ["MoGe × Atlas agreement: DISABLED", "REPORT ONLY · no automatic correction"]},
                "result": (_safe_text(report), "DISABLED", 0.0),
            }
        report = moge_atlas_metric_agreement(
            scene_bundle, (float(base_x_px), float(base_y_px)), target_label=str(target_label)
        )
        target = report.get("target_camera_distance_agreement") or {}
        state = str(report.get("overall_state") or "UNAVAILABLE")
        pct = float(target.get("percent_difference") or 0.0)
        ui = {"text": [
            f"MoGe × Atlas: {state} · {target_label}",
            (f"Target distance disagreement: {pct:.2f}%" if target.get("percent_difference") is not None else "Target distance agreement unavailable"),
            f"Camera-height state: {(report.get('camera_height_agreement') or {}).get('state', 'UNAVAILABLE')}",
            "REPORT ONLY · Atlas camera / PrimaryMesh unchanged",
        ]}
        return {"ui": ui, "result": (_safe_text(report), state, pct)}


class ConceptGhostMetricConsensus:
    """Robust report-only metric consensus across Atlas, MoGe and Depth Pro."""

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "metric_agreement_report": ("STRING",),
            "depthpro_evidence": (CG_DEPTHPRO_EVIDENCE,),
            "enabled": ("BOOLEAN", {"default": False}),
        }}

    RETURN_TYPES = ("STRING", "STRING", "FLOAT")
    RETURN_NAMES = ("consensus_report", "consensus_status", "consensus_distance_m")
    FUNCTION = "consensus"
    CATEGORY = "ConceptGhost/04 Metrology"
    OUTPUT_NODE = True

    def consensus(self, metric_agreement_report, depthpro_evidence, enabled):
        if not bool(enabled):
            report = {
                "schema": "ConceptGhost.MetricConsensus.v0.33",
                "status": "DISABLED",
                "policy": "report_only_weighted_median_mad_agreement_groups_no_simple_mean",
                "automatic_correction": False,
            }
            return {
                "ui": {"text": ["Metric consensus: DISABLED", "REPORT ONLY · no automatic correction"]},
                "result": (_safe_text(report), "DISABLED", 0.0),
            }
        report = build_metric_consensus(metric_agreement_report, dict(depthpro_evidence or {}))
        status = str(report.get("status") or "INSUFFICIENT_EVIDENCE")
        distance = float(report.get("consensus_distance_m") or 0.0)
        states = report.get("source_states") or {}
        ui = {"text": [
            f"Metric consensus: {status}",
            (f"Consensus distance: {distance:.3f} m" if distance > 0 else "Consensus distance unavailable"),
            f"Sources: {states}",
            "REPORT ONLY · weighted median/MAD · no simple mean",
        ]}
        return {"ui": ui, "result": (_safe_text(report), status, distance)}


class ConceptGhostGeometricRegions:
    """Deterministic metadata-only regions derived from the exact PrimaryMesh.

    This P7/B4 node never edits vertices/faces. It writes only a compact region
    map/report plus a small 2D overlay for artist inspection.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "run_dir": ("STRING", {"forceInput": True}),
            "enabled": ("BOOLEAN", {"default": False}),
        }}

    RETURN_TYPES = ("STRING", "IMAGE", "INT", "STRING")
    RETURN_NAMES = ("region_report", "region_overlay", "region_count", "report_path")
    FUNCTION = "analyze"
    CATEGORY = "ConceptGhost/05 Regions"
    OUTPUT_NODE = True

    def analyze(self, run_dir, enabled):
        blank = _numpy_image_to_tensor(np.zeros((1, 1, 3), dtype=np.float32))
        if not bool(enabled):
            report = {
                "schema": "ConceptGhost.GeometricRegions.v0.33",
                "status": "DISABLED",
                "policy": "diagnostic_metadata_only_no_geometry_movement_no_geometry_deletion",
                "geometry_modified": False,
            }
            return {
                "ui": {"text": ["Geometric regions: DISABLED", "P7/B4 · metadata only · PrimaryMesh unchanged"]},
                "result": (_safe_text(report), blank, 0, ""),
            }

        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir)))).resolve()
        if not run.is_dir():
            raise FileNotFoundError(f"ConceptGhost run folder not found: {run}")
        payload_path = run / "maya" / "primary_mesh_payload.json"
        if not payload_path.is_file():
            raise FileNotFoundError(f"PrimaryMesh payload not found: {payload_path}")
        payload = json.loads(payload_path.read_text(encoding="utf-8"))
        npz_path = Path(str(payload.get("npz_path") or ""))
        if not npz_path.is_file():
            raise FileNotFoundError(f"PrimaryMesh NPZ not found: {npz_path}")

        report, face_region_ids, region_mask = analyze_primary_mesh_regions(npz_path)
        region_dir = run / "geometry" / "regions"
        region_dir.mkdir(parents=True, exist_ok=True)
        report_path = write_json(region_dir / "geometric_regions.json", json_safe(report))
        np.savez_compressed(
            region_dir / "region_map.npz",
            face_region_ids=np.asarray(face_region_ids),
            region_vertex_mask=np.asarray(region_mask),
        )

        overlay_tensor = blank
        source_path = run / "source" / "source.png"
        overlay_path = run / "diagnostics" / "geometric_regions_overlay.png"
        if Image is not None and source_path.is_file():
            src = np.asarray(Image.open(source_path).convert("RGB"), dtype=np.uint8)
            overlay = colorize_region_overlay(src, region_mask)
            overlay_path.parent.mkdir(parents=True, exist_ok=True)
            Image.fromarray(overlay, mode="RGB").save(overlay_path)
            overlay_tensor = _numpy_image_to_tensor(overlay.astype(np.float32) / 255.0)

        region_count = int(report.get("region_count") or 0)
        ui = {"text": [
            f"Geometric regions: {report.get('status')} · {region_count} retained",
            f"Coverage: {float(report.get('coverage_ratio') or 0.0) * 100.0:.2f}% of PrimaryMesh faces",
            "P7/B4 · metadata/selection only · no vertex or face movement",
        ]}
        return {"ui": ui, "result": (_safe_text(report), overlay_tensor, region_count, str(report_path))}


class ConceptGhostLocalGeometryCleanup:
    """P8/A7 diagnostic + explicitly approved derived cleanup candidate.

    The official PrimaryMesh is never overwritten. Plane fitting remains
    diagnostic; the first candidate only removes severe sliver/whisker faces
    inside automatically flagged regions while protecting strong boundaries.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "run_dir": ("STRING", {"forceInput": True}),
            "region_report_path": ("STRING", {"forceInput": True}),
            "enabled": ("BOOLEAN", {"default": False}),
            "approve_cleanup_candidate": ("BOOLEAN", {"default": False}),
        }}

    RETURN_TYPES = ("STRING", "STRING", "STRING", "INT")
    RETURN_NAMES = ("cleanup_report", "cleanup_candidate_glb", "cleanup_status", "candidate_removed_faces")
    FUNCTION = "cleanup"
    CATEGORY = "ConceptGhost/05 Regions"
    OUTPUT_NODE = True

    def cleanup(self, run_dir, region_report_path, enabled, approve_cleanup_candidate):
        if not bool(enabled):
            report = {
                "schema": "ConceptGhost.LocalGeometryCleanup.v0.33",
                "status": "DISABLED",
                "policy": "diagnostic_then_artist_approved_candidate_primarymesh_never_replaced",
                "official_primarymesh_modified": False,
            }
            return {
                "ui": {"text": ["Local geometry cleanup: DISABLED", "P8/A7 · PrimaryMesh unchanged"]},
                "result": (_safe_text(report), "", "DISABLED", 0),
            }

        if not str(region_report_path or "").strip():
            raise RuntimeError("P8/A7 requires the P7 geometric-region report from the same run")
        result = run_local_cleanup_from_run(
            Path(os.path.expandvars(os.path.expanduser(str(run_dir)))),
            approve_candidate=bool(approve_cleanup_candidate),
        )
        removed = int(((result.get("candidate") or {}).get("removed_faces")) or 0)
        status = str(result.get("status") or "READY_FOR_ARTIST_REVIEW")
        flagged = result.get("flagged_region_ids") or []
        ui = {"text": [
            f"Local cleanup: {status} · flagged regions={len(flagged)}",
            f"Candidate removable faces: {int(result.get('candidate_removable_faces') or 0):,}",
            (f"Approved candidate removed faces: {removed:,}" if approve_cleanup_candidate else "Candidate NOT generated · artist approval OFF"),
            (f"Derived candidate moved vertices: {int(((result.get('candidate') or {}).get('moved_vertices')) or 0):,}" if approve_cleanup_candidate else "Official PrimaryMesh unchanged · diagnostic only"),
        ]}
        return {
            "ui": ui,
            "result": (_safe_text(result), str(result.get("candidate_glb") or ""), status, removed),
        }


class ConceptGhostCanonicalize:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "camera_bundle": (CG_CAMERA_BUNDLE,),
            "primary_evidence": (CG_GEOMETRY_EVIDENCE,),
            "source_image": ("IMAGE",),
            "preset": ("STRING", {"forceInput": True}),
        }}
    RETURN_TYPES=(CG_SCENE_BUNDLE,"IMAGE","STRING")
    RETURN_NAMES=("scene_bundle","reprojection_overlay","scene_report")
    FUNCTION="build"
    CATEGORY="ConceptGhost/04 Normalizer"

    def build(self,camera_bundle,primary_evidence,source_image,preset):
        if str(primary_evidence.get("engine") or "").lower() != "moge":
            raise RuntimeError("[CANONICAL] ConceptGhost v0.30 accepts only MoGe geometry evidence")
        profile = assert_profile_contract(dict(primary_evidence.get("profile_config") or {}), stage="CANONICAL_INPUT")
        selected = str(profile["selected_profile"])
        if str(primary_evidence.get("geometry_profile")) != selected:
            raise RuntimeError("[CANONICAL_INPUT] evidence geometry_profile differs from authoritative profile_config")

        primary=canonicalize(camera_bundle,primary_evidence,source_image)
        canonical_profile = assert_profile_contract(dict(primary.get("profile_config") or {}), stage="CANONICAL_OUTPUT", expected_profile=selected)
        if str(primary.get("geometry_profile")) != selected:
            raise RuntimeError("[CANONICAL_OUTPUT] canonical geometry_profile changed unexpectedly")

        health=geometry_health(primary["xyz"])
        reproj=reprojection_report(camera_bundle,primary)
        stage7_status="PASS" if (camera_bundle.get("valid") and len(primary["xyz"]) and reproj.get("pass") and health.get("pass")) else ("PARTIAL" if len(primary["xyz"]) else "FAIL")
        camera_prov=camera_bundle.get("provenance",{})
        metric_reg=(primary.get("refinement") or {}).get("atlas_metric_scale_registration",{}) or {}
        contributors=[
            {"component":"Atlas Camera","role":"camera/projection authority","detail":camera_prov.get("final_solver")},
            {"component":"MoGe","role":"geometry authority","detail":primary_evidence.get("native",{}).get("model")},
            {"component":"Original Source Image","role":"RGB authority","detail":"per-point source color"},
            {"component":"ConceptGhost Normalizer","role":"canonical coordinate assembly","detail":"right-handed Y-up, -Z camera forward; no remeshing"},
            {"component":"Reprojection Gate","role":"integration consistency validation","detail":"Atlas camera reprojection"},
            {"component":"Geometry Health","role":"canonical geometry validation","detail":"point-cloud health gate"},
        ]
        if camera_prov.get("final_solver")=="Atlas Learned":
            contributors.insert(1,{"component":"GeoCalib","role":"learned camera prior through Atlas","detail":camera_prov.get("learned_prior")})
        if metric_reg.get("applied"):
            contributors.append({"component":"Atlas Metric Scale Registration","role":"metric scale authority shared with selected geometry","detail":f"engine ground height × {float(metric_reg.get('scale_factor',1.0)):.6g} -> Atlas camera height {float(metric_reg.get('target_camera_height_m',0.0)):.6g} m"})

        scene={
            "schema":"ConceptGhost.SceneBundle.v0.30",
            "camera":camera_bundle,
            "geometry":{
                "schema":primary["schema"],
                "engine":primary["engine"],
                "point_count":primary["point_count"],
                "native_resolution":primary["native_resolution"],
                "depth_semantics":primary["depth_semantics"],
            },
            "coordinate_convention":dict(CANONICAL_COORDINATES),
            "scale_convention":{
                "units":metric_reg.get("units","meters" if metric_reg.get("applied") else "relative"),
                "meters_per_unit":1.0 if metric_reg.get("applied") else None,
                "scale_applied":bool(metric_reg.get("scale_applied",metric_reg.get("applied",False))),
                "scale_factor":float(metric_reg.get("scale_factor",1.0)),
                "reason_if_not_applied":metric_reg.get("reason_if_not_applied",None if metric_reg.get("applied") else metric_reg.get("reason")),
                "scale_authority":"Atlas metric camera height registered to selected geometry ground evidence" if metric_reg.get("applied") else "relative_unregistered; engine/Atlas evidence insufficient for a metric claim",
                "registration":json_safe(metric_reg),
            },
            "integration_consistency":reproj,
            "geometry_health":health,
            "status":{"run_status":stage7_status,"authoritative":bool(stage7_status=="PASS")},
            "preset":preset,
            "geometry_profile":selected,
            "selected_profile":selected,
            "effective_profile":selected,
            "profile_config":dict(canonical_profile),
            "engine_metadata":json_safe(primary_evidence.get("native",{})),
            "synergy_contributors":contributors,
            "primary_authority":{"camera":"Atlas","geometry":"moge","color":"Original Source Image","final_scene":"ConceptGhost Canonical Scene"},
            "_runtime":{"primary_canonical":primary,"primary_evidence":primary_evidence,"source_image":source_image},
        }
        assert_profile_contract(scene["profile_config"], stage="SCENE_BUNDLE", expected_profile=selected)
        overlay=_make_overlay(source_image,primary,reproj)
        return (scene,overlay,_safe_text({k:v for k,v in scene.items() if k!="_runtime"}))


def _maya_artifact_status(run: Path, ma_path: Path, fbx_path: Path):
    """Trust the worker manifest for FBX validity, not file existence alone."""
    details = {}
    manifest_path = Path(run) / "maya" / "maya_manifest.json"
    if manifest_path.is_file():
        try:
            details = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            details = {"status": "INVALID_MANIFEST", "error": str(exc)}
    ma_entry = details.get("ma") if isinstance(details, dict) else None
    fbx_entry = details.get("fbx") if isinstance(details, dict) else None
    hero_entry = details.get("hero_mesh") if isinstance(details, dict) else None
    hero_ok = not (isinstance(hero_entry, dict) and hero_entry.get("requested")) or hero_entry.get("status") == "PASS"
    maya_ok = bool(ma_path.exists() and isinstance(ma_entry, dict) and ma_entry.get("status") == "PASS" and hero_ok)
    fbx_ok = bool(fbx_path.exists() and isinstance(fbx_entry, dict) and fbx_entry.get("status") == "PASS" and hero_ok)
    return maya_ok, fbx_ok, details


def _first_mesh_batch_item(mesh):
    """Return the first real mesh item using ComfyUI's batched MESH contract.

    Core ComfyUI stores vertices/faces/UVs/normals as BxNx* tensors and may
    attach per-item vertex/face counts for variable-size batches.  ConceptGhost
    intentionally exports a single hero mesh, matching SaveGLB's first-item
    behavior used by our workflow.
    """
    vertices = _to_numpy(getattr(mesh, "vertices", None), np.float32)
    faces = _to_numpy(getattr(mesh, "faces", None), np.int64)
    if vertices.size == 0 or faces.size == 0:
        raise ValueError("Hero MESH requires vertices and faces")

    if vertices.ndim == 3:
        vertices = vertices[0]
    if faces.ndim == 3:
        faces = faces[0]
    if vertices.ndim != 2 or vertices.shape[-1] != 3:
        raise ValueError(f"Hero MESH vertices must resolve to Nx3, got {vertices.shape}")
    if faces.ndim != 2 or faces.shape[-1] < 3:
        raise ValueError(f"Hero MESH faces must resolve to FxK, got {faces.shape}")

    vertex_counts = getattr(mesh, "vertex_counts", None)
    face_counts = getattr(mesh, "face_counts", None)
    if vertex_counts is not None:
        vc = int(_to_numpy(vertex_counts).reshape(-1)[0])
        vertices = vertices[:vc]
    if face_counts is not None:
        fc = int(_to_numpy(face_counts).reshape(-1)[0])
        faces = faces[:fc]

    def optional_vertex_attr(name: str, width: int):
        value = getattr(mesh, name, None)
        if value is None:
            return None
        arr = _to_numpy(value, np.float32)
        if arr.size == 0:
            return None
        if arr.ndim == 3:
            arr = arr[0]
        if arr.ndim != 2 or arr.shape[-1] != width:
            return None
        return arr[: len(vertices)]

    uvs = optional_vertex_attr("uvs", 2)
    normals = optional_vertex_attr("normals", 3)
    return vertices, faces, uvs, normals




def _finalize_camera_facing_mesh_normals(
    vertices: np.ndarray,
    faces: np.ndarray,
    camera: dict[str, Any],
    *,
    enforce_camera_facing: bool = True,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Finalize triangle winding and normals from the *final* mesh topology.

    The old raster-derivative normal path could disagree with the actual triangle
    winding and a single shared vertex normal can become opposite to a folded
    incident face.  This routine makes the final triangle topology authoritative:

    1. orient every non-degenerate triangle toward the matched camera;
    2. build area-weighted smooth vertex normals from those final triangles;
    3. build per-face-vertex normals and hemisphere-clamp every corner to its
       geometric face normal.

    The per-face-vertex normals are what Maya should author.  Therefore no valid
    face corner can receive a stored normal pointing through the back side of its
    polygon, while smooth shading is preserved wherever it is geometrically safe.
    """
    v = np.asarray(vertices, dtype=np.float64).reshape((-1, 3))
    f = np.asarray(faces, dtype=np.int64).reshape((-1, 3)).copy()
    if len(v) == 0 or len(f) == 0:
        raise ValueError("Cannot finalize normals for an empty mesh")

    cam_pos = np.asarray(
        (camera.get("extrinsics") or {}).get("camera_position") or [0.0, 0.0, 0.0],
        dtype=np.float64,
    ).reshape(3)

    def _face_geometry(face_idx: np.ndarray):
        p0 = v[face_idx[:, 0]]
        p1 = v[face_idx[:, 1]]
        p2 = v[face_idx[:, 2]]
        raw = np.cross(p1 - p0, p2 - p0)
        length = np.linalg.norm(raw, axis=1)
        cent = (p0 + p1 + p2) / 3.0
        return raw, length, cent

    raw0, len0, cent0 = _face_geometry(f)
    valid0 = np.isfinite(len0) & (len0 > 1e-12)
    to_cam0 = cam_pos.reshape(1, 3) - cent0
    front_dot0 = np.einsum("ij,ij->i", raw0, to_cam0)
    reverse = valid0 & np.isfinite(front_dot0) & (front_dot0 < 0.0)
    if np.any(reverse):
        tmp = f[reverse, 1].copy()
        f[reverse, 1] = f[reverse, 2]
        f[reverse, 2] = tmp

    raw, length, cent = _face_geometry(f)
    valid = np.isfinite(length) & (length > 1e-12)
    face_normals = np.zeros((len(f), 3), dtype=np.float64)
    face_normals[valid] = raw[valid] / length[valid, None]

    # Area-weighted smooth normals derived from final, camera-facing faces.
    accum = np.zeros((len(v), 3), dtype=np.float64)
    raw_safe = np.where(np.isfinite(raw), raw, 0.0)
    for corner in range(3):
        np.add.at(accum, f[:, corner], raw_safe)
    accum_len = np.linalg.norm(accum, axis=1)
    vertex_normals = np.zeros((len(v), 3), dtype=np.float64)
    vok = np.isfinite(accum_len) & (accum_len > 1e-12)
    vertex_normals[vok] = accum[vok] / accum_len[vok, None]

    # A shared smooth normal cannot be valid for every face of a severe fold.
    # Author face-vertex normals and fall back to that face's own normal whenever
    # a corner normal would point into the wrong hemisphere.
    face_vertex_normals = vertex_normals[f].copy()
    corner_len = np.linalg.norm(face_vertex_normals, axis=2)
    corner_dot_before = np.einsum("fci,fi->fc", face_vertex_normals, face_normals)
    bad_corner = (~np.isfinite(corner_len)) | (corner_len <= 1e-12) | (~np.isfinite(corner_dot_before)) | (corner_dot_before <= 1e-6)
    bad_corner &= valid[:, None]
    if np.any(bad_corner):
        expanded = np.broadcast_to(face_normals[:, None, :], face_vertex_normals.shape)
        face_vertex_normals[bad_corner] = expanded[bad_corner]

    corner_dot_after = np.einsum("fci,fi->fc", face_vertex_normals, face_normals)
    opposed_after = valid[:, None] & (corner_dot_after <= 0.0)
    if np.any(opposed_after):
        # This should be mathematically unreachable after the fallback above.
        raise ValueError(
            f"Normal finalization failed: {int(np.count_nonzero(opposed_after))} face corners remain opposed"
        )

    to_cam = cam_pos.reshape(1, 3) - cent
    front_dot = np.einsum("ij,ij->i", face_normals, to_cam)
    back_facing_after = valid & np.isfinite(front_dot) & (front_dot <= 0.0)

    valid_face_count = int(np.count_nonzero(valid))
    camera_facing = valid & np.isfinite(front_dot) & (front_dot > 0.0)
    camera_away = valid & np.isfinite(front_dot) & (front_dot <= 0.0)

    # The exported shading contract is face-vertex normals.  Validate the
    # averaged exported normal against the geometric normal of every final face.
    fvn_len = np.linalg.norm(face_vertex_normals, axis=2)
    zero_corner = valid[:, None] & ((~np.isfinite(fvn_len)) | (fvn_len <= 1e-12))
    face_export_normal = np.sum(face_vertex_normals, axis=1)
    face_export_len = np.linalg.norm(face_export_normal, axis=1)
    export_ok = valid & np.isfinite(face_export_len) & (face_export_len > 1e-12)
    face_export_unit = np.zeros_like(face_export_normal)
    face_export_unit[export_ok] = face_export_normal[export_ok] / face_export_len[export_ok, None]
    normal_dot = np.einsum("ij,ij->i", face_normals, face_export_unit)
    normal_aligned = export_ok & np.isfinite(normal_dot) & (normal_dot > 0.0)
    normal_opposed = export_ok & np.isfinite(normal_dot) & (normal_dot <= 0.0)

    def _stats(values: np.ndarray, mask: np.ndarray) -> dict[str, float]:
        arr = np.asarray(values[mask], dtype=np.float64)
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return {"min": 0.0, "median": 0.0, "p05": 0.0, "p95": 0.0}
        return {
            "min": float(np.min(arr)),
            "median": float(np.median(arr)),
            "p05": float(np.percentile(arr, 5.0)),
            "p95": float(np.percentile(arr, 95.0)),
        }

    camera_dot_unit = np.zeros_like(front_dot, dtype=np.float64)
    to_cam_len = np.linalg.norm(to_cam, axis=1)
    cam_ok = valid & np.isfinite(to_cam_len) & (to_cam_len > 1e-12)
    camera_dot_unit[cam_ok] = front_dot[cam_ok] / to_cam_len[cam_ok]

    zero_vertex_normals = int(np.count_nonzero(np.linalg.norm(vertex_normals, axis=1) <= 1e-12))
    camera_gate_pass = int(np.count_nonzero(camera_away)) == 0
    normal_gate_pass = int(np.count_nonzero(normal_opposed)) == 0 and int(np.count_nonzero(zero_corner)) == 0
    gate_pass = normal_gate_pass and (camera_gate_pass or not enforce_camera_facing)

    report = {
        "policy": "final_topology_camera_facing_face_vertex_normals_v0.28",
        "gate": "PASS" if gate_pass else "FAIL",
        "camera_gate": "PASS" if camera_gate_pass else "FAIL",
        "normal_gate": "PASS" if normal_gate_pass else "FAIL",
        "camera_gate_enforced": bool(enforce_camera_facing),
        "faces_total": int(len(f)),
        "valid_faces": valid_face_count,
        "degenerate_faces": int(np.count_nonzero(~valid)),
        "winding_reversed_faces": int(np.count_nonzero(reverse)),
        "camera_facing_faces": int(np.count_nonzero(camera_facing)),
        "camera_away_faces": int(np.count_nonzero(camera_away)),
        "back_facing_faces_after": int(np.count_nonzero(back_facing_after)),
        "normal_aligned_faces": int(np.count_nonzero(normal_aligned)),
        "normal_opposed_faces": int(np.count_nonzero(normal_opposed)),
        "zero_normals": int(np.count_nonzero(zero_corner)),
        "zero_vertex_normals": zero_vertex_normals,
        "face_vertex_corners_repaired": int(np.count_nonzero(bad_corner)),
        "opposed_face_vertex_corners_after": int(np.count_nonzero(opposed_after)),
        "face_vertex_min_dot_after": float(np.min(corner_dot_after[valid])) if np.any(valid) else 0.0,
        "camera_dot": _stats(camera_dot_unit, cam_ok),
        "normal_dot": _stats(normal_dot, export_ok),
    }
    if not gate_pass:
        raise ValueError(
            "Pre-Maya normal gate failed: "
            f"camera_away_faces={report['camera_away_faces']}, "
            f"normal_opposed_faces={report['normal_opposed_faces']}, "
            f"zero_normals={report['zero_normals']}"
        )
    return (
        f.astype(np.int32, copy=False),
        vertex_normals.astype(np.float32, copy=False),
        face_normals.astype(np.float32, copy=False),
        face_vertex_normals.astype(np.float32, copy=False),
        report,
    )

def _build_primary_mesh_arrays_from_canonical(
    canonical: dict[str, Any],
    camera: dict[str, Any],
    image_width: int,
    image_height: int,
    *,
    profile_config: dict[str, Any],
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    """Build the final Maya/DCC mesh under the authoritative profile contract.

    Low Resolution keeps the established deterministic transport sampling. High
    Fidelity uses the full valid MoGe grid, rejects triangles that bridge a
    forbidden relative-depth discontinuity, then derives all normals from the
    final topology. No downstream stage is allowed to reinterpret the profile.
    """
    profile = assert_profile_contract(dict(profile_config or {}), stage="PRIMARY_MESH_BUILD")
    selected_profile = str(profile["selected_profile"])
    if str(canonical.get("geometry_profile")) != selected_profile:
        raise RuntimeError(
            f"[PRIMARY_MESH_BUILD] canonical profile mismatch: "
            f"{canonical.get('geometry_profile')!r} != {selected_profile!r}"
        )
    if str(canonical.get("engine") or "").lower() != "moge":
        raise RuntimeError("[PRIMARY_MESH_BUILD] v0.30 final mesh authority must be MoGe")

    xyz_full = np.asarray(canonical.get("xyz"), dtype=np.float32).reshape((-1, 3))
    source_uv_full = np.asarray(canonical.get("source_uv"), dtype=np.float32).reshape((-1, 2))
    grid_xy = np.asarray(canonical.get("grid_xy"), dtype=np.int64).reshape((-1, 2))
    if len(xyz_full) < 3 or len(source_uv_full) != len(xyz_full) or len(grid_xy) != len(xyz_full):
        raise ValueError("Canonical MoGe geometry is missing aligned xyz/source_uv/grid_xy arrays")

    native = canonical.get("native_resolution") or [0, 0]
    grid_w, grid_h = int(native[0] or 0), int(native[1] or 0)
    if grid_w <= 1 or grid_h <= 1:
        raise ValueError(f"Invalid canonical native resolution: {native}")

    gx = grid_xy[:, 0].astype(np.int64)
    gy = grid_xy[:, 1].astype(np.int64)
    valid_xy = (gx >= 0) & (gx < grid_w) & (gy >= 0) & (gy < grid_h)
    index_grid = np.full((grid_h, grid_w), -1, dtype=np.int64)
    index_grid[gy[valid_xy], gx[valid_xy]] = np.arange(len(xyz_full), dtype=np.int64)[valid_xy]

    high_fidelity = selected_profile in {"High Fidelity", "High Fidelity Split Clean"}
    if high_fidelity:
        stride = int(profile["transport_stride"])
        if stride != 1:
            raise RuntimeError(f"[PRIMARY_MESH_BUILD] High Fidelity requires stride=1, got {stride}")
        sampled_grid = index_grid
    else:
        target = int(profile.get("transport_vertex_cap") or 250000)
        stride = max(1, int(math.ceil(math.sqrt(max(len(xyz_full), 1) / float(target)))))
        sampled_grid = index_grid[::stride, ::stride]

    # Candidate raster triangles. Missing/masked source pixels naturally cut topology.
    p00 = sampled_grid[:-1, :-1]
    p10 = sampled_grid[:-1, 1:]
    p01 = sampled_grid[1:, :-1]
    p11 = sampled_grid[1:, 1:]
    m1 = (p00 >= 0) & (p01 >= 0) & (p10 >= 0)
    m2 = (p10 >= 0) & (p01 >= 0) & (p11 >= 0)
    tri1 = np.stack([p00[m1], p01[m1], p10[m1]], axis=1) if np.any(m1) else np.empty((0, 3), dtype=np.int64)
    tri2 = np.stack([p10[m2], p01[m2], p11[m2]], axis=1) if np.any(m2) else np.empty((0, 3), dtype=np.int64)
    candidate_faces = np.concatenate([tri1, tri2], axis=0)
    theoretical_faces = int(max(sampled_grid.shape[0] - 1, 0) * max(sampled_grid.shape[1] - 1, 0) * 2)
    rejected_invalid_faces = max(0, theoretical_faces - int(len(candidate_faces)))
    if len(candidate_faces) == 0:
        raise ValueError("Canonical raster produced no candidate faces")

    rejected_depth_edge_faces = 0
    depth_edge_rtol = profile.get("depth_edge_rtol")
    depth_edge_count = 0
    if high_fidelity:
        if depth_edge_rtol is None:
            raise RuntimeError("[PRIMARY_MESH_BUILD] High Fidelity missing depth_edge_rtol")
        rtol = float(depth_edge_rtol)
        depth_full = np.asarray(canonical.get("camera_depth", []), dtype=np.float64).reshape(-1)
        if len(depth_full) != len(xyz_full):
            # Fallback is geometric, not profile-related: derive positive camera depth
            # from the authoritative Atlas view transform without remeshing.
            view = np.asarray((camera.get("extrinsics") or {}).get("camera_view_matrix"), dtype=np.float64)
            if view.shape != (4, 4):
                raise RuntimeError("[PRIMARY_MESH_BUILD] missing camera_depth and valid camera_view_matrix")
            homo = np.concatenate([xyz_full.astype(np.float64), np.ones((len(xyz_full), 1), dtype=np.float64)], axis=1)
            cam = (view @ homo.T).T[:, :3]
            depth_full = -cam[:, 2]

        td = depth_full[candidate_faces]
        positive = np.isfinite(td).all(axis=1) & (td > 1e-8).all(axis=1)
        denom01 = np.maximum(np.minimum(np.abs(td[:, 0]), np.abs(td[:, 1])), 1e-6)
        denom12 = np.maximum(np.minimum(np.abs(td[:, 1]), np.abs(td[:, 2])), 1e-6)
        denom20 = np.maximum(np.minimum(np.abs(td[:, 2]), np.abs(td[:, 0])), 1e-6)
        jump01 = np.abs(td[:, 0] - td[:, 1]) / denom01
        jump12 = np.abs(td[:, 1] - td[:, 2]) / denom12
        jump20 = np.abs(td[:, 2] - td[:, 0]) / denom20
        max_jump = np.maximum(np.maximum(jump01, jump12), jump20)
        forbidden = (~positive) | (~np.isfinite(max_jump)) | (max_jump >= rtol)
        rejected_depth_edge_faces = int(np.count_nonzero(forbidden))
        depth_edge_count = rejected_depth_edge_faces
        candidate_faces = candidate_faces[~forbidden]
        if len(candidate_faces) == 0:
            raise ValueError("High Fidelity depth-edge policy rejected every candidate face")

    # Reject degenerate triangles before final normal generation.
    pa = xyz_full[candidate_faces[:, 0]].astype(np.float64)
    pb = xyz_full[candidate_faces[:, 1]].astype(np.float64)
    pc = xyz_full[candidate_faces[:, 2]].astype(np.float64)
    area2 = np.linalg.norm(np.cross(pb - pa, pc - pa), axis=1)
    degenerate = (~np.isfinite(area2)) | (area2 <= 1e-12)
    rejected_degenerate_faces = int(np.count_nonzero(degenerate))
    accepted_global_faces = candidate_faces[~degenerate]
    if len(accepted_global_faces) == 0:
        raise ValueError("Primary mesh has no non-degenerate accepted faces")

    forbidden_bridge_faces = None
    if high_fidelity:
        # Independent post-filter proof: recompute the relative-depth rule on
        # the final accepted global triangles rather than hard-coding zero.
        final_td = depth_full[accepted_global_faces]
        final_positive = np.isfinite(final_td).all(axis=1) & (final_td > 1e-8).all(axis=1)
        fden01 = np.maximum(np.minimum(np.abs(final_td[:, 0]), np.abs(final_td[:, 1])), 1e-6)
        fden12 = np.maximum(np.minimum(np.abs(final_td[:, 1]), np.abs(final_td[:, 2])), 1e-6)
        fden20 = np.maximum(np.minimum(np.abs(final_td[:, 2]), np.abs(final_td[:, 0])), 1e-6)
        fj01 = np.abs(final_td[:, 0] - final_td[:, 1]) / fden01
        fj12 = np.abs(final_td[:, 1] - final_td[:, 2]) / fden12
        fj20 = np.abs(final_td[:, 2] - final_td[:, 0]) / fden20
        final_jump = np.maximum(np.maximum(fj01, fj12), fj20)
        final_forbidden = (~final_positive) | (~np.isfinite(final_jump)) | (final_jump >= float(depth_edge_rtol))
        forbidden_bridge_faces = int(np.count_nonzero(final_forbidden))
        if forbidden_bridge_faces != 0:
            raise RuntimeError(
                f"[PRIMARY_MESH_BUILD] {forbidden_bridge_faces} accepted triangles still cross forbidden depth edges"
            )

    # Compact only topology-referenced vertices. RAW/canonical geometry remains
    # full-resolution and is preserved separately in PLY/USD/NPZ evidence.
    selected_ids = np.unique(accepted_global_faces.reshape(-1))
    remap = np.full(len(xyz_full), -1, dtype=np.int64)
    remap[selected_ids] = np.arange(len(selected_ids), dtype=np.int64)
    faces_np = remap[accepted_global_faces].astype(np.int32, copy=False)
    xyz = xyz_full[selected_ids]
    source_uv = source_uv_full[selected_ids]

    faces_np, vertex_normals, face_normals, face_vertex_normals, normal_report = _finalize_camera_facing_mesh_normals(
        xyz, faces_np, camera
    )
    if normal_report.get("gate") != "PASS":
        raise RuntimeError(f"[PRIMARY_MESH_BUILD] final topology/normal gate failed: {normal_report}")

    iw = max(int(image_width) - 1, 1)
    ih = max(int(image_height) - 1, 1)
    uvs = np.empty((len(xyz), 2), dtype=np.float32)
    uvs[:, 0] = np.clip(source_uv[:, 0] / float(iw), 0.0, 1.0)
    uvs[:, 1] = 1.0 - np.clip(source_uv[:, 1] / float(ih), 0.0, 1.0)

    arrays: dict[str, np.ndarray] = {
        "vertices": np.asarray(xyz, dtype=np.float32),
        "faces": np.asarray(faces_np, dtype=np.int32),
        "uvs": uvs,
        "normals": np.asarray(vertex_normals, dtype=np.float32),
        "face_normals": np.asarray(face_normals, dtype=np.float32),
        "face_vertex_normals": np.asarray(face_vertex_normals, dtype=np.float32),
        "canonical_point_indices": np.asarray(selected_ids, dtype=np.int64),
        "source_uv": np.asarray(source_uv, dtype=np.float32),
        "grid_xy": np.asarray(grid_xy[selected_ids], dtype=np.int32),
    }
    if len(np.asarray(canonical.get("source_pixel_id", []))) == len(xyz_full):
        arrays["source_pixel_id"] = np.asarray(canonical["source_pixel_id"], dtype=np.int64)[selected_ids]
    if len(np.asarray(canonical.get("camera_depth", []))) == len(xyz_full):
        arrays["camera_depth"] = np.asarray(canonical["camera_depth"], dtype=np.float32)[selected_ids]
    if len(np.asarray(canonical.get("geometric_boundary_strength", []))) == len(xyz_full):
        arrays["geometric_boundary_strength"] = np.asarray(canonical["geometric_boundary_strength"], dtype=np.float32)[selected_ids]

    split_clean_report = None
    mesh_cfg = dict(profile.get("mesh_profile_config") or {})
    if selected_profile == "High Fidelity Split Clean":
        split_arrays, split_clean_report = build_hf_split_clean(
            arrays, camera,
            discontinuity_threshold=float(mesh_cfg["discontinuity_threshold"]),
            quality_min=float(mesh_cfg["triangle_quality_min"]),
            max_edge_ratio=float(mesh_cfg["long_triangle_ratio"]),
        )
        sf, svn, sfn, sfvn, snormal = _finalize_camera_facing_mesh_normals(
            np.asarray(split_arrays["vertices"], dtype=np.float32),
            np.asarray(split_arrays["faces"], dtype=np.int32),
            camera,
        )
        split_arrays["faces"] = sf
        split_arrays["normals"] = svn
        split_arrays["face_normals"] = sfn
        split_arrays["face_vertex_normals"] = sfvn
        arrays = {k: np.asarray(v) for k, v in split_arrays.items() if k != "source_vertex_ids"}
        normal_report = snormal

    mesher_policy = str(profile["mesher_policy"])
    report = {
        "source_engine": "moge",
        "selected_profile": selected_profile,
        "effective_profile": selected_profile,
        "geometry_profile": selected_profile,
        "profile_schema": profile["schema"],
        "source_model": profile["model"],
        "moge_version": profile["moge_version"],
        "resolution_level": int(profile["resolution_level"]),
        "refine_steps": int(profile["refine_steps"]),
        "silent_fallback": bool(profile["silent_fallback"]),
        "mesher_policy": mesher_policy,
        "transport_stride": int(stride),
        "transport_vertex_cap": profile.get("transport_vertex_cap"),
        "depth_edge_rtol": float(depth_edge_rtol) if depth_edge_rtol is not None else None,
        "simplification_policy": profile["simplification_policy"],
        "decimation_policy": profile["decimation_policy"],
        "smoothing_policy": profile["smoothing_policy"],
        "normal_policy": profile["normal_policy"],
        "topology_authority": profile["topology_authority"],
        "alignment": "EXACT_CANONICAL_XYZ_SUBSET" if len(selected_ids) < len(xyz_full) else "EXACT_SAME_CANONICAL_XYZ",
        "coordinate_space": "Atlas world / ConceptGhost canonical axes",
        "axis_policy": "canonical_world_no_extra_yz_flip",
        "uv_policy": "Maya/DCC-ready V flip only",
        "full_resolution_authority": "RAW canonical PLY/USD; final HF faces are topology authority",
        "dcc_transport_sampled": bool(stride > 1),
        "raw_valid_points": int(len(xyz_full)),
        "mesh_retained_vertices": int(len(arrays["vertices"])),
        "vertex_count": int(len(arrays["vertices"])),
        "face_count": int(len(arrays["faces"])),
        "candidate_face_count": int(theoretical_faces),
        "valid_grid_candidate_faces": int(theoretical_faces - rejected_invalid_faces),
        "accepted_faces": int(len(arrays["faces"])),
        "rejected_invalid_faces": int(rejected_invalid_faces),
        "rejected_depth_edge_faces": int(rejected_depth_edge_faces),
        "rejected_degenerate_faces": int(rejected_degenerate_faces),
        "raw_depth_edge_count": int(depth_edge_count),
        "topology_preserved_edge_count": int(rejected_depth_edge_faces),
        "triangles_crossing_forbidden_depth_edges": forbidden_bridge_faces if high_fidelity else None,
        "retention_ratio": float(len(arrays["vertices"]) / max(len(xyz_full), 1)),
        "topology_unreferenced_vertices": int(len(xyz_full) - len(arrays["vertices"])),
        "mesh_profile_config": json_safe(mesh_cfg),
        "discontinuity_threshold": mesh_cfg.get("discontinuity_threshold"),
        "long_triangle_policy": mesh_cfg.get("long_triangle_policy"),
        "connected_components_policy": mesh_cfg.get("connected_component_policy"),
        "boundary_cleanup_policy": mesh_cfg.get("boundary_cleanup_policy"),
        "split_clean_report": json_safe(split_clean_report) if split_clean_report else None,
        "normal_gate": normal_report["gate"],
        **{k: normal_report[k] for k in (
            "faces_total", "valid_faces", "camera_facing_faces", "camera_away_faces",
            "normal_aligned_faces", "normal_opposed_faces", "zero_normals", "zero_vertex_normals",
            "camera_dot", "normal_dot", "winding_reversed_faces", "degenerate_faces",
            "back_facing_faces_after", "face_vertex_corners_repaired",
            "opposed_face_vertex_corners_after", "face_vertex_min_dot_after",
        )},
    }
    if high_fidelity:
        if mesher_policy != str(profile["mesher_policy"]) or stride != 1 or report["depth_edge_rtol"] is None:
            raise RuntimeError(f"[PRIMARY_MESH_BUILD] High Fidelity contract not reflected in mesher report: {report}")
        if selected_profile == "High Fidelity Split Clean" and not split_clean_report:
            raise RuntimeError("[PRIMARY_MESH_BUILD] Split Clean profile did not modify the authoritative PrimaryMesh")
    return arrays, report


def _write_primary_mesh_payload(
    run_dir: str | Path,
    scene_name: str,
    canonical: dict[str, Any],
    camera: dict[str, Any],
    source_image: Any,
    *,
    profile_config: dict[str, Any],
    texture_path: str | Path | None = None,
) -> dict[str, Any]:
    profile = assert_profile_contract(dict(profile_config or {}), stage="PRIMARY_MESH_PAYLOAD")
    run = Path(run_dir)
    scene = sanitize_scene_name(scene_name)
    maya_dir = run / "maya"
    maya_dir.mkdir(parents=True, exist_ok=True)
    width = int(camera.get("image_width") or _first_rgb(source_image).shape[1])
    height = int(camera.get("image_height") or _first_rgb(source_image).shape[0])
    arrays, report = _build_primary_mesh_arrays_from_canonical(
        canonical, camera, width, height, profile_config=profile
    )
    npz_path = maya_dir / f"ConceptGhost_{scene}_PrimaryMesh.npz"
    np.savez_compressed(npz_path, **arrays)

    resolved_texture_path = None
    if texture_path is not None:
        candidate = Path(texture_path)
        if not candidate.is_file():
            raise RuntimeError(f"PrimaryMesh texture authority is missing: {candidate}")
        resolved_texture_path = candidate
    elif Image is not None:
        # Compatibility fallback for direct callers that do not yet supply the
        # already-saved run source texture. The v0.32 export path always does.
        src = np.clip(np.rint(_first_rgb(source_image) * 255.0), 0, 255).astype(np.uint8)
        resolved_texture_path = maya_dir / f"ConceptGhost_{scene}_PrimaryTexture.png"
        Image.fromarray(src, mode="RGB").save(resolved_texture_path)

    payload = {
        "schema": "ConceptGhost.PrimarySolverMeshPayload.v0.31",
        **{k: json_safe(v) for k, v in report.items()},
        "npz_path": str(npz_path),
        "texture_path": str(resolved_texture_path) if resolved_texture_path else None,
        "profile_config": json_safe(profile),
    }
    # Fail closed at the artifact boundary.
    assert_profile_contract(dict(profile), stage="PRIMARY_MESH_PAYLOAD_FINAL", expected_profile=payload["geometry_profile"])
    if payload["geometry_profile"] in {"High Fidelity", "High Fidelity Split Clean"}:
        required = {
            "mesher_policy": profile["mesher_policy"],
            "transport_stride": 1,
            "source_model": "Ruicheng/moge-3-vitg",
            "resolution_level": 9,
            "refine_steps": 7,
        }
        for key, expected in required.items():
            if payload.get(key) != expected:
                raise RuntimeError(f"[PRIMARY_MESH_PAYLOAD_FINAL] {key}={payload.get(key)!r} != {expected!r}")
        if payload.get("depth_edge_rtol") is None:
            raise RuntimeError("[PRIMARY_MESH_PAYLOAD_FINAL] High Fidelity depth edge preservation is inactive")
    write_json(maya_dir / "primary_mesh_payload.json", payload)
    return payload


class ConceptGhostExportBundle:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "scene_bundle": (CG_SCENE_BUNDLE,),
                "source_image": ("IMAGE",),
                "scene_name": ("STRING", {"forceInput": True}),
                "output_root": ("STRING", {"forceInput": True}),
                "extra_diagnostics": ("BOOLEAN", {"forceInput": True}),
            },
            "optional": {
                "hero_mesh": ("MESH",),
                "atlas_metrology_report": ("STRING",),
                "metric_agreement_report": ("STRING",),
                "metric_consensus_report": ("STRING",),
            },
        }
    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("run_dir", "pointcloud_ply", "preview_ply", "ghost_usda", "ghost_ma", "ghost_fbx", "manifest_path", "status")
    FUNCTION = "export"
    CATEGORY = "ConceptGhost/07 Outputs"
    OUTPUT_NODE = True

    def export(self, scene_bundle, source_image, scene_name, output_root, extra_diagnostics, hero_mesh=None, atlas_metrology_report="", metric_agreement_report="", metric_consensus_report=""):
        runtime = scene_bundle.get("_runtime", {})
        canonical = runtime.get("primary_canonical")
        if canonical is None:
            raise RuntimeError("SceneBundle contains no canonical runtime geometry")
        profile = assert_profile_contract(dict(scene_bundle.get("profile_config") or {}), stage="EXPORT_BUNDLE")
        selected_profile = str(profile["selected_profile"])
        if str(scene_bundle.get("geometry_profile")) != selected_profile or str(canonical.get("geometry_profile")) != selected_profile:
            raise RuntimeError("[EXPORT_BUNDLE] profile changed before export")
        run = make_run_folder(output_root, scene_name)
        scene = sanitize_scene_name(scene_name)
        _stage0607_log(run, "ENTER export bundle")
        src_path = run / "source" / "source.png"
        if Image is not None:
            src = _first_rgb(source_image)
            Image.fromarray(np.clip(np.rint(src*255.0),0,255).astype(np.uint8), mode="RGB").save(src_path)
        else:
            np.save(run / "source" / "source.npy", _first_rgb(source_image))

        camera_json = write_json(run / "camera" / "camera.json", json_safe(scene_bundle["camera"]))
        write_json(run / "diagnostics" / "reprojection_report.json", json_safe(scene_bundle["integration_consistency"]))
        write_json(run / "diagnostics" / "geometry_health.json", json_safe(scene_bundle["geometry_health"]))
        metric_diagnostics_spec = build_maya_metric_diagnostics_spec(
            scene_bundle, atlas_metrology_report, metric_agreement_report, metric_consensus_report, regions=[]
        )
        metric_diagnostics_path = write_json(
            run / "diagnostics" / "metric_diagnostics_spec.json", json_safe(metric_diagnostics_spec)
        )
        overlay = _make_overlay(source_image, canonical, scene_bundle["integration_consistency"])
        if Image is not None:
            ov = _first_rgb(overlay)
            Image.fromarray(np.clip(np.rint(ov*255.0),0,255).astype(np.uint8), mode="RGB").save(run / "diagnostics" / "reprojection_overlay.png")
            support_mask = _projection_support_mask_from_canonical(
                canonical, int(scene_bundle["camera"]["image_width"]), int(scene_bundle["camera"]["image_height"])
            )
            Image.fromarray(support_mask, mode="L").save(run / "diagnostics" / "projection_support_mask.png")

        xyz = np.asarray(canonical["xyz"], dtype=np.float32)
        rgb = np.asarray(canonical["rgb"], dtype=np.uint8)
        _stage0607_log(run, f"PLY START points={len(xyz)}")
        ply_path = write_ply_binary(run / "geometry" / "canonical" / "pointcloud.ply", xyz, rgb)
        _stage0607_log(run, f"PLY DONE bytes={ply_path.stat().st_size if ply_path.exists() else 0}")
        preview_ply_path = None
        preview_warning = None
        try:
            preview_ply_path = copy_preview_ply(ply_path, run.name)
        except Exception as exc:
            preview_warning = str(exc)
            # The canonical PLY remains authoritative even if UI transport fails.
            write_json(run / "logs" / "preview_transport_warning.json", {"warning": preview_warning})
        geom_meta = {k:json_safe(v) for k,v in canonical.items() if k not in {"xyz","rgb","confidence","source_uv","grid_xy","source_pixel_id","camera_depth","geometric_boundary_strength"}}
        geom_meta["geometry_health"] = json_safe(scene_bundle["geometry_health"])
        write_json(run / "geometry" / "canonical" / "geometry.json", geom_meta)
        _stage0607_log(run, "USD START")
        canonical_usd_path = write_usda_points(
            run / "geometry" / "canonical" / "pointcloud.usda",
            xyz,
            rgb,
            point_width=float(PRESET_PARAMETERS.get(scene_bundle.get("preset","Max Reference"), PRESET_PARAMETERS["Max Reference"])["point_width"]),
            metadata={"engine": canonical["engine"], "point_count": len(xyz), "preset": scene_bundle.get("preset","Max Reference"), "geometry_profile": selected_profile, "model": profile["model"]},
        )
        # v0.32: one physical USDA authority only. Maya opens the same canonical
        # file through the run workspace instead of storing a byte-identical copy
        # under maya/.
        usd_path = canonical_usd_path
        _stage0607_log(run, f"USD DONE authority={usd_path.relative_to(run).as_posix()} bytes={canonical_usd_path.stat().st_size if canonical_usd_path.exists() else 0}")

        # Preserve authoritative MoGe evidence separately without tensors in the manifest.
        evidence = runtime.get("primary_evidence", {})
        try:
            if str(evidence.get("engine") or "").lower() != "moge":
                raise RuntimeError("v0.30 export received non-MoGe evidence")
            g = evidence.get("moge_geometry", {})
            base_names = {"points", "depth", "intrinsics", "mask", "normal"}
            arrays = {
                k: _to_numpy(v) for k, v in g.items()
                if k in base_names or str(k).startswith(("points_per_step_", "depth_per_step_", "intrinsics_per_step_"))
            }
            # A1 storage rule: native metric aliases are semantic/zero-copy in RAM
            # but are NOT written again. evidence.npz remains the single physical
            # authority for MoGe-native arrays.
            native_npz = run / "geometry" / "native" / "moge" / "evidence.npz"
            np.savez_compressed(native_npz, **arrays)
            metric_report = summarize_moge_native_metric(
                g, atlas_fov_x_deg=float(evidence.get("atlas_fov_x_deg") or 0.0)
            )
            metric_report["array_authority"] = str(native_npz)
            metric_report["array_keys"] = sorted(arrays)
            metric_report["duplicate_native_array_payloads_written"] = False
            write_json(run / "geometry" / "native" / "moge" / "metric_evidence.json", json_safe(metric_report))
            metadata = json_safe({k:v for k,v in evidence.items() if k not in {"moge_geometry","source_image"}})
            metadata["metric_evidence"] = {
                "path": str(run / "geometry" / "native" / "moge" / "metric_evidence.json"),
                "schema": metric_report.get("schema"),
                "status": metric_report.get("status"),
                "policy": metric_report.get("policy"),
            }
            write_json(run / "geometry" / "native" / "moge" / "metadata.json", metadata)
        except Exception as exc:
            raise RuntimeError(f"Failed to preserve authoritative MoGe evidence: {exc}") from exc

        # Solver-paired Maya geometry contract: CG_FUSED_POINTS and CG_HERO_MESH
        # always come from the same selected primary canonical solver.  The mesh
        # reuses canonical MoGe XYZ as its geometry authority. The upstream MoGe MESH input remains an
        # intermediate/diagnostic workflow output and is no longer the authority
        # for the Maya scene.
        _stage0607_log(run, "DCC TRANSPORT MESH START")
        hero_mesh_payload = _write_primary_mesh_payload(
            run, scene, canonical, scene_bundle["camera"], source_image,
            profile_config=profile,
            texture_path=src_path,
        )
        _stage0607_log(run, f"DCC TRANSPORT MESH DONE vertices={hero_mesh_payload.get('vertex_count')} faces={hero_mesh_payload.get('face_count')} stride={hero_mesh_payload.get('transport_stride', 1)}")


        # Maya worker contract is written before invocation; the worker updates maya_manifest.json.
        worker_input = {
            "schema": "ConceptGhost.MayaWorkerInput.v0.31",
            "scene_name": scene,
            "run_dir": str(run),
            "source_image": str(src_path),
            "ghost_usda": str(usd_path),
            "camera": json_safe(scene_bundle["camera"]),
            "coordinate_convention": dict(CANONICAL_COORDINATES),
            "point_count": int(len(xyz)),
            "geometry_engine": "moge",
            "geometry_profile": selected_profile,
            "selected_profile": selected_profile,
            "effective_profile": selected_profile,
            "profile_config": json_safe(profile),
            "mesher_policy": hero_mesh_payload.get("mesher_policy"),
            "model": profile["model"],
            "resolution_level": profile["resolution_level"],
            "refine_steps": profile["refine_steps"],
            "hero_mesh_payload": hero_mesh_payload,
            "mesh_profile_config": json_safe(profile.get("mesh_profile_config") or {}),
            "discontinuity_threshold": hero_mesh_payload.get("discontinuity_threshold"),
            "depth_edge_rtol": hero_mesh_payload.get("depth_edge_rtol"),
            "long_triangle_policy": hero_mesh_payload.get("long_triangle_policy"),
            "connected_components_policy": hero_mesh_payload.get("connected_components_policy"),
            "boundary_cleanup_policy": hero_mesh_payload.get("boundary_cleanup_policy"),
            "metric_diagnostics_spec": json_safe(metric_diagnostics_spec),
        }
        worker_input_path = write_json(run / "maya" / "maya_worker_input.json", worker_input)
        maya_ok = False
        fbx_ok = False
        worker_message = "Maya worker not attempted on this platform"
        bat = Path(__file__).with_name("run_maya_worker.bat")
        if os.name == "nt" and bat.exists():
            # High Fidelity can legitimately spend a long time authoring and
            # round-tripping a 1M+ vertex / multi-million-triangle mesh in Maya.
            # Quality is authoritative; timeout must not act as a hidden quality cap.
            worker_timeout_seconds = 10800 if selected_profile in {"High Fidelity", "High Fidelity Split Clean"} else 420
            _stage0607_log(run, f"MAYA WORKER START timeout={worker_timeout_seconds}s")
            proc = None
            try:
                creationflags = int(getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
                proc = subprocess.Popen(
                    ["cmd", "/c", str(bat), str(worker_input_path)],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, creationflags=creationflags,
                )
                stdout, stderr = proc.communicate(timeout=worker_timeout_seconds)
                (run / "logs" / "maya_worker_stdout.txt").write_text(stdout or "", encoding="utf-8")
                (run / "logs" / "maya_worker_stderr.txt").write_text(stderr or "", encoding="utf-8")
                worker_message = f"Maya worker exit={proc.returncode}"
                _stage0607_log(run, worker_message)
            except subprocess.TimeoutExpired:
                worker_message = f"Maya worker TIMEOUT after {worker_timeout_seconds}s"
                _stage0607_log(run, worker_message)
                if proc is not None:
                    try:
                        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, text=True, timeout=30)
                    except Exception:
                        try: proc.kill()
                        except Exception: pass
                    try: stdout, stderr = proc.communicate(timeout=10)
                    except Exception: stdout, stderr = "", ""
                    (run / "logs" / "maya_worker_stdout.txt").write_text(stdout or "", encoding="utf-8")
                    (run / "logs" / "maya_worker_stderr.txt").write_text(stderr or "", encoding="utf-8")
                write_json(run / "logs" / "maya_worker_timeout.json", {"timeout_seconds": worker_timeout_seconds, "message": worker_message})
            except Exception as exc:
                worker_message = f"Maya worker error: {exc}"
                _stage0607_log(run, worker_message)
        ma_path = run / "maya" / f"ConceptGhost_{scene}_Ghost.ma"
        fbx_path = run / "maya" / f"ConceptGhost_{scene}_Ghost.fbx"
        camera_fbx_path = run / "maya" / f"ConceptGhost_{scene}_CameraOnly.fbx"
        full_scene_fbx_path = run / "maya" / f"ConceptGhost_{scene}_GhostFullScene.fbx"
        maya_ok, fbx_ok, maya_worker_manifest = _maya_artifact_status(run, ma_path, fbx_path)
        if selected_profile in {"High Fidelity", "High Fidelity Split Clean"} and os.name == "nt" and not (isinstance(maya_worker_manifest, dict) and maya_worker_manifest):
            raise RuntimeError(
                "[EXPORT_BUNDLE] High Fidelity on Windows requires a Maya worker manifest; "
                f"worker result was unavailable ({worker_message})"
            )
        if isinstance(maya_worker_manifest, dict) and maya_worker_manifest:
            # If Maya ran, its result is authoritative and must satisfy the
            # same fail-closed profile/normal/FBX contract as the worker.
            assert_maya_manifest_contract(
                maya_worker_manifest,
                profile,
                stage="EXPORT_BUNDLE_MAYA_MANIFEST",
                require_runtime_gates=True,
            )
        ply_ok, usd_ok = ply_path.exists(), usd_path.exists()
        status = derive_run_status(
            camera_valid=bool(scene_bundle["camera"].get("valid")),
            geometry_has_points=bool(len(xyz)),
            integration_pass=bool(scene_bundle["integration_consistency"].get("pass")),
            geometry_health_pass=bool(scene_bundle["geometry_health"].get("pass")),
            maya_ok=maya_ok,
            ply_ok=ply_ok,
            usd_ok=usd_ok,
            fbx_ok=fbx_ok,
        )
        manifest = {
            "schema": "ConceptGhost.Manifest.v0.31",
            "scene": scene,
            "run_id": run.name,
            "preset": scene_bundle.get("preset"),
            "geometry_profile": selected_profile,
            "selected_profile": selected_profile,
            "effective_profile": selected_profile,
            "profile_config": json_safe(profile),
            "camera": json_safe(scene_bundle["camera"].get("provenance", {})),
            "geometry": {
                "engine": canonical["engine"],
                "point_count": int(len(xyz)),
                "health": json_safe(scene_bundle["geometry_health"]),
                "native_metric_evidence": {
                    "schema": metric_report.get("schema"),
                    "status": metric_report.get("status"),
                    "policy": metric_report.get("policy"),
                    "path": str(run / "geometry" / "native" / "moge" / "metric_evidence.json"),
                    "support_ratio": ((metric_report.get("points_metric_native") or {}).get("support_ratio")),
                    "atlas_intrinsics_comparison_state": ((metric_report.get("atlas_vs_moge_intrinsics") or {}).get("state")),
                },
            },
            "synergy_contributors": json_safe(scene_bundle.get("synergy_contributors", [])),
            "primary_authority": json_safe(scene_bundle.get("primary_authority", {})),
            "metric_diagnostics": {
                "status": metric_diagnostics_spec.get("status"),
                "policy": metric_diagnostics_spec.get("policy"),
                "path": str(metric_diagnostics_path),
                "helper_count": len(metric_diagnostics_spec.get("helpers") or []),
                "agreement_state": (metric_diagnostics_spec.get("agreement") or {}).get("state"),
                "region_count": len(metric_diagnostics_spec.get("regions") or []),
            },
            "integration_consistency": json_safe(scene_bundle["integration_consistency"]),
            "coordinate_convention": dict(CANONICAL_COORDINATES),
            "status": status,
            "worker_message": worker_message,
            "maya_worker_manifest": json_safe(maya_worker_manifest),
            "hero_mesh": {
                "requested": True,
                "source_engine": canonical.get("engine"),
                "alignment": hero_mesh_payload.get("alignment"),
                "payload": json_safe(hero_mesh_payload),
                "maya_status": json_safe((maya_worker_manifest or {}).get("hero_mesh", {})) if isinstance(maya_worker_manifest, dict) else {},
            },
            "outputs": {
                "ply": {"status": "PASS" if ply_ok else "FAIL", "path": str(ply_path), "sha256": sha256_file(ply_path) if ply_ok else None},
                "preview_ply": {
                    "status": "PASS" if (preview_ply_path and Path(preview_ply_path).is_file()) else "WARN",
                    "path": str(preview_ply_path) if preview_ply_path else None,
                    "sha256": sha256_file(preview_ply_path) if (preview_ply_path and Path(preview_ply_path).is_file()) else None,
                    "authority": "viewer-cache-only; canonical PLY remains authoritative",
                    "warning": preview_warning,
                },
                "usd": {"status": "PASS" if usd_ok else "FAIL", "path": str(usd_path), "sha256": sha256_file(usd_path) if usd_ok else None},
                "ma": {"status": "PASS" if maya_ok else "FAIL", "path": str(ma_path)},
                "fbx": {"status": "PASS" if fbx_ok else "FAIL", "path": str(fbx_path)},
                "full_scene_fbx": {
                    "status": str(((maya_worker_manifest or {}).get("full_scene_fbx") or {}).get("status") or "PENDING_RUNTIME") if isinstance(maya_worker_manifest, dict) else "PENDING_RUNTIME",
                    "path": str(full_scene_fbx_path),
                },
                "camera_only_fbx": {
                    "status": str(((maya_worker_manifest or {}).get("camera_only_fbx") or {}).get("status") or "PENDING_RUNTIME") if isinstance(maya_worker_manifest, dict) else "PENDING_RUNTIME",
                    "path": str(camera_fbx_path),
                },
                "fbm": json_safe((maya_worker_manifest or {}).get("fbm", {})) if isinstance(maya_worker_manifest, dict) else {},
                "normal_validation": json_safe((maya_worker_manifest or {}).get("normal_validation", {})) if isinstance(maya_worker_manifest, dict) else {"pre_maya": hero_mesh_payload.get("normal_validation")},
                "moge_metric_evidence": {
                    "status": "PASS",
                    "path": str(run / "geometry" / "native" / "moge" / "metric_evidence.json"),
                    "array_authority": str(run / "geometry" / "native" / "moge" / "evidence.npz"),
                    "policy": "report_only_no_geometry_movement",
                },
            },
        }
        if isinstance(maya_worker_manifest, dict) and maya_worker_manifest:
            assert_final_manifest_contract(
                manifest,
                profile,
                stage="EXPORT_BUNDLE_FINAL_MANIFEST",
                require_runtime_gates=True,
            )
        manifest_path = write_json(run / "manifest.json", manifest)
        _stage0607_log(run, f"EXIT status={status['run_status']}")
        output_index = {
            "schema": "ConceptGhost.OutputIndex.v0.31",
            "run_id": run.name,
            "geometry_profile": selected_profile,
            "selected_profile": selected_profile,
            "effective_profile": selected_profile,
            "model": profile["model"],
            "mesher_policy": hero_mesh_payload.get("mesher_policy"),
            "transport_stride": hero_mesh_payload.get("transport_stride"),
            "depth_edge_rtol": hero_mesh_payload.get("depth_edge_rtol"),
            "policy": "Official artist outputs are separated from intermediate/diagnostic evidence.",
            "official": {
                "matched_camera": {"path": str(camera_json), "role": "OFFICIAL_CAMERA"},
                "canonical_pointcloud": {"path": str(ply_path), "role": "OFFICIAL_GEOMETRY"},
                "canonical_usd": {"path": str(usd_path), "role": "OFFICIAL_INTERCHANGE"},
                "primary_mesh": {
                    "path": str(hero_mesh_payload.get("npz_path")),
                    "role": "OFFICIAL_MODELING_REFERENCE_MESH",
                    "source_engine": canonical.get("engine"),
                    "alignment": hero_mesh_payload.get("alignment"),
                    "visibility_in_maya": "OFF_BY_DEFAULT",
                    "axis_policy": "canonical_world_no_extra_yz_flip",
                },
                "full_scene_fbx": {
                    "path": str(full_scene_fbx_path),
                    "role": "FULL_SCENE_PARITY_CANDIDATE",
                    "status": str(((maya_worker_manifest or {}).get("full_scene_fbx") or {}).get("status") or "PENDING_RUNTIME") if isinstance(maya_worker_manifest, dict) else "PENDING_RUNTIME",
                    "contains_when_validated": ["CG_MATCHED_CAMERA", "CG_ARTIST_CAMERA", "CG_HERO_MESH"],
                },
                "camera_only_fbx": {
                    "path": str(camera_fbx_path),
                    "role": "OFFICIAL_CAMERA_INTERCHANGE_BACKUP",
                    "status": str(((maya_worker_manifest or {}).get("camera_only_fbx") or {}).get("status") or "PENDING_RUNTIME") if isinstance(maya_worker_manifest, dict) else "PENDING_RUNTIME",
                },
                "maya_scene": {
                    "path": str(ma_path), "role": "OFFICIAL_ARTIST_SCENE", "status": "PASS" if maya_ok else "PENDING_RUNTIME",
                    "contains": ["CG_MATCHED_CAMERA", "CG_ARTIST_CAMERA", "CG_HERO_MESH", "CG_FUSED_POINTS", "CG_METRIC_DIAGNOSTICS", "CG_REGIONS"],
                    "hero_mesh_visibility_default": "OFF",
                    "geometry_pair_contract": "CG_FUSED_POINTS + CG_HERO_MESH use the same primary canonical solver XYZ",
                    "source_engine": canonical.get("engine"),
                    "alignment": hero_mesh_payload.get("alignment"),
                },
                "fbx_interchange": {
                    "path": str(fbx_path), "role": "OFFICIAL_INTERCHANGE", "status": "PASS" if fbx_ok else "PENDING_RUNTIME",
                    "contains_when_stage11_plus": ["CG_MATCHED_CAMERA", "CG_ARTIST_CAMERA", "CG_HERO_MESH"],
                    "source_engine": canonical.get("engine"),
                    "mesh_alignment": hero_mesh_payload.get("alignment"),
                },
                "manifest": {"path": str(manifest_path), "role": "OFFICIAL_MANIFEST"},
            },
            "intermediate": {
                "E1_ATLAS_RELIEF": {
                    "role": "INTERMEDIATE_DIAGNOSTIC",
                    "label": "E1 · Atlas Relief",
                    "track_report": str(run / "meshes" / "atlas_relief" / "track.json"),
                    "status": "PENDING_STAGE10",
                },
                "E2_MOGE_NATIVE_MESH": {
                    "role": "INTERMEDIATE_DIAGNOSTIC",
                    "label": "E2 · MoGe Native Preview Mesh",
                    "workflow_output_prefix": "conceptghost/moge_stage11",
                    "coordinate_space": "native MoGe/OpenCV camera space",
                    "uv_policy": "native; intended for ComfyUI preview",
                    "status": "PROVIDER_MANAGED_OUTPUT",
                },
                "E2_MOGE_MAYA_DCC": {
                    "role": "INTERMEDIATE_DCC_EXPORT",
                    "label": "E2-DCC · MoGe Maya-ready Mesh",
                    "workflow_output_prefix": "conceptghost/moge_stage11_maya",
                    "coordinate_space": "Atlas world / ConceptGhost canonical axes",
                    "uv_policy": "V flipped for Maya/DCC",
                    "maya_payload": None,
                    "embedded_in_maya_scene": False,
                    "status": "PROVIDER_MANAGED_OUTPUT_DIAGNOSTIC_ONLY",
                },
            },
            "diagnostics": {
                "projection_support_mask": {"path": str(run / "diagnostics" / "projection_support_mask.png")},
                "reprojection_overlay": {"path": str(run / "diagnostics" / "reprojection_overlay.png")},
                "reprojection_report": {"path": str(run / "diagnostics" / "reprojection_report.json")},
                "geometry_health": {"path": str(run / "diagnostics" / "geometry_health.json")},
                "metric_diagnostics_spec": {
                    "path": str(metric_diagnostics_path),
                    "role": "MAYA_REPORT_ONLY_DIAGNOSTIC_SPEC",
                    "status": metric_diagnostics_spec.get("status"),
                    "moves_official_geometry": False,
                    "moves_camera": False,
                },
                "moge_metric_evidence": {
                    "path": str(run / "geometry" / "native" / "moge" / "metric_evidence.json"),
                    "array_authority": str(run / "geometry" / "native" / "moge" / "evidence.npz"),
                    "role": "NATIVE_METRIC_REPORT_ONLY",
                    "moves_official_geometry": False,
                },
            },
        }
        write_json(run / "output_index.json", output_index)
        result = (
            str(run), str(ply_path), str(preview_ply_path or ply_path), str(usd_path), str(ma_path), str(fbx_path), str(manifest_path), status["run_status"]
        )
        ui_text = [
            f"ConceptGhost {status['run_status']}",
            f"Run: {run}",
            f"Points: {len(xyz):,}",
            f"MoGe native metric support: {float(((metric_report.get('points_metric_native') or {}).get('support_ratio') or 0.0))*100.0:.2f}%",
            f"PLY: {'OK' if ply_ok else 'FAIL'}",
            f"USD: {'OK' if usd_ok else 'FAIL'}",
            f"Maya: {'OK' if maya_ok else 'PENDING/FAIL'}",
            worker_message,
        ]
        return {"ui": {"text": ui_text}, "result": result}


class ConceptGhostSelectedAtlasSolve:
    """Expose the same Atlas solve selected by CameraRouter for downstream native Atlas tracks.

    This keeps Stage 10+ on the exact same camera decision as the canonical Ghost path
    without changing CameraRouter's established output contract.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "camera_mode": ("STRING", {"forceInput": True}),
                "learned_solve": ("ATLAS_SOLVE", {"lazy": True}),
                "vp_solve": ("ATLAS_SOLVE", {"lazy": True}),
            }
        }

    RETURN_TYPES = ("ATLAS_SOLVE", "STRING")
    RETURN_NAMES = ("selected_solve", "selection_report")
    FUNCTION = "route"
    CATEGORY = "ConceptGhost/02 Camera"

    def check_lazy_status(self, camera_mode, learned_solve=None, vp_solve=None):
        if camera_mode == "Atlas Learned":
            return ["learned_solve"] if learned_solve is None else []
        if camera_mode == "Atlas VP":
            return ["vp_solve"] if vp_solve is None else []
        if learned_solve is None:
            return ["learned_solve"]
        learned = camera_bundle_from_atlas_solve(learned_solve, requested_mode="Auto", final_solver="Atlas Learned")
        if learned.get("valid"):
            return []
        return ["vp_solve"] if vp_solve is None else []

    def route(self, camera_mode, learned_solve=None, vp_solve=None):
        if camera_mode == "Atlas Learned":
            selected = learned_solve
            solver = "Atlas Learned"
        elif camera_mode == "Atlas VP":
            selected = vp_solve
            solver = "Atlas VP"
        else:
            learned = camera_bundle_from_atlas_solve(learned_solve, requested_mode="Auto", final_solver="Atlas Learned")
            if learned.get("valid"):
                selected = learned_solve
                solver = "Atlas Learned"
            else:
                selected = vp_solve
                solver = "Atlas VP"
        if selected is None:
            raise RuntimeError("No Atlas solve available for selected camera mode")
        return (selected, _safe_text({"requested_mode": camera_mode, "selected_solver": solver}))


class ConceptGhostStageAudit:
    """Stage 9 structural audit.

    It records the run configuration and output status but never blocks downstream
    stages because of quality warnings. Only missing structural inputs raise errors.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "manifest_path": ("STRING", {"forceInput": True}),
                "camera_report": ("STRING", {"forceInput": True}),
                "profile_report": ("STRING", {"forceInput": True}),
                "scene_report": ("STRING", {"forceInput": True}),
                "run_status": ("STRING", {"forceInput": True}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("stage9_report_path", "stage9_status")
    FUNCTION = "write"
    CATEGORY = "ConceptGhost/09 Audit"
    OUTPUT_NODE = True

    def write(self, run_dir, manifest_path, camera_report, profile_report, scene_report, run_status):
        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir))))
        if not run.is_dir():
            raise RuntimeError(f"ConceptGhost run_dir does not exist: {run}")
        manifest = Path(os.path.expandvars(os.path.expanduser(str(manifest_path))))
        if not manifest.is_file():
            raise RuntimeError(f"ConceptGhost manifest does not exist: {manifest}")
        out = run / "benchmark" / "stage09_run_summary.json"
        payload = {
            "schema": "ConceptGhost.Stage09RunSummary.v0.30",
            "structural_status": "PASS",
            "quality_status": str(run_status),
            "policy": "Quality warnings do not block downstream stages; only structural/runtime failures block.",
            "manifest_path": str(manifest),
            "camera_report": camera_report,
            "geometry_profile_report": profile_report,
            "scene_report": scene_report,
        }
        write_json(out, payload)
        return (str(out), "PASS")






def _refine_moge_projection_support(moge_geometry, discontinuity_threshold: float = 0.20):
    geom = dict(moge_geometry)
    points = geom.get("points")
    if points is None:
        raise ValueError("moge_geometry has no points output")
    points_np = _to_numpy(points, np.float32)
    if points_np.ndim != 4 or points_np.shape[-1] != 3:
        raise ValueError(f"MoGe points must be BxHxWx3, got {points_np.shape}")
    b, h, w, _ = points_np.shape
    depth_obj = geom.get("depth")
    depth_np = _to_numpy(depth_obj, np.float32) if depth_obj is not None else np.linalg.norm(points_np, axis=-1)
    if depth_np.ndim == 4 and depth_np.shape[-1] == 1:
        depth_np = depth_np[..., 0]
    mask_obj = geom.get("mask")
    if mask_obj is None:
        base = np.ones((b, h, w), dtype=bool)
    else:
        base = _to_numpy(mask_obj).astype(bool)
        if base.ndim == 4 and base.shape[-1] == 1:
            base = base[..., 0]
    finite = np.isfinite(points_np).all(axis=-1) & np.isfinite(depth_np) & (depth_np > 0)
    support_np = base & finite
    if discontinuity_threshold > 0:
        for i in range(b):
            d = np.where(finite[i], depth_np[i], np.nan)
            padded = np.pad(d, 1, mode="edge")
            windows = np.lib.stride_tricks.sliding_window_view(padded, (3, 3))
            local_max = np.nanmax(windows, axis=(-2, -1))
            local_min = np.nanmin(windows, axis=(-2, -1))
            span = (local_max - local_min) / np.maximum(np.abs(depth_np[i]), 1e-6)
            edge = np.nan_to_num(span, nan=np.inf, posinf=np.inf, neginf=np.inf) > float(low_resolution_projection_threshold)
            support_np[i] &= ~edge
    if torch is not None and hasattr(torch, "is_tensor") and torch.is_tensor(points):
        support = torch.as_tensor(support_np, device=points.device, dtype=torch.bool)
        pts_out = points.clone()
        pts_out[~support] = float("inf")
        geom["points"] = pts_out
        if depth_obj is not None and hasattr(depth_obj, "clone"):
            dep_out = depth_obj.clone()
            dep_out[~support] = float("inf")
            geom["depth"] = dep_out
        geom["mask"] = support
    else:
        support = support_np
        pts_out = np.array(points_np, copy=True)
        pts_out[~support_np] = np.inf
        geom["points"] = pts_out
        if depth_obj is not None:
            dep_out = np.array(depth_np, copy=True)
            dep_out[~support_np] = np.inf
            geom["depth"] = dep_out
        geom["mask"] = support_np
    geom["conceptghost_projection_support"] = support
    return geom, support


class ConceptGhostMoGeProjectionSupport:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "moge_geometry": ("MOGE_GEOMETRY",),
            "profile_config": ("CG_GEOMETRY_PROFILE",),
            "low_resolution_projection_threshold": ("FLOAT", {"default": 0.20, "min": 0.0, "max": 2.0, "step": 0.01}),
        }}

    RETURN_TYPES = ("MOGE_GEOMETRY",)
    RETURN_NAMES = ("moge_geometry",)
    FUNCTION = "refine"
    CATEGORY = "ConceptGhost/03 Geometry Evidence"

    def refine(self, moge_geometry, profile_config, low_resolution_projection_threshold):
        profile = assert_profile_contract(dict(profile_config or {}), stage="MOGE_PROJECTION_SUPPORT")
        profile_name = str(profile["selected_profile"])
        # High Fidelity preserves the raw MoGe-3 point/depth map. Edge removal is
        # deferred to the profile-aware mesher, where it cuts topology without
        # destroying the underlying canonical geometry. Low Resolution keeps the legacy lightweight path.
        threshold = 0.0 if profile_name in {"High Fidelity", "High Fidelity Split Clean"} else float(low_resolution_projection_threshold)
        refined, _ = _refine_moge_projection_support(moge_geometry, threshold)
        refined["conceptghost_projection_support_policy"] = {
            "geometry_profile": profile_name,
            "threshold": threshold,
            "edge_removal_deferred_to_mesher": bool(profile_name in {"High Fidelity", "High Fidelity Split Clean"}),
        }
        return (refined,)


def _projection_support_mask_from_canonical(canonical, width: int, height: int) -> np.ndarray:
    mask = np.zeros((int(height), int(width)), dtype=np.uint8)
    uv = np.asarray(canonical.get("source_uv", []), dtype=np.float32).reshape((-1, 2))
    if not len(uv):
        return mask
    x = np.rint(uv[:, 0]).astype(np.int64)
    y = np.rint(uv[:, 1]).astype(np.int64)
    good = (x >= 0) & (x < width) & (y >= 0) & (y < height)
    mask[y[good], x[good]] = 255
    return mask


def _clone_array_like(value):
    if hasattr(value, "clone"):
        return value.clone()
    return np.array(value, copy=True)


def _assign_array_like(target, values_np: np.ndarray):
    if torch is not None and hasattr(target, "detach") and hasattr(target, "device"):
        return torch.as_tensor(values_np, dtype=target.dtype, device=target.device)
    return np.asarray(values_np, dtype=getattr(target, "dtype", None))







def _prepare_moge_mesh_for_dcc(mesh, moge_geometry, camera_bundle):
    """Copy native MoGe mesh into Atlas/ConceptGhost world space for DCC export.

    Native preview is intentionally untouched.  The DCC branch converts OpenCV
    camera axes (+X right, +Y down, +Z forward) to ConceptGhost camera-local
    axes, applies the same metric registration policy as canonical MoGe, then
    applies Atlas camera-to-world.  UV V is flipped only on this export copy.
    """
    fixed = copy.copy(mesh)
    vertices = getattr(mesh, "vertices", None)
    if vertices is None:
        raise ValueError("MoGe MESH has no vertices attribute; cannot prepare DCC export")
    v_np = _to_numpy(vertices, np.float32).reshape((-1, 3)).copy()
    local_vertices = v_np.copy()
    local_vertices[:, 1] *= -1.0
    local_vertices[:, 2] *= -1.0

    points = _to_numpy((moge_geometry or {}).get("points"), np.float32)
    if points.ndim == 4:
        points = points[0]
    if points.ndim != 3 or points.shape[-1] != 3:
        raise ValueError(f"MoGe geometry points must resolve to HxWx3, got {points.shape}")
    local_grid = points.copy()
    local_grid[..., 1] *= -1.0
    local_grid[..., 2] *= -1.0
    mask = _to_numpy((moge_geometry or {}).get("mask"))
    if mask.size == 0:
        valid = np.isfinite(local_grid).all(axis=-1)
    else:
        if mask.ndim == 3:
            mask = mask[0]
        valid = mask.astype(bool) & np.isfinite(local_grid).all(axis=-1)
    metric_scale, metric_report = atlas_metric_scale_registration(camera_bundle, local_grid, valid)
    local_vertices *= float(metric_scale)

    world = np.asarray(camera_bundle["extrinsics"]["camera_world_matrix"], dtype=np.float64)
    if world.shape != (4, 4) or not np.isfinite(world).all():
        raise ValueError("CameraBundle requires a finite 4x4 camera_world_matrix for DCC mesh export")
    homo = np.concatenate([local_vertices.astype(np.float64), np.ones((len(local_vertices), 1), dtype=np.float64)], axis=1)
    world_vertices = (world @ homo.T).T[:, :3].astype(np.float32)
    fixed.vertices = _assign_array_like(vertices, world_vertices.reshape(_to_numpy(vertices).shape))

    uvs = getattr(mesh, "uvs", None)
    if uvs is not None:
        uv_np = _to_numpy(uvs, np.float32).copy()
        uv_np[..., 1] = 1.0 - uv_np[..., 1]
        fixed.uvs = _assign_array_like(uvs, uv_np)

    return fixed, {
        "coordinate_space": "Atlas world / ConceptGhost canonical axes",
        "native_axes": "+X right, +Y down, +Z forward",
        "dcc_axes_conversion": "X, -Y, -Z then Atlas camera_world_matrix",
        "uv_policy": "V flipped for Maya/DCC only",
        "metric_scale": float(metric_scale),
        "metric_registration": json_safe(metric_report),
    }


class ConceptGhostMeshForDCC:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "mesh": ("MESH",),
            "moge_geometry": ("MOGE_GEOMETRY",),
            "camera_bundle": (CG_CAMERA_BUNDLE,),
        }}

    RETURN_TYPES = ("MESH", "STRING")
    RETURN_NAMES = ("mesh", "dcc_report")
    FUNCTION = "prepare"
    CATEGORY = "ConceptGhost/11 Mesh Refinement"

    def prepare(self, mesh, moge_geometry, camera_bundle):
        fixed, report = _prepare_moge_mesh_for_dcc(mesh, moge_geometry, camera_bundle)
        return (fixed, _safe_text(report))


def _flip_mesh_uv_v(mesh):
    """Return a shallow-copied mesh with V flipped for Maya/DCC compatibility."""
    fixed = copy.copy(mesh)
    uvs = getattr(mesh, "uvs", None)
    if uvs is None:
        return fixed
    if hasattr(uvs, "clone"):
        new_uvs = uvs.clone()
    else:
        new_uvs = np.array(uvs, copy=True)
    new_uvs[..., 1] = 1.0 - new_uvs[..., 1]
    fixed.uvs = new_uvs
    return fixed


class ConceptGhostMeshUVFix:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"mesh": ("MESH",)}}

    RETURN_TYPES = ("MESH",)
    RETURN_NAMES = ("mesh",)
    FUNCTION = "fix"
    CATEGORY = "ConceptGhost/11 Mesh Refinement"

    def fix(self, mesh):
        return (_flip_mesh_uv_v(mesh),)



class ConceptGhostPointCloudPreview:
    """Artist-facing preview for the existing canonical point-cloud transport.

    The input is the `preview_ply` path already produced by ExportBundle. No
    additional PLY copy is created here.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"preview_ply": ("STRING", {"forceInput": True})}}

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("preview_ply",)
    FUNCTION = "preview"
    CATEGORY = "ConceptGhost/11 Artist Outputs"
    OUTPUT_NODE = True

    def preview(self, preview_ply):
        value = str(preview_ply or "").strip()
        if not value:
            return {"ui": {"text": ["Point cloud preview skipped: no preview path"]}, "result": ("",)}
        path = Path(os.path.expandvars(os.path.expanduser(value))).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"ConceptGhost point-cloud preview is missing: {path}")
        ui = {"text": [f"Canonical fused-points preview: {path.name}"]}
        if folder_paths is not None:
            output_root = Path(folder_paths.get_output_directory()).resolve()
            try:
                rel = path.relative_to(output_root)
                ui["3d"] = [{
                    "filename": rel.name,
                    "subfolder": str(rel.parent).replace("\\", "/") if str(rel.parent) != "." else "",
                    "type": "output",
                }]
            except ValueError:
                ui["text"].append("Preview path is outside ComfyUI output; path returned without another copy.")
        return {"ui": ui, "result": (str(path),)}


class ConceptGhost3DAssetPreview:
    """Preview/download one GLB output while preferring a same-volume hard link."""
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "asset_path": ("STRING", {"forceInput": True}),
            "label": ("STRING", {"default": "ConceptGhost 3D Output"}),
        }}

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("asset_path",)
    FUNCTION = "preview"
    CATEGORY = "ConceptGhost/11 Artist Outputs"
    OUTPUT_NODE = True

    def preview(self, asset_path, label="ConceptGhost 3D Output"):
        value = str(asset_path or "").strip()
        if not value:
            return {"ui": {"text": [f"{label}: SKIPPED / not generated"]}, "result": ("",)}
        src = Path(os.path.expandvars(os.path.expanduser(value))).resolve()
        if not src.is_file():
            raise FileNotFoundError(f"ConceptGhost 3D output is missing: {src}")
        ui = {"text": [f"{label}: {src.name}"]}
        result_path = src
        if folder_paths is not None:
            out_root = Path(folder_paths.get_output_directory()) / "conceptghost" / "artist_outputs" / src.parent.parent.name
            dst = out_root / src.name
            result_path, transport_mode = link_or_copy_transport(src, dst)
            ui["text"].append(f"transport={transport_mode}")
            ui["3d"] = [{
                "filename": result_path.name,
                "subfolder": str(Path("conceptghost") / "artist_outputs" / src.parent.parent.name).replace("\\", "/"),
                "type": "output",
            }]
        return {"ui": ui, "result": (str(result_path),)}


class ConceptGhostGLBFileFromPath:
    """Bridge a ConceptGhost GLB path into ComfyUI's native FILE_3D_GLB type.

    This exists so artist-facing outputs can terminate in the core SaveGLB node,
    which provides the native 3D viewer/download UX. Empty optional paths are
    silently blocked (for example Remesh Light/Medium/Strong when the master
    remesh switch is OFF).
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"asset_path": ("STRING", {"forceInput": True})}}

    RETURN_TYPES = ("FILE_3D_GLB",)
    RETURN_NAMES = ("model_3d",)
    FUNCTION = "load_file"
    CATEGORY = "ConceptGhost/11 Artist Outputs"

    def load_file(self, asset_path):
        value = str(asset_path or "").strip()
        if not value:
            return (ExecutionBlocker(None),)
        src = Path(os.path.expandvars(os.path.expanduser(value))).resolve()
        if not src.is_file():
            raise FileNotFoundError(f"ConceptGhost GLB output is missing: {src}")
        if src.suffix.lower() != ".glb":
            raise ValueError(f"ConceptGhost artist output must be GLB: {src}")
        if ComfyTypes is None:
            raise RuntimeError("ComfyUI FILE_3D API is unavailable; update/repair ComfyUI before using artist download outputs")
        return (ComfyTypes.File3D(source=str(src), file_format="glb"),)


class ConceptGhostPrimaryRemeshExporter:
    """v0.32 PrimaryMesh Master + optional Light/Medium/Strong remesh branches."""
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "profile_config": ("CG_GEOMETRY_PROFILE",),
            },
            "optional": {
                "generate_remesh_variants": ("BOOLEAN", {"default": False}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("primary_master_glb", "remesh_light_glb", "remesh_medium_glb", "remesh_strong_glb", "report")
    FUNCTION = "export_outputs"
    CATEGORY = "ConceptGhost/11 Artist Outputs"
    OUTPUT_NODE = True

    def export_outputs(self, run_dir, profile_config, generate_remesh_variants=False):
        profile = assert_profile_contract(dict(profile_config or {}), stage="PRIMARY_REMESH_VARIANTS")
        if str(profile["selected_profile"]) not in {"High Fidelity", "High Fidelity Split Clean"}:
            report = {
                "status": "SKIPPED",
                "reason": "Primary/remesh artist outputs are generated only for High Fidelity profiles",
                "active_profile": profile["selected_profile"],
                "generate_remesh_variants": bool(generate_remesh_variants),
            }
            return {"ui": {"text": [_safe_text(report)]}, "result": ("", "", "", "", _safe_text(report))}

        info = export_primary_and_remesh_variants(
            run_dir,
            generate_remesh_variants=bool(generate_remesh_variants),
        )
        if info.get("status") != "PASS":
            return {"ui": {"text": [_safe_text(info)]}, "result": ("", "", "", "", _safe_text(info))}

        remesh = info.get("remesh_variants") or {}
        light = str((remesh.get("light") or {}).get("path") or "")
        medium = str((remesh.get("medium") or {}).get("path") or "")
        strong = str((remesh.get("strong") or {}).get("path") or "")
        ui_lines = [
            f"PrimaryMesh Master: {info['master']['vertices']:,} vertices / {info['master']['faces']:,} faces",
            f"Generate Remesh Variants: {'ON' if generate_remesh_variants else 'OFF'}",
        ]
        if generate_remesh_variants:
            for key, title in (("light", "Light"), ("medium", "Medium"), ("strong", "Strong")):
                item = remesh[key]
                ui_lines.append(f"Remesh {title}: {item['output_vertices']:,} vertices / {item['output_faces']:,} faces")
        else:
            ui_lines.append("Light / Medium / Strong skipped before computation.")
        return {
            "ui": {"text": ui_lines},
            "result": (str(info["master"]["path"]), light, medium, strong, _safe_text(info)),
        }


class ConceptGhostHFVariantExporter:
    """Export three artist-facing HF GLBs from the exact Maya PrimaryMesh authority.

    The variants are generated from `primary_mesh_payload.json`, not from the
    provider preview mesh. Therefore HF Master is spatially/topologically the
    same authoritative mesh used to author CG_HERO_MESH in Maya. Every GLB also
    embeds a perspective camera node named CG_ARTIST_CAMERA in the same world
    transform used by the .ma scene.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "run_dir": ("STRING", {"forceInput": True}),
            "profile_config": ("CG_GEOMETRY_PROFILE",),
        }}

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("hf_master_glb", "hf_split_clean_glb", "hf_simplified_proxy_glb", "report")
    FUNCTION = "export_variants"
    CATEGORY = "ConceptGhost/11 Mesh Refinement"
    OUTPUT_NODE = True

    def export_variants(self, run_dir, profile_config):
        profile = assert_profile_contract(dict(profile_config or {}), stage="HF_VARIANTS")
        if str(profile["selected_profile"]) not in {"High Fidelity", "High Fidelity Split Clean"}:
            report = {
                "status": "SKIPPED",
                "reason": "HF variants are generated only for High Fidelity profiles",
                "active_profile": profile["selected_profile"],
            }
            return {"ui": {"text": [_safe_text(report)]}, "result": ("", "", "", _safe_text(report))}

        info = export_hf_variants(run_dir)
        if info.get("status") != "PASS":
            return {"ui": {"text": [_safe_text(info)]}, "result": ("", "", "", _safe_text(info))}

        paths = [
            info["master"]["path"],
            info["split_clean"]["path"],
            info["simplified_proxy"]["path"],
        ]
        ui_3d = []
        if folder_paths is not None:
            out_root = Path(folder_paths.get_output_directory()) / "conceptghost" / "hf_variants" / Path(str(run_dir)).name
            out_root.mkdir(parents=True, exist_ok=True)
            for src in paths:
                srcp = Path(src)
                dst = out_root / srcp.name
                dst, transport_mode = link_or_copy_transport(srcp, dst)
                ui_3d.append({
                    "filename": dst.name,
                    "subfolder": str(Path("conceptghost") / "hf_variants" / Path(str(run_dir)).name).replace("\\", "/"),
                    "type": "output",
                })
        ui = {
            "text": [
                "HF Master = exact Maya PrimaryMesh authority + CG_ARTIST_CAMERA",
                f"HF Split Clean: {info['split_clean']['output_vertices']:,} vertices / {info['split_clean']['output_faces']:,} faces",
                f"HF Simplified Proxy: {info['simplified_proxy']['output_vertices']:,} vertices / {info['simplified_proxy']['output_faces']:,} faces",
            ]
        }
        if ui_3d:
            ui["3d"] = ui_3d
        return {
            "ui": ui,
            "result": (paths[0], paths[1], paths[2], _safe_text(info)),
        }


class ConceptGhostMeshTrackRecorder:
    """Non-blocking manifest recorder that also makes upstream mesh tracks executable outputs."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "mesh_path": ("STRING", {"forceInput": True}),
                "upstream_report": ("STRING", {"forceInput": True}),
                "track_name": ("STRING", {"default": "atlas_relief"}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING")
    RETURN_NAMES = ("track_report_path", "track_status")
    FUNCTION = "record"
    CATEGORY = "ConceptGhost/10-12 Mesh Tracks"
    OUTPUT_NODE = True

    def record(self, run_dir, mesh_path, upstream_report, track_name):
        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir))))
        if not run.is_dir():
            raise RuntimeError(f"ConceptGhost run_dir does not exist: {run}")
        safe_track = sanitize_scene_name(track_name or "mesh_track")
        mesh = Path(os.path.expandvars(os.path.expanduser(str(mesh_path)))) if mesh_path else None
        exists = bool(mesh and mesh.is_file())
        payload = {
            "schema": "ConceptGhost.MeshTrack.v0.12",
            "track": safe_track,
            "structural_status": "PASS" if exists else "WARN",
            "quality_status": "UNJUDGED",
            "mesh_path": str(mesh) if mesh else None,
            "mesh_exists": exists,
            "upstream_report": upstream_report,
            "policy": "Mesh quality does not block end-to-end skeleton progression.",
        }
        out = run / "meshes" / safe_track / "track.json"
        write_json(out, payload)

        index_path = run / "output_index.json"
        if index_path.is_file():
            try:
                index = json.loads(index_path.read_text(encoding="utf-8"))
                key_map = {"atlas_relief": "E1_ATLAS_RELIEF"}
                key = key_map.get(safe_track)
                if key and key in index.get("intermediate", {}):
                    entry = index["intermediate"][key]
                    entry["path"] = str(mesh) if mesh else None
                    entry["track_report"] = str(out)
                    entry["structural_status"] = payload["structural_status"]
                    entry["status"] = "AVAILABLE" if exists else "WARN"
                    write_json(index_path, index)
            except Exception:
                # Discoverability metadata must never block the mesh track itself.
                pass
        return (str(out), payload["structural_status"])


class ConceptGhostStage13Packager:
    """Package the MoGe-only v0.30 run without forcing retired geometry branches."""
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "manifest_path": ("STRING", {"forceInput": True}),
                "stage09_report_path": ("STRING", {"forceInput": True}),
                "quality_status": ("STRING", {"forceInput": True}),
            },
            "optional": {
                "atlas_track_report_path": ("STRING", {"default": ""}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("package_manifest_path", "acceptance_report_path", "packaging_log_path", "stage13_status")
    FUNCTION = "package"
    CATEGORY = "ConceptGhost/13 Packaging"
    OUTPUT_NODE = True

    @staticmethod
    def _required_file(path_value: str, label: str) -> Path:
        p = Path(os.path.expandvars(os.path.expanduser(str(path_value))))
        if not p.is_file():
            raise RuntimeError(f"ConceptGhost Stage 13 missing {label}: {p}")
        return p

    def package(self, run_dir, manifest_path, stage09_report_path, quality_status, atlas_track_report_path=""):
        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir))))
        if not run.is_dir():
            raise RuntimeError(f"ConceptGhost Stage 13 run_dir does not exist: {run}")
        manifest = self._required_file(manifest_path, "manifest")
        stage09 = self._required_file(stage09_report_path, "Stage 9 report")
        atlas_track = None
        if str(atlas_track_report_path or "").strip():
            atlas_track = self._required_file(atlas_track_report_path, "Atlas mesh track report")

        manifest_data = json.loads(manifest.read_text(encoding="utf-8"))
        profile = assert_profile_contract(dict(manifest_data.get("profile_config") or {}), stage="STAGE13_MANIFEST")
        if str(manifest_data.get("geometry_profile")) != str(profile["selected_profile"]):
            raise RuntimeError("[STAGE13_MANIFEST] manifest geometry_profile/profile_config mismatch")

        files=[]
        for file_path in sorted(x for x in run.rglob("*") if x.is_file()):
            rel=file_path.relative_to(run).as_posix()
            files.append({"relative_path":rel,"bytes":int(file_path.stat().st_size),"sha256":sha256_file(file_path)})

        package_dir=run/"package"; acceptance_dir=run/"acceptance"; logs_dir=run/"logs"
        package_dir.mkdir(parents=True,exist_ok=True); acceptance_dir.mkdir(parents=True,exist_ok=True); logs_dir.mkdir(parents=True,exist_ok=True)
        package_manifest=package_dir/"stage13_package_manifest.json"
        acceptance_report=acceptance_dir/"stage13_acceptance.json"
        log_path=logs_dir/"stage13_packaging.log"
        package_payload={
            "schema":"ConceptGhost.Stage13Package.v0.30",
            "structural_status":"PASS",
            "quality_status":str(quality_status),
            "geometry_profile":profile["selected_profile"],
            "profile_config":json_safe(profile),
            "run_dir":str(run),
            "authoritative_manifest":str(manifest),
            "stage09_report":str(stage09),
            "mesh_track_reports":{
                "atlas_relief": str(atlas_track) if atlas_track else "RETIRED_NOT_REQUIRED_IN_V035",
                "moge_mesh": "RETIRED_FROM_CANONICAL_WORKFLOW; PrimaryMesh is the modeling authority.",
            },
            "file_count":len(files),
            "files":files,
            "policy":"MoGe-3 canonical package; retired Atlas-relief/MoGe-preview branches are not required.",
        }
        write_json(package_manifest,package_payload)
        acceptance_payload={
            "schema":"ConceptGhost.Stage13Acceptance.v0.30",
            "structural_status":"PASS",
            "quality_status":str(quality_status),
            "geometry_profile":profile["selected_profile"],
            "required_inputs":{
                "manifest":str(manifest),
                "stage09_report":str(stage09),
                "atlas_track_report": str(atlas_track) if atlas_track else "RETIRED_NOT_REQUIRED_IN_V035",
            },
            "package_manifest":str(package_manifest),
            "next_stage":14,
        }
        write_json(acceptance_report,acceptance_payload)
        log_path.write_text("\n".join([
            "ConceptGhost Stage 13 Packaging v0.30",
            "structural_status=PASS",
            f"geometry_profile={profile['selected_profile']}",
            f"quality_status={quality_status}",
            f"file_count={len(files)}",
        ])+"\n",encoding="utf-8")
        return (str(package_manifest),str(acceptance_report),str(log_path),"PASS")

class ConceptGhostStage14CameraValidation:
    """Optional PCS/fSpy camera-validation branch.

    Atlas remains the production camera authority.  This node writes a neutral
    camera-reference contract on every run and, when the user supplies an fSpy
    project path, parses the fSpy project header/state and compares its camera
    calibration against Atlas.  A missing or invalid optional fSpy project never
    replaces Atlas or blocks the end-to-end skeleton.

    The fSpy file reader follows the public fSpy/fSpy-Blender project format:
    little-endian file id/version/header sizes followed by JSON state and image
    bytes.  Principal-point conversion follows the public fSpy-Blender importer
    conventions so the comparison is expressed in source-image pixels.
    """

    FSPY_FILE_ID = 2037412710
    FSPY_VERSION = 1

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "run_dir": ("STRING", {"forceInput": True}),
                "camera_bundle": (CG_CAMERA_BUNDLE,),
                "stage13_acceptance_path": ("STRING", {"forceInput": True}),
                "fspy_project_path": ("STRING", {"default": ""}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("validation_report_path", "camera_reference_path", "stage14_status")
    FUNCTION = "validate"
    CATEGORY = "ConceptGhost/14 Camera Validation"
    OUTPUT_NODE = True

    @staticmethod
    def _fspy_principal_point_px(pp_x: float, pp_y: float, width: int, height: int) -> tuple[float, float]:
        # fSpy-Blender expresses the fSpy normalized principal point relative to
        # image aspect before converting it to render/camera shift.  Recreate the
        # same normalized image location and convert to pixels for comparison.
        aspect = float(width) / float(height)
        if aspect <= 1.0:
            rel_x = 0.5 * (float(pp_x) / aspect + 1.0)
            rel_y = 0.5 * (-float(pp_y) + 1.0)
        else:
            rel_x = 0.5 * (float(pp_x) + 1.0)
            rel_y = 0.5 * (-float(pp_y) * aspect + 1.0)
        return rel_x * float(width), rel_y * float(height)

    @classmethod
    def _read_fspy(cls, path: Path) -> dict[str, Any]:
        with path.open("rb") as f:
            header = f.read(16)
            if len(header) != 16:
                raise ValueError("fSpy project header is incomplete")
            file_id, version, state_size, image_size = struct.unpack("<IIII", header)
            if file_id != cls.FSPY_FILE_ID:
                raise ValueError("file is not an fSpy project")
            if version != cls.FSPY_VERSION:
                raise ValueError(f"unsupported fSpy project version: {version}")
            state_raw = f.read(state_size)
            if len(state_raw) != state_size:
                raise ValueError("fSpy project JSON state is incomplete")
            state = json.loads(state_raw.decode("utf-8"))
        cp = state.get("cameraParameters") or {}
        pp = cp.get("principalPoint") or {}
        width = int(cp.get("imageWidth") or 0)
        height = int(cp.get("imageHeight") or 0)
        if width <= 0 or height <= 0:
            raise ValueError("fSpy cameraParameters contain invalid image dimensions")
        fov_rad = float(cp.get("horizontalFieldOfView"))
        ppx, ppy = cls._fspy_principal_point_px(float(pp.get("x", 0.0)), float(pp.get("y", 0.0)), width, height)
        transform = (cp.get("cameraTransform") or {}).get("rows")
        return {
            "project_path": str(path),
            "project_version": version,
            "image_payload_bytes": int(image_size),
            "image_width": width,
            "image_height": height,
            "horizontal_fov_deg": float(math.degrees(fov_rad)),
            "principal_point_px": [float(ppx), float(ppy)],
            "camera_transform_rows": transform,
            "reference_distance_unit": (state.get("calibrationSettingsBase") or {}).get("referenceDistanceUnit"),
        }

    def validate(self, run_dir, camera_bundle, stage13_acceptance_path, fspy_project_path):
        run = Path(os.path.expandvars(os.path.expanduser(str(run_dir))))
        if not run.is_dir():
            raise RuntimeError(f"ConceptGhost Stage 14 run_dir does not exist: {run}")
        acceptance = Path(os.path.expandvars(os.path.expanduser(str(stage13_acceptance_path))))
        if not acceptance.is_file():
            raise RuntimeError(f"ConceptGhost Stage 14 missing Stage 13 acceptance report: {acceptance}")
        if not camera_bundle or not camera_bundle.get("valid"):
            raise RuntimeError("ConceptGhost Stage 14 requires a valid Atlas CameraBundle")

        validation_dir = run / "validation"
        validation_dir.mkdir(parents=True, exist_ok=True)
        reference_path = validation_dir / "stage14_atlas_camera_reference.json"
        report_path = validation_dir / "stage14_camera_validation.json"

        intr = camera_bundle.get("intrinsics", {})
        reference = {
            "schema": "ConceptGhost.Stage14CameraReference.v0.16",
            "camera_authority": "Atlas",
            "solver": (camera_bundle.get("provenance") or {}).get("final_solver"),
            "image_width": int(camera_bundle.get("image_width", 0)),
            "image_height": int(camera_bundle.get("image_height", 0)),
            "horizontal_fov_deg": float(camera_bundle.get("horizontal_fov_deg", 0.0)),
            "intrinsics": json_safe(intr),
            "camera_world_matrix": json_safe((camera_bundle.get("extrinsics") or {}).get("camera_world_matrix")),
            "pcs_role": "Reference contract for later PCS/manual camera validation; never replaces Atlas automatically.",
        }
        write_json(reference_path, reference)

        supplied = bool(str(fspy_project_path or "").strip())
        fspy_payload = None
        comparison = None
        comparison_status = "REFERENCE_ONLY"
        optional_warning = None
        if supplied:
            project = Path(os.path.expandvars(os.path.expanduser(str(fspy_project_path))))
            try:
                fspy_payload = self._read_fspy(project)
                atlas_w = int(reference["image_width"])
                atlas_h = int(reference["image_height"])
                atlas_pp = [float(intr.get("cx_px", 0.0)), float(intr.get("cy_px", 0.0))]
                fspy_pp = fspy_payload["principal_point_px"]
                comparison = {
                    "horizontal_fov_error_deg": abs(float(reference["horizontal_fov_deg"]) - float(fspy_payload["horizontal_fov_deg"])),
                    "principal_point_error_px": float(math.hypot(atlas_pp[0] - float(fspy_pp[0]), atlas_pp[1] - float(fspy_pp[1]))),
                    "image_size_match": bool(atlas_w == int(fspy_payload["image_width"]) and atlas_h == int(fspy_payload["image_height"])),
                    "transform_comparison": "deferred_axis_normalization; raw fSpy transform preserved for refinement phase",
                }
                comparison_status = "COMPARED"
            except Exception as exc:
                optional_warning = str(exc)
                comparison_status = "FSPY_WARNING"

        report = {
            "schema": "ConceptGhost.Stage14CameraValidation.v0.16",
            "structural_status": "PASS",
            "camera_authority": "Atlas",
            "comparison_status": comparison_status,
            "stage13_acceptance_path": str(acceptance),
            "atlas_reference_path": str(reference_path),
            "fspy": {
                "project_supplied": supplied,
                "parsed": fspy_payload is not None,
                "payload": fspy_payload,
                "warning": optional_warning,
            },
            "comparison": comparison,
            "references": {
                "fspy_role": "fSpy project format / manual vanishing-point camera baseline",
                "fspy_blender_role": "fSpy-Blender importer conventions for FOV, camera transform and principal-point interpretation",
                "pcs_role": "ConceptGhost PCS remains a future/manual validation consumer of this reference contract",
            },
            "policy": "Stage 14 is validation-only. fSpy/PCS evidence cannot silently replace the Atlas production camera. Missing optional fSpy input does not block the skeleton.",
        }
        write_json(report_path, report)
        return (str(report_path), str(reference_path), "PASS")






class ConceptGhostWorkflowNote:
    """Artist-facing documentation card used only to explain workflow controls.

    This node has no data outputs and does not participate in geometry, camera,
    metrology, export, or Maya execution. It exists purely to keep the canonical
    workflow self-documenting.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "note": ("STRING", {
                    "default": "",
                    "multiline": True,
                    "dynamicPrompts": False,
                }),
            }
        }

    RETURN_TYPES = ()
    FUNCTION = "show"
    CATEGORY = "ConceptGhost/00 Workflow Guide"

    def show(self, note):
        return ()


class ConceptGhostRunPackageDownload:
    """Compatibility node for pre-v0.32 workflows.

    Full-run ZIP generation was retired because it physically duplicated the
    already-authoritative saved run. New workflows omit this node. If an older
    workflow still invokes it, execution remains successful but no ZIP is made.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "run_dir": ("STRING", {"forceInput": True}),
            "completion_token": ("STRING", {"forceInput": True}),
        }}

    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("complete_run_zip", "saved_run_folder", "package_status")
    FUNCTION = "package"
    CATEGORY = "ConceptGhost/Compatibility"
    OUTPUT_NODE = True

    def package(self, run_dir, completion_token, output_dir=None):
        info = create_run_download_archive(run_dir, output_dir=output_dir)
        status = info.get("status", "PASS_NO_DUPLICATE_ARCHIVE")
        ui = {"text": [
            "ConceptGhost full-run ZIP retired in v0.32 — no duplicate archive generated.",
            f"Authoritative saved run folder: {info['run_dir']}",
            f"Upstream completion: {completion_token}",
        ]}
        return {"ui": ui, "result": ("", info["run_dir"], status)}


NODE_CLASS_MAPPINGS = {
    "ConceptGhostMasterConfig": ConceptGhostMasterConfig,
    "ConceptGhostCameraRouter": ConceptGhostCameraRouter,
    "ConceptGhostSelectedAtlasSolve": ConceptGhostSelectedAtlasSolve,
    "ConceptGhostGeometryProfile": ConceptGhostGeometryProfile,
    "ConceptGhostMoGe3Inference": ConceptGhostMoGe3Inference,
    "ConceptGhostMoGeVersionRouter": ConceptGhostMoGeVersionRouter,
    "ConceptGhostMoGeEvidence": ConceptGhostMoGeEvidence,
    "ConceptGhostMoGeMetricMeasure": ConceptGhostMoGeMetricMeasure,
    "ConceptGhostDepthProEvidence": ConceptGhostDepthProEvidence,
    "ConceptGhostAtlasMetrologyMeasure": ConceptGhostAtlasMetrologyMeasure,
    "ConceptGhostMoGeAtlasAgreement": ConceptGhostMoGeAtlasAgreement,
    "ConceptGhostMetricConsensus": ConceptGhostMetricConsensus,
    "ConceptGhostGeometricRegions": ConceptGhostGeometricRegions,
    "ConceptGhostLocalGeometryCleanup": ConceptGhostLocalGeometryCleanup,
    "ConceptGhostCanonicalize": ConceptGhostCanonicalize,
    "ConceptGhostExportBundle": ConceptGhostExportBundle,
    "ConceptGhostStageAudit": ConceptGhostStageAudit,
    "ConceptGhostMoGeProjectionSupport": ConceptGhostMoGeProjectionSupport,
    "ConceptGhostMeshForDCC": ConceptGhostMeshForDCC,
    "ConceptGhostHFVariantExporter": ConceptGhostHFVariantExporter,
    "ConceptGhostPrimaryRemeshExporter": ConceptGhostPrimaryRemeshExporter,
    "ConceptGhostPointCloudPreview": ConceptGhostPointCloudPreview,
    "ConceptGhost3DAssetPreview": ConceptGhost3DAssetPreview,
    "ConceptGhostGLBFileFromPath": ConceptGhostGLBFileFromPath,
    "ConceptGhostMeshUVFix": ConceptGhostMeshUVFix,
    "ConceptGhostMeshTrackRecorder": ConceptGhostMeshTrackRecorder,
    "ConceptGhostStage13Packager": ConceptGhostStage13Packager,
    "ConceptGhostStage14CameraValidation": ConceptGhostStage14CameraValidation,
    "ConceptGhostWorkflowNote": ConceptGhostWorkflowNote,
    "ConceptGhostRunPackageDownload": ConceptGhostRunPackageDownload,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ConceptGhostMasterConfig": "ConceptGhost — Master Controls",
    "ConceptGhostCameraRouter": "ConceptGhost — Atlas Camera Router",
    "ConceptGhostSelectedAtlasSolve": "ConceptGhost — Selected Atlas Solve",
    "ConceptGhostGeometryProfile": "ConceptGhost — Geometry Profile: Low Resolution / High Fidelity / Split Clean",
    "ConceptGhostMoGe3Inference": "ConceptGhost — MoGe-3 Isolated Inference",
    "ConceptGhostMoGeVersionRouter": "ConceptGhost — MoGe-2 / MoGe-3 Router",
    "ConceptGhostMoGeEvidence": "ConceptGhost — MoGe Evidence",
    "ConceptGhostMoGeMetricMeasure": "ConceptGhost — MoGe Native Metric Measurement (Report Only)",
    "ConceptGhostDepthProEvidence": "ConceptGhost — Depth Pro Independent Metric Witness (Report Only)",
    "ConceptGhostAtlasMetrologyMeasure": "ConceptGhost — Atlas Ground / Distance / Height Metrology (Report Only)",
    "ConceptGhostMoGeAtlasAgreement": "ConceptGhost — MoGe × Atlas Metric Agreement (Report Only)",
    "ConceptGhostMetricConsensus": "ConceptGhost — Robust Metric Consensus (Report Only)",
    "ConceptGhostGeometricRegions": "ConceptGhost — Simplified Geometric Regions (Report Only)",
    "ConceptGhostLocalGeometryCleanup": "ConceptGhost — Local Geometry Cleanup (Artist-Approved Candidate)",
    "ConceptGhostCanonicalize": "ConceptGhost — Canonical Point Cloud",
    "ConceptGhostExportBundle": "ConceptGhost — Export Evaluation Bundle",
    "ConceptGhostStageAudit": "ConceptGhost — Stage 9 Run Audit",
    "ConceptGhostMoGeProjectionSupport": "ConceptGhost — MoGe Projection Support",
    "ConceptGhostMeshForDCC": "ConceptGhost — MoGe Mesh → Maya/DCC",
    "ConceptGhostHFVariantExporter": "ConceptGhost — HF Master / Split Clean / Simplified Proxy (legacy)",
    "ConceptGhostPrimaryRemeshExporter": "ConceptGhost — PrimaryMesh Master + Optional Remesh Light / Medium / Strong",
    "ConceptGhostPointCloudPreview": "ConceptGhost — Fused Points Preview",
    "ConceptGhost3DAssetPreview": "ConceptGhost — 3D Output Preview / Download",
    "ConceptGhostGLBFileFromPath": "ConceptGhost — GLB → Native Save 3D",
    "ConceptGhostMeshUVFix": "ConceptGhost — Flip Mesh V for Maya (legacy)",
    "ConceptGhostMeshTrackRecorder": "ConceptGhost — Mesh Track Recorder",
    "ConceptGhostStage13Packager": "ConceptGhost — Stage 13 Package & Acceptance",
    "ConceptGhostStage14CameraValidation": "ConceptGhost — Stage 14 PCS/fSpy Camera Validation",
    "ConceptGhostWorkflowNote": "ConceptGhost — Workflow Guide Note",
    "ConceptGhostRunPackageDownload": "ConceptGhost — Legacy Run ZIP (disabled; no duplicate)",
}

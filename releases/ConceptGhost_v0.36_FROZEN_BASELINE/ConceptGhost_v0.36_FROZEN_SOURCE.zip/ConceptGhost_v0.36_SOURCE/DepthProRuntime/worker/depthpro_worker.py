from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np

UPSTREAM_COMMIT = "9e65e4dbe9568d23c546fcec53302b10445e109e"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--request", required=True)
    args = ap.parse_args()
    req_path = Path(args.request).resolve()
    req = json.loads(req_path.read_text(encoding="utf-8"))
    result_npz = Path(req["result_npz"]).resolve()
    result_json = Path(req["result_json"]).resolve()
    image_path = Path(req["image"]).resolve()
    runtime_root = Path(req["runtime_root"]).resolve()
    checkpoint = runtime_root / "checkpoints" / "depth_pro.pt"
    if not checkpoint.is_file():
        raise FileNotFoundError(f"Depth Pro checkpoint missing: {checkpoint}")

    import torch
    from PIL import Image
    import depth_pro

    if not torch.cuda.is_available():
        raise RuntimeError("Depth Pro ConceptGhost spike requires CUDA; CPU fallback is intentionally disabled")
    device = torch.device("cuda")
    model, transform = depth_pro.create_model_and_transforms(device=device, precision=torch.float32)
    model.eval()

    image = Image.open(image_path).convert("RGB")
    tensor = transform(image)
    with torch.no_grad():
        pred = model.infer(tensor, f_px=None)
    depth_ind = pred["depth"].detach().float().cpu().numpy().astype(np.float32, copy=False)
    focal_pred = float(pred["focallength_px"].detach().float().cpu().item())
    if depth_ind.ndim != 2 or not np.isfinite(depth_ind).any():
        raise RuntimeError(f"Depth Pro returned invalid depth shape: {depth_ind.shape}")

    atlas_focal = req.get("atlas_focal_px")
    depth_atlas = np.array([], dtype=np.float32)
    atlas_ratio = None
    if atlas_focal is not None:
        atlas_focal = float(atlas_focal)
        if math.isfinite(atlas_focal) and atlas_focal > 0 and math.isfinite(focal_pred) and focal_pred > 0:
            atlas_ratio = atlas_focal / focal_pred
            depth_atlas = (depth_ind * atlas_ratio).astype(np.float32, copy=False)

    valid = np.isfinite(depth_ind) & (depth_ind > 0)
    result_npz.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        result_npz,
        depth_independent_m=depth_ind,
        depth_atlas_focal_m=depth_atlas,
        valid_mask=valid,
    )
    report = {
        "schema": "ConceptGhost.DepthProWorkerResult.v0.33",
        "status": "PASS",
        "upstream_commit": UPSTREAM_COMMIT,
        "device": str(device),
        "torch_version": str(torch.__version__),
        "cuda_version": str(torch.version.cuda),
        "depth_shape": list(depth_ind.shape),
        "predicted_focal_px": focal_pred,
        "atlas_focal_px": atlas_focal,
        "atlas_focal_scale_ratio": atlas_ratio,
        "primary_witness": "depth_independent_m",
        "primary_independence": "Depth Pro inferred focal + Depth Pro depth network",
        "atlas_conditioned_variant": bool(depth_atlas.size),
        "geometry_authority": False,
        "camera_authority": False,
        "automatic_correction": False,
    }
    result_json.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# ConceptGhost v0.36 — Metric Authority Candidate

v0.36 preserves the v0.35 frozen baseline and adds an explicit, fail-closed manual physical scale authority.

Key changes:
- shared Measurement Target for P2/P3;
- known height can become sovereign metric scale authority only through an explicit switch;
- uniform scene/camera-translation similarity scaling preserves projection and proportions;
- manual authority is recorded in run diagnostics and Maya metadata;
- automatic metric agreement/consensus remains diagnostic when manual authority is active;
- P7/P8 v0.35.1 presentation/UV fixes included.

Status: candidate pending fresh Windows/ComfyUI/Maya validation.

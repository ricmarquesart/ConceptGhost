# ConceptGhost v0.36 — Validation Guide

## First run: automatic metric scale
- High Fidelity
- Measurement Target: ON only if testing P2/P3; `Use Known Height as Scale Authority = OFF`
- P5/P6: ON after Depth Pro is installed
- P7: ON
- P8 Enabled: ON
- P8 Approve Cleanup Candidate: OFF
- Remesh Variants: OFF

This run shows what the automatic Atlas/MoGe/Depth Pro evidence believes before a manual physical calibration.

## Known-height calibration run
Choose one real physical vertical reference visible in the image.

In **KEY · MEASUREMENT TARGET**:
1. Enabled = ON
2. Set Base X/Y on the lower endpoint of the known dimension.
3. Use Top Pixel = ON
4. Set Top X/Y on the upper endpoint of the same physical span.
5. Enter Known Height (m).
6. Set `Use Known Height as Scale Authority = ON`.

Expected behavior:
- the scene is uniformly rescaled so that reference equals the entered meters;
- camera translation changes by the same scale factor;
- FOV/focal/rotation do not change;
- reprojection must remain PASS;
- P2 verifies the calibrated height;
- P3/P6 may report disagreement with automatic evidence, but cannot override the manual scale;
- Maya PrimaryMesh and camera use the calibrated metric scene.

## Important interpretation
A single known height calibrates **global scale**. It cannot uniquely solve camera rotation or FOV; Atlas remains optical/pose authority.

If the entered known height differs dramatically from automatic estimates, ConceptGhost records a large-scale-shift warning but the explicit manual measurement remains scale authority. Invalid/zero height or missing top pixel fails closed.

## Derived geometry run
- P7: ON
- P8 Enabled: ON
- Approve Cleanup Candidate: ON
- Remesh Variants: ON

The cleanup/remesh outputs remain derived. The official PrimaryMesh is not automatically replaced.

## Final Maya evidence
After a completed run, execute `COLLECT_V036_VALIDATION_EVIDENCE.bat` and send the resulting evidence ZIP first.

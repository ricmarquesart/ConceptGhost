# ConceptGhost v0.36 — Workflow Guide

## Key metric controls

The amber/orange **KEY · MEASUREMENT TARGET** node is the single source of target coordinates for P2 and P3. This prevents typing the same pixel twice and accidentally comparing different places.

### Enabled
- **OFF:** P2/P3 remain disabled for this target.
- **ON:** P2 and P3 use the target below.

### Target Label
Human-readable name only, e.g. `Door 01`, `Facade floor height`, `Arch base`.

### Base X / Base Y
Pixel at the **base** of the reference. Prefer a point that physically touches the ground/support plane.
- X grows left → right.
- Y grows top → bottom.

### Use Top Pixel
Turn ON when the target represents a vertical physical height.

### Top X / Top Y
Pixel at the **top of the same physical vertical span** used by Base X/Y.
Do not mix the base of one object with the top of another depth layer.

### Known Height (m)
Optional real-world physical measurement in meters.
Examples: a measured facade module, doorway, column, wall, or another dimension whose real size is known.

### Use Known Height as Scale Authority
This is the most important switch.

- **OFF:** Known Height is diagnostic/plausibility evidence only. It does not move the scene.
- **ON:** Known Height becomes the **sovereign global metric scale authority**.

When ON, ConceptGhost first measures the current base→top reference using Atlas geometry, then applies one uniform similarity scale so that the same reference equals the artist-entered Known Height exactly.

The following are scaled together:
- Primary/canonical geometry XYZ
- Maya PrimaryMesh positions
- point-cloud world positions
- camera translation / camera height / world distances

The following do **not** change:
- camera FOV / focal length
- camera rotation
- perspective projection / image alignment
- object proportions
- UVs / texture mapping
- topology

Because geometry and camera translation receive the same uniform scale, the view remains aligned while Maya units become physically calibrated.

A single known height is sufficient to calibrate **global scale**, but is not sufficient to uniquely re-solve camera rotation/FOV. Atlas remains camera optical/pose authority.

## If manual height disagrees with automatic evidence
The artist-entered known height remains authoritative when the explicit scale-authority switch is ON.

MoGe, Atlas automatic metric evidence and Depth Pro are still evaluated. Their disagreement becomes diagnostic evidence and may produce `MODERATE_DISAGREEMENT`, `STRONG_CONFLICT`, `OUTLIER`, or a consensus warning. They **cannot override** the manual scale.

This means a measured 2.50 m facade reference will be 2.50 m in the calibrated Maya scene even if an automatic model originally estimated 2.8 m or 3.1 m.

## P2 — Atlas Metrology
P2 consumes the shared Measurement Target automatically.
It reports:
- ground model quality
- base camera distance
- ground distance
- estimated base→top height
- comparison to Known Height

After manual scale authority is applied, P2 acts as a post-calibration verification.

## P3 — MoGe × Atlas Agreement
P3 consumes the **same target** automatically. It compares native MoGe metric evidence against the calibrated Atlas/world interpretation.

If manual scale authority is active, P3 is strictly diagnostic: disagreement never rescales the scene.

## P5 — Depth Pro Witness
Optional independent metric witness. Enable only after the private Depth Pro runtime is installed and verified.

## P6 — Robust Metric Consensus
Uses Atlas + MoGe + Depth Pro when available.
Uses weighted median, MAD, agreement groups and outlier rejection rather than a simple mean.

If manual scale authority is active, P6 remains useful to tell you whether the automatic models agree with the real-world calibration, but it cannot alter the scale.

## P7 / P8
P7 defines safe geometric regions; it never edits PrimaryMesh.
P8 can create a derived cleanup candidate after explicit artist approval. It never automatically replaces PrimaryMesh.

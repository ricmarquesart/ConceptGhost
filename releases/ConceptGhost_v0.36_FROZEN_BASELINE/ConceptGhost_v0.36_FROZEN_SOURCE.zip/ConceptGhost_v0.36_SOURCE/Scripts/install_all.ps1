$ErrorActionPreference="Stop"
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " ConceptGhost v0.36 FROZEN - FULL INSTALL" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "This installs the ConceptGhost payload, private MoGe-3 runtime, and private Depth Pro runtime." -ForegroundColor Yellow
Write-Host "No global/ComfyUI Python, Torch, CUDA or NumPy replacement is performed." -ForegroundColor Yellow
& (Join-Path $PSScriptRoot "install_comfy_payload.ps1")
& (Join-Path $PSScriptRoot "install_moge3_runtime.ps1")
& (Join-Path $PSScriptRoot "install_depthpro_runtime.ps1")
Write-Host "[PASS] ConceptGhost v0.36 full feature installation finished." -ForegroundColor Green

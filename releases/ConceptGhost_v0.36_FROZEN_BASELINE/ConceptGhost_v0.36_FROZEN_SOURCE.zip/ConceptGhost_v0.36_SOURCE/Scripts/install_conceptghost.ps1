$ErrorActionPreference="Stop"
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " ConceptGhost v0.36 FROZEN - CORE INSTALL" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "Only ConceptGhost-owned files/runtimes are modified." -ForegroundColor Yellow
Write-Host "ComfyUI Python/Torch/CUDA/NumPy and unrelated custom nodes are not replaced." -ForegroundColor Yellow
& (Join-Path $PSScriptRoot "install_comfy_payload.ps1")
& (Join-Path $PSScriptRoot "install_moge3_runtime.ps1")
Write-Host "[PASS] ConceptGhost v0.36 core installation finished." -ForegroundColor Green
Write-Host "Use INSTALL_ALL.bat for the complete P1-P8 + Depth Pro feature set." -ForegroundColor Cyan

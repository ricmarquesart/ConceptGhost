param([string]$RuntimeRoot="$env:LOCALAPPDATA\ConceptGhost-DepthProRuntime-v1")
$ErrorActionPreference="Stop"; $ProgressPreference="SilentlyContinue"
$BundleRoot=Split-Path -Parent $PSScriptRoot
$Lock=Get-Content (Join-Path $BundleRoot "Tools\DepthProRuntime\SOURCE_LOCK.json") -Raw|ConvertFrom-Json
$WorkerSrc=Join-Path $BundleRoot "Tools\DepthProRuntime\worker\depthpro_worker.py"
$PythonRoot=Join-Path $RuntimeRoot "python"; $PythonExe=Join-Path $PythonRoot "python.exe"
$RepoRoot=Join-Path $RuntimeRoot "repo"; $Repo=Join-Path $RepoRoot "ml-depth-pro"
$WorkerDst=Join-Path $RuntimeRoot "worker"; $CheckpointDir=Join-Path $RuntimeRoot "checkpoints"; $Checkpoint=Join-Path $CheckpointDir "depth_pro.pt"
$Logs=Join-Path $RuntimeRoot "logs"; $Ready=Join-Path $RuntimeRoot "READY.json"
New-Item -ItemType Directory -Force $RuntimeRoot,$PythonRoot,$RepoRoot,$WorkerDst,$CheckpointDir,$Logs|Out-Null
Set-Content (Join-Path $RuntimeRoot "OWNED_BY_CONCEPTGHOST_DEPTHPRO_RUNTIME_V1.txt") "ConceptGhost Depth Pro private runtime" -Encoding UTF8
function Run([string]$Exe,[string[]]$A){& $Exe @A; if($LASTEXITCODE -ne 0){throw "Command failed ($LASTEXITCODE): $Exe $($A -join ' ')"}}
if(-not(Test-Path $PythonExe)){
  # Use the official embeddable distribution instead of the Windows installer.
  # The EXE installer can legally return success while reusing an already-registered
  # Python installation elsewhere, leaving $PythonRoot without python.exe.
  Write-Host "[INFO] Bootstrapping private Python 3.11.9 (embeddable) into: $PythonRoot" -ForegroundColor Cyan
  if(Test-Path $PythonRoot){Remove-Item $PythonRoot -Recurse -Force}
  New-Item -ItemType Directory -Force $PythonRoot|Out-Null
  $PyZip=Join-Path $env:TEMP "python-3.11.9-embed-amd64.zip"
  Invoke-WebRequest "https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip" -OutFile $PyZip -UseBasicParsing
  Expand-Archive $PyZip $PythonRoot -Force
  if(-not(Test-Path $PythonExe)){throw "Private embedded Python bootstrap failed: python.exe missing at $PythonExe"}

  # Embeddable Python disables site-packages by default. Enable it explicitly,
  # then bootstrap pip inside this private runtime only.
  $Pth=Get-ChildItem $PythonRoot -Filter 'python*._pth' | Select-Object -First 1
  if(-not $Pth){throw "Private embedded Python bootstrap failed: python*._pth missing"}
  $PthText=Get-Content $Pth.FullName -Raw
  if($PthText -match '(?m)^#import site\s*$'){$PthText=[regex]::Replace($PthText,'(?m)^#import site\s*$','import site')}
  elseif($PthText -notmatch '(?m)^import site\s*$'){$PthText=$PthText.TrimEnd()+"`r`nimport site`r`n"}
  Set-Content $Pth.FullName $PthText -Encoding ASCII
  New-Item -ItemType Directory -Force (Join-Path $PythonRoot 'Lib\site-packages')|Out-Null

  $GetPip=Join-Path $env:TEMP 'get-pip.py'
  Invoke-WebRequest 'https://bootstrap.pypa.io/get-pip.py' -OutFile $GetPip -UseBasicParsing
  Run $PythonExe @($GetPip,'--disable-pip-version-check')
}
if(-not(Test-Path $PythonExe)){throw "Private Python is not ready: $PythonExe"}
Run $PythonExe @('-m','pip','--version')
Run $PythonExe @('-m','pip','install','--upgrade','pip','setuptools','wheel')
$Commit=[string]$Lock.commit; $SrcZip=Join-Path $env:TEMP ("ConceptGhost-DepthPro-"+$Commit+".zip")
$SrcUrl="https://github.com/apple-aiml-research/ml-depth-pro/archive/$Commit.zip"
Invoke-WebRequest $SrcUrl -OutFile $SrcZip -UseBasicParsing
$Tmp=Join-Path $RepoRoot '_extract'; if(Test-Path $Tmp){Remove-Item $Tmp -Recurse -Force}; New-Item -ItemType Directory $Tmp -Force|Out-Null
Expand-Archive $SrcZip $Tmp -Force
$Extracted=Get-ChildItem $Tmp -Directory|Select-Object -First 1
if(-not $Extracted -or -not(Test-Path (Join-Path $Extracted.FullName 'pyproject.toml'))){throw 'Unexpected Depth Pro source archive'}
if(Test-Path $Repo){Remove-Item $Repo -Recurse -Force}; Move-Item $Extracted.FullName $Repo; Remove-Item $Tmp -Recurse -Force
Copy-Item $WorkerSrc (Join-Path $WorkerDst 'depthpro_worker.py') -Force
$TorchIndex=if($env:CONCEPTGHOST_DEPTHPRO_TORCH_INDEX){$env:CONCEPTGHOST_DEPTHPRO_TORCH_INDEX}else{'https://download.pytorch.org/whl/cu130'}
Run $PythonExe @('-m','pip','install','--index-url',$TorchIndex,'--extra-index-url','https://pypi.org/simple','torch','torchvision')
Run $PythonExe @('-m','pip','install','-e',$Repo)
if(-not(Test-Path $Checkpoint)){Invoke-WebRequest ([string]$Lock.official_checkpoint_url) -OutFile $Checkpoint -UseBasicParsing}
$env:PYTHONPATH=(Join-Path $Repo 'src'); $env:CONCEPTGHOST_DEPTHPRO_RUNTIME=$RuntimeRoot
$verify=@'
import json, pathlib, torch, depth_pro
root=pathlib.Path(r"RUNTIME_ROOT")
ck=root/'checkpoints'/'depth_pro.pt'
assert ck.is_file()
assert torch.cuda.is_available(), 'CUDA unavailable'
# create_model uses ./checkpoints/depth_pro.pt; execute from runtime root.
model, transform=depth_pro.create_model_and_transforms(device=torch.device('cuda'),precision=torch.float32)
ready={'schema':'ConceptGhost.DepthProRuntimeReady.v0.36','status':'PASS','torch':torch.__version__,'cuda':str(torch.version.cuda),'checkpoint':str(ck)}
(root/'READY.json').write_text(json.dumps(ready,indent=2))
print(json.dumps(ready))
'@.Replace('RUNTIME_ROOT',$RuntimeRoot.Replace('\','\\'))
$VerifyPy=Join-Path $RuntimeRoot 'verify_depthpro.py'; Set-Content $VerifyPy $verify -Encoding UTF8
Push-Location $RuntimeRoot; try{Run $PythonExe @($VerifyPy)}finally{Pop-Location}
if(-not(Test-Path $Ready)){throw 'Depth Pro READY.json not created'}
Write-Host "[PASS] Optional Depth Pro private runtime ready: $RuntimeRoot" -ForegroundColor Green

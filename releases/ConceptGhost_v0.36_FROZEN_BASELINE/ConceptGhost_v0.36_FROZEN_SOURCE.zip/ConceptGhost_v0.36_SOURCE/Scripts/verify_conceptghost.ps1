$ErrorActionPreference='Stop'
$Candidates=@(
  (Join-Path $env:LOCALAPPDATA 'Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI'),
  (Join-Path $env:LOCALAPPDATA 'Programs\@comfyorgcomfyui-electron\resources\ComfyUI')
)
$Comfy=$Candidates|Where-Object{Test-Path $_}|Select-Object -First 1
if(-not $Comfy){throw 'ComfyUI root not found'}
$N=Join-Path $Comfy 'custom_nodes\ConceptGhost_Stage68\nodes.py'
$W=Join-Path $Comfy 'user\default\workflows\ConceptGhost\ConceptGhost_Master_v0.36.json'
$M=Join-Path $env:LOCALAPPDATA 'ConceptGhost-v0.36-install.json'
foreach($P in @($N,$W,$M)){if(-not(Test-Path $P)){throw "Required v0.36 file missing: $P"}}
$Code=Get-Content $N -Raw
$WF=Get-Content $W -Raw|ConvertFrom-Json
foreach($T in @('ConceptGhostMoGeMetricMeasure','ConceptGhostMeasurementTarget','ConceptGhostKnownScaleAuthority','ConceptGhostAtlasMetrologyMeasure','ConceptGhostMoGeAtlasAgreement','ConceptGhostDepthProEvidence','ConceptGhostMetricConsensus','ConceptGhostGeometricRegions','ConceptGhostLocalGeometryCleanup','ConceptGhostGLBFileFromPath','ConceptGhostWorkflowNote')){
  if($Code -notmatch [regex]::Escape($T)){throw "v0.36 node missing: $T"}
}
if(@($WF.nodes).Count -ne 44){throw "Unexpected v0.36 node count: $(@($WF.nodes).Count)"}
if(@($WF.links).Count -ne 75){throw "Unexpected v0.36 link count: $(@($WF.links).Count)"}
if(@($WF.groups).Count -ne 9){throw "Unexpected v0.36 group count: $(@($WF.groups).Count)"}
if(@($WF.nodes|Where-Object{$_.type-eq'ConceptGhostWorkflowNote'}).Count -ne 7){throw 'Expected 7 workflow guide notes'}
if(@($WF.nodes|Where-Object{$_.type-eq'SaveGLB'}).Count -ne 5){throw 'Expected 5 native Save 3D Model outputs'}
foreach($Legacy in @('LoadMoGeModel','MoGeInference','ConceptGhostMoGeVersionRouter','ConceptGhostSelectedAtlasSolve','AtlasDepthMap','AtlasDeriveReliefMesh','AtlasExportReliefMesh','ConceptGhostMeshTrackRecorder','MoGePointMapToMesh')){
  if(@($WF.nodes|Where-Object{$_.type-eq$Legacy}).Count -gt 0){throw "Legacy canonical-workflow node still present: $Legacy"}
}
$Master=$WF.nodes|Where-Object{$_.type-eq'ConceptGhostMasterConfig'}|Select-Object -First 1
$Remesh=$WF.nodes|Where-Object{$_.type-eq'ConceptGhostPrimaryRemeshExporter'}|Select-Object -First 1
$Target=$WF.nodes|Where-Object{$_.type-eq'ConceptGhostMeasurementTarget'}|Select-Object -First 1
$Scale=$WF.nodes|Where-Object{$_.type-eq'ConceptGhostKnownScaleAuthority'}|Select-Object -First 1
$P7=$WF.nodes|Where-Object{$_.type-eq'ConceptGhostGeometricRegions'}|Select-Object -First 1
$P8=$WF.nodes|Where-Object{$_.type-eq'ConceptGhostLocalGeometryCleanup'}|Select-Object -First 1
if(-not $Master -or -not $Remesh -or -not $Target -or -not $Scale -or -not $P7 -or -not $P8){throw 'Core v0.36 control node missing'}
if([bool]$Remesh.widgets_values[0]){throw 'Remesh must default OFF'}
if([bool]$Target.widgets_values[0] -or [bool]$Target.widgets_values[8]){throw 'Measurement Target / manual scale authority must default OFF'}
if([bool]$P7.widgets_values[0]){throw 'P7 must default OFF'}
if([bool]$P8.widgets_values[0] -or [bool]$P8.widgets_values[1]){throw 'P8 diagnostic/approval must default OFF'}
if($Master.widgets_values[3]-ne'MoGe-3'){throw 'Canonical workflow must be locked to MoGe-3'}
# Every link must reference existing nodes and valid slots.
$Ids=@{}; foreach($Node in $WF.nodes){$Ids[[int]$Node.id]=$Node}
foreach($L in $WF.links){
  $O=[int]$L[1]; $OS=[int]$L[2]; $T=[int]$L[3]; $TS=[int]$L[4]
  if(-not $Ids.ContainsKey($O) -or -not $Ids.ContainsKey($T)){throw "Dangling link id=$($L[0])"}
  if($OS -ge @($Ids[$O].outputs).Count -or $TS -ge @($Ids[$T].inputs).Count){throw "Invalid link slot id=$($L[0])"}
}
# Visual overlap guard: no canonical graph nodes may geometrically overlap.
$Nodes=@($WF.nodes)
for($i=0;$i-lt$Nodes.Count;$i++){
  $A=$Nodes[$i]; $ax=[double]$A.pos[0]; $ay=[double]$A.pos[1]; $aw=[double]$A.size[0]; $ah=[double]$A.size[1]
  for($j=$i+1;$j-lt$Nodes.Count;$j++){
    $B=$Nodes[$j]; $bx=[double]$B.pos[0]; $by=[double]$B.pos[1]; $bw=[double]$B.size[0]; $bh=[double]$B.size[1]
    $ix=[Math]::Max(0,[Math]::Min($ax+$aw,$bx+$bw)-[Math]::Max($ax,$bx))
    $iy=[Math]::Max(0,[Math]::Min($ay+$ah,$by+$bh)-[Math]::Max($ay,$by))
    if($ix-gt 0 -and $iy-gt 0){throw "Workflow node overlap: $($A.id) / $($B.id)"}
  }
}
$Marker=Get-Content $M -Raw|ConvertFrom-Json
if($Marker.schema-ne'ConceptGhost.InstallMarker.v0.36'){throw 'Install marker schema mismatch'}
$H=(Get-FileHash $W -Algorithm SHA256).Hash.ToLowerInvariant()
if($H-ne$Marker.canonical_workflow_sha256){throw 'Workflow hash differs from install marker'}
Write-Host '[PASS] ConceptGhost v0.36 installed-file verification PASS.' -ForegroundColor Green
Write-Host 'Workflow nodes/links/groups/notes: 44 / 75 / 9 / 7' -ForegroundColor Green
Write-Host 'No node overlaps detected. Canonical workflow is MoGe-3 only.' -ForegroundColor Green
Write-Host $W -ForegroundColor Cyan

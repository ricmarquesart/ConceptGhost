$ErrorActionPreference="Stop"
$R=Join-Path $env:LOCALAPPDATA "ConceptGhost-DepthProRuntime-v1"
$Py=Join-Path $R "python\python.exe"; $Ready=Join-Path $R "READY.json"; $W=Join-Path $R "worker\depthpro_worker.py"; $C=Join-Path $R "checkpoints\depth_pro.pt"
foreach($P in @($Py,$Ready,$W,$C)){if(-not(Test-Path $P)){throw "Depth Pro private runtime file missing: $P"}}
$J=Get-Content $Ready -Raw|ConvertFrom-Json; if($J.status -ne 'PASS'){throw 'Depth Pro runtime READY.json is not PASS'}
& $Py -c "import torch, depth_pro; assert torch.cuda.is_available(); print('Depth Pro import/CUDA PASS:', torch.__version__, torch.version.cuda)"
if($LASTEXITCODE -ne 0){throw 'Depth Pro private Python import/CUDA verification failed'}
Write-Host "[PASS] Depth Pro private runtime verified at: $R" -ForegroundColor Green

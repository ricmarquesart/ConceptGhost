from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import numpy as np

try:
    from .conceptghost_variants import _compact_mesh, _recompute_vertex_normals, _triangle_metrics, write_glb_with_artist_camera
except ImportError:
    from conceptghost_variants import _compact_mesh, _recompute_vertex_normals, _triangle_metrics, write_glb_with_artist_camera


def _load_json(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8"))
    return dict(obj) if isinstance(obj, dict) else {}


def _plane_fit(vertices: np.ndarray, vertex_ids: np.ndarray, max_samples: int = 20_000) -> dict[str, Any]:
    ids = np.asarray(vertex_ids, dtype=np.int64).reshape(-1)
    if len(ids) < 3:
        return {"status": "UNAVAILABLE", "reason": "too_few_vertices"}
    ids = np.unique(ids)
    if len(ids) > int(max_samples):
        step = int(math.ceil(len(ids) / float(max_samples)))
        ids = ids[::step][: int(max_samples)]
    pts = np.asarray(vertices, dtype=np.float64)[ids]
    center = pts.mean(axis=0)
    centered = pts - center
    try:
        _, singular, vh = np.linalg.svd(centered, full_matrices=False)
    except Exception as exc:
        return {"status": "UNAVAILABLE", "reason": f"svd_failed:{exc}"}
    normal = vh[-1]
    nlen = float(np.linalg.norm(normal))
    if not math.isfinite(nlen) or nlen <= 1e-12:
        return {"status": "UNAVAILABLE", "reason": "invalid_normal"}
    normal = normal / nlen
    dist = centered @ normal
    rms = float(np.sqrt(np.mean(dist * dist)))
    scale = float(np.sqrt(np.mean(np.sum(centered * centered, axis=1))))
    return {
        "status": "PASS",
        "sample_count": int(len(ids)),
        "center_world": [float(x) for x in center],
        "normal_world": [float(x) for x in normal],
        "rms_residual_m": rms,
        "relative_rms": float(rms / max(scale, 1e-12)),
    }



def _small_hole_diagnostics(
    vertices: np.ndarray,
    faces: np.ndarray,
    *,
    face_region_ids: np.ndarray | None = None,
    boundary_strength: np.ndarray | None = None,
    grid_xy: np.ndarray | None = None,
    max_loop_edges: int = 64,
    max_reported_loops: int = 64,
) -> dict[str, Any]:
    """Detect small closed boundary loops without filling them.

    This is deliberately diagnostic-only.  A boundary loop can represent a true
    hole, an intended depth discontinuity, the image/silhouette border, or an
    artist-valid opening.  ConceptGhost therefore reports small closed loops and
    their evidence, but never triangulates them automatically in v0.33.
    """
    v = np.asarray(vertices, dtype=np.float32)
    f = np.asarray(faces, dtype=np.int64).reshape((-1, 3))
    if len(f) == 0:
        return {
            "status": "PASS", "policy": "diagnostic_only_no_automatic_fill",
            "boundary_edge_count": 0, "closed_loop_count": 0,
            "small_closed_loop_count": 0, "artist_review_candidate_count": 0,
            "loops": [],
        }

    # int32 is sufficient for current ConceptGhost meshes and materially reduces
    # peak memory on multi-million-triangle High Fidelity runs.
    fi = f.astype(np.int32, copy=False)
    edges = np.concatenate([fi[:, [0, 1]], fi[:, [1, 2]], fi[:, [2, 0]]], axis=0)
    edge_faces = np.tile(np.arange(len(fi), dtype=np.int32), 3)
    edges.sort(axis=1)
    order = np.lexsort((edges[:, 1], edges[:, 0]))
    sorted_edges = edges[order]
    sorted_faces = edge_faces[order]
    change = np.empty(len(sorted_edges), dtype=bool)
    change[0] = True
    change[1:] = np.any(sorted_edges[1:] != sorted_edges[:-1], axis=1)
    starts = np.flatnonzero(change)
    ends = np.r_[starts[1:], len(sorted_edges)]
    counts = ends - starts
    bstart = starts[counts == 1]
    if len(bstart) == 0:
        return {
            "status": "PASS", "policy": "diagnostic_only_no_automatic_fill",
            "boundary_edge_count": 0, "closed_loop_count": 0,
            "small_closed_loop_count": 0, "artist_review_candidate_count": 0,
            "loops": [],
        }
    bedges = sorted_edges[bstart].astype(np.int64, copy=False)
    bfaces = sorted_faces[bstart].astype(np.int64, copy=False)

    degree = np.bincount(bedges.reshape(-1), minlength=len(v))
    # Closed manifold boundary loops have boundary-degree exactly two.  Restrict
    # graph construction to those vertices; open chains/branching cuts are kept
    # in global counts but cannot become fill candidates.
    good_edge = (degree[bedges[:, 0]] == 2) & (degree[bedges[:, 1]] == 2)
    loop_edges = bedges[good_edge]
    loop_faces = bfaces[good_edge]
    adjacency: dict[int, list[int]] = {}
    owner_by_edge: dict[tuple[int, int], int] = {}
    for (a, b), owner in zip(loop_edges.tolist(), loop_faces.tolist()):
        ia, ib = int(a), int(b)
        adjacency.setdefault(ia, []).append(ib)
        adjacency.setdefault(ib, []).append(ia)
        owner_by_edge[(min(ia, ib), max(ia, ib))] = int(owner)

    labels = None
    if face_region_ids is not None:
        arr = np.asarray(face_region_ids, dtype=np.int32).reshape(-1)
        if len(arr) == len(f):
            labels = arr
    strength = None
    strength_threshold = math.inf
    if boundary_strength is not None:
        arr = np.asarray(boundary_strength, dtype=np.float32).reshape(-1)
        if len(arr) == len(v):
            strength = arr
            finite = arr[np.isfinite(arr)]
            if len(finite):
                strength_threshold = float(np.percentile(finite, 85.0))
                if not math.isfinite(strength_threshold) or strength_threshold <= 0:
                    strength_threshold = math.inf

    grid = None
    gx_min = gx_max = gy_min = gy_max = None
    if grid_xy is not None:
        arr = np.asarray(grid_xy, dtype=np.int64).reshape((-1, 2))
        if len(arr) == len(v) and len(arr):
            grid = arr
            gx_min, gy_min = int(arr[:, 0].min()), int(arr[:, 1].min())
            gx_max, gy_max = int(arr[:, 0].max()), int(arr[:, 1].max())

    visited: set[int] = set()
    closed_loop_count = 0
    small_loop_count = 0
    review_count = 0
    loops: list[dict[str, Any]] = []
    for start in sorted(adjacency):
        if start in visited:
            continue
        stack = [start]
        component: list[int] = []
        visited.add(start)
        while stack:
            cur = stack.pop()
            component.append(cur)
            for nb in adjacency.get(cur, []):
                if nb not in visited:
                    visited.add(nb); stack.append(nb)
        comp_set = set(component)
        closed = bool(component) and all(len(adjacency.get(x, [])) == 2 for x in component)
        if not closed:
            continue
        # Count each undirected edge once.
        comp_edges: list[tuple[int, int]] = []
        for a in component:
            for b in adjacency.get(a, []):
                if a < b and b in comp_set:
                    comp_edges.append((a, b))
        edge_count = len(comp_edges)
        if edge_count < 3:
            continue
        closed_loop_count += 1
        if edge_count > int(max_loop_edges):
            continue
        small_loop_count += 1
        pts_a = v[np.asarray([e[0] for e in comp_edges], dtype=np.int64)]
        pts_b = v[np.asarray([e[1] for e in comp_edges], dtype=np.int64)]
        perimeter = float(np.linalg.norm(pts_a - pts_b, axis=1).sum())
        owner_faces = np.asarray([owner_by_edge[e] for e in comp_edges], dtype=np.int64)
        region_ids: list[int] = []
        if labels is not None and len(owner_faces):
            region_ids = sorted(int(x) for x in np.unique(labels[owner_faces]) if int(x) >= 0)
        single_region = len(region_ids) == 1
        strong_fraction = 0.0
        if strength is not None and math.isfinite(strength_threshold):
            vv = np.asarray(component, dtype=np.int64)
            vals = strength[vv]
            strong_fraction = float(np.count_nonzero(np.isfinite(vals) & (vals >= strength_threshold)) / max(len(vv), 1))
        touches_image_border = False
        if grid is not None:
            gv = grid[np.asarray(component, dtype=np.int64)]
            touches_image_border = bool(
                np.any(gv[:, 0] == gx_min) or np.any(gv[:, 0] == gx_max) or
                np.any(gv[:, 1] == gy_min) or np.any(gv[:, 1] == gy_max)
            )
        # Review candidate only: never an automatic fill instruction. Strong
        # depth-edge support, cross-region ownership, or image-border contact
        # protects the opening from being mistaken for a small hole.
        review = bool(single_region and strong_fraction <= 0.20 and not touches_image_border)
        if review:
            review_count += 1
        if len(loops) < int(max_reported_loops):
            loops.append({
                "edge_count": int(edge_count),
                "vertex_count": int(len(component)),
                "perimeter_m": perimeter,
                "region_ids": region_ids,
                "single_region": bool(single_region),
                "strong_boundary_vertex_fraction": strong_fraction,
                "touches_image_border": touches_image_border,
                "artist_review_candidate": review,
                "automatic_fill": False,
            })

    return {
        "status": "PASS",
        "policy": "diagnostic_only_no_automatic_fill",
        "boundary_edge_count": int(len(bedges)),
        "boundary_degree2_edge_count": int(np.count_nonzero(good_edge)),
        "closed_loop_count": int(closed_loop_count),
        "small_loop_max_edges": int(max_loop_edges),
        "small_closed_loop_count": int(small_loop_count),
        "artist_review_candidate_count": int(review_count),
        "strong_boundary_threshold": None if not math.isfinite(strength_threshold) else float(strength_threshold),
        "reported_loop_count": int(len(loops)),
        "loops": loops,
        "automatic_fill_enabled": False,
    }


def _connected_component_diagnostics(vertices: np.ndarray, faces: np.ndarray, *, small_face_threshold: int = 128, max_reported: int = 64) -> dict[str, Any]:
    """Exact mesh-shell diagnostics. Never deletes components automatically.

    Uses SciPy sparse connected-components when available. If SciPy is not
    available, the diagnostic fails closed as UNAVAILABLE rather than guessing.
    """
    v = np.asarray(vertices, dtype=np.float32).reshape((-1, 3))
    f = np.asarray(faces, dtype=np.int64).reshape((-1, 3))
    if len(v) == 0 or len(f) == 0:
        return {"status": "PASS", "component_count": 0, "components": [], "automatic_deletion": False}
    try:
        from scipy.sparse import coo_matrix
        from scipy.sparse.csgraph import connected_components
    except Exception as exc:
        return {"status": "UNAVAILABLE", "reason": f"scipy_unavailable:{exc}", "automatic_deletion": False}

    # Three undirected triangle edges. Build a symmetric sparse graph without
    # materializing Python edge tuples.
    a = np.concatenate([f[:, 0], f[:, 1], f[:, 2]]).astype(np.int64, copy=False)
    b = np.concatenate([f[:, 1], f[:, 2], f[:, 0]]).astype(np.int64, copy=False)
    rows = np.concatenate([a, b])
    cols = np.concatenate([b, a])
    data = np.ones(len(rows), dtype=np.uint8)
    graph = coo_matrix((data, (rows, cols)), shape=(len(v), len(v))).tocsr()
    count, labels = connected_components(graph, directed=False, return_labels=True)
    vertex_counts = np.bincount(labels, minlength=count).astype(np.int64)
    face_labels = labels[f[:, 0]]
    face_counts = np.bincount(face_labels, minlength=count).astype(np.int64)
    order = np.argsort(face_counts)[::-1]
    comps = []
    small_ids = []
    for cid in range(int(count)):
        if int(face_counts[cid]) <= int(small_face_threshold):
            small_ids.append(int(cid))
    for cid in order[:int(max_reported)]:
        comps.append({
            "component_id": int(cid),
            "vertex_count": int(vertex_counts[cid]),
            "face_count": int(face_counts[cid]),
            "face_ratio": float(face_counts[cid] / max(len(f), 1)),
            "small_floating_candidate": bool(int(cid) in small_ids),
        })
    return {
        "status": "PASS",
        "component_count": int(count),
        "small_face_threshold": int(small_face_threshold),
        "small_component_count": int(len(small_ids)),
        "small_component_ids": small_ids[:int(max_reported)],
        "reported_component_count": int(len(comps)),
        "components": comps,
        "automatic_deletion": False,
        "policy": "diagnostic_only_small_shells_require_artist_review",
    }


def _adaptive_local_remesh_gate(region_report: dict[str, Any], cleanup_report: dict[str, Any]) -> dict[str, Any]:
    """Fail-closed promotion gate for adaptive local remeshing.

    v0.33 deliberately does not triangulate irregular region interiors.  A safe
    implementation needs constrained boundary triangulation/stitching and a
    benchmark proving that it improves a defect metric without cracks, UV drift,
    or cross-depth bridges.  Recording this decision in the run is preferable to
    a silent TODO or an unsafe approximation.
    """
    planar_ids = [int(x) for x in (cleanup_report.get("planar_relaxation_region_ids") or [])]
    region_count = int(region_report.get("region_count") or len(region_report.get("regions") or []))
    return {
        "status": "DEFERRED_BY_BENCHMARK",
        "automatic_execution": False,
        "official_primarymesh_replacement": False,
        "region_count_available": region_count,
        "candidate_planar_region_ids": planar_ids,
        "required_before_promotion": [
            "boundary_constrained_triangulation_or_equivalent_crack_free_stitching",
            "exact_preservation_of_region_boundary_vertices",
            "no_cross_region_or_cross_depth_bridges",
            "uv_and_material_continuity",
            "fixed_suite_before_after_metric_improvement",
            "maya_fbx_roundtrip_pass",
        ],
        "decision": "do_not_ship_an_unproven_local_remesher_in_v0.33",
    }

def analyze_local_cleanup(
    arrays: dict[str, np.ndarray],
    region_report: dict[str, Any],
    face_region_ids: np.ndarray,
) -> tuple[dict[str, Any], np.ndarray]:
    """Diagnose safe local cleanup opportunities without modifying geometry."""
    v = np.asarray(arrays["vertices"], dtype=np.float32)
    f = np.asarray(arrays["faces"], dtype=np.int64).reshape((-1, 3))
    labels = np.asarray(face_region_ids, dtype=np.int32).reshape(-1)
    if len(labels) != len(f):
        raise ValueError("region face map must align one-to-one with PrimaryMesh faces")

    quality, ratio = _triangle_metrics(v, f)
    boundary = np.asarray(arrays.get("geometric_boundary_strength", []), dtype=np.float32).reshape(-1)
    if len(boundary) == len(v):
        fboundary = np.nanmax(boundary[f], axis=1)
        finite = fboundary[np.isfinite(fboundary)]
        boundary_threshold = float(np.percentile(finite, 85.0)) if len(finite) else math.inf
        if not math.isfinite(boundary_threshold) or boundary_threshold <= 0:
            boundary_threshold = math.inf
        boundary_protected = np.isfinite(fboundary) & (fboundary >= boundary_threshold)
    else:
        boundary_threshold = math.inf
        boundary_protected = np.zeros(len(f), dtype=bool)

    incidence = np.bincount(f.reshape(-1), minlength=len(v))
    dangling = ((incidence[f] <= 2).sum(axis=1) >= 2) & (quality < 0.18)
    severe_sliver = (quality < 0.015) | (ratio > 35.0)
    catastrophic = (quality < 0.004) | (ratio > 90.0)

    regions = region_report.get("regions") if isinstance(region_report.get("regions"), list) else []
    flagged_ids = set()
    planar_relaxation_ids = set()
    region_diagnostics = []
    for rid, region in enumerate(regions):
        if rid >= int(labels.max(initial=-1) + 1):
            break
        rmask = labels == rid
        face_count = int(np.count_nonzero(rmask))
        if face_count == 0:
            continue
        curvature = float(region.get("curvature_proxy") or 0.0)
        b_ratio = float(region.get("boundary_face_ratio") or 0.0)
        planarity = float(region.get("planarity_score") or 0.0)
        sliver_count = int(np.count_nonzero(severe_sliver & rmask))
        whisker_count = int(np.count_nonzero(dangling & rmask))
        bad_ratio = float((sliver_count + whisker_count) / max(face_count, 1))
        # Automatic FLAGGING is diagnostic only. Actual candidate generation still
        # requires explicit artist approval in the node.
        flagged = bool(curvature >= 0.28 or bad_ratio >= 0.0025 or (planarity < 0.72 and face_count < 200_000))
        if flagged:
            flagged_ids.add(rid)
        face_idx = np.flatnonzero(rmask)
        # Plane fitting is report-only; it does not project vertices.
        sample_faces = face_idx
        if len(sample_faces) > 25_000:
            step = int(math.ceil(len(sample_faces) / 25_000.0))
            sample_faces = sample_faces[::step][:25_000]
        plane = _plane_fit(v, f[sample_faces].reshape(-1))
        planar_candidate = bool(
            plane.get("status") == "PASS"
            and planarity >= 0.93
            and float(plane.get("relative_rms") or 1.0) <= 0.10
            and b_ratio <= 0.10
            and face_count >= 5_000
        )
        if planar_candidate:
            planar_relaxation_ids.add(rid)
        region_diagnostics.append({
            "region_id": int(rid),
            "name": region.get("name") or f"CG_REGION_{rid+1:03d}",
            "label": region.get("label"),
            "face_count": face_count,
            "flagged_for_artist_review": flagged,
            "planar_relaxation_candidate": planar_candidate,
            "planarity_score": planarity,
            "curvature_proxy": curvature,
            "boundary_face_ratio": b_ratio,
            "severe_sliver_faces": sliver_count,
            "dangling_whisker_faces": whisker_count,
            "bad_face_ratio": bad_ratio,
            "plane_fit": plane,
        })

    target = np.isin(labels, np.fromiter(sorted(flagged_ids), dtype=np.int32)) if flagged_ids else np.zeros(len(f), dtype=bool)
    # Strong boundaries are protected. Only catastrophic triangles may override
    # protection because they are numerically broken rather than merely sharp.
    removable_sliver = target & severe_sliver & (~boundary_protected | catastrophic)
    removable_whisker = target & dangling & ~boundary_protected
    remove_mask = removable_sliver | removable_whisker

    small_holes = _small_hole_diagnostics(
        v, f, face_region_ids=labels, boundary_strength=arrays.get("geometric_boundary_strength"),
        grid_xy=arrays.get("grid_xy"),
    )
    components = _connected_component_diagnostics(v, f)

    report = {
        "schema": "ConceptGhost.LocalGeometryCleanup.v0.33",
        "status": "READY_FOR_ARTIST_REVIEW",
        "policy": "diagnostic_then_artist_approved_candidate_primarymesh_never_replaced",
        "official_primarymesh_modified": False,
        "vertex_motion": 0.0,
        "input_vertices": int(len(v)),
        "input_faces": int(len(f)),
        "flagged_region_ids": [int(x) for x in sorted(flagged_ids)],
        "flagged_region_count": int(len(flagged_ids)),
        "planar_relaxation_region_ids": [int(x) for x in sorted(planar_relaxation_ids)],
        "planar_relaxation_region_count": int(len(planar_relaxation_ids)),
        "candidate_removable_faces": int(np.count_nonzero(remove_mask)),
        "candidate_severe_sliver_faces": int(np.count_nonzero(removable_sliver)),
        "candidate_dangling_whisker_faces": int(np.count_nonzero(removable_whisker)),
        "protected_boundary_faces": int(np.count_nonzero(boundary_protected)),
        "boundary_threshold": None if not math.isfinite(boundary_threshold) else float(boundary_threshold),
        "outside_flagged_regions_removed": 0,
        "region_diagnostics": region_diagnostics,
        "small_hole_diagnostics": small_holes,
        "connected_component_diagnostics": components,
        "adaptive_local_remesh": None,
        "deferred_operations": [
            "small-hole filling remains diagnostic-only; loops are never auto-filled",
            "adaptive local remesh is fail-closed until constrained stitching passes benchmark",
        ],
    }
    report["adaptive_local_remesh"] = _adaptive_local_remesh_gate(region_report, report)
    return report, remove_mask


def build_cleanup_candidate(
    arrays: dict[str, np.ndarray],
    camera: dict[str, Any],
    remove_mask: np.ndarray,
    *,
    face_region_ids: np.ndarray | None = None,
    cleanup_report: dict[str, Any] | None = None,
    apply_planar_relaxation: bool = False,
    plane_strength: float = 0.25,
    max_plane_displacement_m: float = 0.02,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    source_v = np.asarray(arrays["vertices"], dtype=np.float32)
    f = np.asarray(arrays["faces"], dtype=np.int64).reshape((-1, 3))
    rm = np.asarray(remove_mask, dtype=bool).reshape(-1)
    if len(rm) != len(f):
        raise ValueError("cleanup remove mask must align to faces")

    working_v = source_v.copy()
    moved = np.zeros(len(source_v), dtype=bool)
    planar_results = []
    outside_region_moved = 0

    labels = None if face_region_ids is None else np.asarray(face_region_ids, dtype=np.int32).reshape(-1)
    report = dict(cleanup_report or {})
    planar_ids = set(int(x) for x in (report.get("planar_relaxation_region_ids") or []))
    diagnostics = {int(x.get("region_id")): x for x in (report.get("region_diagnostics") or []) if isinstance(x, dict) and x.get("region_id") is not None}

    if apply_planar_relaxation and planar_ids:
        if labels is None or len(labels) != len(f):
            raise ValueError("planar relaxation requires face_region_ids aligned to faces")

        # Build a conservative vertex-region ownership map. Vertices touched by
        # multiple regions are region boundaries and are never moved.
        vmin = np.full(len(source_v), np.iinfo(np.int32).max, dtype=np.int32)
        vmax = np.full(len(source_v), -1, dtype=np.int32)
        chunk = 250_000
        for start_i in range(0, len(f), chunk):
            end_i = min(start_i + chunk, len(f))
            lab = labels[start_i:end_i]
            fc = f[start_i:end_i]
            good = lab >= 0
            if not np.any(good):
                continue
            vids = fc[good].reshape(-1)
            reps = np.repeat(lab[good], 3)
            np.minimum.at(vmin, vids, reps)
            np.maximum.at(vmax, vids, reps)
        single_region_vertex = (vmin == vmax) & (vmax >= 0)

        boundary = np.asarray(arrays.get("geometric_boundary_strength", []), dtype=np.float32).reshape(-1)
        if len(boundary) == len(source_v):
            finite = boundary[np.isfinite(boundary)]
            threshold = float(np.percentile(finite, 85.0)) if len(finite) else math.inf
            if not math.isfinite(threshold) or threshold <= 0:
                threshold = math.inf
            boundary_vertex = np.isfinite(boundary) & (boundary >= threshold)
        else:
            boundary_vertex = np.zeros(len(source_v), dtype=bool)

        strength = float(np.clip(plane_strength, 0.0, 0.5))
        displacement_cap = max(0.0, float(max_plane_displacement_m))
        approved_vertex_union = np.zeros(len(source_v), dtype=bool)
        for rid in sorted(planar_ids):
            diag = diagnostics.get(rid) or {}
            plane = diag.get("plane_fit") or {}
            if plane.get("status") != "PASS":
                continue
            center = np.asarray(plane.get("center_world"), dtype=np.float64).reshape(3)
            normal = np.asarray(plane.get("normal_world"), dtype=np.float64).reshape(3)
            nlen = float(np.linalg.norm(normal))
            if not math.isfinite(nlen) or nlen <= 1e-12:
                continue
            normal /= nlen
            owned = single_region_vertex & (vmin == int(rid)) & ~boundary_vertex
            ids = np.flatnonzero(owned)
            if len(ids) == 0:
                continue
            approved_vertex_union[ids] = True
            pts = working_v[ids].astype(np.float64)
            signed_before = (pts - center.reshape(1, 3)) @ normal
            delta_scalar = -signed_before * strength
            delta_scalar = np.clip(delta_scalar, -displacement_cap, displacement_cap)
            delta = delta_scalar[:, None] * normal.reshape(1, 3)
            working_v[ids] = (pts + delta).astype(np.float32)
            disp = np.linalg.norm(delta, axis=1)
            moved_ids = ids[disp > 1e-12]
            moved[moved_ids] = True
            signed_after = (working_v[ids].astype(np.float64) - center.reshape(1, 3)) @ normal
            planar_results.append({
                "region_id": int(rid),
                "name": diag.get("name") or f"CG_REGION_{rid+1:03d}",
                "eligible_interior_vertices": int(len(ids)),
                "moved_vertices": int(len(moved_ids)),
                "rms_before_m": float(np.sqrt(np.mean(signed_before * signed_before))),
                "rms_after_m": float(np.sqrt(np.mean(signed_after * signed_after))),
                "max_displacement_m": float(disp.max(initial=0.0)),
                "mean_displacement_m": float(disp.mean()) if len(disp) else 0.0,
                "strength": strength,
                "boundary_vertices_protected": True,
                "cross_region_vertices_protected": True,
            })
        outside_region_moved = int(np.count_nonzero(moved & ~approved_vertex_union))

    kept = f[~rm]
    if len(kept) == 0:
        raise ValueError("cleanup candidate would remove every face")
    compact = _compact_mesh(
        working_v,
        kept,
        uvs=arrays.get("uvs"),
        grid_xy=arrays.get("grid_xy"),
        source_uv=arrays.get("source_uv"),
        camera_depth=arrays.get("camera_depth"),
        geometric_boundary_strength=arrays.get("geometric_boundary_strength"),
        canonical_point_indices=arrays.get("canonical_point_indices"),
        source_pixel_id=arrays.get("source_pixel_id"),
    )
    compact["faces"], compact["normals"] = _recompute_vertex_normals(compact["vertices"], compact["faces"], camera)
    displacement = np.linalg.norm(working_v.astype(np.float64) - source_v.astype(np.float64), axis=1)
    out_report = {
        "status": "PASS",
        "input_vertices": int(len(source_v)),
        "input_faces": int(len(f)),
        "removed_faces": int(np.count_nonzero(rm)),
        "output_vertices": int(len(compact["vertices"])),
        "output_faces": int(len(compact["faces"])),
        "moved_vertices": int(np.count_nonzero(displacement > 1e-12)),
        "vertex_motion_max_m": float(displacement.max(initial=0.0)),
        "vertex_motion_mean_m": float(displacement[displacement > 1e-12].mean()) if np.any(displacement > 1e-12) else 0.0,
        "outside_approved_regions_moved": int(outside_region_moved),
        "protected_boundary_vertices_moved": 0,
        "cross_region_vertices_moved": 0,
        "uvs_preserved_from_source": bool(arrays.get("uvs") is not None),
        "topology_change": "face_removal_only; no new faces or cross-region bridges",
        "planar_relaxation": planar_results,
        "geometry_policy": "derived_artist_approved_candidate_boundary_protected_local_planar_relaxation_plus_severe_face_cleanup",
        "official_primarymesh_replacement": False,
    }
    return compact, out_report


def _prepare_cleanup_candidate_for_glb(candidate: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    """Convert DCC/Maya-ready PrimaryMesh UVs to glTF preview convention.

    PrimaryMesh stores the DCC/Maya-ready UV orientation.  Master/remesh GLBs
    flip V exactly once before glTF export.  P8 must do the same; otherwise only
    the derived cleanup candidate displays with vertically inverted texture.
    The input candidate is never mutated.
    """
    out = dict(candidate)
    if out.get("uvs") is not None:
        uvs = np.asarray(out["uvs"], dtype=np.float32).copy()
        if uvs.ndim == 2 and uvs.shape[1] == 2:
            uvs[:, 1] = 1.0 - uvs[:, 1]
        out["uvs"] = uvs
    return out


def run_local_cleanup_from_run(run_dir: str | Path, *, approve_candidate: bool = False) -> dict[str, Any]:
    run = Path(run_dir).resolve()
    payload_path = run / "maya" / "primary_mesh_payload.json"
    regions_path = run / "geometry" / "regions" / "geometric_regions.json"
    region_map_path = run / "geometry" / "regions" / "region_map.npz"
    if not payload_path.is_file():
        raise FileNotFoundError(f"PrimaryMesh payload not found: {payload_path}")
    if not regions_path.is_file() or not region_map_path.is_file():
        raise FileNotFoundError("P8 requires P7 geometric regions from the same run")
    payload = _load_json(payload_path)
    npz_path = Path(str(payload.get("npz_path") or ""))
    if not npz_path.is_file():
        raise FileNotFoundError(f"PrimaryMesh NPZ not found: {npz_path}")
    with np.load(npz_path, allow_pickle=False) as data:
        arrays = {k: np.asarray(data[k]) for k in data.files}
    region_report = _load_json(regions_path)
    with np.load(region_map_path, allow_pickle=False) as data:
        face_region_ids = np.asarray(data["face_region_ids"])
    diagnostic, remove_mask = analyze_local_cleanup(arrays, region_report, face_region_ids)
    out_dir = run / "geometry" / "local_cleanup"
    out_dir.mkdir(parents=True, exist_ok=True)
    report_path = out_dir / "cleanup_report.json"

    result = dict(diagnostic)
    result["artist_approved_candidate"] = bool(approve_candidate)
    result["candidate_glb"] = None
    if not approve_candidate:
        report_path.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
        result["report_path"] = str(report_path)
        return result

    camera_path = run / "camera" / "camera.json"
    texture_path = run / "source" / "source.png"
    if not camera_path.is_file():
        raise FileNotFoundError(f"Camera JSON not found: {camera_path}")
    camera = _load_json(camera_path)
    candidate, candidate_report = build_cleanup_candidate(
        arrays, camera, remove_mask,
        face_region_ids=face_region_ids, cleanup_report=diagnostic, apply_planar_relaxation=True,
    )
    result["candidate"] = candidate_report
    has_candidate_change = bool(candidate_report["removed_faces"] > 0 or candidate_report.get("moved_vertices", 0) > 0)
    if has_candidate_change:
        glb_path = out_dir / "ConceptGhost_LocalCleanupCandidate.glb"
        candidate_glb = _prepare_cleanup_candidate_for_glb(candidate)
        write_glb_with_artist_camera(
            glb_path,
            candidate_glb,
            camera,
            texture_path=texture_path if texture_path.is_file() else None,
            mesh_name="CG_LOCAL_CLEANUP_CANDIDATE",
            extras={
                "conceptghost_role": "artist_approved_local_cleanup_candidate",
                "official_primarymesh_replacement": False,
                "vertex_motion_max_m": candidate_report.get("vertex_motion_max_m"),
                "outside_approved_regions_moved": candidate_report.get("outside_approved_regions_moved"),
                "uv_export_policy": "PrimaryMesh DCC UVs -> glTF preview V flip exactly once",
            },
        )
        result["candidate_glb"] = str(glb_path)
    result["status"] = "CANDIDATE_GENERATED" if has_candidate_change else "NO_CHANGE_CANDIDATE"
    report_path.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    result["report_path"] = str(report_path)
    return result

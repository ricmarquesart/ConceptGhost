from __future__ import annotations

import argparse
import json
import os
import re
import sys
import traceback
from pathlib import Path
from typing import Any, Iterable

try:
    from .conceptghost_contracts import assert_profile_contract, assert_maya_manifest_contract
except ImportError:  # standalone mayapy execution
    from conceptghost_contracts import assert_profile_contract, assert_maya_manifest_contract



def _assert_worker_profile(payload: dict[str, Any]) -> dict[str, Any]:
    profile = payload.get("profile_config")
    profile = assert_profile_contract(dict(profile or {}), stage="MAYA_WORKER_INPUT")
    selected = profile["selected_profile"]
    if payload.get("geometry_profile") != selected or payload.get("selected_profile") != selected or payload.get("effective_profile") != selected:
        raise RuntimeError("[MAYA_WORKER] worker input profile fields disagree")
    hero = payload.get("hero_mesh_payload") or {}
    if hero.get("geometry_profile") != selected or hero.get("selected_profile") != selected or hero.get("effective_profile") != selected:
        raise RuntimeError("[MAYA_WORKER] PrimaryMesh profile differs from worker profile")
    if payload.get("model") != profile.get("model") or payload.get("mesher_policy") != profile.get("mesher_policy"):
        raise RuntimeError("[MAYA_WORKER] worker model/mesher differs from GeometryProfile contract")
    if int(payload.get("resolution_level", -1)) != int(profile.get("resolution_level", -2)) or int(payload.get("refine_steps", -1)) != int(profile.get("refine_steps", -2)):
        raise RuntimeError("[MAYA_WORKER] worker resolution/refinement differs from GeometryProfile contract")
    if hero.get("source_model") != profile.get("model") or hero.get("mesher_policy") != profile.get("mesher_policy"):
        raise RuntimeError("[MAYA_WORKER] PrimaryMesh model/mesher differs from GeometryProfile contract")
    if selected in {"High Fidelity", "High Fidelity Split Clean"}:
        required = {
            "model": "Ruicheng/moge-3-vitg",
            "mesher_policy": profile.get("mesher_policy"),
        }
        for key, value in required.items():
            if payload.get(key) != value:
                raise RuntimeError(f"[MAYA_WORKER] High Fidelity input {key} mismatch: {payload.get(key)!r} != {value!r}")
        if int(hero.get("transport_stride", -1)) != 1 or hero.get("depth_edge_rtol") is None:
            raise RuntimeError("[MAYA_WORKER] High Fidelity PrimaryMesh is not stride-1 depth-edge-preserving")
        if hero.get("source_model") != "Ruicheng/moge-3-vitg" or int(hero.get("resolution_level", -1)) != 9 or int(hero.get("refine_steps", -1)) != 7:
            raise RuntimeError("[MAYA_WORKER] High Fidelity PrimaryMesh model/refine contract mismatch")
    return profile

def _clean_name(value: str) -> str:
    value = Path(value or "scene").stem
    value = re.sub(r"[^A-Za-z0-9_]+", "_", value).strip("_")
    return value or "scene"


def build_output_paths(run_dir: str | Path, scene_name: str) -> dict[str, Path]:
    run = Path(run_dir)
    scene = _clean_name(scene_name)
    maya_dir = run / "maya"
    return {
        "ma": maya_dir / f"ConceptGhost_{scene}_Ghost.ma",
        "fbx": maya_dir / f"ConceptGhost_{scene}_Ghost.fbx",
        "camera_fbx": maya_dir / f"ConceptGhost_{scene}_CameraOnly.fbx",
        "fbm_dir": maya_dir / f"ConceptGhost_{scene}_Ghost.fbm",
        "full_scene_fbx": maya_dir / f"ConceptGhost_{scene}_GhostFullScene.fbx",
        "manifest": maya_dir / "maya_manifest.json",
    }


def maya_hierarchy_names(scene_name: str) -> dict[str, str]:
    _clean_name(scene_name)  # validate/sanitize input even though hierarchy is canonical.
    return {
        "root": "CG_ROOT",
        "cameras": "CG_CAMERA",
        "matched_camera": "CG_MATCHED_CAMERA",
        "artist_camera": "CG_ARTIST_CAMERA",
        "source": "CG_SOURCE",
        "source_plate": "CG_SOURCE_PLATE",
        "geometry": "CG_GEOMETRY",
        "hero_mesh": "CG_HERO_MESH",
        "fused_points": "CG_FUSED_POINTS",
        "diagnostics": "CG_DIAGNOSTICS",
        "metric_diagnostics": "CG_METRIC_DIAGNOSTICS",
        "regions": "CG_REGIONS",
        "atlas_relief": "CG_ATLAS_RELIEF",
        "moge_native": "CG_MOGE_NATIVE",
        "metadata": "CG_METADATA",
    }




def fbx_required_camera_names(matched_camera: str, artist_camera: str) -> list[str]:
    return [str(matched_camera), str(artist_camera)]


def fbx_required_export_names(matched_camera: str, artist_camera: str, hero_mesh: str | None = None) -> list[str]:
    names = fbx_required_camera_names(matched_camera, artist_camera)
    if hero_mesh:
        names.append(str(hero_mesh))
    return names


def fbx_export_mel_commands(fbx_path: str | Path) -> list[str]:
    """Robust full-scene FBX export used for the official interchange file.

    Selection export proved unreliable in the artist runtime for cameras.  The
    official scene is intentionally small/curated, so export-all is safer and
    lets the FBX plug-in walk the complete camera hierarchy.
    """
    path = str(fbx_path).replace("\\", "/")
    while "//" in path:
        path = path.replace("//", "/")
    return [
        "FBXResetExport;",
        "FBXExportCameras -v true;",
        "FBXExportLights -v false;",
        "FBXExportUpAxis y;",
        "FBXExportEmbeddedTextures -v true;",
        "FBXExportBakeComplexAnimation -v false;",
        f'FBXExport -f "{path}";',
    ]


def fbx_camera_only_export_mel_commands(fbx_path: str | Path) -> list[str]:
    path = str(fbx_path).replace("\\", "/")
    while "//" in path:
        path = path.replace("//", "/")
    return [
        "FBXResetExport;",
        "FBXExportCameras -v true;",
        "FBXExportLights -v false;",
        "FBXExportUpAxis y;",
        f'FBXExport -f "{path}" -s;',
    ]


def _hardlink_or_copy_alias(source: str | Path, alias: str | Path) -> str:
    """Create a compatibility filename without a second physical payload when possible."""
    import shutil

    src = Path(source)
    dst = Path(alias)
    if not src.is_file():
        raise RuntimeError(f"FBX alias source missing: {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.unlink(missing_ok=True)
    mode = "hardlink"
    try:
        os.link(src, dst)
    except (OSError, NotImplementedError):
        mode = "copy_fallback"
        shutil.copy2(src, dst)
    if int(src.stat().st_size) != int(dst.stat().st_size):
        dst.unlink(missing_ok=True)
        raise RuntimeError(f"FBX compatibility alias size mismatch: {src} -> {dst}")
    return mode


def _verify_fbx_camera_roundtrip(
    cmds, mel, fbx_path: Path, required_cameras: list[str], expected_signatures: dict[str, dict[str, Any]] | None = None,
    required_meshes: list[str] | None = None, expected_mesh_signatures: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Round-trip verify camera presence *and* calibrated camera properties."""
    result: dict[str, Any] = {
        "status": "NOT_RUN",
        "required_cameras": list(required_cameras),
        "found_cameras": [],
        "missing_cameras": list(required_cameras),
        "signature_checks": {},
        "required_meshes": list(required_meshes or []),
        "found_meshes": [],
        "missing_meshes": list(required_meshes or []),
        "mesh_signature_checks": {},
        "mesh_orientation_checks": {},
    }
    if not fbx_path.exists():
        result["status"] = "FAIL"
        result["error"] = "FBX file was not created"
        return result
    try:
        cmds.file(new=True, force=True)
        fbx_norm = str(fbx_path).replace("\\", "/")
        mel.eval(f'FBXImport -f "{fbx_norm}";')
        found: list[str] = []
        signature_failures: list[str] = []
        for camera in required_cameras:
            if cmds.objExists(camera):
                shapes = cmds.listRelatives(camera, shapes=True, type="camera") or []
                if shapes:
                    found.append(camera)
                    if expected_signatures and camera in expected_signatures:
                        actual = _camera_signature(cmds, camera)
                        check = _compare_camera_signatures(expected_signatures[camera], actual)
                        result["signature_checks"][camera] = check
                        if not check["pass"]:
                            signature_failures.append(camera)
        missing = [name for name in required_cameras if name not in found]
        found_meshes: list[str] = []
        mesh_signature_failures: list[str] = []
        for mesh in required_meshes or []:
            if cmds.objExists(mesh):
                shapes = cmds.listRelatives(mesh, shapes=True, type="mesh") or []
                if shapes:
                    found_meshes.append(mesh)
                    if expected_mesh_signatures and mesh in expected_mesh_signatures:
                        actual_mesh = _mesh_signature(cmds, mesh)
                        mesh_check = _compare_mesh_signatures(expected_mesh_signatures[mesh], actual_mesh)
                        result["mesh_signature_checks"][mesh] = mesh_check
                        if not mesh_check["pass"]:
                            mesh_signature_failures.append(mesh)
                    if required_cameras:
                        orientation = _maya_mesh_orientation_gate(cmds, mesh, required_cameras[0], stage="FBX_ROUNDTRIP")
                        result["mesh_orientation_checks"][mesh] = orientation
                        if orientation.get("status") != "PASS":
                            mesh_signature_failures.append(mesh)
        missing_meshes = [name for name in (required_meshes or []) if name not in found_meshes]
        passed = not missing and not signature_failures and not missing_meshes and not mesh_signature_failures
        result.update({
            "status": "PASS" if passed else "FAIL",
            "found_cameras": found,
            "missing_cameras": missing,
            "signature_failures": signature_failures,
            "found_meshes": found_meshes,
            "missing_meshes": missing_meshes,
            "mesh_signature_failures": mesh_signature_failures,
        })
    except Exception as exc:
        result["status"] = "FAIL"
        result["error"] = str(exc)
    return result



def _camera_signature(cmds, camera_transform: str) -> dict[str, Any]:
    shapes = cmds.listRelatives(camera_transform, shapes=True, type="camera") or []
    if not shapes:
        raise ValueError(f"{camera_transform} has no camera shape")
    shape = shapes[0]

    def get(name: str, default: float = 0.0) -> float:
        try:
            return float(cmds.getAttr(f"{shape}.{name}"))
        except Exception:
            return float(default)

    return {
        "focal_length_mm": get("focalLength"),
        "horizontal_film_aperture_in": get("horizontalFilmAperture"),
        "vertical_film_aperture_in": get("verticalFilmAperture"),
        "horizontal_film_offset": get("horizontalFilmOffset"),
        "vertical_film_offset": get("verticalFilmOffset"),
        "world_matrix": [float(v) for v in cmds.xform(camera_transform, query=True, worldSpace=True, matrix=True)],
    }



def _mesh_signature(cmds, mesh_transform: str, sample_vertices: int = 8) -> dict[str, Any]:
    shapes = cmds.listRelatives(mesh_transform, shapes=True, type="mesh") or []
    if not shapes:
        raise ValueError(f"{mesh_transform} has no mesh shape")
    vertex_count = int(cmds.polyEvaluate(mesh_transform, vertex=True))
    face_count = int(cmds.polyEvaluate(mesh_transform, face=True))
    edge_count = int(cmds.polyEvaluate(mesh_transform, edge=True))
    try:
        shell_count = int(cmds.polyEvaluate(mesh_transform, shell=True) or 0)
    except Exception:
        shell_count = 0
    bbox = [float(v) for v in cmds.exactWorldBoundingBox(mesh_transform)]
    take = min(max(vertex_count, 0), int(sample_vertices))
    sample: list[float] = []
    if take > 0:
        values = cmds.xform(f"{mesh_transform}.vtx[0:{take-1}]", query=True, worldSpace=True, translation=True) or []
        sample = [float(v) for v in values]
    try:
        uv_count = int(cmds.polyEvaluate(mesh_transform, uvcoord=True) or 0)
    except Exception:
        uv_count = 0
    shading_engines = sorted(set(cmds.listConnections(shapes, type="shadingEngine") or []))
    materials = []
    textures = []
    for sg in shading_engines:
        for mat in cmds.ls(cmds.listConnections(f"{sg}.surfaceShader") or [], materials=True) or []:
            if mat not in materials:
                materials.append(mat)
            for file_node in cmds.listConnections(mat, type="file") or []:
                try:
                    tex = str(cmds.getAttr(f"{file_node}.fileTextureName") or "")
                except Exception:
                    tex = ""
                if tex and tex not in textures:
                    textures.append(tex)
    return {
        "vertex_count": vertex_count,
        "face_count": face_count,
        "edge_count": edge_count,
        "shell_count": shell_count,
        "uv_count": uv_count,
        "material_count": len(materials),
        "materials": sorted(materials),
        "texture_paths": sorted(textures),
        "bbox": bbox,
        "sample_world_positions": sample,
    }


def _npz_orientation_gate(hero_payload: dict[str, Any] | None, camera: dict[str, Any], *, stage: str = "PRE_MAYA") -> dict[str, Any]:
    """Validate the serialized transport mesh before Maya touches it.

    This lets v0.28 recover an already-computed incomplete run while still
    enforcing the same topology/normal contract used by fresh executions.
    """
    import numpy as np
    result: dict[str, Any] = {"stage": stage, "status": "FAIL"}
    try:
        if not hero_payload:
            return {"stage": stage, "status": "NOT_REQUESTED"}
        npz_path = Path(hero_payload["npz_path"]).resolve()
        data = np.load(npz_path)
        v = np.asarray(data["vertices"], dtype=np.float64).reshape((-1, 3))
        f = np.asarray(data["faces"], dtype=np.int64).reshape((-1, 3))
        if not len(v) or not len(f):
            raise ValueError("empty transport mesh")
        p0=v[f[:,0]]; p1=v[f[:,1]]; p2=v[f[:,2]]
        raw=np.cross(p1-p0,p2-p0); raw_len=np.linalg.norm(raw,axis=1)
        valid=np.isfinite(raw_len)&(raw_len>1e-12)
        face_n=np.zeros_like(raw); face_n[valid]=raw[valid]/raw_len[valid,None]
        cent=(p0+p1+p2)/3.0
        cam=np.asarray((camera.get("extrinsics") or {}).get("camera_position") or [0,0,0],dtype=np.float64).reshape(3)
        to_cam=cam[None,:]-cent; to_cam_len=np.linalg.norm(to_cam,axis=1)
        cam_ok=valid&np.isfinite(to_cam_len)&(to_cam_len>1e-12)
        camera_dot=np.zeros(len(f),dtype=np.float64)
        camera_dot[cam_ok]=np.einsum("ij,ij->i",face_n[cam_ok],to_cam[cam_ok]/to_cam_len[cam_ok,None])
        camera_facing=cam_ok&(camera_dot>0.0); camera_away=cam_ok&(camera_dot<=0.0)

        if "face_vertex_normals" in data:
            fvn=np.asarray(data["face_vertex_normals"],dtype=np.float64).reshape((len(f),3,3))
        elif "normals" in data:
            vn=np.asarray(data["normals"],dtype=np.float64).reshape((-1,3))
            fvn=vn[f]
        else:
            raise ValueError("transport payload contains no normals")
        fvn_len=np.linalg.norm(fvn,axis=2)
        zero_corner=valid[:,None]&((~np.isfinite(fvn_len))|(fvn_len<=1e-12))
        face_export=np.sum(fvn,axis=1); face_export_len=np.linalg.norm(face_export,axis=1)
        export_ok=valid&np.isfinite(face_export_len)&(face_export_len>1e-12)
        face_export_unit=np.zeros_like(face_export); face_export_unit[export_ok]=face_export[export_ok]/face_export_len[export_ok,None]
        normal_dot=np.zeros(len(f),dtype=np.float64)
        normal_dot[export_ok]=np.einsum("ij,ij->i",face_n[export_ok],face_export_unit[export_ok])
        normal_aligned=export_ok&(normal_dot>0.0); normal_opposed=export_ok&(normal_dot<=0.0)

        def stats(values, mask):
            a=np.asarray(values[mask],dtype=np.float64); a=a[np.isfinite(a)]
            if not len(a): return {"min":0.0,"median":0.0,"p05":0.0,"p95":0.0}
            return {"min":float(np.min(a)),"median":float(np.median(a)),"p05":float(np.percentile(a,5)),"p95":float(np.percentile(a,95))}

        passed=(
            int(np.count_nonzero(~valid)) == 0
            and int(np.count_nonzero(camera_away)) == 0
            and int(np.count_nonzero(normal_opposed)) == 0
            and int(np.count_nonzero(zero_corner)) == 0
        )
        result.update({
            "status":"PASS" if passed else "FAIL",
            "vertex_count":int(len(v)),
            "faces_total":int(len(f)),
            "valid_faces":int(np.count_nonzero(valid)),
            "degenerate_faces":int(np.count_nonzero(~valid)),
            "camera_facing_faces":int(np.count_nonzero(camera_facing)),
            "camera_away_faces":int(np.count_nonzero(camera_away)),
            "normal_aligned_faces":int(np.count_nonzero(normal_aligned)),
            "normal_opposed_faces":int(np.count_nonzero(normal_opposed)),
            "zero_normals":int(np.count_nonzero(zero_corner)),
            "camera_dot":stats(camera_dot,cam_ok),
            "normal_dot":stats(normal_dot,export_ok),
            "npz_path":str(npz_path),
        })
    except Exception as exc:
        result.update({"status":"FAIL","error":str(exc)})
    return result


def _maya_mesh_orientation_gate(cmds, mesh_transform: str, camera_transform: str, *, stage: str) -> dict[str, Any]:
    """Validate final Maya/FBX mesh winding, face-vertex normals and camera facing.

    Uses the authored mesh topology as the authority.  No Reverse operation is
    performed here: the gate measures the DCC result and fails if winding or
    exported normals disagree with the single-view relief contract.
    """
    import numpy as np
    import maya.api.OpenMaya as om  # type: ignore

    result: dict[str, Any] = {
        "stage": stage,
        "status": "FAIL",
        "mesh": mesh_transform,
        "camera": camera_transform,
    }
    try:
        shapes = cmds.listRelatives(mesh_transform, shapes=True, type="mesh", fullPath=True) or []
        if not shapes:
            raise ValueError(f"{mesh_transform} has no mesh shape")
        sel = om.MSelectionList(); sel.add(shapes[0])
        dag = sel.getDagPath(0)
        fn = om.MFnMesh(dag)

        pts_m = fn.getPoints(om.MSpace.kWorld)
        points = np.asarray([[p.x, p.y, p.z] for p in pts_m], dtype=np.float64)
        poly_counts_m, poly_connects_m = fn.getVertices()
        poly_counts = np.asarray(poly_counts_m, dtype=np.int64)
        poly_connects = np.asarray(poly_connects_m, dtype=np.int64)
        faces_total = int(len(poly_counts))
        if faces_total == 0:
            raise ValueError("mesh has no faces")
        if not np.all(poly_counts == 3):
            raise ValueError(f"orientation gate requires triangulated mesh; polygon sizes={sorted(set(poly_counts.tolist()))}")
        faces = poly_connects.reshape((-1, 3))

        p0 = points[faces[:, 0]]; p1 = points[faces[:, 1]]; p2 = points[faces[:, 2]]
        raw = np.cross(p1 - p0, p2 - p0)
        raw_len = np.linalg.norm(raw, axis=1)
        valid = np.isfinite(raw_len) & (raw_len > 1e-12)
        face_n = np.zeros_like(raw)
        face_n[valid] = raw[valid] / raw_len[valid, None]
        cent = (p0 + p1 + p2) / 3.0

        cam = np.asarray(cmds.xform(camera_transform, query=True, worldSpace=True, translation=True), dtype=np.float64).reshape(3)
        to_cam = cam[None, :] - cent
        to_cam_len = np.linalg.norm(to_cam, axis=1)
        cam_ok = valid & np.isfinite(to_cam_len) & (to_cam_len > 1e-12)
        camera_dot = np.zeros(faces_total, dtype=np.float64)
        camera_dot[cam_ok] = np.einsum("ij,ij->i", face_n[cam_ok], to_cam[cam_ok] / to_cam_len[cam_ok, None])
        camera_facing = cam_ok & (camera_dot > 0.0)
        camera_away = cam_ok & (camera_dot <= 0.0)

        normal_counts_m, normal_ids_m = fn.getNormalIds()
        normal_counts = np.asarray(normal_counts_m, dtype=np.int64)
        normal_ids = np.asarray(normal_ids_m, dtype=np.int64)
        if len(normal_counts) != faces_total or not np.all(normal_counts == 3):
            raise ValueError("unexpected face-vertex normal layout")
        normals_m = fn.getNormals(om.MSpace.kWorld)
        normals = np.asarray([[n.x, n.y, n.z] for n in normals_m], dtype=np.float64)
        fvn = normals[normal_ids.reshape((-1, 3))]
        fvn_len = np.linalg.norm(fvn, axis=2)
        zero_corner = valid[:, None] & ((~np.isfinite(fvn_len)) | (fvn_len <= 1e-12))
        face_export = np.sum(fvn, axis=1)
        face_export_len = np.linalg.norm(face_export, axis=1)
        export_ok = valid & np.isfinite(face_export_len) & (face_export_len > 1e-12)
        face_export_unit = np.zeros_like(face_export)
        face_export_unit[export_ok] = face_export[export_ok] / face_export_len[export_ok, None]
        normal_dot = np.zeros(faces_total, dtype=np.float64)
        normal_dot[export_ok] = np.einsum("ij,ij->i", face_n[export_ok], face_export_unit[export_ok])
        normal_aligned = export_ok & (normal_dot > 0.0)
        normal_opposed = export_ok & (normal_dot <= 0.0)

        def stats(values, mask):
            a = np.asarray(values[mask], dtype=np.float64)
            a = a[np.isfinite(a)]
            if not len(a):
                return {"min": 0.0, "median": 0.0, "p05": 0.0, "p95": 0.0}
            return {"min": float(np.min(a)), "median": float(np.median(a)), "p05": float(np.percentile(a, 5)), "p95": float(np.percentile(a, 95))}

        gate_pass = (
            int(np.count_nonzero(~valid)) == 0
            and int(np.count_nonzero(camera_away)) == 0
            and int(np.count_nonzero(normal_opposed)) == 0
            and int(np.count_nonzero(zero_corner)) == 0
        )
        result.update({
            "status": "PASS" if gate_pass else "FAIL",
            "vertex_count": int(len(points)),
            "faces_total": faces_total,
            "valid_faces": int(np.count_nonzero(valid)),
            "degenerate_faces": int(np.count_nonzero(~valid)),
            "camera_facing_faces": int(np.count_nonzero(camera_facing)),
            "camera_away_faces": int(np.count_nonzero(camera_away)),
            "normal_aligned_faces": int(np.count_nonzero(normal_aligned)),
            "normal_opposed_faces": int(np.count_nonzero(normal_opposed)),
            "zero_normals": int(np.count_nonzero(zero_corner)),
            "camera_dot": stats(camera_dot, cam_ok),
            "normal_dot": stats(normal_dot, export_ok),
        })
    except Exception as exc:
        result["status"] = "FAIL"
        result["error"] = str(exc)
    return result


def _ensure_fbx_media_folder(out: dict[str, Path], texture_path: str | None) -> dict[str, Any]:
    """Keep the historical portable .fbm companion folder available."""
    result = {"path": str(out["fbm_dir"]), "status": "NOT_REQUESTED", "copied": []}
    if not texture_path:
        return result
    src = Path(texture_path)
    if not src.is_file():
        result.update({"status": "FAIL", "error": f"texture missing: {src}"})
        return result
    try:
        import shutil
        out["fbm_dir"].mkdir(parents=True, exist_ok=True)
        dst = out["fbm_dir"] / src.name
        shutil.copy2(src, dst)
        result.update({"status": "PASS", "copied": [str(dst)]})
    except Exception as exc:
        result.update({"status": "FAIL", "error": str(exc)})
    return result


def _compare_mesh_signatures(expected: dict[str, Any], actual: dict[str, Any]) -> dict[str, Any]:
    mismatches: dict[str, Any] = {}
    for key in ("vertex_count", "face_count", "edge_count", "shell_count", "uv_count", "material_count"):
        if int(expected.get(key, -1)) != int(actual.get(key, -2)):
            mismatches[key] = {"expected": expected.get(key), "actual": actual.get(key)}
    for key, tol in (("bbox", 1e-5), ("sample_world_positions", 1e-5)):
        ev = [float(v) for v in expected.get(key, [])]
        av = [float(v) for v in actual.get(key, [])]
        if len(ev) != len(av) or any(abs(a-b) > tol for a,b in zip(ev, av)):
            mismatches[key] = {"expected": ev, "actual": av, "tolerance": tol}

    # FBX may add namespaces or relocate a texture into an .fbm directory.
    # Compare stable semantic identity rather than absolute host-specific paths.
    def _stable_material_names(values):
        return sorted(str(v).split(":")[-1].split("|")[-1] for v in (values or []))
    def _texture_basenames(values):
        return sorted(Path(str(v).replace("\\", "/")).name.lower() for v in (values or []))

    em = _stable_material_names(expected.get("materials"))
    am = _stable_material_names(actual.get("materials"))
    if em != am:
        mismatches["materials"] = {"expected": em, "actual": am}
    et = _texture_basenames(expected.get("texture_paths"))
    at = _texture_basenames(actual.get("texture_paths"))
    if et != at:
        mismatches["texture_linkage"] = {"expected": et, "actual": at}
    return {"pass": not mismatches, "mismatches": mismatches}


def _compare_camera_signatures(expected: dict[str, Any], actual: dict[str, Any]) -> dict[str, Any]:
    scalar_tolerances = {
        "focal_length_mm": 1e-4,
        "horizontal_film_aperture_in": 1e-6,
        "vertical_film_aperture_in": 1e-6,
        "horizontal_film_offset": 1e-6,
        "vertical_film_offset": 1e-6,
    }
    mismatches: dict[str, Any] = {}
    for key, tol in scalar_tolerances.items():
        ev = float(expected.get(key, 0.0)); av = float(actual.get(key, 0.0))
        if abs(ev - av) > tol:
            mismatches[key] = {"expected": ev, "actual": av, "tolerance": tol}
    ew = [float(v) for v in expected.get("world_matrix", [])]
    aw = [float(v) for v in actual.get("world_matrix", [])]
    if len(ew) != 16 or len(aw) != 16 or any(abs(a-b) > 1e-5 for a,b in zip(ew, aw)):
        mismatches["world_matrix"] = {"expected": ew, "actual": aw, "tolerance": 1e-5}
    return {"pass": not mismatches, "mismatches": mismatches}


def _configure_source_image_plane(cmds, plane_shape: str) -> dict[str, Any]:
    attrs = {"fit": 1, "displayOnlyIfCurrent": 1}
    for attr, value in attrs.items():
        if cmds.attributeQuery(attr, node=plane_shape, exists=True):
            cmds.setAttr(f"{plane_shape}.{attr}", value)
    return {
        "fit": "best",
        "fit_policy": "reference aspect == film gate == resolution gate",
        "display_only_if_current": True,
    }


def _worker_exit_code(manifest: dict[str, Any]) -> int:
    ma_ok = (manifest.get("ma") or {}).get("status") == "PASS"
    fbx_ok = (manifest.get("fbx") or {}).get("status") == "PASS"
    camera_fbx_ok = (manifest.get("camera_only_fbx") or {}).get("status") == "PASS"
    full_scene_ok = (manifest.get("full_scene_fbx") or {}).get("status") == "PASS"
    fbm_status = (manifest.get("fbm") or {}).get("status")
    fbm_ok = fbm_status in {"PASS", "NOT_REQUESTED"}
    hero = manifest.get("hero_mesh") or {}
    hero_ok = not hero.get("requested") or hero.get("status") == "PASS"
    normal_validation = manifest.get("normal_validation") or {}
    normal_ok = all(
        not gate or gate.get("status", gate.get("gate")) == "PASS"
        for gate in normal_validation.values()
        if isinstance(gate, dict)
    )
    return 0 if ma_ok and fbx_ok and camera_fbx_ok and full_scene_ok and fbm_ok and hero_ok and normal_ok else 2

def discover_mayapy(*, explicit: str | None = None, search_roots: Iterable[str | Path] | None = None) -> Path | None:
    """Find mayapy without changing PATH or user/system environment variables."""
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))
    env_explicit = os.environ.get("CONCEPTGHOST_MAYAPY")
    if env_explicit:
        candidates.append(Path(env_explicit))

    if search_roots is None:
        search_roots = [
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Autodesk",
            Path(os.environ.get("PROGRAMW6432", r"C:\Program Files")) / "Autodesk",
        ]
    roots = [Path(r) for r in search_roots]
    # Prefer newer Mayas for MayaUSD availability; Stage 8 still records the actual version.
    for version in (2026, 2025, 2024, 2023, 2022, 2020, 2019, 2018):
        for root in roots:
            candidates.append(root / f"Maya{version}" / "bin" / "mayapy.exe")

    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file():
            return candidate
    return None


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")


def _progress(run_dir: str | Path, message: str) -> None:
    line = f"[ConceptGhost MayaWorker] {message}"
    print(line, flush=True)
    try:
        path = Path(run_dir) / "logs" / "maya_worker_progress.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


def _sensor_in(sensor_mm: float) -> float:
    return float(sensor_mm) / 25.4


def atlas_matrix_to_maya_flat(matrix: Any) -> list[float]:
    """Atlas column-vector row-major affine matrix -> Maya row-vector flat matrix.

    Mirrors Atlas Camera's verified Maya exporter convention: transpose the full
    affine matrix so translation moves from the last column into Maya's last row.
    Both systems are right-handed Y-up, so no axis swap is needed.
    """
    rows = [[float(v) for v in row] for row in matrix]
    if len(rows) != 4 or any(len(row) != 4 for row in rows):
        raise ValueError("camera_world_matrix must be 4x4")
    transposed = [[rows[r][c] for r in range(4)] for c in range(4)]
    return [v for row in transposed for v in row]


def maya_camera_settings_from_bundle(camera: dict[str, Any]) -> dict[str, float | int]:
    """Convert a CameraBundle to Maya settings using the pinned Atlas exporter contract.

    Atlas 9f9ff451 authors principal-point offsets as image-space fractions
    (pixel_offset / image_size).  Do not multiply those values by the physical
    film aperture a second time: doing so changes the solved framing in Maya.
    """
    intr = camera.get("intrinsics", {})
    width = int(camera.get("image_width") or intr.get("image_width") or 0)
    height = int(camera.get("image_height") or intr.get("image_height") or 0)
    if width <= 0 or height <= 0:
        raise ValueError("CameraBundle requires positive image_width/image_height for Maya export")

    focal_raw = intr.get("focal_length_mm")
    if focal_raw is None:
        raise ValueError("CameraBundle requires focal_length_mm for Maya export")
    sensor_w_raw = intr.get("sensor_width_mm")
    if sensor_w_raw is None:
        raise ValueError("CameraBundle requires sensor_width_mm for Maya export")

    focal = float(focal_raw)
    sensor_w = float(sensor_w_raw)
    # The film-back aspect must match the reference image exactly.  Atlas may
    # carry a physical sensor-height estimate, but Maya framing becomes
    # ambiguous if that aspect disagrees with the source resolution.  Keep the
    # solved horizontal sensor width and derive height from the image ratio.
    sensor_h = float(sensor_w * height / width)
    if focal <= 0.0 or sensor_w <= 0.0 or sensor_h <= 0.0:
        raise ValueError("CameraBundle focal/sensor dimensions must be positive")

    cx = float(intr.get("cx_px", width * 0.5))
    cy = float(intr.get("cy_px", height * 0.5))
    return {
        "focal_length_mm": focal,
        "sensor_width_mm": sensor_w,
        "sensor_height_mm": sensor_h,
        "horizontal_film_aperture_in": _sensor_in(sensor_w),
        "vertical_film_aperture_in": _sensor_in(sensor_h),
        # Intentionally mirrors Atlas camera_math.pixel_offset_to_normalized_film_offset.
        "horizontal_film_offset": (cx - width * 0.5) / width,
        "vertical_film_offset": (cy - height * 0.5) / height,
        "image_width": width,
        "image_height": height,
        "device_aspect_ratio": width / height,
        "film_fit": 1,  # Maya enum: horizontal. Gates share the same aspect.
        "pixel_aspect": 1.0,
    }


def _set_camera_from_bundle(cmds, camera_transform: str, camera_shape: str, camera: dict[str, Any]) -> dict[str, float | int]:
    intr = camera.get("intrinsics", {})
    extr = camera.get("extrinsics", {})
    settings = maya_camera_settings_from_bundle(camera)
    cmds.setAttr(f"{camera_shape}.focalLength", settings["focal_length_mm"])
    cmds.setAttr(f"{camera_shape}.horizontalFilmAperture", settings["horizontal_film_aperture_in"])
    cmds.setAttr(f"{camera_shape}.verticalFilmAperture", settings["vertical_film_aperture_in"])
    cmds.setAttr(f"{camera_shape}.nearClipPlane", 0.01)
    cmds.setAttr(f"{camera_shape}.farClipPlane", 100000.0)

    if cmds.attributeQuery("horizontalFilmOffset", node=camera_shape, exists=True):
        cmds.setAttr(f"{camera_shape}.horizontalFilmOffset", settings["horizontal_film_offset"])
    if cmds.attributeQuery("verticalFilmOffset", node=camera_shape, exists=True):
        cmds.setAttr(f"{camera_shape}.verticalFilmOffset", settings["vertical_film_offset"])
    # Explicit gate/framing contract: the film back is already forced to the
    # source-image aspect, and Horizontal fit makes the resolution gate
    # deterministic instead of inheriting a user/default camera setting.
    for attr, value in (
        ("filmFit", int(settings["film_fit"])),
        ("displayResolution", 1),
        ("displayGateMask", 1),
        ("overscan", 1.0),
    ):
        if cmds.attributeQuery(attr, node=camera_shape, exists=True):
            cmds.setAttr(f"{camera_shape}.{attr}", value)

    world = extr.get("camera_world_matrix")
    if world and len(world) == 4:
        cmds.xform(camera_transform, worldSpace=True, matrix=atlas_matrix_to_maya_flat(world))
    else:
        pos = extr.get("camera_position") or (0.0, 0.0, 0.0)
        cmds.xform(camera_transform, worldSpace=True, translation=[float(x) for x in pos])
    return settings


def _prepare_maya_review_view(
    cmds,
    matched_camera: str,
    matched_shape: str,
    settings: dict[str, float | int],
) -> dict[str, Any]:
    """Make Maya open/review the solved framing without changing camera authority.

    The locked ConceptGhost camera remains authoritative.  Maya's default
    ``persp`` startup camera is only synchronized as a disposable viewing copy
    so an artist opening the .ma lands on the recovered framing immediately.
    """
    result: dict[str, Any] = {
        "matched_camera": matched_camera,
        "startup_camera": None,
        "startup_view_synced": False,
        "look_through_requested": False,
    }

    if cmds.objExists("defaultResolution"):
        cmds.setAttr("defaultResolution.width", int(settings["image_width"]))
        cmds.setAttr("defaultResolution.height", int(settings["image_height"]))
        cmds.setAttr("defaultResolution.pixelAspect", float(settings.get("pixel_aspect", 1.0)))
        try:
            cmds.setAttr("defaultResolution.deviceAspectRatio", float(settings["device_aspect_ratio"]))
        except Exception:
            pass

    try:
        cmds.setAttr(f"{matched_shape}.renderable", 1)
    except Exception:
        pass

    if cmds.objExists("persp") and cmds.objExists("perspShape"):
        try:
            world = cmds.xform(matched_camera, query=True, worldSpace=True, matrix=True)
            cmds.xform("persp", worldSpace=True, matrix=world)
            camera_attrs = {
                "focalLength": settings["focal_length_mm"],
                "horizontalFilmAperture": settings["horizontal_film_aperture_in"],
                "verticalFilmAperture": settings["vertical_film_aperture_in"],
                "horizontalFilmOffset": settings["horizontal_film_offset"],
                "verticalFilmOffset": settings["vertical_film_offset"],
                "nearClipPlane": 0.01,
                "farClipPlane": 100000.0,
                "filmFit": int(settings.get("film_fit", 1)),
                "displayResolution": 1,
                "displayGateMask": 1,
                "overscan": 1.0,
            }
            for attr, value in camera_attrs.items():
                try:
                    cmds.setAttr(f"perspShape.{attr}", value)
                except Exception:
                    pass
            result["startup_camera"] = "persp"
            result["startup_view_synced"] = True
        except Exception as exc:
            result["startup_view_error"] = str(exc)

    # Mirrors the pinned Atlas Maya exporter.  In mayapy standalone there may
    # be no modelPanel, so this is best-effort; the synced persp remains the
    # deterministic fallback for the saved scene.
    try:
        cmds.lookThru(matched_camera)
        result["look_through_requested"] = True
    except Exception as exc:
        result["look_through_error"] = str(exc)
    return result


def _create_string_attr(cmds, node: str, name: str, value: str) -> None:
    if not cmds.attributeQuery(name, node=node, exists=True):
        cmds.addAttr(node, longName=name, dataType="string")
    cmds.setAttr(f"{node}.{name}", str(value), type="string")


def _create_metric_diagnostics_layer(cmds, diagnostics_parent: str, regions_parent: str, spec: dict[str, Any] | None) -> dict[str, Any]:
    """Author report-only metric helpers and region selection metadata.

    This function must never edit the hero mesh, cameras, or source plate.
    """
    spec = dict(spec or {})
    result = {
        "status": "DISABLED" if spec.get("status") in {None, "", "DISABLED"} else "PASS",
        "policy": spec.get("policy", "diagnostic_metadata_only_no_geometry_deletion_no_camera_or_mesh_movement"),
        "group": diagnostics_parent,
        "regions_group": regions_parent,
        "helpers_created": [],
        "selection_sets_created": [],
        "errors": [],
    }
    _create_string_attr(cmds, diagnostics_parent, "CG_METRIC_DIAGNOSTICS_SCHEMA", str(spec.get("schema") or ""))
    _create_string_attr(cmds, diagnostics_parent, "CG_METRIC_POLICY", str(result["policy"]))
    _create_string_attr(cmds, diagnostics_parent, "CG_METRIC_LABELS", json.dumps(spec.get("labels") or {}, sort_keys=True))
    _create_string_attr(cmds, diagnostics_parent, "CG_METRIC_AGREEMENT", json.dumps(spec.get("agreement") or {}, sort_keys=True))
    _create_string_attr(cmds, diagnostics_parent, "CG_METRIC_CONSENSUS", json.dumps(spec.get("consensus") or {}, sort_keys=True))
    _create_string_attr(cmds, diagnostics_parent, "CG_SCALE_AUTHORITY", json.dumps(spec.get("scale_authority") or {}, sort_keys=True))
    _create_string_attr(cmds, regions_parent, "CG_REGION_POLICY", str(spec.get("region_policy") or "region_is_metadata_selection_not_geometry_deletion"))
    if result["status"] == "DISABLED":
        return result

    def locator(name: str, position: list[float]):
        node = cmds.spaceLocator(name=name)[0]
        cmds.xform(node, worldSpace=True, translation=[float(x) for x in position])
        cmds.parent(node, diagnostics_parent)
        return node

    def line(name: str, start: list[float], end: list[float]):
        node = cmds.curve(degree=1, point=[start, end], name=name)
        cmds.parent(node, diagnostics_parent)
        return node

    for item in spec.get("helpers") or []:
        try:
            kind = str(item.get("kind") or "")
            name = str(item.get("name") or "CG_METRIC_HELPER")
            if kind == "locator":
                node = locator(name, item["position"])
            elif kind == "line":
                node = line(name, item["start"], item["end"])
            else:
                continue
            result["helpers_created"].append(str(node))
        except Exception as exc:
            result["errors"].append(f"helper:{item.get('name')}:{exc}")

    ground = spec.get("ground_plane") or {}
    if ground and ground.get("anchor_world") is not None and ground.get("normal_world") is not None:
        try:
            import numpy as np
            center = np.asarray(ground["anchor_world"], dtype=float).reshape(3)
            normal = np.asarray(ground["normal_world"], dtype=float).reshape(3)
            normal /= max(float(np.linalg.norm(normal)), 1e-12)
            ref = np.array([1.0, 0.0, 0.0]) if abs(float(normal[0])) < 0.9 else np.array([0.0, 0.0, 1.0])
            axis_u = np.cross(normal, ref); axis_u /= max(float(np.linalg.norm(axis_u)), 1e-12)
            axis_v = np.cross(normal, axis_u); axis_v /= max(float(np.linalg.norm(axis_v)), 1e-12)
            extent = 5.0
            for i, t in enumerate(np.linspace(-extent, extent, 11)):
                a = center + axis_u * t - axis_v * extent
                b = center + axis_u * t + axis_v * extent
                c = center + axis_v * t - axis_u * extent
                d = center + axis_v * t + axis_u * extent
                result["helpers_created"].append(str(line(f"CG_METRIC_GROUND_U_{i:02d}", a.tolist(), b.tolist())))
                result["helpers_created"].append(str(line(f"CG_METRIC_GROUND_V_{i:02d}", c.tolist(), d.tolist())))
        except Exception as exc:
            result["errors"].append(f"ground_grid:{exc}")

    for region in spec.get("regions") or []:
        try:
            set_name = str(region.get("name") or "CG_REGION")
            members = [m for m in (region.get("maya_members") or []) if cmds.objExists(str(m).split(".", 1)[0])]
            if members:
                created = cmds.sets(members, name=set_name)
            else:
                created = cmds.sets(empty=True, name=set_name)
            _create_string_attr(cmds, created, "CG_REGION_LABEL", str(region.get("label") or set_name))
            _create_string_attr(cmds, created, "CG_REGION_SOURCE", str(region.get("source") or "metadata"))
            _create_string_attr(cmds, created, "CG_REGION_POLICY", str(region.get("policy") or "metadata_selection_only_no_geometry_deletion"))
            result["selection_sets_created"].append(str(created))
        except Exception as exc:
            result["errors"].append(f"region:{region.get('name')}:{exc}")

    if result["errors"]:
        result["status"] = "WARN"
    return result




def _create_hero_mesh_from_payload(cmds, hero_transform: str, payload: dict[str, Any] | None) -> dict[str, Any]:
    """Author the run's Maya-ready E2 mesh directly under CG_HERO_MESH.

    The payload is already in Atlas world space and its UV V coordinate is
    already converted for Maya.  This function must not rotate/flip it again.
    """
    result: dict[str, Any] = {
        "requested": bool(payload),
        "status": "NOT_REQUESTED" if not payload else "FAIL",
        "transform": hero_transform,
        "shape": None,
        "visible_by_default": False,
    }
    if not payload:
        return result
    try:
        import numpy as np  # Maya ships NumPy; keep it worker-local.
        import maya.api.OpenMaya as om  # type: ignore

        npz_path = Path(payload["npz_path"]).resolve()
        if not npz_path.is_file():
            raise FileNotFoundError(f"Hero mesh payload missing: {npz_path}")
        data = np.load(npz_path)
        vertices = np.asarray(data["vertices"], dtype=np.float64)
        faces = np.asarray(data["faces"], dtype=np.int64)
        if vertices.ndim != 2 or vertices.shape[1] != 3 or len(vertices) == 0:
            raise ValueError(f"Invalid hero vertices: {vertices.shape}")
        if faces.ndim != 2 or faces.shape[1] < 3 or len(faces) == 0:
            raise ValueError(f"Invalid hero faces: {faces.shape}")

        sel = om.MSelectionList()
        sel.add(hero_transform)
        parent_obj = sel.getDependNode(0)
        points = om.MPointArray()
        for x, y, z in vertices:
            points.append(om.MPoint(float(x), float(y), float(z)))
        polygon_counts = [int(faces.shape[1])] * int(len(faces))
        polygon_connects = [int(v) for v in faces.reshape(-1)]
        fn = om.MFnMesh()
        fn.create(points, polygon_counts, polygon_connects, parent=parent_obj)
        shape_name = fn.setName(f"{hero_transform}Shape")

        uv_count = 0
        if "uvs" in data:
            uvs = np.asarray(data["uvs"], dtype=np.float64)
            if uvs.ndim == 2 and uvs.shape == (len(vertices), 2):
                fn.setUVs([float(v) for v in uvs[:, 0]], [float(v) for v in uvs[:, 1]])
                fn.assignUVs(polygon_counts, polygon_connects)
                uv_count = int(len(uvs))

        normal_count = 0
        normal_mode = "MAYA_COMPUTED"
        # v0.25: author per-face-vertex normals when available.  A single shared
        # vertex normal can be opposite to one incident polygon on folded 2.5D
        # geometry even when every face winding is correct.  The payload has
        # already hemisphere-clamped each corner against its final face normal.
        if "face_vertex_normals" in data:
            fvn = np.asarray(data["face_vertex_normals"], dtype=np.float64)
            if fvn.ndim == 3 and fvn.shape == (len(faces), faces.shape[1], 3):
                flat_normals = fvn.reshape((-1, 3))
                face_ids = np.repeat(np.arange(len(faces), dtype=np.int32), faces.shape[1]).tolist()
                vertex_ids = faces.reshape(-1).astype(np.int32).tolist()
                setter = getattr(fn, "setFaceVertexNormals", None)
                if setter is not None:
                    setter(
                        [om.MVector(float(x), float(y), float(z)) for x, y, z in flat_normals],
                        face_ids,
                        vertex_ids,
                    )
                    normal_count = int(len(flat_normals))
                    normal_mode = "FACE_VERTEX_PAYLOAD"
        if normal_count == 0 and "normals" in data:
            normals = np.asarray(data["normals"], dtype=np.float64)
            if normals.ndim == 2 and normals.shape == (len(vertices), 3):
                fn.setVertexNormals(
                    [om.MVector(float(x), float(y), float(z)) for x, y, z in normals],
                    list(range(len(vertices))),
                )
                normal_count = int(len(normals))
                normal_mode = "VERTEX_PAYLOAD_FALLBACK"

        shader = cmds.shadingNode("lambert", asShader=True, name="CG_HERO_MESH_MAT")
        shading_group = cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name="CG_HERO_MESH_MAT_SG")
        cmds.connectAttr(f"{shader}.outColor", f"{shading_group}.surfaceShader", force=True)
        texture_path = payload.get("texture_path")
        texture_loaded = False
        if texture_path and Path(texture_path).is_file():
            try:
                file_node = cmds.shadingNode("file", asTexture=True, isColorManaged=True, name="CG_HERO_MESH_BASECOLOR")
            except Exception:
                file_node = cmds.shadingNode("file", asTexture=True, name="CG_HERO_MESH_BASECOLOR")
            place = cmds.shadingNode("place2dTexture", asUtility=True, name="CG_HERO_MESH_UVPLACE")
            try:
                cmds.connectAttr(f"{place}.outUV", f"{file_node}.uvCoord", force=True)
                cmds.connectAttr(f"{place}.outUvFilterSize", f"{file_node}.uvFilterSize", force=True)
            except Exception:
                pass
            cmds.setAttr(f"{file_node}.fileTextureName", str(Path(texture_path).resolve()), type="string")
            cmds.connectAttr(f"{file_node}.outColor", f"{shader}.color", force=True)
            texture_loaded = True
        cmds.sets(hero_transform, edit=True, forceElement=shading_group)


        # Keep the new mesh available in the scene but non-intrusive by default.
        # The artist can enable CG_HERO_MESH with one visibility toggle.
        cmds.setAttr(f"{hero_transform}.visibility", 0)
        _create_string_attr(cmds, hero_transform, "CG_ROLE", "Solver-paired primary mesh; modeling reference")
        _create_string_attr(cmds, hero_transform, "CG_SOURCE_ENGINE", str(payload.get("source_engine", "unknown")))
        _create_string_attr(cmds, hero_transform, "CG_ALIGNMENT", str(payload.get("alignment", "unknown")))
        _create_string_attr(cmds, hero_transform, "CG_AXIS_POLICY", str(payload.get("axis_policy", "canonical world")))
        _create_string_attr(cmds, hero_transform, "CG_COORDINATE_SPACE", str(payload.get("coordinate_space", "Atlas world")))
        _create_string_attr(cmds, hero_transform, "CG_UV_POLICY", str(payload.get("uv_policy", "Maya/DCC-ready")))

        result.update({
            "status": "PASS",
            "geometry_profile": payload.get("geometry_profile"),
            "selected_profile": payload.get("selected_profile"),
            "effective_profile": payload.get("effective_profile"),
            "model": payload.get("source_model"),
            "mesher_policy": payload.get("mesher_policy"),
            "transport_stride": payload.get("transport_stride"),
            "depth_edge_rtol": payload.get("depth_edge_rtol"),
            "discontinuity_threshold": payload.get("discontinuity_threshold"),
            "long_triangle_policy": payload.get("long_triangle_policy"),
            "connected_components_policy": payload.get("connected_components_policy"),
            "boundary_cleanup_policy": payload.get("boundary_cleanup_policy"),
            "mesh_profile_config": payload.get("mesh_profile_config"),
            "topology_authority": payload.get("topology_authority"),
            "source_engine": str(payload.get("source_engine", "unknown")),
            "alignment": str(payload.get("alignment", "unknown")),
            "axis_policy": str(payload.get("axis_policy", "canonical world")),
            "shape": str(shape_name),
            "vertex_count": int(len(vertices)),
            "face_count": int(len(faces)),
            "uv_count": uv_count,
            "normal_count": normal_count,
            "normal_mode": normal_mode,
            "material_count": 1,
            "material_names": [str(shader)],
            "texture_path": str(texture_path) if texture_path else None,
            "texture_loaded": texture_loaded,
            "topology_split": False,
        })
    except Exception as exc:
        result["status"] = "FAIL"
        result["error"] = str(exc)
    return result


def _create_maya_scene(payload: dict[str, Any]) -> dict[str, Any]:
    # Maya imports happen only in the external mayapy process.
    import maya.standalone  # type: ignore
    maya.standalone.initialize(name="python")
    import maya.cmds as cmds  # type: ignore
    import maya.mel as mel  # type: ignore

    run = Path(payload["run_dir"]).resolve()
    profile = _assert_worker_profile(payload)
    selected_profile = str(profile["selected_profile"])
    _progress(run, f"ENTER profile={selected_profile}")
    scene_name = _clean_name(payload["scene_name"])
    names = maya_hierarchy_names(scene_name)
    out = build_output_paths(run, scene_name)
    out["ma"].parent.mkdir(parents=True, exist_ok=True)

    pre_maya_validation = _npz_orientation_gate(payload.get("hero_mesh_payload"), payload.get("camera") or {}, stage="PRE_MAYA")
    _write_json(run / "maya" / "normal_validation_pre_maya.json", pre_maya_validation)
    _progress(run, f"Pre-Maya normal gate status={pre_maya_validation.get('status')}")
    if pre_maya_validation.get("status") not in {"PASS", "NOT_REQUESTED"}:
        raise RuntimeError(f"Pre-Maya normal gate failed: {pre_maya_validation}")

    _progress(run, "Maya standalone initialized")
    plugin_status: dict[str, bool] = {}
    for plugin in ("mayaUsdPlugin", "fbxmaya"):
        try:
            if not cmds.pluginInfo(plugin, query=True, loaded=True):
                cmds.loadPlugin(plugin, quiet=True)
            plugin_status[plugin] = bool(cmds.pluginInfo(plugin, query=True, loaded=True))
        except Exception:
            plugin_status[plugin] = False

    _progress(run, f"Plugins: {plugin_status}")
    cmds.file(new=True, force=True)
    try:
        cmds.workspace(str(run), openWorkspace=True)
    except Exception:
        pass

    root = cmds.group(empty=True, name=names["root"])
    cameras_grp = cmds.group(empty=True, name=names["cameras"], parent=root)
    source_grp = cmds.group(empty=True, name=names["source"], parent=root)
    geometry_grp = cmds.group(empty=True, name=names["geometry"], parent=root)
    hero_grp = cmds.group(empty=True, name=names["hero_mesh"], parent=geometry_grp)
    diagnostics_grp = cmds.group(empty=True, name=names["diagnostics"], parent=root)
    metric_diagnostics_grp = cmds.group(empty=True, name=names["metric_diagnostics"], parent=diagnostics_grp)
    regions_grp = cmds.group(empty=True, name=names["regions"], parent=root)
    cmds.group(empty=True, name=names["atlas_relief"], parent=diagnostics_grp)
    cmds.group(empty=True, name=names["moge_native"], parent=diagnostics_grp)
    try:
        cmds.setAttr(f"{diagnostics_grp}.visibility", 0)
    except Exception:
        pass
    metadata_grp = cmds.group(empty=True, name=names["metadata"], parent=root)

    _progress(run, "Scene hierarchy created")
    matched, matched_shape = cmds.camera(name=names["matched_camera"])
    cmds.parent(matched, cameras_grp)
    camera_settings = _set_camera_from_bundle(cmds, matched, matched_shape, payload["camera"])
    review_view = _prepare_maya_review_view(cmds, matched, matched_shape, camera_settings)
    _create_string_attr(cmds, matched, "CG_REFERENCE_RESOLUTION", f"{camera_settings['image_width']}x{camera_settings['image_height']}")
    _create_string_attr(cmds, matched, "CG_REFERENCE_ASPECT", f"{camera_settings['device_aspect_ratio']:.12g}")
    _create_string_attr(cmds, matched, "CG_CAMERA_AUTHORITY", "Atlas CameraBundle")

    artist = cmds.duplicate(matched, name=names["artist_camera"], parentOnly=False)[0]
    # Duplicate can carry locked attrs only after locking, so lock matched after duplicate.
    for attr in ("translateX", "translateY", "translateZ", "rotateX", "rotateY", "rotateZ", "scaleX", "scaleY", "scaleZ"):
        try:
            cmds.setAttr(f"{matched}.{attr}", lock=True, keyable=False, channelBox=True)
        except Exception:
            pass
    try:
        cmds.setAttr(f"{matched_shape}.focalLength", lock=True)
    except Exception:
        pass

    source_image = Path(payload["source_image"]).resolve()
    # Workspace root is run_dir, so keep the authored image path run-local.
    relative_source = source_image.relative_to(run).as_posix() if source_image.is_relative_to(run) else str(source_image)
    try:
        plane_transform, plane_shape = cmds.imagePlane(camera=matched, fileName=relative_source, name=names["source_plate"], showInAllViews=False, maintainRatio=True)
        image_plane_contract = _configure_source_image_plane(cmds, plane_shape)
        try:
            cmds.parent(plane_transform, source_grp)
        except Exception:
            pass
    except Exception as exc:
        plane_transform, plane_shape = None, None
        image_plane_contract = {"status": "FAIL", "error": str(exc)}
        _create_string_attr(cmds, metadata_grp, "sourcePlateWarning", str(exc))

    _progress(run, "Camera and source plate configured")
    if not plugin_status.get("mayaUsdPlugin"):
        raise RuntimeError("mayaUsdPlugin is not available; cannot create the dense Ghost proxy")
    proxy_transform = cmds.createNode("transform", name=names["fused_points"], parent=geometry_grp)
    proxy_shape = cmds.createNode("mayaUsdProxyShape", name=f"{names['fused_points']}Shape", parent=proxy_transform)
    ghost_usda = Path(payload["ghost_usda"]).resolve()
    relative_usd = ghost_usda.relative_to(run).as_posix() if ghost_usda.is_relative_to(run) else str(ghost_usda)
    # MayaUSD normally resolves asset paths through the workspace. Preserve run-local form first.
    if cmds.attributeQuery("filePath", node=proxy_shape, exists=True):
        cmds.setAttr(f"{proxy_shape}.filePath", relative_usd, type="string")
    else:
        raise RuntimeError("mayaUsdProxyShape has no filePath attribute")
    _create_string_attr(cmds, proxy_transform, "CG_SOURCE_ENGINE", str(payload.get("geometry_engine", "unknown")))
    _create_string_attr(cmds, proxy_transform, "CG_PAIR_MESH", names["hero_mesh"])
    _create_string_attr(cmds, proxy_transform, "CG_ALIGNMENT", str((payload.get("hero_mesh_payload") or {}).get("alignment") or "EXACT_SAME_CANONICAL_XYZ"))
    _progress(run, f"USD proxy authored: {relative_usd}")

    _progress(run, "Hero transport mesh START")
    hero_mesh_status = _create_hero_mesh_from_payload(cmds, hero_grp, payload.get("hero_mesh_payload"))
    _progress(run, f"Hero transport mesh DONE status={hero_mesh_status.get('status')} vertices={hero_mesh_status.get('vertex_count')} faces={hero_mesh_status.get('face_count')}")
    live_normal_validation = {"stage": "MAYA_LIVE", "status": "NOT_REQUESTED"}
    if hero_mesh_status.get("status") == "PASS":
        live_normal_validation = _maya_mesh_orientation_gate(cmds, hero_grp, matched, stage="MAYA_LIVE")
        _progress(run, f"Maya live normal gate status={live_normal_validation.get('status')}")
        if live_normal_validation.get("status") != "PASS":
            raise RuntimeError(f"Maya live normal gate failed: {live_normal_validation}")
        if int(live_normal_validation.get("vertex_count", -1)) != int(hero_mesh_status.get("vertex_count", -2)) or int(live_normal_validation.get("faces_total", -1)) != int(hero_mesh_status.get("face_count", -2)):
            raise RuntimeError("Maya live topology count differs from PrimaryMesh payload")

    maya_input_parity = {"status": "NOT_REQUESTED"}
    if hero_mesh_status.get("status") == "PASS":
        live_sig = _mesh_signature(cmds, hero_grp)
        expected_counts = {
            "vertex_count": int(hero_mesh_status.get("vertex_count", -1)),
            "face_count": int(hero_mesh_status.get("face_count", -1)),
            "uv_count": int(hero_mesh_status.get("uv_count", -1)),
            "material_count": int(hero_mesh_status.get("material_count", -1)),
        }
        mismatches = {k: {"expected": v, "actual": live_sig.get(k)} for k,v in expected_counts.items() if int(live_sig.get(k, -2)) != int(v)}
        maya_input_parity = {"status": "PASS" if not mismatches else "FAIL", "expected": expected_counts, "maya_live": live_sig, "mismatches": mismatches}
        if mismatches:
            raise RuntimeError(f"MAYA_INPUT_PARITY failed: {mismatches}")

    _create_string_attr(cmds, metadata_grp, "conceptGhostSchema", payload.get("schema", ""))
    _create_string_attr(cmds, metadata_grp, "geometryEngine", payload.get("geometry_engine", "unknown"))
    _create_string_attr(cmds, metadata_grp, "geometryProfile", selected_profile)
    _create_string_attr(cmds, metadata_grp, "selectedProfile", selected_profile)
    _create_string_attr(cmds, metadata_grp, "effectiveProfile", selected_profile)
    _create_string_attr(cmds, metadata_grp, "geometryModel", str(payload.get("model") or ""))
    _create_string_attr(cmds, metadata_grp, "mesherPolicy", str(payload.get("mesher_policy") or ""))
    _create_string_attr(cmds, metadata_grp, "transportStride", str((payload.get("hero_mesh_payload") or {}).get("transport_stride")))
    _create_string_attr(cmds, metadata_grp, "depthEdgeRtol", str((payload.get("hero_mesh_payload") or {}).get("depth_edge_rtol")))
    _create_string_attr(cmds, metadata_grp, "discontinuityThreshold", str((payload.get("hero_mesh_payload") or {}).get("discontinuity_threshold")))
    _create_string_attr(cmds, metadata_grp, "longTrianglePolicy", str((payload.get("hero_mesh_payload") or {}).get("long_triangle_policy")))
    _create_string_attr(cmds, metadata_grp, "connectedComponentsPolicy", str((payload.get("hero_mesh_payload") or {}).get("connected_components_policy")))
    _create_string_attr(cmds, metadata_grp, "boundaryCleanupPolicy", str((payload.get("hero_mesh_payload") or {}).get("boundary_cleanup_policy")))
    _create_string_attr(cmds, metadata_grp, "canonicalConvention", json.dumps(payload.get("coordinate_convention", {}), sort_keys=True))
    if not cmds.attributeQuery("pointCount", node=metadata_grp, exists=True):
        cmds.addAttr(metadata_grp, longName="pointCount", attributeType="long")
    cmds.setAttr(f"{metadata_grp}.pointCount", int(payload.get("point_count", 0)))

    metric_diagnostics_status = _create_metric_diagnostics_layer(
        cmds, metric_diagnostics_grp, regions_grp, payload.get("metric_diagnostics_spec")
    )
    _progress(run, f"Metric diagnostics layer status={metric_diagnostics_status.get('status')} helpers={len(metric_diagnostics_status.get('helpers_created') or [])} regions={len(metric_diagnostics_status.get('selection_sets_created') or [])}")

    _progress(run, "Maya ASCII save START")
    cmds.file(rename=str(out["ma"]))
    cmds.file(save=True, type="mayaAscii", force=True)
    _progress(run, f"Maya ASCII save DONE path={out['ma']}")

    # Mandatory reopen gate: do not trust a successful save alone.  Re-open the
    # authored .ma in standalone Maya and re-measure final topology/normals.
    reopened_ma_validation = {"stage": "MAYA_REOPEN", "status": "NOT_REQUESTED"}
    if hero_mesh_status.get("status") == "PASS":
        _progress(run, "Maya ASCII reopen normal gate START")
        cmds.file(new=True, force=True)
        cmds.file(str(out["ma"]), open=True, force=True)
        reopened_ma_validation = _maya_mesh_orientation_gate(cmds, hero_grp, matched, stage="MAYA_REOPEN")
        reopened_fused_points_present = bool(cmds.objExists(names["fused_points"]))
        reopened_ma_validation["fused_points_transform"] = names["fused_points"]
        reopened_ma_validation["fused_points_present"] = reopened_fused_points_present
        _progress(run, f"Maya ASCII reopen normal gate DONE status={reopened_ma_validation.get('status')} fused_points={reopened_fused_points_present}")
        if reopened_ma_validation.get("status") != "PASS":
            raise RuntimeError(f"Maya .ma reopen normal gate failed: {reopened_ma_validation}")
        if not reopened_fused_points_present:
            raise RuntimeError("Maya .ma reopen lost CG_FUSED_POINTS")
        if int(reopened_ma_validation.get("vertex_count", -1)) != int(hero_mesh_status.get("vertex_count", -2)) or int(reopened_ma_validation.get("faces_total", -1)) != int(hero_mesh_status.get("face_count", -2)):
            raise RuntimeError("Maya reopen topology count differs from PrimaryMesh payload")

    fbx_error = None
    fbx_verification: dict[str, Any] = {
        "status": "NOT_RUN",
        "required_cameras": fbx_required_camera_names(matched, artist),
        "found_cameras": [],
        "missing_cameras": fbx_required_camera_names(matched, artist),
    }
    camera_only_verification: dict[str, Any] = {
        "status": "NOT_RUN", "path": str(out["camera_fbx"]),
        "required_cameras": fbx_required_camera_names(matched, artist),
    }
    full_scene_verification: dict[str, Any] = {
        "status": "NOT_RUN", "path": str(out["full_scene_fbx"]),
        "required_cameras": fbx_required_camera_names(matched, artist),
        "required_meshes": [hero_grp] if hero_mesh_status.get("status") == "PASS" else [],
    }
    if plugin_status.get("fbxmaya"):
        try:
            # The .ma has already been saved with the full-resolution USD proxy.
            # FBX is a DCC interchange artifact: remove only the in-memory dense
            # proxy before export so FBX never tries to traverse/convert 1M+ USD
            # points. PLY/USD remain the point-cloud authority.
            try:
                if cmds.objExists(proxy_transform):
                    cmds.delete(proxy_transform)
                _progress(run, "Dense USD proxy removed from in-memory FBX export scene")
            except Exception as exc:
                _progress(run, f"USD proxy removal warning: {exc}")

            required_fbx_cameras = fbx_required_camera_names(matched, artist)
            required_fbx_meshes = [hero_grp] if hero_mesh_status.get("status") == "PASS" else []
            expected_signatures = {name: _camera_signature(cmds, name) for name in required_fbx_cameras}
            expected_mesh_signatures = {name: _mesh_signature(cmds, name) for name in required_fbx_meshes}

            # Official FBX: export the complete curated ConceptGhost Maya scene.
            # Previous selection-only export passed synthetic checks but cameras
            # were absent in the artist runtime. Export-all lets the FBX plug-in
            # traverse camera shapes/hierarchy directly.
            _progress(run, "Official FBX export START")
            cmds.select(clear=True)
            for command in fbx_export_mel_commands(out["fbx"]):
                mel.eval(command)
            _progress(run, f"Official FBX export DONE path={out['fbx']}")

            # v0.32 dedup: Ghost.fbx is already a full curated-scene export.
            # Preserve the GhostFullScene.fbx compatibility filename without
            # performing a second identical scene export or consuming another
            # ~140 MB when both paths are on the same filesystem.
            _progress(run, "FullScene FBX compatibility alias START")
            full_scene_alias_mode = _hardlink_or_copy_alias(out["fbx"], out["full_scene_fbx"])
            _progress(run, f"FullScene FBX compatibility alias DONE mode={full_scene_alias_mode} path={out['full_scene_fbx']}")

            # Independent camera-only artifact for diagnosis/interchange. Include
            # both transform and camera shapes in the selection explicitly.
            camera_nodes = []
            for cam in required_fbx_cameras:
                camera_nodes.append(cam)
                camera_nodes.extend(cmds.listRelatives(cam, shapes=True, type="camera") or [])
            cmds.select(camera_nodes, replace=True)
            for command in fbx_camera_only_export_mel_commands(out["camera_fbx"]):
                mel.eval(command)

            _progress(run, "FBX round-trip verification START")
            fbx_verification = _verify_fbx_camera_roundtrip(
                cmds, mel, out["fbx"], required_fbx_cameras, expected_signatures, required_fbx_meshes, expected_mesh_signatures
            )
            # GhostFullScene.fbx is the same physical payload exposed through a
            # compatibility filename. Re-importing it would provide no additional
            # geometry/camera evidence and would create another transient .fbm
            # extraction directory, so reuse the verified authority result.
            full_scene_verification = dict(fbx_verification)
            full_scene_verification.update({
                "alias_of": str(out["fbx"]),
                "alias_path": str(out["full_scene_fbx"]),
                "alias_storage_mode": full_scene_alias_mode,
                "verification_basis": "same_physical_payload_as_official_fbx",
            })
            camera_only_verification = _verify_fbx_camera_roundtrip(
                cmds, mel, out["camera_fbx"], required_fbx_cameras, expected_signatures, []
            )
            _progress(run, f"FBX round-trip verification DONE status={fbx_verification.get('status')}")
            if fbx_verification.get("status") != "PASS":
                fbx_error = "FBX round-trip verification failed"
        except Exception as exc:
            fbx_error = str(exc)
    else:
        fbx_error = "fbxmaya plugin unavailable"

    # FBX is exported with embedded textures. Any .fbm directory created while
    # round-trip importing the FBX is verification scratch, not an authoritative
    # run artifact. Remove it after verification instead of persisting duplicate
    # texture files beside the embedded-texture FBX.
    import shutil
    removed_fbm = []
    for candidate in (
        out.get("fbm_dir"),
        Path(str(out["full_scene_fbx"])[:-4] + ".fbm"),
    ):
        if candidate and Path(candidate).is_dir():
            shutil.rmtree(candidate, ignore_errors=False)
            removed_fbm.append(str(candidate))
    media_folder = {
        "status": "NOT_REQUESTED",
        "policy": "embedded_textures_no_persistent_sidecar",
        "removed_transient_fbm": removed_fbm,
    }
    maya_version = str(cmds.about(version=True))
    hero_required_ok = not hero_mesh_status.get("requested") or hero_mesh_status.get("status") == "PASS"
    fbx_normal_validation = {}
    if "required_fbx_meshes" in locals() and required_fbx_meshes:
        fbx_normal_validation = (fbx_verification.get("mesh_orientation_checks") or {}).get(required_fbx_meshes[0], {})
    normal_validation = {
        "pre_maya": pre_maya_validation,
        "maya_live": live_normal_validation,
        "maya_reopen": reopened_ma_validation,
        "fbx_roundtrip": fbx_normal_validation,
    }
    manifest = {
        "schema": "ConceptGhost.MayaManifest.v0.31",
        "status": "PASS",
        "geometry_profile": selected_profile,
        "selected_profile": selected_profile,
        "effective_profile": selected_profile,
        "profile_config": profile,
        "model": payload.get("model"),
        "mesher_policy": payload.get("mesher_policy"),
        "resolution_level": payload.get("resolution_level"),
        "refine_steps": payload.get("refine_steps"),
        "transport_stride": (payload.get("hero_mesh_payload") or {}).get("transport_stride"),
        "depth_edge_rtol": (payload.get("hero_mesh_payload") or {}).get("depth_edge_rtol"),
        "discontinuity_threshold": (payload.get("hero_mesh_payload") or {}).get("discontinuity_threshold"),
        "long_triangle_policy": (payload.get("hero_mesh_payload") or {}).get("long_triangle_policy"),
        "connected_components_policy": (payload.get("hero_mesh_payload") or {}).get("connected_components_policy"),
        "boundary_cleanup_policy": (payload.get("hero_mesh_payload") or {}).get("boundary_cleanup_policy"),
        "mesh_profile_config": profile.get("mesh_profile_config"),
        "silent_fallback": bool(profile.get("silent_fallback", True)),
        "topology_authority": profile.get("topology_authority"),
        "maya_version": maya_version,
        "plugins": plugin_status,
        "hierarchy": names,
        "ma": {
            "path": str(out["ma"]),
            "status": "PASS" if (
                out["ma"].exists()
                and hero_required_ok
                and live_normal_validation.get("status") in {"PASS", "NOT_REQUESTED"}
                and reopened_ma_validation.get("status") in {"PASS", "NOT_REQUESTED"}
            ) else "FAIL",
        },
        "fbx": {
            "path": str(out["fbx"]),
            "status": "PASS" if out["fbx"].exists() and fbx_verification.get("status") == "PASS" else "FAIL",
            "error": fbx_error,
            "camera_roundtrip": fbx_verification,
            "export_policy": "full_scene_export_all_for_camera_reliability",
        },
        "full_scene_fbx": {
            "path": str(out["full_scene_fbx"]),
            "status": "PASS" if out["full_scene_fbx"].exists() and full_scene_verification.get("status") == "PASS" else "FAIL",
            "camera_roundtrip": full_scene_verification,
            "export_policy": "compatibility_alias_of_official_full_scene_fbx",
            "storage_mode": locals().get("full_scene_alias_mode", "not_created"),
            "authority_path": str(out["fbx"]),
        },
        "camera_only_fbx": {
            "path": str(out["camera_fbx"]),
            "status": "PASS" if out["camera_fbx"].exists() and camera_only_verification.get("status") == "PASS" else "FAIL",
            "camera_roundtrip": camera_only_verification,
        },
        "usd_proxy": {"path": relative_usd, "shape": proxy_shape},
        "hero_mesh": hero_mesh_status,
        "maya_input_parity": maya_input_parity,
        "normal_validation": normal_validation,
        "metric_diagnostics": metric_diagnostics_status,
        "fbm": media_folder,
        "source_plate": {"path": relative_source, "shape": plane_shape, "framing": image_plane_contract},
        "camera": {
            "matched_transform": matched,
            "matched_shape": matched_shape,
            "artist_transform": artist,
            "settings": camera_settings,
            "review_view": review_view,
            "authority": "Atlas CameraBundle",
        },
        "hero_mesh_in_fbx": bool(hero_mesh_status.get("status") == "PASS" and fbx_verification.get("status") == "PASS"),
        "solver_pair": {
            "source_engine": hero_mesh_status.get("source_engine") or payload.get("geometry_engine"),
            "alignment": (payload.get("hero_mesh_payload") or {}).get("alignment"),
            "points_object": names["fused_points"],
            "mesh_object": names["hero_mesh"],
        },
        "point_cloud_in_fbx": False,
        "point_cloud_authority": "USDA/PLY",
    }
    try:
        assert_maya_manifest_contract(manifest, profile, stage="MAYA_WORKER_FINAL", require_runtime_gates=True)
        manifest["contract_validation"] = {
            "status": "PASS",
            "gate": "GATE_7_8_MAYA_FBX_PROFILE_NORMALS",
        }
    except Exception as exc:
        manifest["status"] = "FAIL"
        manifest["contract_validation"] = {
            "status": "FAIL",
            "gate": "GATE_7_8_MAYA_FBX_PROFILE_NORMALS",
            "error": str(exc),
        }
        _write_json(out["manifest"], manifest)
        raise
    _write_json(out["manifest"], manifest)
    _progress(run, f"EXIT ma={manifest['ma']['status']} fbx={manifest['fbx']['status']}")
    return manifest


def run_worker(input_json: str | Path) -> int:
    input_path = Path(input_json).resolve()
    payload = json.loads(input_path.read_text(encoding="utf-8"))
    out = build_output_paths(payload["run_dir"], payload["scene_name"])
    try:
        manifest = _create_maya_scene(payload)
        return _worker_exit_code(manifest)
    except Exception as exc:
        failure: dict[str, Any] = {}
        if out["manifest"].is_file():
            try:
                loaded = json.loads(out["manifest"].read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    failure.update(loaded)
            except Exception:
                pass
        failure.update({
            "schema": "ConceptGhost.MayaManifest.v0.31",
            "geometry_profile": payload.get("geometry_profile"),
            "selected_profile": payload.get("selected_profile"),
            "effective_profile": payload.get("effective_profile"),
            "profile_config": payload.get("profile_config"),
            "model": payload.get("model"),
            "mesher_policy": payload.get("mesher_policy"),
            "resolution_level": payload.get("resolution_level"),
            "refine_steps": payload.get("refine_steps"),
            "transport_stride": (payload.get("hero_mesh_payload") or {}).get("transport_stride"),
            "depth_edge_rtol": (payload.get("hero_mesh_payload") or {}).get("depth_edge_rtol"),
            "silent_fallback": bool((payload.get("profile_config") or {}).get("silent_fallback", True)),
            "status": "FAIL",
            "error": str(exc),
            "traceback": traceback.format_exc(),
            "ma": failure.get("ma") or {"path": str(out["ma"]), "status": "PASS" if out["ma"].exists() else "FAIL"},
            "fbx": failure.get("fbx") or {"path": str(out["fbx"]), "status": "PASS" if out["fbx"].exists() else "FAIL"},
        })
        _write_json(out["manifest"], failure)
        return 1
    finally:
        try:
            import maya.standalone  # type: ignore
            maya.standalone.uninitialize()
        except Exception:
            pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ConceptGhost Stage 8 Maya Worker")
    parser.add_argument("input_json", help="Run-local maya_worker_input.json")
    args = parser.parse_args(argv)
    return run_worker(args.input_json)


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import math
import re
from typing import Any

import numpy as np


def _to_numpy(value: Any, dtype=None) -> np.ndarray:
    if value is None:
        return np.array([])
    if isinstance(value, np.ndarray):
        arr = value
    elif hasattr(value, "detach"):
        arr = value.detach().cpu().numpy()
    elif hasattr(value, "cpu") and hasattr(value, "numpy"):
        arr = value.cpu().numpy()
    else:
        arr = np.asarray(value)
    return arr.astype(dtype, copy=False) if dtype is not None else arr


def _single(arr: Any) -> np.ndarray:
    x = _to_numpy(arr)
    if x.ndim >= 1 and x.shape[0] == 1:
        return x[0]
    return x


def _stats(values: np.ndarray) -> dict[str, float | None]:
    a = np.asarray(values, dtype=np.float64).reshape(-1)
    a = a[np.isfinite(a)]
    if a.size == 0:
        return {"min": None, "median": None, "mean": None, "p05": None, "p95": None, "max": None}
    return {
        "min": float(np.min(a)),
        "median": float(np.median(a)),
        "mean": float(np.mean(a)),
        "p05": float(np.percentile(a, 5.0)),
        "p95": float(np.percentile(a, 95.0)),
        "max": float(np.max(a)),
    }


def normalized_intrinsics_fov_deg(intrinsics: Any) -> dict[str, Any]:
    """Interpret MoGe normalized 3x3 intrinsics and derive FOV in degrees.

    MoGe v3 constructs intrinsics with normalized focal lengths and center 0.5/0.5.
    Its own focal_to_fov convention is fov = 2*atan(0.5/focal).
    """
    k = _single(intrinsics).astype(np.float64, copy=False)
    if k.shape != (3, 3) or not np.isfinite(k).all():
        return {"valid": False, "reason": f"invalid_intrinsics_shape_or_values:{list(k.shape)}"}
    fx, fy = float(k[0, 0]), float(k[1, 1])
    if fx <= 0.0 or fy <= 0.0:
        return {"valid": False, "reason": "non_positive_focal", "matrix": k.tolist()}
    fov_x = math.degrees(2.0 * math.atan(0.5 / fx))
    fov_y = math.degrees(2.0 * math.atan(0.5 / fy))
    return {
        "valid": True,
        "matrix": k.tolist(),
        "fx_normalized": fx,
        "fy_normalized": fy,
        "cx_normalized": float(k[0, 2]),
        "cy_normalized": float(k[1, 2]),
        "fov_x_deg": float(fov_x),
        "fov_y_deg": float(fov_y),
    }


def _mask_for_points(points: np.ndarray, mask: Any = None) -> np.ndarray:
    valid = np.isfinite(points).all(axis=-1) & (points[..., 2] > 0)
    m = _single(mask)
    if m.size:
        if m.shape != valid.shape:
            raise ValueError(f"MoGe native mask shape {m.shape} != point grid {valid.shape}")
        valid &= m.astype(bool)
    return valid


def point_distance_m(points: Any, pixel_a: tuple[int, int], pixel_b: tuple[int, int] | None = None, mask: Any = None) -> float:
    """Metric camera→point or point→point distance from the native MoGe point map."""
    p = _single(points).astype(np.float64, copy=False)
    if p.ndim != 3 or p.shape[-1] != 3:
        raise ValueError(f"points must resolve to HxWx3, got {p.shape}")
    valid = _mask_for_points(p, mask)

    def pick(px: tuple[int, int]) -> np.ndarray:
        x, y = int(px[0]), int(px[1])
        if not (0 <= x < p.shape[1] and 0 <= y < p.shape[0]):
            raise ValueError(f"pixel {px} is outside {p.shape[1]}x{p.shape[0]}")
        if not bool(valid[y, x]):
            raise ValueError(f"pixel {px} has no valid native metric point")
        return p[y, x]

    a = pick(pixel_a)
    if pixel_b is None:
        return float(np.linalg.norm(a))
    b = pick(pixel_b)
    return float(np.linalg.norm(a - b))


def regional_metric_summary(points: Any, mask: Any = None, *, x0: int = 0, y0: int = 0, x1: int | None = None, y1: int | None = None) -> dict[str, Any]:
    """Report native metric depth/distance/extent for a rectangular image region."""
    p = _single(points).astype(np.float64, copy=False)
    if p.ndim != 3 or p.shape[-1] != 3:
        raise ValueError(f"points must resolve to HxWx3, got {p.shape}")
    h, w = p.shape[:2]
    x0, y0 = max(0, int(x0)), max(0, int(y0))
    x1 = w if x1 is None else min(w, int(x1))
    y1 = h if y1 is None else min(h, int(y1))
    if x1 <= x0 or y1 <= y0:
        raise ValueError("empty region")
    valid = _mask_for_points(p, mask)
    rv = valid[y0:y1, x0:x1]
    rp = p[y0:y1, x0:x1]
    pts = rp[rv]
    total = int(rv.size)
    count = int(len(pts))
    if count == 0:
        return {"region_px": [x0, y0, x1, y1], "support_count": 0, "support_ratio": 0.0, "status": "NO_SUPPORT"}
    extent = np.max(pts, axis=0) - np.min(pts, axis=0)
    return {
        "region_px": [x0, y0, x1, y1],
        "status": "VALID",
        "support_count": count,
        "support_ratio": float(count / max(total, 1)),
        "depth_m": _stats(pts[:, 2]),
        "camera_distance_m": _stats(np.linalg.norm(pts, axis=1)),
        "extent_camera_xyz_m": [float(x) for x in extent],
        "approx_width_m": float(extent[0]),
        "approx_vertical_extent_m": float(extent[1]),
    }


def _normal_summary(normal: Any, valid_mask: np.ndarray) -> dict[str, Any]:
    n = _single(normal).astype(np.float64, copy=False)
    if n.size == 0:
        return {"available": False}
    if n.shape != valid_mask.shape + (3,):
        return {"available": True, "valid": False, "shape": list(n.shape), "reason": "shape_mismatch"}
    finite = np.isfinite(n).all(axis=-1)
    lengths = np.linalg.norm(n, axis=-1)
    supported = valid_mask & finite
    nonzero = supported & (lengths > 1e-12)
    return {
        "available": True,
        "valid": True,
        "shape": list(n.shape),
        "finite_supported_count": int(np.count_nonzero(supported)),
        "nonzero_supported_count": int(np.count_nonzero(nonzero)),
        "zero_or_invalid_supported_count": int(np.count_nonzero(valid_mask) - np.count_nonzero(nonzero)),
        "length": _stats(lengths[nonzero]),
        "camera_space_mean_xyz": [float(x) for x in np.mean(n[nonzero], axis=0)] if np.any(nonzero) else None,
    }


def _refinement_summary(geometry: dict[str, Any]) -> dict[str, Any]:
    groups: dict[str, list[tuple[int, np.ndarray]]] = {"points": [], "depth": [], "intrinsics": []}
    pat = re.compile(r"^(points|depth|intrinsics)_per_step_(\d+)$")
    for key, value in geometry.items():
        m = pat.match(str(key))
        if not m:
            continue
        groups[m.group(1)].append((int(m.group(2)), _to_numpy(value)))
    for values in groups.values():
        values.sort(key=lambda item: item[0])
    count = max((len(v) for v in groups.values()), default=0)
    out: dict[str, Any] = {"available": count > 0, "step_count": count, "arrays": {k: [i for i, _ in v] for k, v in groups.items()}}
    if count <= 1 or not groups["points"]:
        return out
    deltas = []
    prev = _single(groups["points"][0][1]).astype(np.float64, copy=False)
    for idx, arr in groups["points"][1:]:
        cur = _single(arr).astype(np.float64, copy=False)
        if cur.shape != prev.shape:
            deltas.append({"step": idx, "status": "SHAPE_MISMATCH", "shape": list(cur.shape)})
        else:
            good = np.isfinite(prev).all(axis=-1) & np.isfinite(cur).all(axis=-1)
            d = np.linalg.norm(cur[good] - prev[good], axis=-1) if np.any(good) else np.array([])
            deltas.append({"step": idx, "status": "VALID", "point_motion_m": _stats(d)})
        prev = cur
    out["point_change_between_steps"] = deltas
    return out


def summarize_moge_native_metric(geometry: dict[str, Any], *, atlas_fov_x_deg: float | None = None) -> dict[str, Any]:
    """Summarize immutable MoGe-native metric evidence before Atlas registration."""
    points = _single(geometry.get("points_metric_native", geometry.get("points"))).astype(np.float64, copy=False)
    if points.ndim != 3 or points.shape[-1] != 3:
        raise ValueError(f"MoGe native points must resolve to HxWx3, got {points.shape}")
    mask_obj = geometry.get("mask_native", geometry.get("mask"))
    valid = _mask_for_points(points, mask_obj)
    total = int(valid.size)
    count = int(np.count_nonzero(valid))
    pts = points[valid]

    depth_obj = geometry.get("depth_metric_native", geometry.get("depth"))
    depth = _single(depth_obj).astype(np.float64, copy=False) if depth_obj is not None else np.array([])
    if depth.size and depth.shape != valid.shape:
        depth_info = {"available": True, "valid": False, "shape": list(depth.shape), "reason": "shape_mismatch"}
    elif depth.size:
        d = depth[valid]
        d = d[np.isfinite(d) & (d > 0)]
        depth_info = {"available": True, "valid": True, "shape": list(depth.shape), "meters": _stats(d)}
    else:
        depth_info = {"available": False}

    intr_obj = geometry.get("intrinsics_native", geometry.get("intrinsics"))
    intr = normalized_intrinsics_fov_deg(intr_obj) if intr_obj is not None else {"valid": False, "reason": "missing"}
    worker = dict(geometry.get("conceptghost_worker_report") or {})
    conditioned = bool(worker.get("atlas_fov_used"))
    atlas = float(atlas_fov_x_deg) if atlas_fov_x_deg is not None and math.isfinite(float(atlas_fov_x_deg)) else None
    if intr.get("valid") and atlas is not None:
        delta = abs(float(intr["fov_x_deg"]) - atlas)
        if conditioned:
            state = "CONDITIONED_NOT_INDEPENDENT"
            threshold_policy = None
        else:
            # Candidate diagnostic thresholds. They classify disagreement only;
            # Atlas remains camera authority and no geometry/camera is moved.
            state = "CONSISTENT" if delta <= 1.0 else ("MODERATE_DISAGREEMENT" if delta <= 5.0 else "STRONG_CONFLICT")
            threshold_policy = "candidate_v0.33_fov_delta_deg:consistent<=1,moderate<=5,strong>5"
        comparison = {
            "atlas_fov_x_deg": atlas,
            "moge_fov_x_deg": float(intr["fov_x_deg"]),
            "absolute_delta_deg": float(delta),
            "independent": not conditioned,
            "state": state,
            "threshold_policy": threshold_policy,
            "moves_camera": False,
        }
    else:
        comparison = {"atlas_fov_x_deg": atlas, "independent": not conditioned, "state": "UNAVAILABLE"}

    return {
        "schema": "ConceptGhost.MoGeMetricEvidence.v0.33",
        "status": "PASS",
        "policy": "report_only_no_geometry_movement",
        "native_coordinate_system": "OpenCV camera: +X right, +Y down, +Z forward",
        "units": "meters",
        "points_metric_native": {
            "available": True,
            "shape": list(points.shape),
            "support_count": count,
            "support_ratio": float(count / max(total, 1)),
            "camera_distance_m": _stats(np.linalg.norm(pts, axis=1)) if count else _stats(np.array([])),
            "depth_z_m": _stats(pts[:, 2]) if count else _stats(np.array([])),
            "camera_xyz_extent_m": [float(x) for x in (np.max(pts, axis=0) - np.min(pts, axis=0))] if count else None,
        },
        "depth_metric_native": depth_info,
        "normal_native": _normal_summary(geometry.get("normal_native", geometry.get("normal")), valid),
        "intrinsics_native": intr,
        "atlas_vs_moge_intrinsics": comparison,
        "mask_native": {
            "available": mask_obj is not None and _to_numpy(mask_obj).size > 0,
            "support_count": count,
            "support_ratio": float(count / max(total, 1)),
            "unsupported_count": int(total - count),
        },
        "global_measurements": regional_metric_summary(points, mask_obj),
        "refinement": _refinement_summary(geometry),
    }

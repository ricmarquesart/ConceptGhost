from __future__ import annotations

import math
from typing import Any

import numpy as np

try:
    from .conceptghost_metrology import atlas_architectural_metrology
except ImportError:
    from conceptghost_metrology import atlas_architectural_metrology


def _arr(value: Any) -> np.ndarray:
    if value is None:
        return np.array([])
    if isinstance(value, np.ndarray):
        return value
    if hasattr(value, "detach"):
        return value.detach().cpu().numpy()
    if hasattr(value, "cpu") and hasattr(value, "numpy"):
        return value.cpu().numpy()
    return np.asarray(value)


def _single(value: Any) -> np.ndarray:
    arr = _arr(value)
    if arr.ndim >= 1 and arr.shape[0] == 1:
        arr = arr[0]
    return arr


def disagreement_state(a: float | None, b: float | None) -> dict[str, Any]:
    """Candidate report-only relative disagreement classifier.

    Thresholds are intentionally diagnostic, not correction authority.
    """
    if a is None or b is None:
        return {"state": "UNAVAILABLE", "relative_difference": None, "percent_difference": None}
    a, b = float(a), float(b)
    if not (math.isfinite(a) and math.isfinite(b)) or a <= 0.0 or b <= 0.0:
        return {"state": "UNAVAILABLE", "relative_difference": None, "percent_difference": None}
    denom = max((abs(a) + abs(b)) * 0.5, 1e-12)
    rel = abs(a - b) / denom
    state = "CONSISTENT" if rel <= 0.05 else ("MODERATE_DISAGREEMENT" if rel <= 0.15 else "STRONG_CONFLICT")
    return {
        "state": state,
        "relative_difference": float(rel),
        "percent_difference": float(rel * 100.0),
        "threshold_policy": "candidate_v0.33:consistent<=5%,moderate<=15%,strong>15%",
    }


def source_pixel_to_native(camera: dict[str, Any], points: Any, x_px: float, y_px: float) -> tuple[int, int]:
    p = _single(points)
    if p.ndim != 3 or p.shape[-1] != 3:
        raise ValueError(f"MoGe native points must resolve to HxWx3, got {p.shape}")
    h, w = p.shape[:2]
    sw = float(camera.get("image_width") or 0)
    sh = float(camera.get("image_height") or 0)
    if sw <= 0 or sh <= 0:
        raise ValueError("Atlas image dimensions unavailable")
    # Inverse of canonical source_uv construction: source_x = grid_x * source_w/native_w.
    gx = int(round(float(x_px) * w / sw))
    gy = int(round(float(y_px) * h / sh))
    return max(0, min(w - 1, gx)), max(0, min(h - 1, gy))


def _native_point_distance(geometry: dict[str, Any], camera: dict[str, Any], x_px: float, y_px: float) -> dict[str, Any]:
    points = _single(geometry.get("points_metric_native", geometry.get("points"))).astype(np.float64, copy=False)
    if points.ndim != 3 or points.shape[-1] != 3:
        return {"status": "UNAVAILABLE", "reason": f"invalid_points_shape:{list(points.shape)}"}
    gx, gy = source_pixel_to_native(camera, points, x_px, y_px)
    p = points[gy, gx]
    mask_obj = geometry.get("mask_native", geometry.get("mask"))
    mask = _single(mask_obj)
    if mask.size and (mask.shape != points.shape[:2] or not bool(mask[gy, gx])):
        return {"status": "UNAVAILABLE", "reason": "native_pixel_unsupported", "native_pixel": [gx, gy]}
    if not np.isfinite(p).all() or float(p[2]) <= 0.0:
        return {"status": "UNAVAILABLE", "reason": "native_point_invalid", "native_pixel": [gx, gy]}
    return {
        "status": "VALID",
        "native_pixel": [gx, gy],
        "point_camera_xyz_m": [float(x) for x in p],
        "camera_distance_m": float(np.linalg.norm(p)),
        "depth_z_m": float(p[2]),
    }


def moge_atlas_metric_agreement(scene_bundle: dict[str, Any], base_pixel: tuple[float, float], *, target_label: str = "Target") -> dict[str, Any]:
    runtime = dict(scene_bundle.get("_runtime") or {})
    evidence = dict(runtime.get("primary_evidence") or {})
    geometry = dict(evidence.get("moge_geometry") or {})
    worker_report = dict(geometry.get("conceptghost_worker_report") or {})
    camera = dict(scene_bundle.get("camera") or {})
    canonical = dict(runtime.get("primary_canonical") or {})

    atlas = atlas_architectural_metrology(scene_bundle, base_pixel, None)
    native = _native_point_distance(geometry, camera, *base_pixel)
    atlas_distance = ((atlas.get("base") or {}).get("camera_distance_m"))
    moge_distance = native.get("camera_distance_m") if native.get("status") == "VALID" else None
    target_agreement = disagreement_state(atlas_distance, moge_distance)

    reg = ((canonical.get("refinement") or {}).get("atlas_metric_scale_registration") or {})
    atlas_height = reg.get("target_camera_height_m")
    moge_height = reg.get("raw_camera_height_engine_units")
    camera_height_agreement = disagreement_state(atlas_height, moge_height)
    scale = reg.get("scale_factor") if reg.get("applied") else reg.get("scale_factor_candidate")
    scale_agreement = disagreement_state(1.0, float(scale)) if scale is not None else disagreement_state(None, None)
    if scale_agreement.get("state") != "UNAVAILABLE":
        scale_agreement.update({
            "moge_native_scale": 1.0,
            "atlas_registration_scale_factor": float(scale),
            "registration_applied": bool(reg.get("applied")),
        })

    states = [target_agreement.get("state"), camera_height_agreement.get("state"), scale_agreement.get("state")]
    rank = {"UNAVAILABLE": 0, "CONSISTENT": 1, "MODERATE_DISAGREEMENT": 2, "STRONG_CONFLICT": 3}
    available = [s for s in states if s and s != "UNAVAILABLE"]
    overall = max(available, key=lambda s: rank[s]) if available else "UNAVAILABLE"

    return {
        "schema": "ConceptGhost.MoGeAtlasMetricAgreement.v0.33",
        "status": "PASS" if overall != "UNAVAILABLE" else "INSUFFICIENT_EVIDENCE",
        "policy": "report_only_no_camera_or_geometry_movement",
        "target_label": str(target_label or "Target"),
        "base_pixel": [float(base_pixel[0]), float(base_pixel[1])],
        "atlas_metrology": atlas,
        "moge_native_target": native,
        "target_camera_distance_agreement": {
            **target_agreement,
            "atlas_camera_distance_m": float(atlas_distance) if atlas_distance is not None else None,
            "moge_camera_distance_m": float(moge_distance) if moge_distance is not None else None,
        },
        "camera_height_agreement": {
            **camera_height_agreement,
            "atlas_camera_height_m": float(atlas_height) if atlas_height is not None else None,
            "moge_native_ground_camera_height_m": float(moge_height) if moge_height is not None else None,
        },
        "global_scale_agreement": scale_agreement,
        "overall_state": overall,
        "automatic_correction": False,
        "dependencies": {
            "moge_atlas_fov_conditioned": bool(worker_report.get("atlas_fov_used")),
            "atlas_camera_authority": True,
            "moge_metric_pre_registration": True,
        },
        "notes": [
            "Atlas remains camera authority.",
            "MoGe native metric remains evidence, not an automatic correction command.",
            "Run this target measurement at multiple representative regions (near/far/foreground/structure base) for regional comparison.",
        ],
    }

from __future__ import annotations

import json
import math
from typing import Any

import numpy as np


def _finite_positive(value: Any) -> float | None:
    try:
        v = float(value)
    except Exception:
        return None
    if not math.isfinite(v) or v <= 0:
        return None
    return v


def weighted_median(values: list[float], weights: list[float]) -> float:
    if not values or len(values) != len(weights):
        raise ValueError("weighted_median requires same-length non-empty values/weights")
    pairs = sorted((float(v), max(0.0, float(w))) for v, w in zip(values, weights))
    total = sum(w for _, w in pairs)
    if total <= 0:
        raise ValueError("weighted_median requires positive total weight")
    half = total * 0.5
    acc = 0.0
    for value, weight in pairs:
        acc += weight
        if acc >= half:
            return value
    return pairs[-1][0]


def robust_mad(values: list[float], center: float) -> float:
    if not values:
        return 0.0
    return float(np.median(np.abs(np.asarray(values, dtype=np.float64) - float(center))))


def relative_difference(a: float, b: float) -> float:
    denom = max((abs(float(a)) + abs(float(b))) * 0.5, 1e-12)
    return abs(float(a) - float(b)) / denom


def _best_agreement_group(observations: list[dict[str, Any]], threshold: float = 0.15) -> list[int]:
    """Return indices of the highest-weight mutually compatible 1D group."""
    if not observations:
        return []
    best: tuple[float, int, list[int]] = (-1.0, -1, [])
    for i, obs in enumerate(observations):
        vi = obs["value_m"]
        group = [j for j, other in enumerate(observations) if relative_difference(vi, other["value_m"]) <= threshold]
        # tighten to a truly coherent group by requiring every pair to be within threshold
        coherent = []
        for j in group:
            if all(relative_difference(observations[j]["value_m"], observations[k]["value_m"]) <= threshold for k in group):
                coherent.append(j)
        if not coherent:
            coherent = [i]
        weight = sum(float(observations[j]["weight"]) for j in coherent)
        score = (weight, len(coherent), coherent)
        if (score[0], score[1]) > (best[0], best[1]):
            best = score
    return best[2]


def depthpro_camera_distance_at_pixel(evidence: dict[str, Any], x_px: float, y_px: float) -> dict[str, Any]:
    if evidence.get("status") != "PASS":
        return {"status": "UNAVAILABLE", "reason": "depthpro_not_available"}
    depth_obj = evidence.get("depth_independent_m")
    if depth_obj is None:
        return {"status": "UNAVAILABLE", "reason": "missing_depth"}
    if hasattr(depth_obj, "detach"):
        depth = depth_obj.detach().cpu().numpy()
    else:
        depth = np.asarray(depth_obj)
    if depth.ndim == 3 and depth.shape[0] == 1:
        depth = depth[0]
    if depth.ndim != 2:
        return {"status": "UNAVAILABLE", "reason": f"invalid_depth_shape:{list(depth.shape)}"}
    sw = int(evidence.get("source_width") or depth.shape[1])
    sh = int(evidence.get("source_height") or depth.shape[0])
    gx = max(0, min(depth.shape[1] - 1, int(round(float(x_px) * depth.shape[1] / max(sw, 1)))))
    gy = max(0, min(depth.shape[0] - 1, int(round(float(y_px) * depth.shape[0] / max(sh, 1)))))
    z = _finite_positive(depth[gy, gx])
    focal = _finite_positive(evidence.get("predicted_focal_px"))
    if z is None or focal is None:
        return {"status": "UNAVAILABLE", "reason": "invalid_depth_or_focal", "native_pixel": [gx, gy]}
    cx = sw * 0.5
    cy = sh * 0.5
    xn = (float(x_px) - cx) / focal
    yn = (float(y_px) - cy) / focal
    ray_factor = math.sqrt(1.0 + xn * xn + yn * yn)
    return {
        "status": "VALID",
        "native_pixel": [gx, gy],
        "depth_z_m": float(z),
        "camera_distance_m": float(z * ray_factor),
        "predicted_focal_px": float(focal),
        "independence": "depthpro_predicted_focal_independent_witness",
    }


def build_metric_consensus(metric_agreement_report: Any, depthpro_evidence: dict[str, Any]) -> dict[str, Any]:
    if isinstance(metric_agreement_report, str):
        try:
            agreement = json.loads(metric_agreement_report)
        except Exception:
            agreement = {}
    elif isinstance(metric_agreement_report, dict):
        agreement = dict(metric_agreement_report)
    else:
        agreement = {}

    base_pixel = agreement.get("base_pixel") or [0.0, 0.0]
    x_px, y_px = float(base_pixel[0]), float(base_pixel[1])
    target = agreement.get("target_camera_distance_agreement") or {}
    atlas = _finite_positive(target.get("atlas_camera_distance_m"))
    moge = _finite_positive(target.get("moge_camera_distance_m"))
    dp = depthpro_camera_distance_at_pixel(depthpro_evidence or {}, x_px, y_px)
    depthpro = _finite_positive(dp.get("camera_distance_m")) if dp.get("status") == "VALID" else None

    deps = agreement.get("dependencies") or {}
    observations: list[dict[str, Any]] = []
    if atlas is not None:
        observations.append({"source": "Atlas", "value_m": atlas, "weight": 1.0, "independence": "camera_geometry_metrology"})
    if moge is not None:
        conditioned = bool(deps.get("moge_atlas_fov_conditioned"))
        observations.append({
            "source": "MoGe",
            "value_m": moge,
            "weight": 0.75 if conditioned else 1.0,
            "independence": "atlas_fov_conditioned" if conditioned else "independent_native_metric",
        })
    if depthpro is not None:
        observations.append({"source": "DepthPro", "value_m": depthpro, "weight": 1.0, "independence": "independent_predicted_focal"})

    result: dict[str, Any] = {
        "schema": "ConceptGhost.MetricConsensus.v0.33",
        "policy": "report_only_weighted_median_mad_agreement_groups_no_simple_mean",
        "target_label": agreement.get("target_label") or "Target",
        "base_pixel": [x_px, y_px],
        "observations": [],
        "consensus_distance_m": None,
        "mad_m": None,
        "agreement_group": [],
        "status": "INSUFFICIENT_EVIDENCE",
        "automatic_correction": False,
        "depthpro_sample": dp,
    }
    if not observations:
        return result

    group_idx = _best_agreement_group(observations, threshold=0.15)
    group = [observations[i] for i in group_idx]
    group_sources = {o["source"] for o in group}
    if len(group) >= 2:
        consensus = weighted_median([o["value_m"] for o in group], [o["weight"] for o in group])
        mad = robust_mad([o["value_m"] for o in group], consensus)
        spread_rel = max(relative_difference(o["value_m"], consensus) for o in group)
        status = "HIGH_AGREEMENT" if len(group) >= 3 and spread_rel <= 0.05 else "AGREEMENT"
    else:
        consensus = None
        mad = None
        status = "CONFLICT" if len(observations) >= 2 else "INSUFFICIENT_EVIDENCE"

    output_obs = []
    for obs in observations:
        in_group = obs["source"] in group_sources
        if not in_group and len(observations) >= 2:
            state = "OUTLIER"
        elif obs["weight"] < 0.99:
            state = "WEAK"
        else:
            state = "VALID"
        output_obs.append({**obs, "state": state})

    result.update({
        "status": status,
        "observations": output_obs,
        "agreement_group": [o["source"] for o in group],
        "consensus_distance_m": float(consensus) if consensus is not None else None,
        "mad_m": float(mad) if mad is not None else None,
        "source_states": {o["source"]: o["state"] for o in output_obs},
    })
    return result

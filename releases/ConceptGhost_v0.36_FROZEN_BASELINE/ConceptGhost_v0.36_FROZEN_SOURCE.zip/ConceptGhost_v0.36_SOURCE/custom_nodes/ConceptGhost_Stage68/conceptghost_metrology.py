from __future__ import annotations

import math
from typing import Any

import numpy as np


def _arr(v: Any, dtype=np.float64) -> np.ndarray:
    return np.asarray(v, dtype=dtype)


def atlas_pixel_ray(camera: dict[str, Any], x_px: float, y_px: float) -> dict[str, Any]:
    """Return a normalized world-space Atlas ray for a source-image pixel."""
    if not bool(camera.get("valid")):
        raise ValueError("Atlas camera is not valid")
    intr = camera.get("intrinsics") or {}
    fx, fy = float(intr.get("fx_px", 0.0)), float(intr.get("fy_px", 0.0))
    cx, cy = float(intr.get("cx_px", 0.0)), float(intr.get("cy_px", 0.0))
    if fx <= 0 or fy <= 0:
        raise ValueError("Atlas camera focal is invalid")
    world = _arr((camera.get("extrinsics") or {}).get("camera_world_matrix"))
    if world.shape != (4, 4) or not np.isfinite(world).all():
        raise ValueError("Atlas camera world matrix is invalid")
    local = np.array([(float(x_px) - cx) / fx, -(float(y_px) - cy) / fy, -1.0], dtype=np.float64)
    local /= np.linalg.norm(local)
    direction = world[:3, :3] @ local
    direction /= np.linalg.norm(direction)
    origin = _arr((camera.get("extrinsics") or {}).get("camera_position", world[:3, 3])).reshape(3)
    return {
        "origin": origin,
        "direction": direction,
        "pixel": [float(x_px), float(y_px)],
        "policy": "Atlas pinhole; image origin top-left; camera forward -Z",
    }


def intersect_ray_plane(ray: dict[str, Any], normal: Any, offset_b: float, eps: float = 1e-9) -> dict[str, Any]:
    c = _arr(ray["origin"]).reshape(3)
    d = _arr(ray["direction"]).reshape(3)
    n = _arr(normal).reshape(3)
    nlen = float(np.linalg.norm(n))
    if not np.isfinite(nlen) or nlen <= eps:
        return {"status": "INVALID_PLANE"}
    n = n / nlen
    b = float(offset_b) / nlen
    denom = float(np.dot(n, d))
    if not math.isfinite(denom) or abs(denom) <= eps:
        return {"status": "PARALLEL"}
    t = -float(np.dot(n, c) + b) / denom
    if not math.isfinite(t) or t <= 0.0:
        return {"status": "BEHIND_CAMERA", "t": float(t)}
    p = c + t * d
    cproj = c - (float(np.dot(n, c) + b)) * n
    return {
        "status": "VALID",
        "t": float(t),
        "point_world": p,
        "camera_distance_m": float(np.linalg.norm(p - c)),
        "ground_distance_m": float(np.linalg.norm(p - cproj)),
        "camera_projection_on_plane": cproj,
    }


def _fit_plane_svd(points: np.ndarray) -> tuple[np.ndarray, float, np.ndarray]:
    pts = _arr(points)
    center = np.mean(pts, axis=0)
    _, _, vh = np.linalg.svd(pts - center, full_matrices=False)
    n = vh[-1]
    n /= np.linalg.norm(n)
    if n[1] < 0:
        n = -n
    b = -float(np.dot(n, center))
    residual = np.abs(pts @ n + b)
    return n, b, residual


def _ground_candidates(canonical: dict[str, Any], camera: dict[str, Any], *, target_uv: tuple[float, float] | None = None, local_radius_px: float | None = None) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    xyz = _arr(canonical.get("xyz"))
    uv = _arr(canonical.get("source_uv"))
    if xyz.ndim != 2 or xyz.shape[1] != 3 or uv.shape != (len(xyz), 2):
        raise ValueError("canonical xyz/source_uv alignment is invalid")
    finite = np.isfinite(xyz).all(axis=1) & np.isfinite(uv).all(axis=1)
    cam = _arr((camera.get("extrinsics") or {}).get("camera_position", [0, 0, 0])).reshape(3)
    below = xyz[:, 1] < cam[1] - 1e-4
    mask = finite & below
    mode = "GLOBAL"
    if target_uv is None:
        h = float(camera.get("image_height") or 0)
        if h <= 0:
            raise ValueError("camera image height is invalid")
        mask &= uv[:, 1] >= 0.60 * h
    else:
        mode = "LOCAL"
        tx, ty = map(float, target_uv)
        if local_radius_px is None:
            w = float(camera.get("image_width") or 0)
            h = float(camera.get("image_height") or 0)
            local_radius_px = max(48.0, 0.12 * math.hypot(w, h))
        dist = np.linalg.norm(uv - np.array([tx, ty], dtype=np.float64), axis=1)
        mask &= dist <= float(local_radius_px)
    return xyz[mask], uv[mask], {"candidate_mode": mode, "candidate_count": int(np.count_nonzero(mask))}


def fit_ground_plane(canonical: dict[str, Any], camera: dict[str, Any], *, target_uv: tuple[float, float] | None = None, local_radius_px: float | None = None) -> dict[str, Any]:
    """Fit a deterministic world-space ground plane with explicit quality metrics."""
    pts, uv, meta = _ground_candidates(canonical, camera, target_uv=target_uv, local_radius_px=local_radius_px)
    candidate_count = int(len(pts))
    result: dict[str, Any] = {
        "schema": "ConceptGhost.GroundPlane.v0.33",
        "mode": meta["candidate_mode"],
        "candidate_count": candidate_count,
        "status": "FAIL",
        "quality_policy": "candidate_v0.33_report_only",
    }
    if candidate_count < 30:
        result["reason"] = "INSUFFICIENT_CANDIDATES"
        return result

    # Atlas establishes world-up, so first isolate the dominant lower-image Y band.
    y = pts[:, 1]
    lo, hi = np.percentile(y, [2.0, 98.0])
    if not np.isfinite([lo, hi]).all():
        result["reason"] = "NONFINITE_GROUND_DISTRIBUTION"
        return result
    if abs(float(hi - lo)) <= 1e-8:
        mode_y = float(np.median(y))
        band = 0.05
    else:
        hist, edges = np.histogram(y, bins=128, range=(float(lo), float(hi)))
        peak = int(np.argmax(hist))
        mode_y = float((edges[peak] + edges[peak + 1]) * 0.5)
        band = max(0.05, 3.0 * float(edges[peak + 1] - edges[peak]))
    seed = np.abs(y - mode_y) <= band
    seed_pts = pts[seed]
    if len(seed_pts) < 30:
        result.update({"reason": "INSUFFICIENT_MODE_INLIERS", "mode_y_m": mode_y, "mode_band_m": band})
        return result

    n0, b0, r0 = _fit_plane_svd(seed_pts)
    mad = float(np.median(np.abs(r0 - np.median(r0))))
    threshold = max(0.03, 3.0 * 1.4826 * mad, float(np.percentile(r0, 75)) * 1.5)
    residual_all = np.abs(pts @ n0 + b0)
    inlier = residual_all <= threshold
    inlier_pts = pts[inlier]
    if len(inlier_pts) < 30:
        result.update({"reason": "INSUFFICIENT_PLANE_INLIERS", "residual_threshold_m": threshold})
        return result

    n, b, residual = _fit_plane_svd(inlier_pts)
    normal_consistency = float(abs(np.dot(n, np.array([0.0, 1.0, 0.0]))))
    p50 = float(np.median(residual))
    p95 = float(np.percentile(residual, 95.0))
    inlier_ratio = float(len(inlier_pts) / max(candidate_count, 1))

    cand_span = np.ptp(pts[:, [0, 2]], axis=0)
    in_span = np.ptp(inlier_pts[:, [0, 2]], axis=0)
    cand_area = float(max(cand_span[0] * cand_span[1], 1e-9))
    in_area = float(max(in_span[0] * in_span[1], 0.0))
    coverage = float(min(1.0, in_area / cand_area))

    support_score = min(1.0, inlier_ratio / 0.20)
    residual_score = max(0.0, 1.0 - p95 / 0.20)
    normal_score = max(0.0, min(1.0, (normal_consistency - 0.70) / 0.30))
    coverage_score = min(1.0, coverage / 0.20)
    confidence = float(0.30 * support_score + 0.30 * residual_score + 0.25 * normal_score + 0.15 * coverage_score)

    passed = bool(len(inlier_pts) >= 30 and inlier_ratio >= 0.08 and p95 <= 0.20 and normal_consistency >= 0.75 and coverage >= 0.03 and confidence >= 0.55)
    result.update({
        "status": "PASS" if passed else "FAIL",
        "reason": "GROUND_MODEL_PASS" if passed else "GROUND_QUALITY_FAIL",
        "normal_world": n.tolist(),
        "offset_b": float(b),
        "inlier_count": int(len(inlier_pts)),
        "inlier_ratio": inlier_ratio,
        "support_count": int(len(inlier_pts)),
        "support_ratio": inlier_ratio,
        "planarity_residual_median_m": p50,
        "planarity_residual_p95_m": p95,
        "spatial_coverage": coverage,
        "normal_consistency": normal_consistency,
        "confidence": confidence,
        "residual_threshold_m": threshold,
        "mode_y_m": mode_y,
        "mode_band_m": band,
    })
    return result


def resolve_ground_plane(canonical: dict[str, Any], camera: dict[str, Any], base_pixel: tuple[float, float]) -> dict[str, Any]:
    global_model = fit_ground_plane(canonical, camera)
    if global_model.get("status") == "PASS":
        return {"status": "PASS", "selected": "GLOBAL", "model": global_model, "global": global_model, "local": None}
    local_model = fit_ground_plane(canonical, camera, target_uv=base_pixel)
    if local_model.get("status") == "PASS":
        return {"status": "PASS", "selected": "LOCAL", "model": local_model, "global": global_model, "local": local_model}
    return {"status": "INSUFFICIENT_GROUND_MODEL", "selected": None, "model": None, "global": global_model, "local": local_model}


def architectural_height(camera: dict[str, Any], base_world: Any, top_pixel: tuple[float, float]) -> dict[str, Any]:
    """Closest approach between vertical line B+hU and Atlas top-pixel ray."""
    b = _arr(base_world).reshape(3)
    ray = atlas_pixel_ray(camera, *top_pixel)
    c = _arr(ray["origin"]).reshape(3)
    d = _arr(ray["direction"]).reshape(3)
    up = np.array([0.0, 1.0, 0.0], dtype=np.float64)
    a = np.column_stack([up, -d])
    rhs = c - b
    sol, _, _, _ = np.linalg.lstsq(a, rhs, rcond=None)
    h, t = float(sol[0]), float(sol[1])
    p_vertical = b + h * up
    p_ray = c + t * d
    residual = float(np.linalg.norm(p_vertical - p_ray))
    status = "VALID" if math.isfinite(h) and math.isfinite(t) and h >= 0.0 and t > 0.0 else "INVALID"
    return {
        "status": status,
        "estimated_height_m": h if status == "VALID" else None,
        "ray_t_m": t if status == "VALID" else None,
        "closest_approach_residual_m": residual,
        "vertical_point_world": p_vertical.tolist(),
        "ray_point_world": p_ray.tolist(),
    }


def atlas_architectural_metrology(scene_bundle: dict[str, Any], base_pixel: tuple[float, float], top_pixel: tuple[float, float] | None = None) -> dict[str, Any]:
    camera = dict(scene_bundle.get("camera") or {})
    runtime = dict(scene_bundle.get("_runtime") or {})
    canonical = runtime.get("primary_canonical")
    if not isinstance(canonical, dict):
        raise ValueError("SceneBundle is missing primary canonical geometry")
    ground = resolve_ground_plane(canonical, camera, base_pixel)
    report: dict[str, Any] = {
        "schema": "ConceptGhost.AtlasMetrology.v0.33",
        "policy": "report_only_no_camera_or_geometry_movement",
        "base_pixel": [float(base_pixel[0]), float(base_pixel[1])],
        "top_pixel": [float(top_pixel[0]), float(top_pixel[1])] if top_pixel is not None else None,
        "ground": ground,
    }
    if ground.get("status") != "PASS":
        report.update({"status": "INSUFFICIENT_GROUND_MODEL", "base": None, "height": None})
        return report
    model = ground["model"]
    ray = atlas_pixel_ray(camera, *base_pixel)
    hit = intersect_ray_plane(ray, model["normal_world"], model["offset_b"])
    if hit.get("status") != "VALID":
        report.update({"status": "INVALID_BASE_INTERSECTION", "base": hit, "height": None})
        return report
    report["base"] = {
        "status": "VALID",
        "world_xyz": hit["point_world"].tolist(),
        "camera_distance_m": hit["camera_distance_m"],
        "ground_distance_m": hit["ground_distance_m"],
    }
    if top_pixel is not None:
        report["height"] = architectural_height(camera, hit["point_world"], top_pixel)
    else:
        report["height"] = None
    report["status"] = "VALID" if (report["height"] is None or report["height"].get("status") == "VALID") else "PARTIAL"
    return report

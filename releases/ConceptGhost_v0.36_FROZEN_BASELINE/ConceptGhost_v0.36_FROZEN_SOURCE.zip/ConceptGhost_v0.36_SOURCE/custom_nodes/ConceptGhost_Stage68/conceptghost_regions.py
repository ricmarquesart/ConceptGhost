from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import numpy as np


def _relative_difference(a: float, b: float) -> float:
    denom = max((abs(float(a)) + abs(float(b))) * 0.5, 1e-12)
    return abs(float(a) - float(b)) / denom


def _orientation_class(face_normals: np.ndarray) -> np.ndarray:
    """Coarse world-space surface class using |normal dot Y-up|.

    Camera-facing winding can flip the sign, therefore the absolute Y component
    is intentional.  This classification is metadata only and never edits mesh
    topology.
    """
    ny = np.abs(np.asarray(face_normals, dtype=np.float32)[:, 1])
    out = np.full(len(ny), 1, dtype=np.int8)  # 1 = SLOPED
    out[ny >= 0.82] = 0  # HORIZONTAL-like: ground / roofs
    out[ny <= 0.38] = 2  # VERTICAL-like: facades / walls
    return out


def _orientation_name(value: int) -> str:
    return {0: "HORIZONTAL", 1: "SLOPED", 2: "VERTICAL"}.get(int(value), "OTHER")


class _UnionFind:
    def __init__(self, n: int):
        self.parent = np.arange(int(n), dtype=np.int32)
        self.rank = np.zeros(int(n), dtype=np.int8)

    def find(self, x: int) -> int:
        p = self.parent
        x = int(x)
        while int(p[x]) != x:
            p[x] = p[int(p[x])]
            x = int(p[x])
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return
        rank = self.rank
        if rank[ra] < rank[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        if rank[ra] == rank[rb]:
            rank[ra] += 1


def _compress_face_ranges(face_region_ids: np.ndarray, region_count: int, max_ranges_per_region: int = 512):
    labels = np.asarray(face_region_ids, dtype=np.int32).reshape(-1)
    ranges: list[list[list[int]]] = [[] for _ in range(int(region_count))]
    total_runs = np.zeros(int(region_count), dtype=np.int32)
    if len(labels) == 0:
        return ranges, total_runs
    changes = np.flatnonzero(np.r_[True, labels[1:] != labels[:-1], True])
    for start, end in zip(changes[:-1], changes[1:]):
        rid = int(labels[start])
        if rid < 0 or rid >= region_count:
            continue
        total_runs[rid] += 1
        if len(ranges[rid]) < int(max_ranges_per_region):
            ranges[rid].append([int(start), int(end - 1)])
    return ranges, total_runs


def build_simplified_geometric_regions(
    arrays: dict[str, Any],
    *,
    tile_size_px: int = 96,
    normal_merge_angle_deg: float = 24.0,
    depth_merge_relative: float = 0.22,
    depth_band_relative: float = 0.18,
    min_faces: int = 500,
    max_regions: int = 96,
    max_maya_ranges_per_region: int = 512,
) -> tuple[dict[str, Any], np.ndarray]:
    """Build deterministic metadata-only geometric regions on PrimaryMesh.

    The algorithm intentionally works on coarse structured supertiles instead of
    expensive learned segmentation.  It never edits vertices/faces.  Depth-edge
    topology has already been protected by the authoritative PrimaryMesh mesher;
    this layer only groups faces for diagnostics and later artist-approved local
    operations.
    """
    vertices = np.asarray(arrays.get("vertices"), dtype=np.float32).reshape((-1, 3))
    faces = np.asarray(arrays.get("faces"), dtype=np.int64).reshape((-1, 3))
    face_normals = np.asarray(arrays.get("face_normals"), dtype=np.float32).reshape((-1, 3))
    grid_xy = np.asarray(arrays.get("grid_xy"), dtype=np.float32).reshape((-1, 2))
    if len(vertices) == 0 or len(faces) == 0:
        raise ValueError("PrimaryMesh regions require non-empty vertices/faces")
    if len(face_normals) != len(faces):
        raise ValueError("PrimaryMesh regions require one face normal per face")
    if len(grid_xy) != len(vertices):
        raise ValueError("PrimaryMesh regions require grid_xy per vertex")

    # Face-level summaries are vectorized and bounded in memory.
    fgrid = grid_xy[faces].mean(axis=1)
    fcenter = vertices[faces].mean(axis=1)
    orientations = _orientation_class(face_normals)

    camera_depth = np.asarray(arrays.get("camera_depth", []), dtype=np.float32).reshape(-1)
    if len(camera_depth) == len(vertices):
        fdepth = camera_depth[faces].mean(axis=1)
    else:
        # Atlas canonical convention uses -Z camera forward only before world
        # transform; when explicit camera_depth is unavailable use Euclidean
        # magnitude as a report-only grouping proxy.
        fdepth = np.linalg.norm(fcenter, axis=1).astype(np.float32)
    good_depth = np.isfinite(fdepth) & (fdepth > 1e-6)
    if not np.any(good_depth):
        fdepth = np.ones(len(faces), dtype=np.float32)
        good_depth[:] = True
    fallback_depth = float(np.median(fdepth[good_depth]))
    fdepth = np.where(good_depth, fdepth, fallback_depth).astype(np.float32)

    boundary = np.asarray(arrays.get("geometric_boundary_strength", []), dtype=np.float32).reshape(-1)
    if len(boundary) == len(vertices):
        fboundary = np.nanmax(boundary[faces], axis=1)
        finite_boundary = fboundary[np.isfinite(fboundary)]
        boundary_threshold = float(np.percentile(finite_boundary, 85.0)) if len(finite_boundary) else math.inf
        if not math.isfinite(boundary_threshold) or boundary_threshold <= 0:
            boundary_threshold = math.inf
        boundary_face = np.isfinite(fboundary) & (fboundary >= boundary_threshold)
    else:
        boundary_threshold = math.inf
        boundary_face = np.zeros(len(faces), dtype=bool)

    tile = max(8, int(tile_size_px))
    tx = np.floor(fgrid[:, 0] / float(tile)).astype(np.int64)
    ty = np.floor(fgrid[:, 1] / float(tile)).astype(np.int64)
    # Relative depth bins are logarithmic so equal bin deltas have approximately
    # equal percentage scale at near/far distances.
    log_step = math.log1p(max(float(depth_band_relative), 0.02))
    dband = np.floor(np.log(np.maximum(fdepth.astype(np.float64), 1e-6)) / log_step).astype(np.int64)

    # Structured unique bucket key.  We keep this as an Nx4 matrix for clarity;
    # number of faces is large but only four int64 columns are allocated.
    raw_key = np.column_stack([tx, ty, orientations.astype(np.int64), dband])
    unique_key, inverse = np.unique(raw_key, axis=0, return_inverse=True)
    bucket_count = len(unique_key)
    counts = np.bincount(inverse, minlength=bucket_count).astype(np.int64)

    def bsum(values: np.ndarray) -> np.ndarray:
        values = np.asarray(values)
        if values.ndim == 1:
            return np.bincount(inverse, weights=values.astype(np.float64), minlength=bucket_count)
        return np.column_stack([
            np.bincount(inverse, weights=values[:, i].astype(np.float64), minlength=bucket_count)
            for i in range(values.shape[1])
        ])

    normal_sum = bsum(face_normals)
    normal_len = np.linalg.norm(normal_sum, axis=1)
    bucket_normal = normal_sum / np.maximum(normal_len[:, None], 1e-12)
    bucket_center = bsum(fcenter) / np.maximum(counts[:, None], 1)
    bucket_depth = bsum(fdepth) / np.maximum(counts, 1)
    bucket_boundary_ratio = bsum(boundary_face.astype(np.float32)) / np.maximum(counts, 1)

    # Merge only neighboring supertiles with compatible orientation, depth and
    # representative normal.  This gives us a small graph even for 2.8M faces.
    lookup = {tuple(map(int, k)): i for i, k in enumerate(unique_key.tolist())}
    uf = _UnionFind(bucket_count)
    normal_cos = math.cos(math.radians(float(normal_merge_angle_deg)))
    for i, k in enumerate(unique_key):
        x, y, orient, band = map(int, k)
        for dx, dy in ((1, 0), (0, 1), (1, 1), (-1, 1)):
            for band_delta in (-1, 0, 1):
                j = lookup.get((x + dx, y + dy, orient, band + band_delta))
                if j is None:
                    continue
                if max(float(bucket_boundary_ratio[i]), float(bucket_boundary_ratio[j])) >= 0.65:
                    continue
                if float(np.dot(bucket_normal[i], bucket_normal[j])) < normal_cos:
                    continue
                if _relative_difference(float(bucket_depth[i]), float(bucket_depth[j])) > float(depth_merge_relative):
                    continue
                uf.union(i, j)

    roots = np.fromiter((uf.find(i) for i in range(bucket_count)), dtype=np.int32, count=bucket_count)
    _, bucket_region = np.unique(roots, return_inverse=True)
    raw_face_region = bucket_region[inverse]
    raw_region_count = int(raw_face_region.max(initial=-1) + 1)
    raw_counts = np.bincount(raw_face_region, minlength=raw_region_count).astype(np.int64)

    eligible = np.flatnonzero(raw_counts >= max(1, int(min_faces)))
    if len(eligible) > int(max_regions):
        order = np.argsort(raw_counts[eligible])[::-1][: int(max_regions)]
        eligible = eligible[order]
    else:
        eligible = eligible[np.argsort(raw_counts[eligible])[::-1]]

    remap = np.full(raw_region_count, -1, dtype=np.int32)
    for new_id, old_id in enumerate(eligible.tolist()):
        remap[int(old_id)] = int(new_id)
    face_region_ids = remap[raw_face_region]
    kept_count = len(eligible)

    # Aggregate summary values only over kept regions.
    keep_face = face_region_ids >= 0
    kept_labels = face_region_ids[keep_face]
    kept_centers = fcenter[keep_face]
    kept_normals = face_normals[keep_face]
    kept_depth = fdepth[keep_face]
    kept_grid = fgrid[keep_face]
    kept_boundary = boundary_face[keep_face]
    rc = np.bincount(kept_labels, minlength=kept_count).astype(np.int64) if kept_count else np.zeros(0, dtype=np.int64)

    def rsum(values: np.ndarray) -> np.ndarray:
        values = np.asarray(values)
        if kept_count == 0:
            shape = (0,) if values.ndim == 1 else (0, values.shape[1])
            return np.zeros(shape, dtype=np.float64)
        if values.ndim == 1:
            return np.bincount(kept_labels, weights=values.astype(np.float64), minlength=kept_count)
        return np.column_stack([
            np.bincount(kept_labels, weights=values[:, i].astype(np.float64), minlength=kept_count)
            for i in range(values.shape[1])
        ])

    center_sum = rsum(kept_centers)
    mean_center = center_sum / np.maximum(rc[:, None], 1) if kept_count else np.zeros((0, 3))
    nsum = rsum(kept_normals)
    planarity = np.linalg.norm(nsum, axis=1) / np.maximum(rc, 1) if kept_count else np.zeros(0)
    mean_normal = nsum / np.maximum(np.linalg.norm(nsum, axis=1)[:, None], 1e-12) if kept_count else np.zeros((0, 3))
    depth_sum = rsum(kept_depth)
    depth_sq_sum = rsum(kept_depth.astype(np.float64) ** 2)
    depth_mean = depth_sum / np.maximum(rc, 1) if kept_count else np.zeros(0)
    depth_var = np.maximum(depth_sq_sum / np.maximum(rc, 1) - depth_mean ** 2, 0.0) if kept_count else np.zeros(0)
    depth_std = np.sqrt(depth_var)
    boundary_ratio = rsum(kept_boundary.astype(np.float32)) / np.maximum(rc, 1) if kept_count else np.zeros(0)

    world_min = np.full((kept_count, 3), np.inf, dtype=np.float64)
    world_max = np.full((kept_count, 3), -np.inf, dtype=np.float64)
    image_min = np.full((kept_count, 2), np.inf, dtype=np.float64)
    image_max = np.full((kept_count, 2), -np.inf, dtype=np.float64)
    if kept_count:
        for axis in range(3):
            np.minimum.at(world_min[:, axis], kept_labels, kept_centers[:, axis])
            np.maximum.at(world_max[:, axis], kept_labels, kept_centers[:, axis])
        for axis in range(2):
            np.minimum.at(image_min[:, axis], kept_labels, kept_grid[:, axis])
            np.maximum.at(image_max[:, axis], kept_labels, kept_grid[:, axis])

    ranges, total_runs = _compress_face_ranges(face_region_ids, kept_count, max_maya_ranges_per_region)

    # Region orientation comes from the dominant face class (groups are already
    # constrained to one orientation class at bucket level).
    orient_votes = np.zeros((kept_count, 3), dtype=np.int64)
    if kept_count:
        kept_orient = orientations[keep_face]
        for o in range(3):
            orient_votes[:, o] = np.bincount(kept_labels, weights=(kept_orient == o).astype(np.int64), minlength=kept_count)
    dominant_orient = np.argmax(orient_votes, axis=1) if kept_count else np.zeros(0, dtype=np.int64)

    regions = []
    total_faces = max(len(faces), 1)
    for rid in range(kept_count):
        name = f"CG_REGION_{rid + 1:03d}"
        full_ranges = int(total_runs[rid]) <= int(max_maya_ranges_per_region)
        face_ranges = ranges[rid] if full_ranges else []
        maya_members = []
        if full_ranges:
            for start, end in face_ranges:
                if int(start) == int(end):
                    maya_members.append(f"CG_HERO_MESH.f[{int(start)}]")
                else:
                    maya_members.append(f"CG_HERO_MESH.f[{int(start)}:{int(end)}]")
        regions.append({
            "name": name,
            "label": f"{_orientation_name(int(dominant_orient[rid]))}_{rid + 1:03d}",
            "source": "simplified_geometric_region_graph",
            "policy": "metadata_selection_only_no_geometry_deletion",
            "orientation": _orientation_name(int(dominant_orient[rid])),
            "face_count": int(rc[rid]),
            "face_ratio": float(rc[rid] / total_faces),
            "center_world": [float(x) for x in mean_center[rid]],
            "mean_normal_world": [float(x) for x in mean_normal[rid]],
            "planarity_score": float(np.clip(planarity[rid], 0.0, 1.0)),
            "curvature_proxy": float(np.clip(1.0 - planarity[rid], 0.0, 1.0)),
            "depth_mean_m": float(depth_mean[rid]),
            "depth_std_m": float(depth_std[rid]),
            "boundary_face_ratio": float(boundary_ratio[rid]),
            "image_bbox_px": [float(x) for x in np.r_[image_min[rid], image_max[rid]]],
            "world_bbox": {
                "min": [float(x) for x in world_min[rid]],
                "max": [float(x) for x in world_max[rid]],
            },
            "face_ranges": face_ranges,
            "face_range_count": int(total_runs[rid]),
            "maya_selection_materialized": bool(full_ranges),
            "maya_members": maya_members,
        })

    discarded_faces = int(np.count_nonzero(face_region_ids < 0))
    report = {
        "schema": "ConceptGhost.GeometricRegions.v0.33",
        "status": "PASS" if kept_count else "INSUFFICIENT_REGIONS",
        "policy": "diagnostic_metadata_only_no_geometry_movement_no_geometry_deletion",
        "algorithm": "structured_supertile_region_graph",
        "geometry_modified": False,
        "parameters": {
            "tile_size_px": tile,
            "normal_merge_angle_deg": float(normal_merge_angle_deg),
            "depth_merge_relative": float(depth_merge_relative),
            "depth_band_relative": float(depth_band_relative),
            "min_faces": int(min_faces),
            "max_regions": int(max_regions),
            "boundary_threshold": None if not math.isfinite(boundary_threshold) else float(boundary_threshold),
        },
        "input": {
            "vertex_count": int(len(vertices)),
            "face_count": int(len(faces)),
            "bucket_count": int(bucket_count),
            "raw_region_count": int(raw_region_count),
        },
        "region_count": int(kept_count),
        "covered_faces": int(np.count_nonzero(face_region_ids >= 0)),
        "discarded_small_region_faces": discarded_faces,
        "coverage_ratio": float(np.count_nonzero(face_region_ids >= 0) / total_faces),
        "regions": regions,
    }
    return report, face_region_ids.astype(np.int16 if kept_count < 32767 else np.int32, copy=False)


def build_region_vertex_mask(arrays: dict[str, Any], face_region_ids: np.ndarray) -> np.ndarray:
    faces = np.asarray(arrays.get("faces"), dtype=np.int64).reshape((-1, 3))
    grid_xy = np.asarray(arrays.get("grid_xy"), dtype=np.int32).reshape((-1, 2))
    labels = np.asarray(face_region_ids, dtype=np.int32).reshape(-1)
    if len(faces) != len(labels) or len(grid_xy) == 0:
        return np.zeros((1, 1), dtype=np.int16)
    width = max(int(np.max(grid_xy[:, 0])) + 1, 1)
    height = max(int(np.max(grid_xy[:, 1])) + 1, 1)
    mask = np.full((height, width), -1, dtype=np.int16 if labels.max(initial=-1) < 32767 else np.int32)
    valid_face = labels >= 0
    if not np.any(valid_face):
        return mask
    flat_vertices = faces[valid_face].reshape(-1)
    flat_labels = np.repeat(labels[valid_face], 3)
    xy = grid_xy[flat_vertices]
    good = (xy[:, 0] >= 0) & (xy[:, 0] < width) & (xy[:, 1] >= 0) & (xy[:, 1] < height)
    mask[xy[good, 1], xy[good, 0]] = flat_labels[good]
    return mask


def colorize_region_overlay(
    source_rgb: np.ndarray,
    region_mask: np.ndarray,
    alpha: float = 0.10,
    *,
    boundary_alpha: float = 0.90,
    boundary_width_px: int = 2,
) -> np.ndarray:
    """Artist-readable P7 overlay: subtle region tint + emphasized boundaries.

    P7 regions are geometric work partitions, not semantic/object labels.  The
    earlier high-alpha fill made valid supertile partitions look like a noisy
    segmentation failure.  Keep the source image dominant, use only a faint
    deterministic tint inside retained regions, and draw strong boundaries
    where neighboring retained region IDs differ.  Visualization only: this
    function never changes the region map or PrimaryMesh.
    """
    src = np.asarray(source_rgb, dtype=np.float32)
    if src.ndim == 4:
        src = src[0]
    if src.max(initial=0.0) <= 1.0:
        src = np.clip(src * 255.0, 0, 255)
    else:
        src = np.clip(src, 0, 255)
    h, w = src.shape[:2]
    mask = np.asarray(region_mask)
    if mask.shape != (h, w):
        # nearest-neighbor resize without external dependencies
        yy = np.minimum((np.arange(h) * mask.shape[0] / max(h, 1)).astype(np.int64), mask.shape[0] - 1)
        xx = np.minimum((np.arange(w) * mask.shape[1] / max(w, 1)).astype(np.int64), mask.shape[1] - 1)
        mask = mask[np.ix_(yy, xx)]

    out = src.copy()
    ids = np.unique(mask[mask >= 0])
    fill_alpha = float(np.clip(alpha, 0.0, 0.35))
    for rid in ids.tolist():
        # Deterministic palette; deliberately low-opacity so the source image
        # remains the primary visual reference.
        r = (53 * (rid + 1) + 97) % 256
        g = (97 * (rid + 1) + 53) % 256
        b = (193 * (rid + 1) + 29) % 256
        sel = mask == rid
        out[sel] = out[sel] * (1.0 - fill_alpha) + np.array([r, g, b], dtype=np.float32) * fill_alpha

    valid = mask >= 0
    boundary = np.zeros((h, w), dtype=bool)
    if w > 1:
        d = valid[:, 1:] & valid[:, :-1] & (mask[:, 1:] != mask[:, :-1])
        boundary[:, 1:] |= d
        boundary[:, :-1] |= d
    if h > 1:
        d = valid[1:, :] & valid[:-1, :] & (mask[1:, :] != mask[:-1, :])
        boundary[1:, :] |= d
        boundary[:-1, :] |= d

    # Small dependency-free dilation so boundaries remain readable at 1448x1086.
    width_px = max(1, min(int(boundary_width_px), 4))
    dilated = boundary.copy()
    for _ in range(width_px - 1):
        expanded = dilated.copy()
        expanded[1:, :] |= dilated[:-1, :]
        expanded[:-1, :] |= dilated[1:, :]
        expanded[:, 1:] |= dilated[:, :-1]
        expanded[:, :-1] |= dilated[:, 1:]
        dilated = expanded

    if np.any(dilated):
        edge_color = np.array([255.0, 230.0, 64.0], dtype=np.float32)
        edge_alpha = float(np.clip(boundary_alpha, 0.0, 1.0))
        out[dilated] = out[dilated] * (1.0 - edge_alpha) + edge_color * edge_alpha

    return np.clip(out, 0, 255).astype(np.uint8)


def analyze_primary_mesh_regions(npz_path: str | Path) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    path = Path(npz_path)
    if not path.is_file():
        raise FileNotFoundError(f"PrimaryMesh NPZ not found: {path}")
    with np.load(path, allow_pickle=False) as data:
        arrays = {k: np.asarray(data[k]) for k in data.files}
    report, face_region_ids = build_simplified_geometric_regions(arrays)
    mask = build_region_vertex_mask(arrays, face_region_ids)
    return report, face_region_ids, mask

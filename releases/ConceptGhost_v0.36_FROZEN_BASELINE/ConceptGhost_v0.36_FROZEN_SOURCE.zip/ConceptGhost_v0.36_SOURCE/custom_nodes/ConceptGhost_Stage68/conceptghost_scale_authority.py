from __future__ import annotations

import copy
import math
from typing import Any

import numpy as np

try:
    from .conceptghost_geometry import geometry_health, reprojection_report
    from .conceptghost_metrology import atlas_architectural_metrology
except ImportError:
    from conceptghost_geometry import geometry_health, reprojection_report
    from conceptghost_metrology import atlas_architectural_metrology


def _finite_positive(value: Any) -> float | None:
    try:
        v = float(value)
    except Exception:
        return None
    if not math.isfinite(v) or v <= 0.0:
        return None
    return v


def normalize_measurement_target(target: Any) -> dict[str, Any]:
    obj = dict(target or {}) if isinstance(target, dict) else {}
    return {
        "schema": "ConceptGhost.MeasurementTarget.v0.36",
        "enabled": bool(obj.get("enabled", False)),
        "target_label": str(obj.get("target_label") or "Known reference"),
        "base_pixel": [float((obj.get("base_pixel") or [0, 0])[0]), float((obj.get("base_pixel") or [0, 0])[1])],
        "use_top_pixel": bool(obj.get("use_top_pixel", False)),
        "top_pixel": [float((obj.get("top_pixel") or [0, 0])[0]), float((obj.get("top_pixel") or [0, 0])[1])],
        "known_height_m": _finite_positive(obj.get("known_height_m")),
        "use_known_height_as_scale_authority": bool(obj.get("use_known_height_as_scale_authority", False)),
        "manual_measurement_policy": "artist_entered_known_physical_measurement_is_scale_authority_when_explicitly_enabled",
    }


def apply_known_height_scale_authority(scene_bundle: dict[str, Any], measurement_target: Any) -> tuple[dict[str, Any], dict[str, Any]]:
    """Apply an explicit known object height as global metric scale authority.

    This is a uniform similarity transform. Geometry XYZ and camera translation are
    multiplied by the same factor while camera rotation/intrinsics remain unchanged.
    Therefore perspective projection, proportions, UVs and image alignment are preserved.
    The manual reference is sovereign over learned/automatic metric estimates, but it
    does not solve camera FOV/rotation by itself.
    """
    target = normalize_measurement_target(measurement_target)
    base_report = {
        "schema": "ConceptGhost.KnownScaleAuthority.v0.36",
        "status": "DISABLED",
        "policy": "manual_known_height_overrides_automatic_metric_scale_only_when_explicitly_enabled",
        "measurement_target": target,
        "moves_geometry": False,
        "moves_camera_translation": False,
        "changes_camera_rotation": False,
        "changes_camera_intrinsics": False,
        "preserves_projection": True,
        "official_primarymesh_scale_authority": False,
    }
    if not target["enabled"]:
        base_report["reason"] = "measurement_target_disabled"
        return scene_bundle, base_report
    if not target["use_known_height_as_scale_authority"]:
        base_report["reason"] = "known_height_scale_authority_disabled"
        return scene_bundle, base_report
    if not target["use_top_pixel"]:
        raise RuntimeError("Known Height Scale Authority requires Use Top Pixel = ON so the referenced height is defined.")
    known = target.get("known_height_m")
    if known is None:
        raise RuntimeError("Known Height Scale Authority requires Known Height (m) > 0.")

    base_px = tuple(target["base_pixel"])
    top_px = tuple(target["top_pixel"])
    pre = atlas_architectural_metrology(scene_bundle, base_px, top_px)
    pre_h = _finite_positive(((pre.get("height") or {}).get("estimated_height_m")))
    if pre.get("status") not in {"VALID", "PARTIAL"} or pre_h is None:
        raise RuntimeError(
            "Known Height Scale Authority could not derive the current base→top height. "
            f"Atlas metrology status={pre.get('status')!r}. Check base/top pixels and ground support."
        )

    factor = float(known / pre_h)
    if not math.isfinite(factor) or factor <= 0.0 or factor < 1.0e-4 or factor > 1.0e4:
        raise RuntimeError(f"Known Height Scale Authority produced an invalid scale factor: {factor!r}")

    runtime0 = dict(scene_bundle.get("_runtime") or {})
    canonical0 = runtime0.get("primary_canonical")
    if not isinstance(canonical0, dict):
        raise RuntimeError("Known Height Scale Authority requires SceneBundle primary canonical geometry.")

    camera = copy.deepcopy(dict(scene_bundle.get("camera") or {}))
    extr = copy.deepcopy(dict(camera.get("extrinsics") or {}))
    world = np.asarray(extr.get("camera_world_matrix"), dtype=np.float64)
    if world.shape != (4, 4) or not np.isfinite(world).all():
        raise RuntimeError("Known Height Scale Authority received an invalid Atlas camera world matrix.")
    position = np.asarray(extr.get("camera_position", world[:3, 3]), dtype=np.float64).reshape(3)
    world2 = world.copy()
    world2[:3, 3] *= factor
    position2 = position * factor
    try:
        view2 = np.linalg.inv(world2)
    except np.linalg.LinAlgError as exc:
        raise RuntimeError("Known Height Scale Authority could not invert scaled camera matrix") from exc
    extr["camera_position"] = position2.tolist()
    extr["camera_world_matrix"] = world2.tolist()
    extr["camera_view_matrix"] = view2.tolist()
    camera["extrinsics"] = extr

    native = copy.deepcopy(dict(camera.get("native") or {}))
    debug = copy.deepcopy(dict(native.get("debug_metadata") or {}))
    for key in ("camera_height_candidate", "camera_height_measured"):
        if key in debug:
            try:
                debug[key] = float(debug[key]) * factor
            except Exception:
                pass
    debug["scale_source"] = "manual_known_height"
    debug["manual_known_height_m"] = float(known)
    debug["manual_scale_factor"] = factor
    debug["manual_scale_target_label"] = target["target_label"]
    native["debug_metadata"] = debug
    camera["native"] = native

    canonical = dict(canonical0)
    xyz0 = np.asarray(canonical0.get("xyz"), dtype=np.float32)
    if xyz0.ndim != 2 or xyz0.shape[1] != 3 or not np.isfinite(xyz0).all():
        raise RuntimeError("Known Height Scale Authority received invalid canonical XYZ.")
    canonical["xyz"] = (xyz0.astype(np.float64) * factor).astype(np.float32)
    if canonical0.get("camera_depth") is not None:
        canonical["camera_depth"] = (np.asarray(canonical0["camera_depth"], dtype=np.float64) * factor).astype(np.float32)
    refinement = copy.deepcopy(dict(canonical0.get("refinement") or {}))
    refinement["manual_known_height_scale_authority"] = {
        "applied": True,
        "known_height_m": float(known),
        "precalibration_estimated_height_m": float(pre_h),
        "manual_scale_factor": factor,
        "target_label": target["target_label"],
        "base_pixel": target["base_pixel"],
        "top_pixel": target["top_pixel"],
        "authority": "artist_known_physical_measurement",
    }
    canonical["refinement"] = refinement

    scene = dict(scene_bundle)
    scene["camera"] = camera
    runtime = dict(runtime0)
    runtime["primary_canonical"] = canonical
    scene["_runtime"] = runtime
    scene["geometry_health"] = geometry_health(canonical["xyz"])
    scene["integration_consistency"] = reprojection_report(camera, canonical)

    old_scale = dict(scene_bundle.get("scale_convention") or {})
    prior_factor = float(old_scale.get("scale_factor") or 1.0)
    scene["scale_convention"] = {
        "units": "meters",
        "meters_per_unit": 1.0,
        "scale_applied": True,
        "scale_factor": prior_factor * factor,
        "prior_scale_factor": prior_factor,
        "manual_scale_factor": factor,
        "scale_authority": "Manual known physical height (artist-entered, explicit authority)",
        "manual_reference": {
            "target_label": target["target_label"],
            "known_height_m": float(known),
            "base_pixel": target["base_pixel"],
            "top_pixel": target["top_pixel"],
        },
        "automatic_metric_evidence_role": "diagnostic_only_when_manual_authority_active",
    }
    auth = dict(scene.get("primary_authority") or {})
    auth["scale"] = "Manual known physical height"
    scene["primary_authority"] = auth
    contrib = list(scene.get("synergy_contributors") or [])
    contrib.append({
        "component": "Artist Known Physical Measurement",
        "role": "metric scale authority",
        "detail": f"{target['target_label']} = {known:.6g} m; global similarity scale × {factor:.9g}",
    })
    scene["synergy_contributors"] = contrib

    # The exact authority check is algebraic: the pre-calibration reference span
    # is uniformly scaled by `factor`, so its physical height is known exactly.
    exact_reference_height = float(pre_h * factor)
    exact_rel_err = abs(exact_reference_height - known) / known
    if exact_rel_err > 1.0e-9:
        raise RuntimeError(
            "Known Height Scale Authority failed exact similarity verification: "
            f"known={known:.9g} m, scaled_reference={exact_reference_height:.9g} m"
        )
    # Re-running ground fitting after a large global scale shift can select a
    # slightly different candidate band because its robust thresholds are in
    # metric units. Keep that as diagnostics only; it must not overrule the
    # artist-entered physical measurement.
    try:
        post = atlas_architectural_metrology(scene, base_px, top_px)
    except Exception as exc:
        post = {"status": "POST_SCALE_DIAGNOSTIC_FAILED", "error": str(exc)}
    post_h = _finite_positive(((post.get("height") or {}).get("estimated_height_m")))
    rel_err = abs(post_h - known) / known if post_h is not None else None
    if not bool(scene["integration_consistency"].get("pass")):
        raise RuntimeError("Known Height Scale Authority changed camera/geometry projection consistency; refusing calibrated scene.")

    base_report.update({
        "status": "APPLIED",
        "reason": "artist_known_height_is_scale_authority",
        "moves_geometry": True,
        "moves_camera_translation": True,
        "changes_camera_rotation": False,
        "changes_camera_intrinsics": False,
        "preserves_projection": True,
        "official_primarymesh_scale_authority": True,
        "known_height_m": float(known),
        "precalibration_estimated_height_m": float(pre_h),
        "exact_scaled_reference_height_m": exact_reference_height,
        "postcalibration_estimated_height_m": float(post_h) if post_h is not None else None,
        "postcalibration_relative_error": float(rel_err) if rel_err is not None else None,
        "post_metrology_warning": bool(rel_err is None or rel_err > 0.01),
        "manual_scale_factor": factor,
        "prior_scene_scale_factor": prior_factor,
        "final_scene_scale_factor": prior_factor * factor,
        "camera_position_before_m": position.tolist(),
        "camera_position_after_m": position2.tolist(),
        "automatic_metric_evidence_role": "diagnostic_only; may disagree but cannot override explicit manual authority",
        "large_scale_shift_warning": bool(factor < 0.5 or factor > 2.0),
        "precalibration_atlas_metrology": pre,
        "postcalibration_atlas_metrology": post,
    })
    return scene, base_report
